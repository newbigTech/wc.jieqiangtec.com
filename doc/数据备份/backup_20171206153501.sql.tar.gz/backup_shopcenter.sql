-- MySQL dump 10.13  Distrib 5.1.73, for pc-linux-gnu (i686)
--
-- Host: localhost    Database: shopcenter
-- ------------------------------------------------------
-- Server version	5.1.63

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `shopcenter_action_log`
--

DROP TABLE IF EXISTS `shopcenter_action_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_action_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `comment` text,
  `add_time` int(11) DEFAULT NULL,
  `user_real_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tid` (`target_id`),
  KEY `p10` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=545283 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_action_log`
--

LOCK TABLES `shopcenter_action_log` WRITE;
/*!40000 ALTER TABLE `shopcenter_action_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_action_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_brand`
--

DROP TABLE IF EXISTS `shopcenter_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT NULL,
  `logo` tinyint(4) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_brand`
--

LOCK TABLES `shopcenter_brand` WRITE;
/*!40000 ALTER TABLE `shopcenter_brand` DISABLE KEYS */;
INSERT INTO `shopcenter_brand` VALUES (54,'小米note3',1507685869,0,'');
/*!40000 ALTER TABLE `shopcenter_brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_buy_attribute`
--

DROP TABLE IF EXISTS `shopcenter_buy_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_buy_attribute` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `tid` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `append_price` decimal(10,2) DEFAULT NULL,
  `length` tinyint(4) DEFAULT NULL,
  `hidden` tinyint(4) DEFAULT '0',
  `required` tinyint(4) DEFAULT '0',
  `switch` varchar(255) DEFAULT '0',
  `switch_title` varchar(255) DEFAULT NULL,
  `disable` tinyint(4) DEFAULT '0',
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1435 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_buy_attribute`
--

LOCK TABLES `shopcenter_buy_attribute` WRITE;
/*!40000 ALTER TABLE `shopcenter_buy_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_buy_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_buy_attribute_template`
--

DROP TABLE IF EXISTS `shopcenter_buy_attribute_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_buy_attribute_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_buy_attribute_template`
--

LOCK TABLES `shopcenter_buy_attribute_template` WRITE;
/*!40000 ALTER TABLE `shopcenter_buy_attribute_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_buy_attribute_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_buy_attribute_value`
--

DROP TABLE IF EXISTS `shopcenter_buy_attribute_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_buy_attribute_value` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `about_disabled` varchar(255) DEFAULT NULL,
  `append_price` decimal(10,2) DEFAULT NULL,
  `hidden` tinyint(4) DEFAULT '0',
  `length` tinyint(4) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `required` tinyint(4) DEFAULT '0',
  `service` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6117 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_buy_attribute_value`
--

LOCK TABLES `shopcenter_buy_attribute_value` WRITE;
/*!40000 ALTER TABLE `shopcenter_buy_attribute_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_buy_attribute_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_category`
--

DROP TABLE IF EXISTS `shopcenter_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `sort_name` varchar(255) DEFAULT NULL,
  `product_num` int(11) DEFAULT NULL,
  `add_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `attribute_type_id` int(11) DEFAULT NULL,
  `attribute_list` varchar(255) DEFAULT NULL,
  `parent_id_list` varchar(255) DEFAULT NULL,
  `hidden` tinyint(4) DEFAULT '0',
  `product_total` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parent` (`pid`),
  KEY `p10` (`hidden`)
) ENGINE=MyISAM AUTO_INCREMENT=2077 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_category`
--

LOCK TABLES `shopcenter_category` WRITE;
/*!40000 ALTER TABLE `shopcenter_category` DISABLE KEYS */;
INSERT INTO `shopcenter_category` VALUES (2076,0,'手机','',0,1507685888,1507685888,0,0,'','',0,NULL);
/*!40000 ALTER TABLE `shopcenter_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_category_brand`
--

DROP TABLE IF EXISTS `shopcenter_category_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_category_brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) DEFAULT NULL,
  `bid` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_category_brand`
--

LOCK TABLES `shopcenter_category_brand` WRITE;
/*!40000 ALTER TABLE `shopcenter_category_brand` DISABLE KEYS */;
INSERT INTO `shopcenter_category_brand` VALUES (46,2076,54,0);
/*!40000 ALTER TABLE `shopcenter_category_brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_category_extra`
--

DROP TABLE IF EXISTS `shopcenter_category_extra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_category_extra` (
  `cid` int(11) NOT NULL,
  `content_block_id` int(11) DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `value` text,
  UNIQUE KEY `id` (`cid`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_category_extra`
--

LOCK TABLES `shopcenter_category_extra` WRITE;
/*!40000 ALTER TABLE `shopcenter_category_extra` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_category_extra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_channel`
--

DROP TABLE IF EXISTS `shopcenter_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `add_time` int(11) DEFAULT NULL,
  `px` int(11) DEFAULT NULL,
  `mini_name` varchar(11) DEFAULT NULL,
  `print_name` varchar(11) DEFAULT NULL,
  `C1` decimal(10,4) DEFAULT NULL,
  `C3` decimal(10,4) DEFAULT NULL,
  `C6` decimal(10,4) DEFAULT NULL,
  `C12` decimal(10,4) DEFAULT NULL,
  `C15` decimal(10,4) DEFAULT NULL,
  `C18` decimal(10,4) DEFAULT NULL,
  `C24` decimal(10,4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `p10` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=96 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_channel`
--

LOCK TABLES `shopcenter_channel` WRITE;
/*!40000 ALTER TABLE `shopcenter_channel` DISABLE KEYS */;
INSERT INTO `shopcenter_channel` VALUES (5,'光大银行 → 商城零售',NULL,NULL,999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(46,'建设银行 → 善融商城',NULL,NULL,999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(47,'光大银行 → 商城团购',NULL,NULL,999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(48,'通联支付 → 常规销售',NULL,NULL,999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(50,'北京银行 → DM单销售',NULL,NULL,999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(51,'北京银行 → 短信销售',NULL,NULL,999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(52,'其他渠道 → 常规销售',NULL,NULL,999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(53,'其他渠道 → 安卓平台短信',NULL,NULL,999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(54,'交通银行 → aasdas',NULL,NULL,999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(55,'中信银行 → 商城团购',1,NULL,119,'中信银行','中信银行',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(56,'中信银行 → 商城零售',NULL,NULL,999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(57,'平安银行 → 商城零售',NULL,NULL,999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(58,'平安银行 → 商城零售',18,NULL,106,'平安','平安银行',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(59,'平安银行 → 商城零售',NULL,NULL,999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(60,'建设银行 → 龙卡商城',10,NULL,101,'建行','建行分期',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(61,'交通银行 → 分期零售',11,NULL,104,'交行','交行分期',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(62,'广发银行 → 分期零售',12,NULL,103,'广发','广发分期',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(63,'江苏银行 → 积分项目',9,NULL,999,'江苏银行','江苏积分',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(64,'苏酒集团 → 礼品采购',7,NULL,999,'苏酒集团','苏酒集团',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65,'金色世纪 → 积分商城',7,NULL,999,'金色世纪 ','金色世纪 ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(66,'铁建永泰 → 积分礼品',7,NULL,999,'铁建永泰 ','铁建永泰 ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(67,'中信总行 → 积分项目',1,NULL,999,'中信总行','中信总行',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(68,'建设银行 → 善荣商城',22,NULL,102,'建行善荣','建行善荣',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(69,'银联数据 → 分期零售',2,NULL,106,'银联数据 ','银联数据 ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(70,'工商银行 → 融E购',13,NULL,105,'融E购','融E购',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(71,'通联支付 → ',14,NULL,107,'通联支付 ','通联支付 ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(72,'民生银行',4,NULL,108,'民生银行','民生银行',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(73,'易礼商城',15,NULL,209,'易礼网','易礼网',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(74,'北京农商行→分期零售',16,NULL,201,'北京农商行','北京农商行',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(75,'北京银行',6,NULL,202,'北京银行','北京银行',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(76,'乐益通',17,NULL,999,'乐益通','乐益通',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(77,'邮乐网',19,NULL,112,'邮乐网','邮乐网',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(78,'邮储分期',20,NULL,108,'邮储分期','邮储分期',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(79,'三维度',21,NULL,999,'三维度','三维度',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(80,'惠家有',23,NULL,202,'惠家有','惠家有',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(81,'E中信',24,NULL,203,'E中信','E中信',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(82,'北京银行 → 银联积分',25,NULL,203,'北京银行积分','北京银行积分',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(83,'资和信',26,NULL,205,'资和信','资和信',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(84,'工行集采',27,NULL,205,'工行集采','工行集采',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(85,'内购网',28,NULL,206,'内购网','内购网',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(86,'民生员工福利',29,NULL,207,'民生员工福利','民生员工福利',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(87,'中行聪明购',30,NULL,208,'中行聪明购','中行聪明购',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(88,'招行每日特惠',31,NULL,209,'招行每日特惠','招行每日特惠',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(89,'民生生活圈',32,NULL,210,'民生生活圈','民生生活圈',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(90,'光大APP',33,NULL,211,'光大APP','光大APP',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(91,'壹缘通',34,NULL,212,'壹缘通','壹缘通',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(92,'广发福利平台',35,NULL,212,'广发福利平台','广发福利平台',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(93,'峰麟博朗集采',36,NULL,213,'峰麟博朗集采','峰麟博朗集采',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(94,'珍品网',37,NULL,215,'珍品网','珍品网',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(95,'福卡商城',38,NULL,216,'福卡商城','福卡商城',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `shopcenter_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_channel_parent`
--

DROP TABLE IF EXISTS `shopcenter_channel_parent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_channel_parent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `display` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `p10` (`display`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_channel_parent`
--

LOCK TABLES `shopcenter_channel_parent` WRITE;
/*!40000 ALTER TABLE `shopcenter_channel_parent` DISABLE KEYS */;
INSERT INTO `shopcenter_channel_parent` VALUES (1,'中信银行',1),(2,'银联数据',1),(3,'光大银行',0),(4,'民生银行',1),(5,'华夏银行',0),(6,'北京银行',0),(7,'其它渠道',0),(8,'中国银行',0),(9,'江苏银行',1),(10,'建行龙卡',1),(11,'交通银行',1),(12,'广发银行',1),(13,'工商银行',1),(14,'通联支付',1),(15,'易礼商城',1),(16,'北京农商行',1),(17,'乐益通',1),(18,'平安银行',1),(19,'邮乐网',1),(20,'邮储分期',1),(21,'三维度',1),(22,'建行善荣',1),(23,'惠家有',1),(24,'E中信',1),(25,'北京银行积分',1),(26,'资和信',1),(27,'工行集采',1),(28,'内购网',1),(29,'民生员工福利',1),(30,'中行聪明购',1),(31,'招行每日特惠',1),(32,'民生生活圈',1),(33,'光大APP',1),(34,'壹缘通',1),(35,'广发福利平台',1),(36,'峰麟博朗集采',1),(37,'珍品网',1),(38,'福卡商城',1);
/*!40000 ALTER TABLE `shopcenter_channel_parent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_delivery`
--

DROP TABLE IF EXISTS `shopcenter_delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `comment` text,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT NULL,
  `total_quantity` int(11) DEFAULT '0',
  `total_breed` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '0',
  `status` tinyint(4) DEFAULT NULL,
  `logistics_company` varchar(255) DEFAULT NULL,
  `logistics_sn` varchar(255) DEFAULT NULL,
  `express_id` varchar(255) DEFAULT NULL,
  `order_ids` text,
  `channel_id` int(4) DEFAULT '0',
  `channel_name` varchar(255) DEFAULT NULL,
  `is_logistics` int(11) DEFAULT '0',
  `is_logistics_time` int(11) DEFAULT NULL,
  `is_print` int(11) DEFAULT '0',
  `is_print_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `p10` (`warehouse_id`),
  KEY `p11` (`type`),
  KEY `p12` (`is_print`)
) ENGINE=MyISAM AUTO_INCREMENT=16949 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_delivery`
--

LOCK TABLES `shopcenter_delivery` WRITE;
/*!40000 ALTER TABLE `shopcenter_delivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_invoice`
--

DROP TABLE IF EXISTS `shopcenter_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sn` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `purchase_id` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `p10` (`supplier_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1479 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_invoice`
--

LOCK TABLES `shopcenter_invoice` WRITE;
/*!40000 ALTER TABLE `shopcenter_invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_order`
--

DROP TABLE IF EXISTS `shopcenter_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_shipping_cost` decimal(10,2) DEFAULT '0.00',
  `channel_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `target_id` varchar(255) DEFAULT NULL,
  `total_quantity` int(11) DEFAULT '0',
  `total_breed` int(11) DEFAULT '0',
  `total_money` decimal(10,2) DEFAULT NULL,
  `add_time` int(11) DEFAULT NULL,
  `lock_status` tinyint(4) DEFAULT '0',
  `delivery_type` tinyint(4) DEFAULT '0',
  `delivery_status` tinyint(4) DEFAULT '0',
  `delivery_ready_status` tinyint(4) DEFAULT '0',
  `delivery_comment` text,
  `delivery_time` int(11) DEFAULT NULL,
  `order_time` int(11) DEFAULT NULL,
  `purchase_status` tinyint(4) DEFAULT '0',
  `print_status` tinyint(4) DEFAULT '0',
  `call_status` tinyint(4) DEFAULT '0',
  `call_timer` tinyint(4) DEFAULT '0',
  `call_time` int(11) DEFAULT NULL,
  `collate_status` tinyint(4) DEFAULT '0',
  `sign_status` tinyint(4) DEFAULT '0',
  `sign_time` int(11) DEFAULT '0',
  `sing_name` varchar(255) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT '0',
  `import_type` tinyint(4) DEFAULT NULL,
  `payment_type` tinyint(255) DEFAULT '0',
  `delivery_first` tinyint(4) DEFAULT '0',
  `purchase_check` tinyint(4) DEFAULT '0',
  `purchase_check_time` int(11) DEFAULT NULL,
  `purchase_real_name` varchar(255) DEFAULT NULL,
  `service_check` tinyint(4) DEFAULT '0',
  `service_check_time` int(11) DEFAULT NULL,
  `service_real_name` varchar(255) DEFAULT NULL,
  `logistics_company` varchar(255) DEFAULT NULL,
  `logistics_sn` varchar(255) DEFAULT NULL,
  `logistics_time` int(11) DEFAULT NULL,
  `finance_recieve` tinyint(4) DEFAULT '0',
  `finance_recieve_time` int(11) DEFAULT NULL,
  `order_data` text,
  `order_sell_type` tinyint(4) DEFAULT NULL,
  `order_customer_name` varchar(255) DEFAULT NULL,
  `order_customer_card` varchar(255) DEFAULT NULL,
  `order_customer_card_length` varchar(255) DEFAULT NULL,
  `order_customer_phone` varchar(255) DEFAULT NULL,
  `order_customer_mobile` varchar(255) DEFAULT NULL,
  `order_customer_address` varchar(500) DEFAULT NULL,
  `order_customer_zip` varchar(255) DEFAULT NULL,
  `order_comment` text,
  `order_shipping_name` varchar(255) DEFAULT NULL,
  `order_shipping_phone` varchar(255) DEFAULT NULL,
  `order_shipping_mobile` varchar(255) DEFAULT NULL,
  `order_shipping_card` varchar(255) DEFAULT NULL,
  `order_shipping_zip` varchar(255) DEFAULT NULL,
  `order_shipping_address` varchar(500) DEFAULT NULL,
  `order_shipping_barcode` varchar(255) DEFAULT NULL,
  `order_points` varchar(255) DEFAULT NULL,
  `order_add_name` varchar(255) DEFAULT NULL,
  `order_invoice` tinyint(4) DEFAULT NULL,
  `order_invoice_status` tinyint(4) DEFAULT '0',
  `order_invoice_time` int(11) DEFAULT NULL,
  `order_invoice_header` varchar(255) DEFAULT NULL,
  `order_invoice_number` varchar(255) DEFAULT NULL,
  `total_pay_num` int(11) DEFAULT NULL,
  `total_pay_money` decimal(10,2) DEFAULT NULL,
  `order_instalment_times` tinyint(4) DEFAULT NULL,
  `order_add_name_id` int(11) DEFAULT NULL,
  `order_help_cost` decimal(11,2) DEFAULT '0.00',
  `total_pay_money_one` decimal(11,2) DEFAULT '0.00',
  `order_shipping_bj` decimal(11,2) DEFAULT '0.00',
  `order_shipping_pssj` varchar(255) DEFAULT NULL,
  `order_shipping_xh` varchar(255) DEFAULT NULL,
  `order_sj_status` int(4) DEFAULT '0',
  `order_sj` int(11) DEFAULT '0',
  `order_psyq` varchar(255) DEFAULT NULL,
  `order_invoice_cost` decimal(10,2) DEFAULT '0.00',
  `order_invoice_type` int(4) DEFAULT '0',
  `order_invoice_product` varchar(255) DEFAULT NULL,
  `lock_call` int(1) DEFAULT '0',
  `lock_call_time` int(11) DEFAULT NULL,
  `lock_call_user_id` int(11) DEFAULT '0',
  `lock_call_user_name` varchar(255) DEFAULT NULL,
  `service_begin` int(11) DEFAULT NULL,
  `service_end` int(11) DEFAULT NULL,
  `order_service` int(1) DEFAULT '0',
  `logistics_status` int(1) DEFAULT '0',
  `temp_key` int(1) DEFAULT '1',
  `ppIDS` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uni_channel_target` (`channel_id`,`target_id`),
  KEY `120` (`order_service`,`service_begin`) USING BTREE,
  KEY `order_shipping_cost` (`order_shipping_cost`),
  KEY `order_shipping_cost_2` (`order_shipping_cost`),
  KEY `channel_id` (`channel_id`),
  KEY `110` (`purchase_check`),
  KEY `111` (`service_check`) USING BTREE,
  KEY `p10` (`status`,`service_check`,`order_time`),
  KEY `m10` (`target_id`)
) ENGINE=MyISAM AUTO_INCREMENT=251138 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_order`
--

LOCK TABLES `shopcenter_order` WRITE;
/*!40000 ALTER TABLE `shopcenter_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_order_product`
--

DROP TABLE IF EXISTS `shopcenter_order_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_order_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_id` varchar(255) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `coupon_price` decimal(10,2) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `sku_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `instalment_price` decimal(10,2) DEFAULT NULL,
  `payout_rate` decimal(10,4) DEFAULT NULL,
  `comment` text,
  `purchase_quantity` int(11) DEFAULT '0',
  `into_quantity` int(11) DEFAULT '0',
  `lock_quantity` int(11) DEFAULT '0',
  `delivery_quantity` int(11) DEFAULT '0',
  `import_data` text,
  `add_time` int(11) DEFAULT NULL,
  `stock_price` decimal(10,2) DEFAULT NULL,
  `stock_money` decimal(10,2) DEFAULT NULL,
  `manager_user_id` int(11) DEFAULT NULL,
  `manager_user_name` varchar(255) DEFAULT NULL,
  `manager_user_real_name` varchar(0) DEFAULT NULL,
  `manager_edit_user_id` int(11) DEFAULT '0',
  `manager_edit_user_name` varchar(255) DEFAULT NULL,
  `manager_edit_time` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT '0',
  `extra_name` varchar(255) DEFAULT NULL,
  `sale_price` decimal(10,2) DEFAULT NULL,
  `price_error` varchar(255) DEFAULT NULL,
  `total_pay_money_one` decimal(11,2) DEFAULT '0.00',
  `buy_type` varchar(255) DEFAULT NULL,
  `order_invoice_cost` decimal(10,2) DEFAULT '0.00',
  `order_shipping_cost` decimal(10,2) DEFAULT '0.00',
  `help_cost` decimal(10,2) DEFAULT '0.00',
  `is_up` int(1) DEFAULT '0',
  `is_upp` int(1) DEFAULT '0',
  `upp_money` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `p12` (`supplier_id`),
  KEY `p1` (`order_id`) USING BTREE,
  KEY `p11` (`supplier_id`,`quantity`,`lock_quantity`,`purchase_quantity`) USING BTREE,
  KEY `p13` (`sku_id`),
  KEY `p15` (`is_upp`,`purchase_quantity`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=261971 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_order_product`
--

LOCK TABLES `shopcenter_order_product` WRITE;
/*!40000 ALTER TABLE `shopcenter_order_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_order_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_pay`
--

DROP TABLE IF EXISTS `shopcenter_pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) DEFAULT NULL,
  `add_time` int(11) DEFAULT NULL,
  `all_money` decimal(11,2) DEFAULT '0.00',
  `supplier_name` varchar(255) DEFAULT NULL,
  `supplier_account_bank` varchar(255) DEFAULT NULL,
  `supplier_account_number` varchar(255) DEFAULT NULL,
  `purchase_id` text,
  `user_id` int(11) DEFAULT '0',
  `user_name` varchar(255) DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  `pay_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `p10` (`status`),
  KEY `p11` (`supplier_id`,`status`)
) ENGINE=MyISAM AUTO_INCREMENT=1139 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_pay`
--

LOCK TABLES `shopcenter_pay` WRITE;
/*!40000 ALTER TABLE `shopcenter_pay` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_pay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_product`
--

DROP TABLE IF EXISTS `shopcenter_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `supplier_now` int(11) DEFAULT '0',
  `summary` text,
  `price` decimal(10,2) DEFAULT NULL,
  `market_price` decimal(10,2) DEFAULT NULL,
  `cost_price` decimal(10,2) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `image_list` tinyint(4) DEFAULT NULL,
  `add_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `supplier_id` varchar(255) DEFAULT NULL,
  `weight` decimal(10,4) DEFAULT NULL,
  `buy_attribute_template_id` int(11) DEFAULT '0',
  `import_pid` varchar(255) DEFAULT NULL,
  `import_category` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_real_name` varchar(255) DEFAULT NULL,
  `manager_user_id` int(11) DEFAULT NULL,
  `manager_user_name` varchar(255) DEFAULT NULL,
  `manager_user_real_name` varchar(255) DEFAULT NULL,
  `board` tinyint(4) DEFAULT '0',
  `scope` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uni_name` (`name`),
  KEY `import_pid_idx` (`import_pid`),
  KEY `p10` (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=11630 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_product`
--

LOCK TABLES `shopcenter_product` WRITE;
/*!40000 ALTER TABLE `shopcenter_product` DISABLE KEYS */;
INSERT INTO `shopcenter_product` VALUES (11625,2076,'小米note3',408,'test',NULL,'2000.00','1500.00',54,0,1507685953,1507685969,'','0.0000',0,NULL,NULL,162,'admin','admin',0,'','',1,NULL),(11626,2076,'tt',408,'sdf',NULL,'1000.00','100.00',54,0,1511325673,1511325673,'','0.0000',-1,NULL,NULL,162,'admin','admin',0,'','',1,NULL),(11627,2076,'433434',408,'',NULL,'1111.00','111.00',0,0,1511325733,1511325733,'','111.0000',-1,NULL,NULL,162,'admin','admin',0,'','',1,NULL),(11628,2076,'测试商品',408,'测试商品\n测试商品\n测试商品',NULL,'999.00','888.00',54,0,1511363396,1511363396,'','0.0000',-1,NULL,NULL,162,'admin','admin',0,'','',2,NULL),(11629,2076,'红米2',408,'红米红米红米红米红米红米红米',NULL,'1999.00','1888.00',54,0,1511363639,1511363753,'','0.0000',0,NULL,NULL,162,'admin','admin',0,'','',1,NULL);
/*!40000 ALTER TABLE `shopcenter_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_product_collate`
--

DROP TABLE IF EXISTS `shopcenter_product_collate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_product_collate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel_id` int(11) DEFAULT NULL,
  `target_id` varchar(255) DEFAULT NULL,
  `target_id2` varchar(255) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `sku_id` int(11) DEFAULT NULL,
  `gift_sku` varchar(255) DEFAULT NULL,
  `gift_sku_id` int(11) DEFAULT NULL,
  `gift_sku2` varchar(255) DEFAULT NULL,
  `gift_sku_id2` int(11) DEFAULT NULL,
  `gift_sku3` varchar(255) DEFAULT NULL,
  `gift_sku_id3` int(11) DEFAULT NULL,
  `gift_sku4` varchar(255) DEFAULT NULL,
  `gift_sku_id4` int(11) DEFAULT NULL,
  `gift_sku5` varchar(255) DEFAULT NULL,
  `gift_sku_id5` int(11) DEFAULT NULL,
  `add_time` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment` text,
  `import_pid` varchar(255) DEFAULT NULL,
  `import_name` varchar(255) DEFAULT NULL,
  `bank_link` varchar(255) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `upok` int(1) DEFAULT '2',
  `bank_key` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16879 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_product_collate`
--

LOCK TABLES `shopcenter_product_collate` WRITE;
/*!40000 ALTER TABLE `shopcenter_product_collate` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_product_collate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_product_collate_price`
--

DROP TABLE IF EXISTS `shopcenter_product_collate_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_product_collate_price` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collate_id` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `instalment_times` tinyint(4) DEFAULT NULL,
  `instalment_price` decimal(10,2) DEFAULT NULL,
  `payout_rate` decimal(10,4) DEFAULT NULL,
  `invoice` decimal(10,4) DEFAULT NULL,
  `comment` varchar(500) DEFAULT NULL,
  `add_time` int(11) DEFAULT NULL,
  `import_pid` varchar(255) DEFAULT NULL,
  `xiaofw` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `p10` (`collate_id`,`instalment_times`)
) ENGINE=MyISAM AUTO_INCREMENT=113989 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_product_collate_price`
--

LOCK TABLES `shopcenter_product_collate_price` WRITE;
/*!40000 ALTER TABLE `shopcenter_product_collate_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_product_collate_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_product_sku`
--

DROP TABLE IF EXISTS `shopcenter_product_sku`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_product_sku` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `hash_key` varchar(255) DEFAULT NULL,
  `is_base` tinyint(4) DEFAULT '0',
  `content` text,
  `add_time` int(11) DEFAULT NULL,
  `erp_sku` varchar(255) DEFAULT NULL,
  `dl` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `hash_key` (`hash_key`)
) ENGINE=MyISAM AUTO_INCREMENT=15095 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_product_sku`
--

LOCK TABLES `shopcenter_product_sku` WRITE;
/*!40000 ALTER TABLE `shopcenter_product_sku` DISABLE KEYS */;
INSERT INTO `shopcenter_product_sku` VALUES (15090,11625,'11625_d41d8cd98f00b204e9800998ecf8427e',1,'',0,NULL,0),(15091,11626,'11626_d41d8cd98f00b204e9800998ecf8427e',1,'',0,NULL,0),(15092,11627,'11627_d41d8cd98f00b204e9800998ecf8427e',1,'',0,NULL,0),(15093,11628,'11628_d41d8cd98f00b204e9800998ecf8427e',1,'',0,NULL,0),(15094,11629,'11629_d41d8cd98f00b204e9800998ecf8427e',1,'',0,NULL,0);
/*!40000 ALTER TABLE `shopcenter_product_sku` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_product_submit`
--

DROP TABLE IF EXISTS `shopcenter_product_submit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_product_submit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_id` varchar(255) DEFAULT NULL,
  `target_category_id` varchar(255) DEFAULT NULL,
  `supply_type` tinyint(4) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `summary` varchar(255) DEFAULT NULL,
  `description` text,
  `price` decimal(11,2) DEFAULT NULL,
  `supply_price` decimal(11,2) DEFAULT NULL,
  `payout_rate` decimal(11,0) DEFAULT NULL,
  `submit_issue` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `add_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_product_submit`
--

LOCK TABLES `shopcenter_product_submit` WRITE;
/*!40000 ALTER TABLE `shopcenter_product_submit` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_product_submit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_purchase`
--

DROP TABLE IF EXISTS `shopcenter_purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_purchase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) DEFAULT NULL,
  `ready_pay` int(1) DEFAULT '0',
  `type` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `invoice_type` tinyint(4) DEFAULT NULL,
  `workflow_status` tinyint(4) DEFAULT '-1',
  `receive_status` tinyint(4) DEFAULT NULL,
  `into_status` tinyint(4) DEFAULT NULL,
  `pay_status` tinyint(4) DEFAULT '0',
  `pay_time` int(11) DEFAULT '0',
  `pay_user_id` int(11) DEFAULT '0',
  `pay_user_name` varchar(255) DEFAULT NULL,
  `pay_invoice` tinyint(4) DEFAULT '0',
  `pay_invoice_time` int(11) DEFAULT '0',
  `pay_invoice_order` varchar(255) DEFAULT NULL,
  `pay_invoice_user_id` int(11) DEFAULT '0',
  `pay_invoice_user_name` varchar(255) DEFAULT NULL,
  `product_type` tinyint(4) DEFAULT NULL,
  `payment_type` tinyint(4) DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `comment` text,
  `add_time` int(11) DEFAULT NULL,
  `plan_arrive_time` int(11) DEFAULT NULL,
  `total_money` decimal(11,2) DEFAULT NULL,
  `total_quantity` int(11) DEFAULT NULL,
  `total_breed` int(11) DEFAULT NULL,
  `sign_pro_mg` int(11) DEFAULT NULL,
  `sign_pro_mg_name` varchar(255) DEFAULT NULL,
  `sign_pro_mg_time` int(11) DEFAULT NULL,
  `sign_ope_mj` int(11) DEFAULT NULL,
  `sign_ope_mj_name` varchar(255) DEFAULT NULL,
  `sign_ope_mj_time` int(11) DEFAULT NULL,
  `sign_ope_vc` int(11) DEFAULT NULL,
  `sign_ope_vc_name` varchar(0) DEFAULT NULL,
  `sign_ope_vc_time` int(11) DEFAULT NULL,
  `sign_top_jl` int(11) DEFAULT '0',
  `sign_top_zj` int(11) DEFAULT '0',
  `user_group` int(11) DEFAULT '0',
  `close_user` int(11) DEFAULT '0',
  `close_name` varchar(255) DEFAULT NULL,
  `close_group` int(11) DEFAULT '0',
  `close_comment` text,
  `pay_lock_time` int(11) DEFAULT '0',
  `pay_lock_user_id` int(11) DEFAULT '0',
  `pay_lock_user_name` varchar(255) DEFAULT NULL,
  `is_edit` int(11) DEFAULT '0',
  `total_cost` decimal(11,2) DEFAULT '0.00',
  `all_money` decimal(11,2) DEFAULT '0.00',
  `invoice_now` int(4) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `p10` (`status`,`warehouse_id`),
  KEY `p11` (`pay_status`,`ready_pay`) USING BTREE,
  KEY `p12` (`supplier_id`),
  KEY `p13` (`ready_pay`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=17140 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_purchase`
--

LOCK TABLES `shopcenter_purchase` WRITE;
/*!40000 ALTER TABLE `shopcenter_purchase` DISABLE KEYS */;
INSERT INTO `shopcenter_purchase` VALUES (17139,408,0,1,3,1,5,1,1,-1,0,0,NULL,0,0,NULL,0,NULL,0,1,162,'admin',6,'',1507686401,1507686401,'1500.00',1,1,162,'admin',1507686401,NULL,NULL,NULL,NULL,NULL,NULL,0,0,38,0,NULL,0,NULL,1507686401,66,'a',0,'0.00','1500.00',0);
/*!40000 ALTER TABLE `shopcenter_purchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_purchase_lock`
--

DROP TABLE IF EXISTS `shopcenter_purchase_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_purchase_lock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `sku` varchar(11) DEFAULT NULL,
  `sku_id` int(11) DEFAULT NULL,
  `add_time` int(11) DEFAULT NULL,
  `supplierId` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4673 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_purchase_lock`
--

LOCK TABLES `shopcenter_purchase_lock` WRITE;
/*!40000 ALTER TABLE `shopcenter_purchase_lock` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_purchase_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_purchase_product`
--

DROP TABLE IF EXISTS `shopcenter_purchase_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_purchase_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `price` decimal(11,2) DEFAULT NULL,
  `history_price` decimal(11,2) DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `sku_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `receive_quantity` int(11) DEFAULT '0',
  `into_quantity` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT NULL,
  `comment` text,
  `manager_user_id` int(11) DEFAULT NULL,
  `manager_user_name` varchar(255) DEFAULT NULL,
  `manager_user_real_name` varchar(255) DEFAULT NULL,
  `help_cost` decimal(11,2) DEFAULT '0.00',
  `total_money` decimal(11,2) DEFAULT '0.00',
  `total_cost` decimal(11,2) DEFAULT '0.00',
  `all_money` decimal(11,2) DEFAULT NULL,
  `sale_price` decimal(11,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `p10` (`purchase_id`)
) ENGINE=MyISAM AUTO_INCREMENT=52712 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_purchase_product`
--

LOCK TABLES `shopcenter_purchase_product` WRITE;
/*!40000 ALTER TABLE `shopcenter_purchase_product` DISABLE KEYS */;
INSERT INTO `shopcenter_purchase_product` VALUES (52711,17139,11625,'1500.00','0.00','S000015090',15090,1,0,0,1507686401,'',0,'','','0.00','1500.00','0.00','1500.00','0.00');
/*!40000 ALTER TABLE `shopcenter_purchase_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_purchase_relation`
--

DROP TABLE IF EXISTS `shopcenter_purchase_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_purchase_relation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_product_id` int(11) DEFAULT NULL,
  `purchase_product_id` int(11) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT '0',
  `into_quantity` int(11) DEFAULT '0',
  `lock_quantity` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT NULL,
  `sale_price` decimal(11,0) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `p10` (`order_product_id`) USING BTREE,
  KEY `p11` (`order_id`),
  KEY `p12` (`purchase_product_id`),
  KEY `p13` (`purchase_id`)
) ENGINE=MyISAM AUTO_INCREMENT=104768 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_purchase_relation`
--

LOCK TABLES `shopcenter_purchase_relation` WRITE;
/*!40000 ALTER TABLE `shopcenter_purchase_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_purchase_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_receive`
--

DROP TABLE IF EXISTS `shopcenter_receive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_receive` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT '0',
  `purchase_id` int(11) DEFAULT '0',
  `status` tinyint(4) DEFAULT NULL,
  `into_status` tinyint(4) DEFAULT NULL,
  `total_quantity` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `comment` text,
  `add_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1570 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_receive`
--

LOCK TABLES `shopcenter_receive` WRITE;
/*!40000 ALTER TABLE `shopcenter_receive` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_receive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_receive_product`
--

DROP TABLE IF EXISTS `shopcenter_receive_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_receive_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receive_id` int(11) DEFAULT '0',
  `purchase_id` int(11) DEFAULT '0',
  `purchase_product_id` int(11) DEFAULT '0',
  `product_id` int(11) DEFAULT '0',
  `price` decimal(11,2) DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `sku_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `into_quantity` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT NULL,
  `comment` text,
  `place_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2809 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_receive_product`
--

LOCK TABLES `shopcenter_receive_product` WRITE;
/*!40000 ALTER TABLE `shopcenter_receive_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_receive_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_service_log`
--

DROP TABLE IF EXISTS `shopcenter_service_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_service_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `comment` text,
  `add_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `p10` (`target_id`,`action`)
) ENGINE=MyISAM AUTO_INCREMENT=68622 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_service_log`
--

LOCK TABLES `shopcenter_service_log` WRITE;
/*!40000 ALTER TABLE `shopcenter_service_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_service_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_store`
--

DROP TABLE IF EXISTS `shopcenter_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT '0',
  `purchase_id` int(11) DEFAULT NULL,
  `receive_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `total_quantity` int(11) DEFAULT '0',
  `total_breed` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `comment` text,
  `add_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `p10` (`warehouse_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11281 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_store`
--

LOCK TABLES `shopcenter_store` WRITE;
/*!40000 ALTER TABLE `shopcenter_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_supplier`
--

DROP TABLE IF EXISTS `shopcenter_supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_good` int(11) DEFAULT '0',
  `manage_name` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `mini_name` varchar(255) DEFAULT NULL,
  `name_op` varchar(255) DEFAULT NULL,
  `op` varchar(255) DEFAULT NULL,
  `y_product` varchar(255) DEFAULT NULL,
  `scope` varchar(500) DEFAULT NULL,
  `linkman` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `company_address` varchar(255) DEFAULT NULL,
  `company_phone` varchar(20) DEFAULT NULL,
  `company_person` varchar(20) DEFAULT NULL,
  `company_nature` varchar(500) DEFAULT NULL,
  `registered_capital` varchar(50) DEFAULT NULL,
  `tax` varchar(100) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `accountbank` varchar(100) DEFAULT NULL,
  `opennumber` varchar(100) DEFAULT NULL,
  `comment` varchar(500) DEFAULT NULL,
  `add_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `payment_period` decimal(4,0) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `manage_id` int(11) DEFAULT '0',
  `key_mode` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `q1` (`key_mode`),
  KEY `q10` (`op`) USING BTREE,
  KEY `p11` (`manage_id`)
) ENGINE=MyISAM AUTO_INCREMENT=409 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_supplier`
--

LOCK TABLES `shopcenter_supplier` WRITE;
/*!40000 ALTER TABLE `shopcenter_supplier` DISABLE KEYS */;
INSERT INTO `shopcenter_supplier` VALUES (408,0,NULL,'小米',NULL,'XM',NULL,'','m','','','','','','','','','','','','',1507685848,1507685848,NULL,162,0,0);
/*!40000 ALTER TABLE `shopcenter_supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_warehouse`
--

DROP TABLE IF EXISTS `shopcenter_warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_warehouse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_warehouse`
--

LOCK TABLES `shopcenter_warehouse` WRITE;
/*!40000 ALTER TABLE `shopcenter_warehouse` DISABLE KEYS */;
INSERT INTO `shopcenter_warehouse` VALUES (5,'★代发货'),(6,'中心总库'),(7,'ddd'),(8,'dddd');
/*!40000 ALTER TABLE `shopcenter_warehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_warehouse_lock`
--

DROP TABLE IF EXISTS `shopcenter_warehouse_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_warehouse_lock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `warehouse_id` int(11) DEFAULT NULL,
  `place_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT '0',
  `sku_id` int(11) DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `order_product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `type` tinyint(4) DEFAULT '0',
  `add_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=141493 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_warehouse_lock`
--

LOCK TABLES `shopcenter_warehouse_lock` WRITE;
/*!40000 ALTER TABLE `shopcenter_warehouse_lock` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_warehouse_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_warehouse_log`
--

DROP TABLE IF EXISTS `shopcenter_warehouse_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_warehouse_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) DEFAULT NULL,
  `type2` tinyint(4) DEFAULT '0',
  `target_id` int(11) DEFAULT '0',
  `target_id2` int(11) DEFAULT '0',
  `target_id3` int(11) DEFAULT '0',
  `user_name` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `add_time` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `sku_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `place_id` int(11) DEFAULT NULL,
  `comment` text,
  PRIMARY KEY (`id`),
  KEY `p10` (`target_id`) USING BTREE,
  KEY `p11` (`type`),
  KEY `p12` (`warehouse_id`)
) ENGINE=MyISAM AUTO_INCREMENT=196032 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_warehouse_log`
--

LOCK TABLES `shopcenter_warehouse_log` WRITE;
/*!40000 ALTER TABLE `shopcenter_warehouse_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_warehouse_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_warehouse_place`
--

DROP TABLE IF EXISTS `shopcenter_warehouse_place`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_warehouse_place` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `warehouse_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `nick_name` varchar(255) DEFAULT NULL,
  `total_quantity` int(11) DEFAULT NULL,
  `no_delivery` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `p10` (`warehouse_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_warehouse_place`
--

LOCK TABLES `shopcenter_warehouse_place` WRITE;
/*!40000 ALTER TABLE `shopcenter_warehouse_place` DISABLE KEYS */;
INSERT INTO `shopcenter_warehouse_place` VALUES (2,5,'2代发货','2代发货',NULL,0),(4,6,'1中心库房','1中心库房',NULL,0);
/*!40000 ALTER TABLE `shopcenter_warehouse_place` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_warehouse_stock`
--

DROP TABLE IF EXISTS `shopcenter_warehouse_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_warehouse_stock` (
  `sku` varchar(255) NOT NULL DEFAULT '0',
  `sku_id` int(11) NOT NULL DEFAULT '0',
  `quantity` int(11) NOT NULL,
  `lock_quantity` int(11) NOT NULL,
  `place_id` int(11) NOT NULL DEFAULT '0',
  `warehouse_id` int(11) NOT NULL DEFAULT '0',
  `product_id` int(11) DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `no_delivery` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`sku_id`,`place_id`,`warehouse_id`),
  UNIQUE KEY `unique_idx` (`warehouse_id`,`place_id`,`sku_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_warehouse_stock`
--

LOCK TABLES `shopcenter_warehouse_stock` WRITE;
/*!40000 ALTER TABLE `shopcenter_warehouse_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopcenter_warehouse_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopcenter_workflow`
--

DROP TABLE IF EXISTS `shopcenter_workflow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopcenter_workflow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_id` int(11) DEFAULT NULL,
  `flow_name` varchar(255) DEFAULT NULL,
  `flow_status` tinyint(11) DEFAULT NULL,
  `add_time` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `group_id` varchar(11) DEFAULT NULL,
  `add_user_id` int(11) DEFAULT NULL,
  `is_delete` tinyint(4) DEFAULT '0',
  `comment` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29823 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopcenter_workflow`
--

LOCK TABLES `shopcenter_workflow` WRITE;
/*!40000 ALTER TABLE `shopcenter_workflow` DISABLE KEYS */;
INSERT INTO `shopcenter_workflow` VALUES (29821,17139,'Purchase',1,1507686401,0,'13',162,1,NULL),(29822,17139,'Purchase',5,1507686401,0,'0',162,0,NULL);
/*!40000 ALTER TABLE `shopcenter_workflow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_administrator`
--

DROP TABLE IF EXISTS `sys_administrator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_administrator` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `user_real_name` varchar(255) DEFAULT NULL,
  `user_group` varchar(255) DEFAULT NULL,
  `user_add_time` int(11) DEFAULT NULL,
  `user_update_time` int(11) DEFAULT NULL,
  `user_login_time` int(11) DEFAULT NULL,
  `user_login_ip` int(11) DEFAULT NULL,
  `user_product` int(11) DEFAULT '0',
  `user_product_1` int(11) DEFAULT '0',
  `user_department` varchar(255) DEFAULT NULL,
  `user_phone` varchar(255) DEFAULT NULL,
  `user_call` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uni_user_name` (`user_name`),
  UNIQUE KEY `uni_user_real_name` (`user_real_name`),
  KEY `p10` (`user_group`)
) ENGINE=MyISAM AUTO_INCREMENT=165 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_administrator`
--

LOCK TABLES `sys_administrator` WRITE;
/*!40000 ALTER TABLE `sys_administrator` DISABLE KEYS */;
INSERT INTO `sys_administrator` VALUES (68,'xfw','a6db0b01fcca7a4445e875b864728726','肖芳伟','38',1374656233,1489291527,1489291540,-1062731675,0,0,NULL,'6029','agent04'),(162,'admin','7fef6171469e80d32c0559f88b377245','admin','38',1481177550,1481177550,1512392940,1033554677,0,0,NULL,'6029','agent04'),(163,'chenboyu','5e622c4bc2c462789acacb31b4106e24','陈博宇','38',1489103006,1489103006,1489295555,-1062731675,0,0,NULL,NULL,NULL),(164,'liudi','e10adc3949ba59abbe56e057f20f883e','刘迪','38',1489103283,1489103283,1489103283,0,0,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `sys_administrator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_administrator_group`
--

DROP TABLE IF EXISTS `sys_administrator_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_administrator_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `allow` text,
  `add_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_administrator_group`
--

LOCK TABLES `sys_administrator_group` WRITE;
/*!40000 ALTER TABLE `sys_administrator_group` DISABLE KEYS */;
INSERT INTO `sys_administrator_group` VALUES (38,'root','71562636,a21bcebd,1686b567,8007a165,7f99ee0a,969aac72,08e73a9a,993ac5b0,fd3bb766,fd744554,a5024476,35f6d147,706d4108,b4fb7107,571fd9e5,67081634,9565903c,848820d0,7072b8d7,d3d8a453,7b04e630,913638de,602844fc,7e2891a9,c923bf2c,cc539ae9,8205f324,9d61daf2,a2952c18,8adac362,9b720f32,589b09c2,0b9d6664,b464a8fe,66525b1b,802bf884,f5401e28,0b5e1d58,4a63689e,bb22a665,dac7e360,cc6feec7,d1058761,745db64a,a0cbf18e,8d1cbd70,f8397556,4a16dcf7,721686b7,bac25f7b,9d2462c1,85fe7a6d,ec7bc950,f1dcaff7,dbafd81d,efb24eec,92dda490,a75877d5,3020704d,7ff6c54b,75336569,a99d78cf,6efea715,4bdc706d,d6e3aa71,60b467c7,6a3698cc,544f6e2d,41717549,7e7e0ff7,c2d6e3a4,e91d39dc,e174016f,757c8cc0,997da0b7,e8a454ee,d30b0197,168647ff,81657d69,09e9a360,8cb99afc,cd0c7329,90703f0b,b38d9d44,961b433f,43b42ba5,3f672847,5454f876,03d3773a,dfe1fbe1,3728f679,0174a255,5bc67a4b,b745c450,c6ed7b85',1374647571,1388995937);
/*!40000 ALTER TABLE `sys_administrator_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-06 15:35:01
