-- MySQL dump 10.13  Distrib 5.1.73, for pc-linux-gnu (i686)
--
-- Host: localhost    Database: cps
-- ------------------------------------------------------
-- Server version	5.1.63

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cps_access`
--

DROP TABLE IF EXISTS `cps_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_access` (
  `role_id` int(5) unsigned NOT NULL COMMENT '角色id',
  `node_id` int(5) unsigned NOT NULL COMMENT '节点id',
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`),
  KEY `node_id` (`node_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1070 DEFAULT CHARSET=utf8 COMMENT='5.2.4权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_access`
--

LOCK TABLES `cps_access` WRITE;
/*!40000 ALTER TABLE `cps_access` DISABLE KEYS */;
INSERT INTO `cps_access` VALUES (4,292,1032),(3,291,1039),(1,291,1022),(1,290,1021),(1,294,1020),(1,281,1019),(1,278,1018),(1,195,1017),(1,102,1016),(1,287,1015),(2,195,895),(2,116,894),(2,102,893),(7,116,817),(4,291,1031),(3,290,1038),(1,13,1014),(6,292,977),(5,292,972),(5,291,971),(5,278,970),(4,290,1030),(4,289,1029),(4,294,1028),(4,281,1027),(4,278,1026),(4,102,1025),(4,287,1024),(1,7,1013),(4,13,1023),(5,102,969),(5,287,968),(5,13,967),(6,278,976),(6,116,975),(6,102,974),(6,287,973),(3,294,1037),(3,281,1036),(3,278,1035),(3,102,1034),(3,287,1033),(7,107,816),(7,102,815),(7,51,814),(7,14,813),(7,13,812),(7,8,811),(7,7,810),(7,118,818),(7,134,819);
/*!40000 ALTER TABLE `cps_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_activity`
--

DROP TABLE IF EXISTS `cps_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_activity` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` tinyint(4) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `orig` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `abst` varchar(255) NOT NULL,
  `info` mediumtext NOT NULL,
  `add_time` datetime NOT NULL,
  `ordid` tinyint(4) NOT NULL,
  `is_hot` tinyint(1) NOT NULL DEFAULT '0',
  `is_best` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-待审核 1-已审核',
  `seo_title` varchar(255) NOT NULL,
  `seo_keys` varchar(255) NOT NULL,
  `seo_desc` text NOT NULL,
  `name` varchar(66) DEFAULT '' COMMENT '主题名称',
  `mobile` varchar(11) DEFAULT '' COMMENT '手机',
  `username` varchar(32) DEFAULT '' COMMENT '姓名',
  `vehicle` varchar(11) DEFAULT NULL COMMENT '适合车辆',
  `circuit` varchar(255) DEFAULT NULL COMMENT '自驾线路',
  `notice` varchar(11) DEFAULT NULL COMMENT '注意事项',
  `price` text COMMENT '价格政策',
  `instructions` text COMMENT '活动目的',
  `place` varchar(255) DEFAULT NULL COMMENT '活动地点',
  `total` int(11) DEFAULT NULL COMMENT '活动人数',
  `uid` int(1) DEFAULT NULL COMMENT '状态（1、启用，0、关闭）',
  `data_state` char(1) DEFAULT '1' COMMENT '数据状态：0删除，1正常',
  `score` int(10) DEFAULT '0' COMMENT '所需积分',
  `cnt_show` int(11) unsigned DEFAULT '0' COMMENT '收藏数展示',
  `left_show` int(11) DEFAULT '0' COMMENT '余量展示',
  `cnt_reply` int(11) DEFAULT '0' COMMENT '余量展示',
  `date_begin` datetime DEFAULT NULL COMMENT '开始时间',
  `date_end` datetime DEFAULT NULL COMMENT '结束时间',
  `plan` text COMMENT '活动安排',
  `fee` varchar(255) DEFAULT NULL COMMENT '费用',
  `stick` varchar(255) DEFAULT NULL COMMENT '置顶',
  `region_name` varchar(256) DEFAULT NULL COMMENT '区域',
  `region_id` int(11) unsigned DEFAULT NULL COMMENT '区域id',
  `remark` varchar(255) DEFAULT NULL,
  `pv` int(11) unsigned DEFAULT '0',
  `update_time` datetime NOT NULL COMMENT '更新时间',
  `update_uid` int(11) DEFAULT NULL,
  `update_username` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `is_best` (`is_best`),
  KEY `add_time` (`add_time`),
  KEY `cate_id` (`cate_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_activity`
--

LOCK TABLES `cps_activity` WRITE;
/*!40000 ALTER TABLE `cps_activity` DISABLE KEYS */;
INSERT INTO `cps_activity` VALUES (1,1,'关于我们','','','','','  <w:worddocument>   <w:view>Normal</w:view>   <w:zoom>0</w:zoom>   <w:trackmoves />   <w:trackformatting />   <w:punctuationkerning />   <w:drawinggridverticalspacing>7.8 磅</w:drawinggridverticalspacing>   <w:displayhorizontaldrawinggridevery>0</w:displayhorizontaldrawinggridevery>   <w:displayverticaldrawinggridevery>2</w:displayverticaldrawinggridevery>   <w:validateagainstschemas />   <w:saveifxmlinvalid>false</w:saveifxmlinvalid>   <w:ignoremixedcontent>false</w:ignoremixedcontent>   <w:alwaysshowplaceholdertext>false</w:alwaysshowplaceholdertext>   <w:donotpromoteqf />   <w:lidthemeother>EN-US</w:lidthemeother>   <w:lidthemeasian>ZH-CN</w:lidthemeasian>   <w:lidthemecomplexscript>X-NONE</w:lidthemecomplexscript>   <w:compatibility>    <w:spaceforul />    <w:balancesinglebytedoublebytewidth />    <w:donotleavebackslashalone />    <w:ultrailspace />    <w:donotexpandshiftreturn />    <w:adjustlineheightintable />    <w:breakwrappedtables />    <w:snaptogridincell />    <w:wraptextwithpunct />    <w:useasianbreakrules />    <w:dontgrowautofit />    <w:splitpgbreakandparamark />    <w:dontvertaligncellwithsp />    <w:dontbreakconstrainedforcedtables />    <w:dontvertalignintxbx />    <w:word11kerningpairs />    <w:cachedcolbalance />    <w:usefelayout />   </w:compatibility>   <w:browserlevel>MicrosoftInternetExplorer4</w:browserlevel>   <m:mathpr>    <m:mathfont m:val=\"Cambria Math\" />    <m:brkbin m:val=\"before\" />    <m:brkbinsub m:val=\"--\" />    <m:smallfrac m:val=\"off\" />    <m:dispdef />    <m:lmargin m:val=\"0\" />    <m:rmargin m:val=\"0\" />    <m:defjc m:val=\"centerGroup\" />    <m:wrapindent m:val=\"1440\" />    <m:intlim m:val=\"subSup\" />    <m:narylim m:val=\"undOvr\" />   </m:mathpr></w:worddocument> </xml><![endif]--><!--[if gte mso 9]><xml>  <w:latentstyles deflockedstate=\"false\" defunhidewhenused=\"true\" defsemihidden=\"true\" defqformat=\"false\" defpriority=\"99\" latentstylecount=\"267\">   <w:lsdexception locked=\"false\" priority=\"0\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Normal\" />   <w:lsdexception locked=\"false\" priority=\"9\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"heading 1\" />   <w:lsdexception locked=\"false\" priority=\"9\" qformat=\"true\" name=\"heading 2\" />   <w:lsdexception locked=\"false\" priority=\"9\" qformat=\"true\" name=\"heading 3\" />   <w:lsdexception locked=\"false\" priority=\"9\" qformat=\"true\" name=\"heading 4\" />   <w:lsdexception locked=\"false\" priority=\"9\" qformat=\"true\" name=\"heading 5\" />   <w:lsdexception locked=\"false\" priority=\"9\" qformat=\"true\" name=\"heading 6\" />   <w:lsdexception locked=\"false\" priority=\"9\" qformat=\"true\" name=\"heading 7\" />   <w:lsdexception locked=\"false\" priority=\"9\" qformat=\"true\" name=\"heading 8\" />   <w:lsdexception locked=\"false\" priority=\"9\" qformat=\"true\" name=\"heading 9\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 1\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 2\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 3\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 4\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 5\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 6\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 7\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 8\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 9\" />   <w:lsdexception locked=\"false\" priority=\"35\" qformat=\"true\" name=\"caption\" />   <w:lsdexception locked=\"false\" priority=\"10\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Title\" />   <w:lsdexception locked=\"false\" priority=\"1\" name=\"Default Paragraph Font\" />   <w:lsdexception locked=\"false\" priority=\"11\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Subtitle\" />   <w:lsdexception locked=\"false\" priority=\"22\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Strong\" />   <w:lsdexception locked=\"false\" priority=\"20\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Emphasis\" />   <w:lsdexception locked=\"false\" priority=\"59\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Table Grid\" />   <w:lsdexception locked=\"false\" unhidewhenused=\"false\" name=\"Placeholder Text\" />   <w:lsdexception locked=\"false\" priority=\"1\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"No Spacing\" />   <w:lsdexception locked=\"false\" priority=\"60\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Shading\" />   <w:lsdexception locked=\"false\" priority=\"61\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light List\" />   <w:lsdexception locked=\"false\" priority=\"62\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Grid\" />   <w:lsdexception locked=\"false\" priority=\"63\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 1\" />   <w:lsdexception locked=\"false\" priority=\"64\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 2\" />   <w:lsdexception locked=\"false\" priority=\"65\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 1\" />   <w:lsdexception locked=\"false\" priority=\"66\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 2\" />   <w:lsdexception locked=\"false\" priority=\"67\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 1\" />   <w:lsdexception locked=\"false\" priority=\"68\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 2\" />   <w:lsdexception locked=\"false\" priority=\"69\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 3\" />   <w:lsdexception locked=\"false\" priority=\"70\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Dark List\" />   <w:lsdexception locked=\"false\" priority=\"71\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Shading\" />   <w:lsdexception locked=\"false\" priority=\"72\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful List\" />   <w:lsdexception locked=\"false\" priority=\"73\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Grid\" />   <w:lsdexception locked=\"false\" priority=\"60\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Shading Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"61\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light List Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"62\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Grid Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"63\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 1 Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"64\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 2 Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"65\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 1 Accent 1\" />   <w:lsdexception locked=\"false\" unhidewhenused=\"false\" name=\"Revision\" />   <w:lsdexception locked=\"false\" priority=\"34\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"List Paragraph\" />   <w:lsdexception locked=\"false\" priority=\"29\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Quote\" />   <w:lsdexception locked=\"false\" priority=\"30\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Intense Quote\" />   <w:lsdexception locked=\"false\" priority=\"66\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 2 Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"67\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 1 Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"68\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 2 Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"69\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 3 Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"70\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Dark List Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"71\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Shading Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"72\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful List Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"73\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Grid Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"60\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Shading Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"61\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light List Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"62\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Grid Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"63\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 1 Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"64\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 2 Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"65\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 1 Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"66\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 2 Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"67\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 1 Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"68\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 2 Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"69\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 3 Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"70\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Dark List Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"71\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Shading Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"72\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful List Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"73\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Grid Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"60\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Shading Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"61\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light List Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"62\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Grid Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"63\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 1 Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"64\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 2 Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"65\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 1 Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"66\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 2 Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"67\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 1 Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"68\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 2 Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"69\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 3 Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"70\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Dark List Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"71\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Shading Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"72\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful List Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"73\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Grid Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"60\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Shading Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"61\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light List Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"62\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Grid Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"63\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 1 Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"64\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 2 Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"65\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 1 Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"66\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 2 Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"67\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 1 Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"68\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 2 Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"69\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 3 Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"70\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Dark List Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"71\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Shading Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"72\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful List Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"73\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Grid Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"60\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Shading Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"61\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light List Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"62\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Grid Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"63\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 1 Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"64\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 2 Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"65\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 1 Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"66\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 2 Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"67\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 1 Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"68\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 2 Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"69\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 3 Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"70\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Dark List Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"71\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Shading Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"72\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful List Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"73\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Grid Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"60\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Shading Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"61\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light List Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"62\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Grid Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"63\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 1 Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"64\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 2 Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"65\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 1 Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"66\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 2 Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"67\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 1 Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"68\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 2 Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"69\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 3 Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"70\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Dark List Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"71\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Shading Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"72\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful List Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"73\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Grid Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"19\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Subtle Emphasis\" />   <w:lsdexception locked=\"false\" priority=\"21\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Intense Emphasis\" />   <w:lsdexception locked=\"false\" priority=\"31\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Subtle Reference\" />   <w:lsdexception locked=\"false\" priority=\"32\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Intense Reference\" />   <w:lsdexception locked=\"false\" priority=\"33\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Book Title\" />   <w:lsdexception locked=\"false\" priority=\"37\" name=\"Bibliography\" />   <w:lsdexception locked=\"false\" priority=\"39\" qformat=\"true\" name=\"TOC Heading\" />  </w:latentstyles> </xml><![endif]--><!--[if gte mso 10]>\r\n<style>\r\n /* Style Definitions */\r\n table.MsoNormalTable\r\n	{mso-style-name:普通表格;\r\n	mso-tstyle-rowband-size:0;\r\n	mso-tstyle-colband-size:0;\r\n	mso-style-noshow:yes;\r\n	mso-style-priority:99;\r\n	mso-style-qformat:yes;\r\n	mso-style-parent:\"\";\r\n	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;\r\n	mso-para-margin:0cm;\r\n	mso-para-margin-bottom:.0001pt;\r\n	mso-pagination:widow-orphan;\r\n	font-size:10.5pt;\r\n	mso-bidi-font-size:11.0pt;\r\n	font-family:\"Calibri\",\"sans-serif\";\r\n	mso-ascii-font-family:Calibri;\r\n	mso-ascii-theme-font:minor-latin;\r\n	mso-hansi-font-family:Calibri;\r\n	mso-hansi-theme-font:minor-latin;\r\n	mso-bidi-font-family:\"Times New Roman\";\r\n	mso-bidi-theme-font:minor-bidi;\r\n	mso-font-kerning:1.0pt;}\r\n</style>\r\n<![endif]--><p class=\"MsoNormal\"><span style=\"font-family:宋体;mso-ascii-font-family:Calibri;mso-ascii-theme-font:minor-latin;mso-fareast-font-family:宋体;mso-fareast-theme-font:minor-fareast;mso-hansi-font-family:Calibri;mso-hansi-theme-font:minor-latin;\">wegou是国内时尚返利购物社区，致力于为用户提供最好时尚购物体验，用最好的互联网技术为用户解决“如何网购更省钱”的问题。</span></p>','2012-03-17 11:30:14',0,1,1,1,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00 00:00:00',NULL,NULL),(13,1,'赚取积分','','','','赚取积分','<p><b><span style=\"color:#666666;\">1 什么是积分？</span></b></p>\r\n<p><span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 积分是就是根据您在我们网站上的活跃情况，给与您的奖励，是一笔虚拟财富！</span></p>\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">2 积分的用处？</span></b></p>\r\n<p><span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 积分可以用于兑换我们提供的精美礼品！</span></p>\r\n<p><span style=\"color:#999999;font-size:12px;\"><br />\r\n</span></p>\r\n<p></p>\r\n<p><b><span style=\"color:#666666;\">3 赚取积分的方法</span></b>？</p>\r\n<p><span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 赚取积分，可以按以下要点操作：</span></p>\r\n<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 1、每天登录网站，积分加+21</span><span style=\"color:#999999;font-size:12px;\">；</span><br />\r\n<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 2、每分享一个商品，积分+21；</span><br />\r\n<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 3、新用户注册，赠送51积分；</span><br />\r\n<p><span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 4、网站活动获奖奖励积分</span></p>','2012-08-04 18:57:34',0,1,0,1,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00 00:00:00',NULL,NULL),(3,1,'联系我们','','','','','<p>联系电话：010-66668888</p>\r\n<p>&nbsp;</p>\r\n<p>官方网站：htt</p>\r\n<br />\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>','2012-03-17 11:32:08',0,0,0,1,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00 00:00:00',NULL,NULL),(21,11,'测试标题sssss','fasdfasdf','58d389eae1dc4.jpg','ddddddddddddd','fadsfasdf','<span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span>','2017-03-23 16:40:10',0,1,1,1,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00 00:00:00',NULL,NULL),(22,9,'测试添加成功跳转ssss','','58d38ade353b7.jpg','','测试添加成功跳转测试添加成功跳转','<h1 class=\"QuestionHeader-title\" style=\"font-weight:400;font-size:24px;font-family:\" color:#1e1e1e;background-color:#ffffff;\"=\"\">\r\n	后台管理员操作日志怎么记录？（ PHP MYSQL）\r\n	</h1>\r\n<div class=\"QuestionHeader-detail\" style=\"color:#262626;font-family:\" font-size:15px;background-color:#ffffff;\"=\"\">\r\n	<div class=\"QuestionRichText QuestionRichText--expandable\">\r\n		<span class=\"RichText\">一个电商网站后台 然后要记录每个管理人员的操作明细， 修改了那些内容 添加了那些内容，比如：添加了什么商品，属性都是什么，订单修改状态之类的。 后台超管还可查看管理人员都改了哪些东西</span> \r\n	</div>\r\n		</div>','2017-03-23 16:44:14',1,1,1,1,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2017-03-23 17:23:42',1,'admin'),(7,9,'国际品牌包包免费试用 ','','4f640f80f14d9.jpg','?a=index&m=cate&cid=3','国际品牌包包免费试用 ','','2012-03-17 12:13:53',0,1,1,1,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00 00:00:00',NULL,NULL),(8,9,'美丽清爽夏装免费试穿','','4f640fe112c89.jpg','?a=index&m=cate&cid=1','美丽清爽夏装免费试穿','','2012-03-17 12:15:29',0,1,1,1,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00 00:00:00',NULL,NULL),(9,9,'清凉夏季凉鞋免费试穿 ','','','?a=index&m=cate&cid=2','清凉夏季凉鞋免费试穿','','2012-03-17 12:15:49',0,1,1,1,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00 00:00:00',NULL,NULL),(10,9,'知名品牌化妆品免费试用','','','?a=index&m=cate&cid=5','知名品牌化妆品免费试用','','2012-03-17 12:16:01',3,1,1,1,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00 00:00:00',NULL,NULL),(11,9,'七夕到 鹊桥会 好礼送','','502e0eec7af0a.jpg','?a=index&m=cate&cid=4','七夕好礼，千万配饰商品等你来拿！\r\n','','2012-03-17 12:16:33',2,1,1,1,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00 00:00:00',NULL,NULL),(12,10,'不错的内容哦','','','','不错的内容哦','不错的内容哦不错的内容哦不错的内容哦不错的内容哦不错的内容哦111111111111111<br />','2012-06-21 16:14:34',1,1,0,0,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00 00:00:00',NULL,NULL),(14,1,'如何返利','','','/index.php?a=index&m=article&id=17','如何返利','如何返利<br />','2012-08-17 14:51:37',0,1,0,1,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00 00:00:00',NULL,NULL),(17,5,' 返利常见问题','','','','','<b><span style=\"color:#666666;\">1 什么是返利？</span></b><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;\r\n您通过本站去商家店铺购买商品，商家会通过购物网支付给本站一定的推广佣金，本站会将这笔佣金的大部分返还给您。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;\r\n假设您在淘宝网看中一个100元的宝贝，通过本站查询该宝贝现金返利金额为10元，通过查询结果中的购买进入淘宝网购物，在确认收货后，我们就会给予您10元的现金返利，您申请提现后我们会将这 笔钱提现到您指定的支付宝账户内。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp; 所以，通过本站去购物可以让您获得更多实惠。</span></p>\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">2 返利的钱从哪里来的？是我多付了钱吗？</span></b> </p>\r\n<p>&nbsp;&nbsp; <span style=\"color:#999999;font-size:12px;\">您好，您并未多付钱，购物网商家为了加大商品的销售渠道，建立了一种付费推广机制，在收入中专门预留了一部分给合作推广渠道。而本站就是购物网推广渠道高级合作伙伴之一，本站会将通过推广 获得的佣金大部分返还给您，您可以将这部分钱直接转账到您的支付宝帐户里，让您购物更加省钱！</span></p>\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">3 店家会不会是提高了宝贝价格所以才给返利的钱？</span></b></p>\r\n&nbsp;&nbsp; <span style=\"font-size:12px;color:#999999;\">当然不是！合理的推广费用是一个网店必要的成本开支，这笔费用与商品的售价无关，因此您完全不必担心是因为宝贝价格高，多付了钱财获得了返利。</span><br />\r\n<span style=\"font-size:12px;\"> </span><span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 举例，您去一个淘宝店铺买一个价值100元的宝贝，无论是否通过本站，您购买该宝贝都需要支付100元，但是通过本站过去购买，您就能额外获得一定比例的返利，这样不是更省钱吗？</span></p>\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">4 一定要通过本站去购物才能获得返利吗？</span></b></p>\r\n&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">不一定哦！在本站不购物一样可以赚到返利哦！</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;\r\n推荐好友注册可获得推广奖励（永久）；可登录本站后在会员中心查看具体详情和推广链接。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">5 购物多久我才能得到现金返利？</span></b></p>\r\n&nbsp;&nbsp;<span style=\"color:#999999;font-size:12px;\">您好，您通过本站去购物网购物后，在购物网确认收货后的24小时内，我们会将返利加到您的本站会员帐户里。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">6 现金返利有什么用？我可以直接拿来购物吗？</span></b></p>\r\n&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">您好，因为本站是个返利导航站，不出售任何商品，所以现金返利不能直接用来购物。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;\r\n当您的现金返利到账后，您可以在“会员中心-我的返利”处申请提现到您的支付宝。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">7 通过本站去购物还能享受店铺本来的优惠吗？</span></b></p>\r\n&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">您好，完全可以！通过本站去购物网购物，丝毫不会影响到您在购物网的权益。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">8 我退换货了，返利怎么计算？</span></b></p>\r\n&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">您好，退货商品无返利，如一单中有部分退货，则符合返利规则的未退货部分有返利；</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;\r\n换货的话，符合返利规则，换一样的商品有返利，换其他商品无返利。如有问题可联系本站在线客服。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">9 如何挑选宝贝才能获得返利啊？有特别的要求吗？</span></b></p>\r\n&nbsp;&nbsp;<span style=\"color:#999999;font-size:12px;\">您好，挑选宝贝没有任何特别的要求，可通过以下几种方式挑选宝贝：</span><br />\r\n<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp;\r\n1，通过本站页面顶部的搜索框，搜索您需要的宝贝或店铺挑选宝贝；</span><br />\r\n<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp;\r\n2，您也可以先在淘宝网、淘宝商城挑选好您需要的宝贝或店铺名称，然后复制宝贝名称，再通过本站顶部搜索框搜索。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">10 如何查询我挑选的宝贝的返利啊？</span></b></p>\r\n&nbsp;&nbsp;&nbsp;<span style=\"color:#999999;font-size:12px;\">本站为会员提供宝贝返利查询通道，在搜索框中输入您要查询的宝贝名称，点击“搜索返利”即可。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">11 如何购物才能获得返利？</span></b></p>\r\n&nbsp;&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">您好，要获得返利，可在“返利”页面的搜索返利框，输入您要购买的宝贝名称，通过查询结果里的“购物按钮”去宝贝页面购买，才能获得返利。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n亦可通过店铺页面，选择您要购物的店铺直接去店铺购物，只要不跳转到其他店铺或使用页面上方的搜索框，也可获得返利。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">12 返利从何而来？</span></b></p>\r\n&nbsp;&nbsp;&nbsp;<span style=\"color:#999999;font-size:12px;\">各大购物网为了推广商品和店铺，推出了（网站联盟）计划。本站参加了网站联盟计划，因此本站通过引导用户购物，就可以从购物网获得一定比例的佣金。本站将所获得的绝大部分佣金都返利给会 员，这就是返利的来源。</span><br />\r\n<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp;&nbsp;\r\n您可以先前往淘宝网挑选好商品，然后通过本站的返利通道，查询返利并购买。同样的商品、同样的价格，不一样的是额外的返利，更加的省钱。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">13 购物为什么不是所有宝贝返利都有40%，甚至有的查询不到？</span></b></p>\r\n&nbsp;&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">每件商品的返利比例，是由购物网卖家来确定的，因此每个店铺的返利比例都会不同。一些商品，例如化妆品、服装类、食品类等，因为利润较高，所以返利比例较高；而电子产品一类，利润空间较 低，所以返利比例相应会低一些。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n还有少数的卖家没有参加网站联盟计划，如果用户购买这些卖家提供的商品，都是没有返利的。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n但是，也有一些商城的卖家虽然没有参加网站联盟推广，通过返利查询不到返利的，但最后还是能从本站拿到返利。这是因为：购物网将自己的收入拿出来进行推广（购物商城入驻都要按照销售额的 一定比例支付给购物网），本站收到这部分的佣金后，也会一样返利给用户的。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">14 返利什么时间可以到账？</span></b></p>\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp; &nbsp; 购物网支付佣金给联盟网站的时间周期，一般来讲都有1-2个月，而本站为了方便会员的返利及时到账，在没有收到购物网的佣金之前，就先行垫付给会员了。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n所以用户在购物网“确认收货”后24小时内，本站会根据购物网反馈的信息同时将返利与订单加到用户在本站的会员帐户里。(若确认收货后3天还未查看到订单请先确认是否严格按照淘宝返利流程操 作，如果是请尽快联系本站在线客服查询)</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">15 如何避免返利掉单？</span></b></p>\r\n&nbsp;&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">除了淘宝聚划算，都要通过返利通道一，或者返利通道二，查询返利后再购买。特别提醒：只有通过“购物拿返利”的按钮，才能保证获得返利。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n其次，购物网站一般都是通过用户浏览器的Cookie值来判断用户来源。如果用户经常访问一些来路不明的网站，那么建议用户在购物拿返利之前，最好能清除一下浏览器的Cookie值，以保证不会被购物网误认为是来源于其他网站而无法得到返利。当然，如果嫌麻烦，这个步骤是可以省略的，前提是不要随意访问来路不明的网站。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n最后，要确保自己的电脑没有中毒，经常杀毒并养成良好的上网习惯，不要访问来路不明的网站，或者随意下载软件。一些病毒就是通过劫持用户浏览器的方式，窃取用户购物返利，而这一切都是很多用户通常所无法察觉出来的。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">16 返利掉单后怎么办？</span></b></p>\r\n<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp;&nbsp; 一旦发现自己按照本站的购物返利流程，还是发生购物掉单的问题，建议马上联系本站的在线客服，提交购物的凭证，以方便本站能够与购物网联系，并帮助用户找回返利。</span><br />\r\n<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp;&nbsp;\r\n另外，要马上检查自己的电脑是否中毒，是否被安装了非法的浏览器插件，要进行严格的杀毒。目前发现的很多浏览器劫持插件，都不能被杀毒软件及时发现，这个时候就需要重装电脑系统，以确保您能获得应得的返利。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">17 为何实际拿到的返利与查询的不符？</span></b></p>\r\n&nbsp;<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 您好，返利金额与购买时候查询到的返利金额不同一般是以下2种情况：</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;</span></p>\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 1，具体返利金额是根据您支付的金额按一定比例返利的。所以如果您实际的支付金额少于原价，那返利也会相应减少。</span></p>\r\n<span style=\"font-size:12px;color:#999999;\"> &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; 比如：查询显示宝贝价格为 100元，返利为20元。（返利比例为 20%）&nbsp;&nbsp; 实际您在购买该宝贝的时候支付的金额为50元（如商家促销、优惠降价、还价等），那么实际最终获得的返利=实际支付金额*返利比例=50*20%=10元。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;</span></p>\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 2，返利是按最后支付时作为确认，若正好卖家在您支付之前正好在调整商品的返利佣金比例，也会导致最后获得的返利与查询到的返利不符。（返利查询是通过购物接口读取物品传输的数据，存在一定的延迟）</span></p>\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;</span></p>\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 因受购物网平台的技术所限，暂无法做到100%保证用户查询时的返利与实际获得的返利相符（可能会多也可能会少），本站已经就这些用户遇到的实际问题积极向购物网反馈，争取给用户更好的返利体验。</span></p>\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">18 购物是否能100%获得返利？</span></b></p>\r\n&nbsp;&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">您好，因受购物网平台的技术所限，需用户确认收货后24小时内购物网才反馈给我们订单信息，故购物返利跟单存在一定风险性，因此本站目前无法100%保证您能够获得返利，就此问题本站已经积极向购物网反馈，争取给予用户更好的购物返利体验。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;</span></p>\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 另下列已知操作方式，本站不保证可获得返利：</span></p>\r\n<span style=\"font-size:12px;color:#999999;\"> </span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n1，通过本站“购物返利”搜索商品进入购物网后，从搜索结果进入的所有商品都有返利，但进入商品页面后再使用“购物网”的搜索，二次搜索的结果里的商品不保证有返利；</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> </span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n2，通过“店铺”页面的任何链接进入购物网后，进入的第一个购物网店铺购物有返利，进入第一个店铺再跳转到其他店铺或通过购物网的搜索购物，不保证有返利；</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> </span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n强烈建议：每次去购物都从本站“购物返利”页面点击进入商品页（不论是通过搜索宝贝、查询返利还是通过“店铺”进入）</span><br />','2012-09-12 14:23:21',0,1,0,0,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00 00:00:00',NULL,NULL),(18,5,'返利订单问题','','','','','<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 在您下单之前，请您先详细了解一下本站返利的相关操作流程，如果您确认自己的操作无误但是仍然无法生成订单，请联系我们本站在线客服。</span><br />','2012-09-12 14:26:32',0,1,0,0,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00 00:00:00',NULL,NULL),(19,5,'现金返利提现问题666','','','','','<b><span style=\"color:#666666;\">1 什么是现金返利？</span></b><br />\r\n<p>\r\n	<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 通过本站去各大购物商城、淘宝店铺购物后获得的返利即为现金返利，只有现金返利可进行提现操作。</span>\r\n</p>\r\n<p>\r\n	<b><br />\r\n</b>\r\n</p>\r\n<p>\r\n	<b><span style=\"color:#666666;\">2 如何申请返利提现？</span></b>\r\n</p>\r\n<p>\r\n	&nbsp;<span style=\"color:#999999;font-size:12px;\">&nbsp; 您好，当您的帐户现金返利时即可申请提现，您可以点击“会员中心-我的返利”申请返利提现，返利提现需先进行“收款信息设置”按照要求设置完毕后才能申请。</span>\r\n</p>\r\n<p>\r\n	<b><br />\r\n</b>\r\n</p>\r\n<p>\r\n	<b><span style=\"color:#666666;\">3 为什么我申请不了提现？提现按钮是灰色的？</span></b>\r\n</p>\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 您好，返利提现需满足2个条件才能申请提现。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 1，您的帐户返利有余额；</span><br />\r\n<p>\r\n	<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 2，您已经在“收款信息设置”里设置过收款帐户信息。</span>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">4 我申请的返利提现多久能收到呢？</span></b><span style=\"color:#666666;\"> </span><br />\r\n<p>\r\n	&nbsp;<span style=\"font-size:12px;color:#999999;\">&nbsp; 您好，会员申请提现后，本站工作人员会在1~3个工作日内把钱支付到您在本站填写提交的收款帐户里，支付宝收款用户可实时到账。</span>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">5 提现只能整数兑吗？</span></b><br />\r\n<p>\r\n	<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 您好，本站对提现没有限制，只要您账户有余额均可以提现。</span>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">6 我填错收款信息了，不想提现了怎么办啊？</span></b><br />\r\n<p>\r\n	<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 您可以及时联系本站在线客服帮你驳回申请，并按照要求修改收款帐户信息后重新申请提现即可。对于已经成功提现的申请将无法取消。</span>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">7 为什么我的提现被驳回了？</span></b><br />\r\n<p>\r\n	&nbsp;<span style=\"font-size:12px;color:#999999;\">&nbsp; 您好，提现申请被驳回可能是您的收款信息填写错误，具体您可以查看站内信里的具体驳回原因，如果还是不清楚可联系本站在线客服帮您解决。</span>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<b><span style=\"color:#666666;\">8 返利提现时需要手续费吗？</span></b>\r\n</p>\r\n<p>\r\n	<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 您好，如果您的收款帐户为支付宝帐户，提现时无需手续费（提现手续费由本站承担）。</span>\r\n</p>','2012-09-12 14:27:23',0,1,0,0,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00 00:00:00',NULL,NULL),(20,5,'用户常见问题3456','','','','','<b><span style=\"color:#666666;\">1 为什么实际拿到的返利金额和当时购买东西时查询到的返利金额不一样呢？</span></b> <br />\r\n<span style=\"color:#999999;font-size:10px;\">&nbsp;&nbsp; <span style=\"font-size:12px;\">您好，返利金额与购买时候查询到的返利金额不同一般是以下2种情况：</span></span><br />\r\n<span style=\"font-size:12px;\"> </span><span style=\"font-size:12px;\"> </span><span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 1，具体返利金额是根据您支付的金额按一定比例返利的。所以如果您实际的支付金额少于原价，那返利也会相应减少。</span><br />\r\n<p>\r\n	<span style=\"font-size:12px;\"> </span><span style=\"font-size:12px;\"> </span><span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 2，在您拍下商品到支付完成期间，正好卖家在调整商品的返利佣金比例，也会导致最后获得的返利与查询到的返利不符。（返利查询是通过购物接口读取物品传输的数据，存在一定的延迟）</span> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">2 为什么开始我要买的宝贝能查到返利，现在查不到了呢？</span></b><br />\r\n<p>\r\n	&nbsp;<span style=\"font-size:12px;\">&nbsp;</span><span style=\"color:#999999;font-size:12px;\">您好，返利是由该店铺卖家决定的，店铺卖家可随时更改调整店铺中各宝贝的返利比例，用户实际获得返利以支付时该宝贝的返利比例为准。</span> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">3 我在下单了为什么看不到订单？</span></b><br />\r\n<p>\r\n	&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">您好，返利与其他购物商城返利不同，购物后需在购物网“确认收货”后（24小时内）方可查看到相应的订单信息。若“确认收货”3天后还看不到订单信息请再详细查看下返利的相关步骤说明，确认所有 操作都没问题后，及时联系本站在线客服人员帮您查询处理。</span> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">4 如何使用购物车购物获得返利？</span></b><br />\r\n<p>\r\n	&nbsp;<span style=\"font-size:12px;\">&nbsp;</span><span style=\"color:#999999;font-size:12px;\">您好，因目前订单跟踪方面存在一定技术问题，所以在购物车购物时必须注意“不同店铺卖家的商品建议不要使用购物车购买”，否则很可能会出现无法跟到订单从而无法获得返利。</span> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">5 购物为什么同一批有的订单拿到返利了有的没拿到？我用的购物车购物的.</span></b><br />\r\n<p>\r\n	&nbsp;&nbsp;<span style=\"color:#999999;font-size:12px;\">您好，购物车购物是根据购物车里的各子订单是否有效判定的。如果购物车中的子订单不符合返利规则要求（任何形式的退款，包括部分退款，退运费等），则该子订单会被判为无效。</span> \r\n</p>\r\n<p>\r\n	<span style=\"color:#999999;font-size:12px;\"><br />\r\n</span> \r\n</p>\r\n<b><span style=\"color:#666666;\">6 同样的商品我购买了多件，返利如何计算啊？</span></b><br />\r\n<p>\r\n	<span style=\"color:#999999;\">&nbsp;&nbsp;</span><span style=\"font-size:12px;color:#999999;\">您好，返利是按单件商品计算的，同样的商品购买多件，返利会按件数叠加累计。</span> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">7 购物返利返的不都是现金吗,为什么会有返金币的？</span></b><br />\r\n&nbsp;&nbsp;<span style=\"color:#999999;font-size:12px;\"> 您好，购物返利大部分是返现金，只有个别商城如 当当网、麦网 等因商城不允许直接给用户</span><br />\r\n<p>\r\n	<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp;\r\n返现金，所以我们将现金返利按同等比例以金币的形式返还给用户。（金币=现金）</span> \r\n</p>\r\n<p>\r\n	<span style=\"color:#999999;font-size:12px;\"><br />\r\n</span> \r\n</p>\r\n<b><span style=\"color:#666666;\">8 购物后的现金返利是返到哪里的啊?</span></b><br />\r\n<p>\r\n	&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">您好，购物后的现金返利和金币返利都是直接加到您在本站的会员帐户里，现金返利到本站账户即可提现到您的支付宝里，金币返利可用于玩本站的金币游戏或兑换礼品。</span> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b> <span style=\"color:#666666;\">9 为什么明明我是通过本站去购物的，结果我没有拿到返利？</span></b><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;\r\n您好，本站是根据购物商城（淘宝网、凡客诚品等）反馈的订单信息给予用户返利的，目前有2种情况会导致您明明是通过本站去购物的，但购物商城判定该订单不属于本站的，从而无法获得返利。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> &nbsp;&nbsp;&nbsp; 1，您有访问过其他相关购物类的站点：一般购物商城会通过COOKIES记录您的访问来源，如果您在近期有访问过这类站点再访问本站，很可能会导致订单被判定不属于本站，从而无法获得返利。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> &nbsp;&nbsp;&nbsp;&nbsp; 解决办法：删除浏览器的 COOKIES 记录。&nbsp; （点击查看如何删除各浏览器的COOKIES记录）</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> &nbsp;&nbsp;&nbsp; 2，您的电脑被安装了拦截木马：有些购物类站点会有这类非法的推广链接拦截替换木马，对您的购物链接进行拦截，并在你购物的时候将链接替换成他们的推广链接。因这类木马只是拦截替换链接，修改特定参数且只针对个别商城（如淘宝网等），对电脑本身包括用户安全等无害，所以杀毒软件一般无法查杀这类恶意插件木马。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> &nbsp;&nbsp;&nbsp;&nbsp; 解决办法：重新安装系统，或换台机器，并且尽量不要去访问一些没有正规网络备案的非法站点和个人主页。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> </span><br />\r\n<br />\r\n<br />','2012-09-12 14:27:58',0,1,0,1,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00 00:00:00',NULL,NULL),(23,9,'php后台操作日志怎么做，记录数据库操作','','','','php后台操作日志怎么做，记录数据库操作\r\nberryblue | 浏览 2165 次\r\n发布于2016-01-18 11:49 最佳答案\r\n解决方案：\r\n插入数据库\r\n$db->先创建一个log表, \']，有id,$username;];update\'，登录后都有的吧\r\nif(in_array($action, action;$username就是当前操作人的名字了;;/, username;这里可以把时间和$query_string处理一下,\'，可添加\r\n$query_string = $_SERVE','<div class=\"wgt-ask accuse-response line mod-shadow \" id=\"wgt-ask\" style=\"color:#333333;font-family:\" font-size:14px;background-color:#ffffff;\"=\"\">\r\n<h1 style=\"font-size:16px;\">\r\n	<span class=\"ask-title \" style=\"font-size:24px;line-height:34px;font-weight:400;\">php后台操作日志怎么做，记录数据库操作</span> \r\n</h1>\r\n<div class=\"line f-aid ask-info ff-arial\" id=\"ask-info\" style=\"font-size:12px;color:#9EADB6;\">\r\n	<span class=\"grid-r ask-time\"> \r\n	<div class=\"others-share\">\r\n		<a target=\"_blank\" class=\"others-share-item weixin iknow-qb_share_icons\"><span class=\"logo\" style=\"color:#BFCAD5;line-height:28px;\"></span></a><a href=\"http://v.t.sina.com.cn/share/share.php?url=http%3A%2F%2Fzhidao.baidu.com%2Fquestion%2F1947579271168463308%3Fsharesource%3Dweibo&title=php%E5%90%8E%E5%8F%B0%E6%93%8D%E4%BD%9C%E6%97%A5%E5%BF%97%E6%80%8E%E4%B9%88%E5%81%9A%EF%BC%8C%E8%AE%B0%E5%BD%95%E6%95%B0%E6%8D%AE%E5%BA%93%E6%93%8D%E4%BD%9C_%E7%99%BE%E5%BA%A6%E7%9F%A5%E9%81%93&pic=https%3A%2F%2Fgss0.bdstatic.com%2F70cFsjip0QIZ8tyhnq%2Fimg%2Fiknow%2Fzhidaologo.png\" target=\"_blank\" class=\"others-share-item weibo iknow-qb_share_icons\"><span class=\"logo\" style=\"color:#BFCAD5;line-height:28px;\"></span></a><a href=\"http://connect.qq.com/widget/shareqq/index.html?url=http%3A%2F%2Fzhidao.baidu.com%2Fquestion%2F1947579271168463308%3Fsharesource%3Dqq&title=php%E5%90%8E%E5%8F%B0%E6%93%8D%E4%BD%9C%E6%97%A5%E5%BF%97%E6%80%8E%E4%B9%88%E5%81%9A%EF%BC%8C%E8%AE%B0%E5%BD%95%E6%95%B0%E6%8D%AE%E5%BA%93%E6%93%8D%E4%BD%9C_%E7%99%BE%E5%BA%A6%E7%9F%A5%E9%81%93&pics=https%3A%2F%2Fgss0.bdstatic.com%2F70cFsjip0QIZ8tyhnq%2Fimg%2Fiknow%2Fzhidaologo.png\" target=\"_blank\" class=\"others-share-item qq iknow-qb_share_icons\"><span class=\"logo\" style=\"color:#BFCAD5;line-height:28px;\"></span></a><a href=\"http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=http%3A%2F%2Fzhidao.baidu.com%2Fquestion%2F1947579271168463308%3Fsharesource%3Dqzone&title=php%E5%90%8E%E5%8F%B0%E6%93%8D%E4%BD%9C%E6%97%A5%E5%BF%97%E6%80%8E%E4%B9%88%E5%81%9A%EF%BC%8C%E8%AE%B0%E5%BD%95%E6%95%B0%E6%8D%AE%E5%BA%93%E6%93%8D%E4%BD%9C_%E7%99%BE%E5%BA%A6%E7%9F%A5%E9%81%93&pics=https%3A%2F%2Fgss0.bdstatic.com%2F70cFsjip0QIZ8tyhnq%2Fimg%2Fiknow%2Fzhidaologo.png\" target=\"_blank\" class=\"others-share-item qzone iknow-qb_share_icons\"><span class=\"logo\" style=\"color:#BFCAD5;font-size:18px;line-height:28px;\"></span></a> \r\n	</div>\r\n</span><a class=\"\" href=\"http://zhidao.baidu.com/usercenter?uid=b0944069236f25705e79a618\" target=\"_blank\">berryblue</a>&nbsp;<span id=\"v-times\" class=\"f-pipe\" style=\"color:#E8ECEE;vertical-align:middle;background:#E8ECEE;\">|</span><span class=\"browse-times\">&nbsp;浏览 2165 次</span> \r\n</div>\r\n	</div>\r\n<div class=\"wgt-best mod-shadow  \" id=\"best-answer-2411180585\" style=\"font-family:\" padding:0px=\"\" 0px=\"\" 28px;color:#333333;font-size:14px;background:0px=\"\" #ffffff;\"=\"\">\r\n	<div class=\"hd line \" style=\"margin:0px;\">\r\n		<span class=\"grid-r f-aid pos-time answer-time f-pening\" style=\"font-size:12px;color:#A4B4BB;line-height:26px;\">发布于2016-01-18 11:49</span> \r\n		<div id=\"act-link-banner-wp\" class=\"grid-r\">\r\n		</div>\r\n<span class=\"iknow-qb_home_icons answer-type answer-best grid\" style=\"vertical-align:middle;color:#4ACA5D;font-size:28px;line-height:1;font-family:iknow-qb_home_icons !important;\"></span><span class=\"answer-title h2 grid\" style=\"font-size:22px;font-family:\" color:#35b558;\"=\"\">最佳答案</span> \r\n	</div>\r\n	<div class=\"bd answer\" id=\"answer-2411180585\" style=\"margin:0px;\">\r\n		<div class=\"line info f-aid\" style=\"font-size:12px;color:#9EADB6;\">\r\n		</div>\r\n		<div class=\"line content\">\r\n<pre id=\"best-content-2411180585\" class=\"best-text mb-10\">解决方案：\r\n插入数据库\r\n$db-&gt;先创建一个log表, \']，有id,$username;];update\'，登录后都有的吧\r\nif(<a href=\"https://www.baidu.com/s?wd=in_array&tn=44039180_cpr&fenlei=mv6quAkxTZn0IZRqIHckPjm4nH00T1Y3n199nhRkmWmvrjFBrHTz0ZwV5Hcvrjm3rH6sPfKWUMw85HfYnjn4nH6sgvPsT6KdThsqpZwYTjCEQLGCpyw9Uz4Bmy-bIi4WUvYETgN-TLwGUv3EnHbYP1RLrHcLnHDvrjfvn1nsr0\" target=\"_blank\" class=\"baidu-highlight\">in_array</a>($action, action;$username就是当前操作人的名字了;;/, username;这里可以把时间和$query_string处理一下,\'，可添加\r\n$query_string = $_SERVER[\', query;, time 等字段，可以自己定义;delete\',$username,$query_string);edit\'，如果需要记录更多。比如;)))\r\n{\r\naddlog($action;/QUERY_STRING\',这个最好处理一下\r\n$action = $_REQUEST[\'///查询(query)的字符串?action=add&amp;id=xx\r\n/,\'action\';操作类型, array(\'add\'/\r\n}\r\nfunction addlog($action,$query_string)\r\n{\r\n/query($sql);\r\n}</pre>\r\n		</div>\r\n	</div>\r\n</div>','2017-03-23 17:26:03',0,1,1,1,'','','','','','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2017-03-23 17:29:37',1,'admin');
/*!40000 ALTER TABLE `cps_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_ad`
--

DROP TABLE IF EXISTS `cps_ad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_ad` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `board_id` smallint(5) NOT NULL,
  `type` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `code` text NOT NULL,
  `start_time` int(10) NOT NULL,
  `end_time` int(10) NOT NULL,
  `clicks` int(10) NOT NULL DEFAULT '0',
  `add_time` int(10) NOT NULL,
  `ordid` int(10) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `board_id` (`board_id`,`start_time`,`end_time`,`status`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_ad`
--

LOCK TABLES `cps_ad` WRITE;
/*!40000 ALTER TABLE `cps_ad` DISABLE KEYS */;
INSERT INTO `cps_ad` VALUES (6,6,'image','59秒开放平台','http://www.59miao.com','50165dc897fbe.jpg',1333595088,1365217491,103,1333681516,1,0),(7,5,'code','凡客','','<a href=\"http://r.59miao.com/?e=103098&s=1064&a=\" target=\"_blank\"><img border=\"0\" src=\"http://www.duomai.com/Public/Uploads/d5755cdbca7ca21daccf62114f129dba.gif\" alt=\"格子衬衫 79元起\" /></a>',1333683143,1365219146,11,1333683151,2,0);
/*!40000 ALTER TABLE `cps_ad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_adboard`
--

DROP TABLE IF EXISTS `cps_adboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_adboard` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `width` smallint(5) NOT NULL,
  `height` smallint(5) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_adboard`
--

LOCK TABLES `cps_adboard` WRITE;
/*!40000 ALTER TABLE `cps_adboard` DISABLE KEYS */;
INSERT INTO `cps_adboard` VALUES (1,'首页焦点图','focus',580,280,'',0),(4,'详细页横幅','banner',950,100,'',0),(5,'详细页右侧','banner',226,226,'',1),(6,'首页下方横幅','banner',960,100,'',0);
/*!40000 ALTER TABLE `cps_adboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_admin`
--

DROP TABLE IF EXISTS `cps_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '编号，自增长',
  `user_name` varchar(50) NOT NULL DEFAULT '' COMMENT '账号（唯一客户经理编号）',
  `password` varchar(100) NOT NULL COMMENT '密码',
  `add_time` int(10) unsigned DEFAULT NULL COMMENT '创建时间',
  `last_time` int(10) DEFAULT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态，1激活、0禁用',
  `role_id` int(10) NOT NULL DEFAULT '6' COMMENT '角色标识',
  `update_time` int(10) unsigned DEFAULT NULL COMMENT '修改时间',
  `user_id` varchar(50) NOT NULL COMMENT '客户经理姓名',
  `mobile` varchar(13) DEFAULT NULL COMMENT '手机号',
  `email` varchar(100) NOT NULL COMMENT '电子信箱',
  `ip` varchar(15) NOT NULL,
  `account` varchar(32) DEFAULT NULL COMMENT '收款账户信息（结算账户）',
  `data_state` tinyint(1) DEFAULT '1' COMMENT '数据状态：0删除，1正常',
  `pid` int(10) unsigned DEFAULT NULL COMMENT '父id',
  `address` varchar(10) DEFAULT NULL COMMENT '家庭地址',
  PRIMARY KEY (`id`,`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COMMENT='5.2.1后台用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_admin`
--

LOCK TABLES `cps_admin` WRITE;
/*!40000 ALTER TABLE `cps_admin` DISABLE KEYS */;
INSERT INTO `cps_admin` VALUES (1,'admin','21232f297a57a5a743894a0e4a801fc3',1504026308,NULL,1,1,NULL,'cps平台',NULL,'','',NULL,1,NULL,NULL),(11,'mingshengshangcheng','dc483e80a7a0bd9ef71d8cf973673924',1504331294,1504331294,1,3,NULL,'民生商城','18999999999','ms@qq.com','','ms@qq.com',1,0,'民生商城'),(12,'beijingfenghang','dc483e80a7a0bd9ef71d8cf973673924',1504331336,1504331336,1,4,NULL,'北京分行','18999999999','bj@qq.com','','bj123@qq.com',1,0,'北京分行'),(13,'zhangsan','dc483e80a7a0bd9ef71d8cf973673924',1504333346,1504333346,1,5,1504333346,'昌平支行',' 18958222222',' bank_sub_xm@qq.com','120.41.220.107',' bank_sub_xm@qq.com',1,12,'昌平支行'),(14,'chaoyang','dc483e80a7a0bd9ef71d8cf973673924',1504333346,1504333346,1,5,1504333346,'朝阳支行',' 18999990000',' bank_sub_xm@qq.com','120.41.220.107',' bank_sub_xm@qq.com',1,12,'朝阳支行'),(15,'xicheng','dc483e80a7a0bd9ef71d8cf973673924',1504333346,1504333346,1,5,1504333346,'西城支行',' 18989898989',' bank_sub_xm@qq.com','120.41.220.107',' bank_sub_xm@qq.com',1,12,'西城支行'),(16,'haidian','dc483e80a7a0bd9ef71d8cf973673924',1504333346,1504333346,1,5,1504333346,'海淀支行',' 18989898989',' bank_sub_xm@qq.com','120.41.220.107',' bank_sub_xm@qq.com',1,12,'海淀支行'),(17,'lisi','dc483e80a7a0bd9ef71d8cf973673924',1504333564,1504333564,1,6,1504333564,'李四',' 18999990000',' bank_sub_xm@qq.com','120.41.220.107',' bank_sub_xm@qq.com',1,16,'海淀支行'),(18,'fujianfenhang','dc483e80a7a0bd9ef71d8cf973673924',1504426211,1504426211,1,4,NULL,'福建分行','0592-23324343','179986365@qq.com','','',1,0,'厦门'),(19,'dongcheng','dc483e80a7a0bd9ef71d8cf973673924',1504427655,1504427655,1,5,1504427655,'东城支行',' 18958222222',' bank_sub_xm@qq.com','219.143.150.29',' bank_sub_xm@qq.com',1,12,'东城支行'),(20,'fentai','dc483e80a7a0bd9ef71d8cf973673924',1504427655,1504427655,1,5,1504427655,'丰台支行',' 18999990000',' bank_sub_xm@qq.com','219.143.150.29',' bank_sub_xm@qq.com',1,12,'丰台支行'),(21,'wangwu','dc483e80a7a0bd9ef71d8cf973673924',1504427699,1504427699,1,6,1504427699,'王五',' 18958222222',' bank_sub_xm@qq.com','219.143.150.29',' bank_sub_xm@qq.com',1,14,'朝阳支行'),(22,'zhaoliu','dc483e80a7a0bd9ef71d8cf973673924',1504427699,1504427699,1,6,1504427699,'赵六',' 18999990000',' bank_sub_xm@qq.com','219.143.150.29',' bank_sub_xm@qq.com',1,14,'朝阳支行');
/*!40000 ALTER TABLE `cps_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_album`
--

DROP TABLE IF EXISTS `cps_album`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_album` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '默认专辑',
  `img` varchar(255) DEFAULT NULL,
  `uid` int(10) NOT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `cid` int(10) NOT NULL DEFAULT '0',
  `sort_order` int(10) DEFAULT '0',
  `recommend_count` int(10) NOT NULL,
  `recommend` tinyint(4) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `add_time` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recommend` (`recommend`),
  KEY `sort_order` (`sort_order`),
  KEY `uid` (`uid`),
  KEY `status` (`status`,`cid`,`sort_order`),
  KEY `recommend_count` (`recommend_count`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_album`
--

LOCK TABLES `cps_album` WRITE;
/*!40000 ALTER TABLE `cps_album` DISABLE KEYS */;
INSERT INTO `cps_album` VALUES (1,'默认专辑',NULL,4,NULL,0,0,0,0,1,1489544175);
/*!40000 ALTER TABLE `cps_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_album_cate`
--

DROP TABLE IF EXISTS `cps_album_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_album_cate` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '我的专辑',
  `add_time` int(10) NOT NULL DEFAULT '0',
  `album_num` int(10) NOT NULL DEFAULT '0',
  `sort_order` int(10) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sort_order` (`status`,`sort_order`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_album_cate`
--

LOCK TABLES `cps_album_cate` WRITE;
/*!40000 ALTER TABLE `cps_album_cate` DISABLE KEYS */;
INSERT INTO `cps_album_cate` VALUES (1,'其他',1338789120,0,5,1),(2,'美容',1338789120,0,4,1),(3,'包包',1338789120,0,3,1),(4,'衣服',1338789120,0,1,1),(5,'鞋子',1338789120,0,2,1);
/*!40000 ALTER TABLE `cps_album_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_album_items`
--

DROP TABLE IF EXISTS `cps_album_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_album_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `items_id` int(10) NOT NULL DEFAULT '0',
  `pid` int(10) NOT NULL DEFAULT '0',
  `remark` varchar(255) DEFAULT NULL,
  `add_time` int(10) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_album_items`
--

LOCK TABLES `cps_album_items` WRITE;
/*!40000 ALTER TABLE `cps_album_items` DISABLE KEYS */;
INSERT INTO `cps_album_items` VALUES (1,1,1,'',1489544175);
/*!40000 ALTER TABLE `cps_album_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_album_recommend`
--

DROP TABLE IF EXISTS `cps_album_recommend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_album_recommend` (
  `album_id` int(10) DEFAULT NULL,
  `uid` int(10) DEFAULT NULL,
  KEY `album_id` (`album_id`,`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_album_recommend`
--

LOCK TABLES `cps_album_recommend` WRITE;
/*!40000 ALTER TABLE `cps_album_recommend` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_album_recommend` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_article`
--

DROP TABLE IF EXISTS `cps_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` tinyint(4) unsigned NOT NULL,
  `title` varchar(255) NOT NULL COMMENT '标题',
  `orig` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `abst` varchar(255) NOT NULL,
  `info` mediumtext NOT NULL COMMENT '信息',
  `add_time` datetime NOT NULL,
  `ordid` tinyint(4) unsigned NOT NULL,
  `is_hot` tinyint(1) NOT NULL DEFAULT '0',
  `is_best` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0-待审核 1-已审核',
  `seo_title` varchar(255) NOT NULL,
  `seo_keys` varchar(255) NOT NULL,
  `seo_desc` varchar(1024) NOT NULL,
  `platform_id` int(10) unsigned NOT NULL COMMENT '分销机构（发布的时候可指定全部或者具体分行、子机构的人员能看到） 0全部',
  `data_state` tinyint(1) unsigned DEFAULT '1' COMMENT '数据状态：0删除，1正常',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '创建人',
  `aid` varchar(255) NOT NULL COMMENT '附件id',
  PRIMARY KEY (`id`),
  KEY `is_best` (`is_best`),
  KEY `add_time` (`add_time`),
  KEY `cate_id` (`cate_id`),
  KEY `status` (`status`),
  KEY `data_state` (`data_state`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='5.2.10公告表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_article`
--

LOCK TABLES `cps_article` WRITE;
/*!40000 ALTER TABLE `cps_article` DISABLE KEYS */;
INSERT INTO `cps_article` VALUES (1,0,'活动公告','','','','','<p style=\"-webkit-tap-highlight-color: transparent; outline-style: initial; outline-width: 0px; padding: 0px; vertical-align: baseline; font-size: 16px; color: rgb(51, 51, 51); font-family: -apple-system, Helvetica, sans-serif; widows: 1;\">1、活动时间：2017年1月1日 00:00:00-12月31日 23:59:59；</p><p style=\"-webkit-tap-highlight-color: transparent; outline-style: initial; outline-width: 0px; margin-top: 0px; padding: 0px; vertical-align: baseline; font-size: 16px; color: rgb(51, 51, 51); font-family: -apple-system, Helvetica, sans-serif; widows: 1;\">2、188元新人大礼包由新注册用户礼包和实名认证礼包组成；</p><p style=\"-webkit-tap-highlight-color: transparent; outline-style: initial; outline-width: 0px; margin-top: 0px; padding: 0px; vertical-align: baseline; font-size: 16px; color: rgb(51, 51, 51); font-family: -apple-system, Helvetica, sans-serif; widows: 1;\">3、188元新人大礼包仅限于拥有京东购物平台正式账号且未发生购买行为的新用户领取。新用户在完成手机验证后，即有机会获得新注册用户礼包；完成手机验证的新用户完成实名身份认证后（实名认证需要京东验证姓名、身份证、银行卡及银行卡预留手机号等信息），即有机会获得实名认证礼包。礼包数量有限，先到先得，发完即止；</p><p style=\"-webkit-tap-highlight-color: transparent; outline-style: initial; outline-width: 0px; margin-top: 0px; padding: 0px; vertical-align: baseline; font-size: 16px; color: rgb(51, 51, 51); font-family: -apple-system, Helvetica, sans-serif; widows: 1;\">4、短信验证时，短信验证手机号码与京东账号绑定号码必须一致，操作时请注意查收系统发送的短信信息；</p><p style=\"-webkit-tap-highlight-color: transparent; outline-style: initial; outline-width: 0px; margin-top: 0px; padding: 0px; vertical-align: baseline; font-size: 16px; color: rgb(51, 51, 51); font-family: -apple-system, Helvetica, sans-serif; widows: 1;\">5、同一个京东账号、手机号视为同一用户，每个用户仅可获取一次礼包权益。优惠券的具体面额及有效期以实际到账为准，优惠券的有效期及使用方法请到“个人中心-我的钱包-优惠券”查看。优惠券过期未使用将自动失效，请及时使用；</p><p style=\"-webkit-tap-highlight-color: transparent; outline-style: initial; outline-width: 0px; margin-top: 0px; padding: 0px; vertical-align: baseline; font-size: 16px; color: rgb(51, 51, 51); font-family: -apple-system, Helvetica, sans-serif; widows: 1;\">6、在获取和使用优惠券过程中，如出现违规行为（如作弊领取、恶意套取、虚拟交易等），京东有权撤销违规交易，收回优惠券礼包；如遇不可抗力（包括但不限于重大灾害事件、活动受政府机关指令需要停止举办或调整的、活动中存在大面积作弊行为、活动遭受网络攻击或因系统故障导致活动领券资格大批出错，活动不能正常进行的），京东可取消、修改或暂停本活动，则活动主办方可依相关法律法规主张免责；</p><p style=\"-webkit-tap-highlight-color: transparent; outline-style: initial; outline-width: 0px; margin-top: 0px; padding: 0px; vertical-align: baseline; font-size: 16px; color: rgb(51, 51, 51); font-family: -apple-system, Helvetica, sans-serif; widows: 1;\">7、京东保留在法律规定范围内对上述规则进行解释的权利。</p>','2017-09-02 14:24:28',0,0,0,1,'','','',0,1,'2017-09-02 14:24:28',1,'');
/*!40000 ALTER TABLE `cps_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_article_cate`
--

DROP TABLE IF EXISTS `cps_article_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_article_cate` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `alias` varchar(50) NOT NULL,
  `pid` smallint(4) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `article_nums` int(10) unsigned NOT NULL,
  `sort_order` smallint(4) unsigned NOT NULL,
  `seo_title` varchar(255) NOT NULL,
  `seo_keys` varchar(255) NOT NULL,
  `seo_desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_article_cate`
--

LOCK TABLES `cps_article_cate` WRITE;
/*!40000 ALTER TABLE `cps_article_cate` DISABLE KEYS */;
INSERT INTO `cps_article_cate` VALUES (1,'网站信息','sites',11,0,4294967295,4,'','',''),(5,'新手入门','rumen',11,1,4294967294,2,'','',''),(9,'热门活动','activity',10,0,8,5,'网站在线帮助说明','',''),(10,'资讯活动','news',0,0,3,1,'网站资讯','',''),(11,'网站帮助','sites',0,0,4294967289,0,'','','');
/*!40000 ALTER TABLE `cps_article_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_attatch`
--

DROP TABLE IF EXISTS `cps_attatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_attatch` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` tinyint(4) unsigned NOT NULL,
  `title` varchar(255) NOT NULL COMMENT '标题',
  `orig` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL COMMENT '文件路径',
  `info` mediumtext NOT NULL COMMENT '信息',
  `add_time` datetime NOT NULL,
  `ordid` tinyint(4) NOT NULL,
  `uptime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `filesize` varchar(32) NOT NULL DEFAULT '0' COMMENT 'w文件大小',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-待审核 1-已审核',
  `filetype` varchar(32) NOT NULL COMMENT '文件类型',
  `data_state` tinyint(1) DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '创建人',
  `shop_id` int(10) unsigned DEFAULT '0' COMMENT '商户id',
  `item_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `origin_id` bigint(20) unsigned DEFAULT NULL COMMENT '商品原始id',
  `origin_name` varchar(32) DEFAULT NULL COMMENT '商品原始title',
  PRIMARY KEY (`id`),
  KEY `is_best` (`filesize`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `cate_id` (`cate_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='5.2.14文件图片管理表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_attatch`
--

LOCK TABLES `cps_attatch` WRITE;
/*!40000 ALTER TABLE `cps_attatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_attatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_auto_collect`
--

DROP TABLE IF EXISTS `cps_auto_collect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_auto_collect` (
  `id` char(4) NOT NULL,
  `value` varchar(200) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_auto_collect`
--

LOCK TABLES `cps_auto_collect` WRITE;
/*!40000 ALTER TABLE `cps_auto_collect` DISABLE KEYS */;
INSERT INTO `cps_auto_collect` VALUES ('i','1'),('p','1');
/*!40000 ALTER TABLE `cps_auto_collect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_auto_collect_date`
--

DROP TABLE IF EXISTS `cps_auto_collect_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_auto_collect_date` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `add_date` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_auto_collect_date`
--

LOCK TABLES `cps_auto_collect_date` WRITE;
/*!40000 ALTER TABLE `cps_auto_collect_date` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_auto_collect_date` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_cash_back_log`
--

DROP TABLE IF EXISTS `cps_cash_back_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_cash_back_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `uname` varchar(40) NOT NULL,
  `before_money` decimal(10,2) DEFAULT NULL,
  `after_money` decimal(10,2) DEFAULT NULL,
  `in_money` decimal(10,2) DEFAULT NULL,
  `out_money` decimal(10,2) DEFAULT NULL,
  `time` varchar(20) NOT NULL,
  `type` int(1) NOT NULL COMMENT '1表示收入，2表示支出',
  `info` varchar(100) NOT NULL,
  `sign` char(40) NOT NULL,
  `before_jifenbao` decimal(10,0) DEFAULT NULL,
  `after_jifenbao` decimal(10,0) DEFAULT NULL,
  `in_jifenbao` decimal(10,0) DEFAULT NULL,
  `out_jifenbao` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_cash_back_log`
--

LOCK TABLES `cps_cash_back_log` WRITE;
/*!40000 ALTER TABLE `cps_cash_back_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_cash_back_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_collect_miao`
--

DROP TABLE IF EXISTS `cps_collect_miao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_collect_miao` (
  `cate_id` smallint(4) NOT NULL,
  `collect_time` int(10) NOT NULL DEFAULT '0',
  UNIQUE KEY `cate_id` (`cate_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_collect_miao`
--

LOCK TABLES `cps_collect_miao` WRITE;
/*!40000 ALTER TABLE `cps_collect_miao` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_collect_miao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_collect_taobao`
--

DROP TABLE IF EXISTS `cps_collect_taobao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_collect_taobao` (
  `cate_id` smallint(4) NOT NULL,
  `collect_time` int(10) NOT NULL DEFAULT '0',
  UNIQUE KEY `cate_id` (`cate_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_collect_taobao`
--

LOCK TABLES `cps_collect_taobao` WRITE;
/*!40000 ALTER TABLE `cps_collect_taobao` DISABLE KEYS */;
INSERT INTO `cps_collect_taobao` VALUES (448,1489541725),(449,1489541728);
/*!40000 ALTER TABLE `cps_collect_taobao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_commission`
--

DROP TABLE IF EXISTS `cps_commission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_commission` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `con_id` varchar(255) DEFAULT '0' COMMENT '合同编号id,分行手动输入',
  `rate` varchar(255) DEFAULT NULL COMMENT '分销比例(佣金比例)',
  `price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `approver` varchar(1000) DEFAULT NULL COMMENT '审批人',
  `approver_id` smallint(4) NOT NULL DEFAULT '0' COMMENT '审批人_id',
  `approver_time` int(10) NOT NULL DEFAULT '0' COMMENT '审批时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `add_time` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '创建人',
  `platform_id` int(10) unsigned DEFAULT '0' COMMENT '分销平台，指定到机构？对，必须对应机构。',
  `remark` varchar(50) DEFAULT NULL,
  `remark_status` tinyint(6) DEFAULT '1',
  `freight` decimal(10,2) DEFAULT '0.00' COMMENT '承担运费',
  `period` varchar(1000) DEFAULT NULL COMMENT '账期',
  `data_state` tinyint(1) unsigned DEFAULT '1' COMMENT '数据状态：0删除，1正常',
  `update_time` int(10) unsigned DEFAULT NULL COMMENT '修改时间',
  `cate_id` bigint(255) unsigned DEFAULT NULL COMMENT '分类id',
  `item_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `shop_id` bigint(10) unsigned NOT NULL COMMENT '商户id',
  `commission` decimal(10,2) DEFAULT NULL COMMENT '佣金金额',
  `click` int(10) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `contract` varchar(255) DEFAULT NULL COMMENT '合同名称',
  `platform` varchar(255) DEFAULT NULL COMMENT '分销平台',
  `cate_name` varchar(128) NOT NULL DEFAULT '1' COMMENT '分类名称',
  `role_id` bigint(10) unsigned NOT NULL DEFAULT '1' COMMENT '角色id,提供是否是分润使用，如果role_id为4',
  `img` varchar(255) DEFAULT '' COMMENT '商品图片URL',
  `url` varchar(1000) DEFAULT '' COMMENT '商品链接URL',
  PRIMARY KEY (`id`),
  KEY `cid` (`con_id`),
  KEY `title` (`rate`),
  KEY `index_sid` (`approver_id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='5.2.8商品佣金表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_commission`
--

LOCK TABLES `cps_commission` WRITE;
/*!40000 ALTER TABLE `cps_commission` DISABLE KEYS */;
INSERT INTO `cps_commission` VALUES (12,'3','20','0.01',NULL,0,0,1,1504332409,1,1,NULL,1,'0.00',NULL,1,1504332409,0,'200',11,'0.00',21,'Sukin 苏芊 水润保湿护肤三件套 乳液+爽肤水+洗面奶 [125ml*3]','民生商城合同',NULL,'美妆个护',1,'http://wx.adjyc.com/attachment/images/6/2017/09/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg','http://wx.adjyc.com/app/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200'),(13,'3','15','3599.00',NULL,0,0,1,1504332409,1,1,NULL,1,'0.00',NULL,1,1504332409,0,'199',11,'539.85',1,'华为 Mate 9 4GB+64GB版 摩卡金 移动联通电信4G手机 双卡双待','民生商城合同',NULL,'手机',1,'http://wx.adjyc.com/attachment/images/6/2017/08/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg','http://wx.adjyc.com/app/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199'),(14,'4','20','0.01',NULL,0,0,1,1504427081,1,12,NULL,1,'0.00',NULL,1,1504427081,0,'200',11,'0.00',21,'Sukin 苏芊 水润保湿护肤三件套 乳液+爽肤水+洗面奶 [125ml*3]','北京分行合同',NULL,'美妆个护',1,'http://wx.adjyc.com/attachment/images/6/2017/09/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg','http://wx.adjyc.com/app/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200'),(15,'4','15','3599.00',NULL,0,0,1,1504427081,1,12,NULL,1,'0.00',NULL,1,1504427081,0,'199',11,'539.85',1,'华为 Mate 9 4GB+64GB版 摩卡金 移动联通电信4G手机 双卡双待','北京分行合同',NULL,'手机',1,'http://wx.adjyc.com/attachment/images/6/2017/08/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg','http://wx.adjyc.com/app/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199'),(16,'','10','3599.00',NULL,0,0,1,1504333204,12,12,NULL,1,'0.00',NULL,1,1504333204,0,'199',11,'359.90',1,'华为 Mate 9 4GB+64GB版 摩卡金 移动联通电信4G手机 双卡双待','',NULL,'手机',4,'http://wx.adjyc.com/attachment/images/6/2017/08/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg','http://wx.adjyc.com/app/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199'),(17,'','100','0.01',NULL,0,0,1,1504333204,12,12,NULL,1,'0.00',NULL,1,1504333204,0,'200',11,'0.01',21,'Sukin 苏芊 水润保湿护肤三件套 乳液+爽肤水+洗面奶 [125ml*3]','',NULL,'美妆个护',4,'http://wx.adjyc.com/attachment/images/6/2017/09/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg','http://wx.adjyc.com/app/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200'),(18,'5','20','829.00',NULL,0,0,1,1504426384,1,18,NULL,1,'0.00',NULL,1,1504426384,0,'23',11,'165.80',0,'奈唯 足金转运珠手链','福建分行合同',NULL,'首饰',1,'http://shop.adjyc.com/attachment/images/5/2017/07/k0FQlfuTs0rfsqtz707tuBHubyUtl0.jpg','http://shop.adjyc.com/app/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=23'),(19,'5','10','4188.00',NULL,0,0,1,1504426384,1,18,NULL,1,'0.00',NULL,1,1504426384,0,'28',11,'418.80',0,'华为 Mate9 手机 (6GB+128GB)','福建分行合同',NULL,'手机',1,'http://shop.adjyc.com/attachment/images/5/2017/08/jpm3sqxvMxq33S34Z3Amsx84XXTA32.jpg','http://shop.adjyc.com/app/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=28'),(20,'4','20','460.00',NULL,0,0,1,1504427081,1,12,NULL,1,'0.00',NULL,1,1504427081,0,'204',11,'92.00',9,'格玛仕 韩版超薄 时尚潮流石英女式时装镶水钻腕表 [玫金色2105-CR-B2-DW]','北京分行合同',NULL,'首饰',1,'http://wx.adjyc.com/attachment/images/6/2017/09/V1yNIw1OErYwyliLlbtWe6oOyW6Ybb.jpg','http://wx.adjyc.com/app/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=204'),(21,'','10','460.00',NULL,0,0,1,1504427410,12,12,NULL,1,'0.00',NULL,1,1504427410,0,'204',11,'46.00',9,'格玛仕 韩版超薄 时尚潮流石英女式时装镶水钻腕表 [玫金色2105-CR-B2-DW]','',NULL,'首饰',4,'http://wx.adjyc.com/attachment/images/6/2017/09/V1yNIw1OErYwyliLlbtWe6oOyW6Ybb.jpg','http://wx.adjyc.com/app/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=204');
/*!40000 ALTER TABLE `cps_commission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_contract`
--

DROP TABLE IF EXISTS `cps_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_contract` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `con_id` varchar(255) DEFAULT NULL COMMENT '合同编号id,分行手动输入',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `approver` varchar(1000) DEFAULT NULL COMMENT '审批人',
  `approver_id` smallint(4) NOT NULL DEFAULT '0' COMMENT '审批人_id',
  `approver_time` int(10) NOT NULL DEFAULT '0' COMMENT '审批时间',
  `period_account` varchar(32) NOT NULL DEFAULT '0' COMMENT '账期',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `add_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '创建人',
  `platform_id` int(10) unsigned DEFAULT '0' COMMENT '分销平台，指定到机构？对，必须对应机构。',
  `seo_desc` text,
  `cash_back_rate` varchar(40) NOT NULL,
  `seller_name` varchar(100) NOT NULL,
  `remark` varchar(50) DEFAULT NULL,
  `remark_status` tinyint(6) DEFAULT '1',
  `freight` decimal(10,2) DEFAULT '0.00' COMMENT '承担运费',
  `period` varchar(1000) DEFAULT NULL COMMENT '账期',
  `data_state` tinyint(1) DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  `update_time` int(10) unsigned DEFAULT NULL COMMENT '修改时间',
  `con_type` varchar(1000) DEFAULT NULL COMMENT '合同类型,关联感觉',
  `shop_id` bigint(11) DEFAULT NULL COMMENT '商城id',
  `payee` varchar(1000) DEFAULT NULL COMMENT '收款方',
  `begin_time` bigint(12) unsigned NOT NULL DEFAULT '0' COMMENT '开始时间',
  `end_time` bigint(12) unsigned NOT NULL DEFAULT '0' COMMENT '结束时间',
  PRIMARY KEY (`id`),
  KEY `cid` (`con_id`),
  KEY `is_index` (`period_account`),
  KEY `title` (`title`),
  KEY `index_sid` (`approver_id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='5.2.7合同表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_contract`
--

LOCK TABLES `cps_contract` WRITE;
/*!40000 ALTER TABLE `cps_contract` DISABLE KEYS */;
INSERT INTO `cps_contract` VALUES (3,'c1001','民生商城合同',NULL,NULL,0,0,'60',1,1504331390,1,1,NULL,'','',NULL,1,'8.00','1',NULL,1504331390,'3',11,NULL,1504281600,1535817600),(4,'b1001','北京分行合同',NULL,NULL,0,0,'60',1,1504332667,1,12,NULL,'','',NULL,1,'12.00','1',NULL,1504332667,'4',1,NULL,1504281600,1535817600),(5,'fjfh001','福建分行合同',NULL,NULL,0,0,'30',1,1504426307,1,18,NULL,'','',NULL,1,'0.00','1',NULL,1504426307,'4',1,NULL,1504368000,1535904000);
/*!40000 ALTER TABLE `cps_contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_contract_log`
--

DROP TABLE IF EXISTS `cps_contract_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_contract_log` (
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(40) DEFAULT NULL,
  `op_time` datetime DEFAULT NULL,
  `op` varchar(66) DEFAULT NULL COMMENT '操作：增加、修改、删除、审核、回复',
  `op_object` varchar(256) DEFAULT NULL COMMENT '操作的表',
  `op_desc` text COMMENT '操作内容',
  `sql` varchar(1024) DEFAULT NULL COMMENT '执行的sql语句 add update insert delete',
  `product` int(11) unsigned DEFAULT '0' COMMENT '商品id',
  `data_state` char(1) DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  `score` int(10) DEFAULT '0' COMMENT '所需积分',
  `uid` int(10) unsigned DEFAULT '0' COMMENT '用户',
  `app` int(11) DEFAULT NULL COMMENT '活动',
  `status` char(1) DEFAULT NULL COMMENT '数据状态：2成功，1审核中',
  `content` varchar(255) DEFAULT NULL,
  `reply_time` datetime DEFAULT NULL COMMENT '审核时间',
  `add_time` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `ip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='操作日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_contract_log`
--

LOCK TABLES `cps_contract_log` WRITE;
/*!40000 ALTER TABLE `cps_contract_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_contract_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_exchange_goods`
--

DROP TABLE IF EXISTS `cps_exchange_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_exchange_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `goods_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1:虚拟卡 2:实体商品',
  `img` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  `integral` int(11) NOT NULL DEFAULT '0',
  `stock` int(11) NOT NULL DEFAULT '0',
  `buy_count` int(11) NOT NULL DEFAULT '0',
  `user_id` smallint(5) NOT NULL DEFAULT '1',
  `user_num` int(8) NOT NULL COMMENT '每人限兑',
  `is_best` tinyint(1) NOT NULL DEFAULT '0',
  `is_hot` tinyint(1) NOT NULL DEFAULT '0',
  `begin_time` varchar(40) NOT NULL,
  `end_time` varchar(40) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `seo_title` varchar(400) NOT NULL,
  `seo_keys` varchar(400) NOT NULL,
  `seo_desc` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `begin_end_time` (`begin_time`,`end_time`),
  KEY `status` (`status`),
  KEY `sort` (`sort`),
  KEY `is_best` (`is_best`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_exchange_goods`
--

LOCK TABLES `cps_exchange_goods` WRITE;
/*!40000 ALTER TABLE `cps_exchange_goods` DISABLE KEYS */;
INSERT INTO `cps_exchange_goods` VALUES (2,'自然堂CHCEDO 雪域精粹系列 四件套装 洗+水+乳+霜 (凝润型) 补水',1,'./data/exchangegoods/503473aa672c6.jpg','自然堂CHCEDO 雪域精粹系列 四件套装 洗+水+乳+霜 (凝润型) 补水',5000,10,0,1,1,0,0,'1345478400','1608566400',100,1,'自然堂CHCEDO 雪域精粹系列 四件套装 洗+水+乳+霜 (凝润型) 补水','自然堂CHCEDO 雪域精粹系列 四件套装 洗+水+乳+霜 (凝润型) 补水','自然堂CHCEDO 雪域精粹系列 四件套装 洗+水+乳+霜 (凝润型) 补水'),(3,'沙宣修护水养套装（洗发露750ml+润发乳400ml+发质重塑发膜150ml）',1,'./data/exchangegoods/5034740bc7671.jpg','沙宣修护水养套装（洗发露750ml+润发乳400ml+发质重塑发膜150ml）',40000,10,0,1,1,0,0,'1345564800','1666281600',100,1,'沙宣修护水养套装（洗发露750ml+润发乳400ml+发质重塑发膜150ml）','沙宣修护水养套装（洗发露750ml+润发乳400ml+发质重塑发膜150ml）','沙宣修护水养套装（洗发露750ml+润发乳400ml+发质重塑发膜150ml）'),(4,'IPHONE 4s 16G原价4999现在只需要50000积分，快快赚取积分吧',1,'./data/exchangegoods/5034749736066.jpg','IPHONE 4s 16G原价4999现在只需要50000积分',50000,1,0,1,1,0,0,'1345478400','1608566400',100,1,'IPHONE 4s 16G原价4999现在只需要50000积分','IPHONE 4s 16G原价4999现在只需要50000积分','IPHONE 4s 16G原价4999现在只需要50000积分'),(5,'佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）',1,'./data/exchangegoods/503474ff36995.jpg','佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）<img src=\"/data/news/image/20170315/20170315114353_26081.jpg\" alt=\"\" />',1,1000,4,1,100,0,0,'1345478400','1769616000',100,1,'佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）','佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）','佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）');
/*!40000 ALTER TABLE `cps_exchange_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_exchange_order`
--

DROP TABLE IF EXISTS `cps_exchange_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_exchange_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sn` varchar(255) NOT NULL,
  `data_name` varchar(255) NOT NULL DEFAULT '',
  `goods_status` tinyint(1) NOT NULL COMMENT '0:未发货;1:部分发货;2:全部发货;3:部分退货;4:全部退货'',',
  `data_num` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL COMMENT '订单状态\r\n0: 未确认\r\n1: 完成\r\n2: 作废',
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `region_lv1` int(11) NOT NULL,
  `region_lv2` int(11) NOT NULL,
  `region_lv3` int(11) NOT NULL,
  `region_lv4` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile_phone` varchar(255) NOT NULL,
  `fax_phone` varchar(255) NOT NULL,
  `fix_phone` varchar(255) NOT NULL,
  `alim` varchar(255) NOT NULL,
  `msn` varchar(255) NOT NULL,
  `qq` varchar(255) NOT NULL,
  `consignee` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `user_name` varchar(60) NOT NULL DEFAULT '',
  `remark` varchar(255) NOT NULL,
  `adm_memo` varchar(255) NOT NULL,
  `order_score` int(11) NOT NULL,
  `goods_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sn` (`sn`),
  KEY `uid` (`uid`),
  KEY `goods_status` (`goods_status`),
  KEY `status` (`status`),
  KEY `goods_id` (`goods_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_exchange_order`
--

LOCK TABLES `cps_exchange_order` WRITE;
/*!40000 ALTER TABLE `cps_exchange_order` DISABLE KEYS */;
INSERT INTO `cps_exchange_order` VALUES (1,'20170315114601181','佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）',0,1,0,1489549561,1489549561,'366200',0,0,0,0,'福建省厦门市集美区','18888888888@163.com','18888888888','05922222222','','','','1569501393','街墙',4,'jieqiang','','',1,5),(2,'20170315115024352','佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）',0,1,0,1489549824,1489549824,'366200',0,0,0,0,'福建省厦门市集美区','18888888888@163.com','18888888888','05922222222','','','','1569501393','街墙',4,'jieqiang','','',1,5),(3,'20170315115028886','佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）',0,1,0,1489549828,1489549828,'366200',0,0,0,0,'福建省厦门市集美区','18888888888@163.com','18888888888','05922222222','','','','1569501393','街墙',4,'jieqiang','','',1,5),(4,'20170315115313461','佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）',0,1,0,1489549993,1489549993,'366200',0,0,0,0,'福建省厦门市集美区','18888888888@163.com','18888888888','05922222222','','','','1569501393','街墙',4,'jieqiang','','',1,5),(5,'20170315115558567','佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）',0,1,0,1489550158,1489550158,'366200',0,0,0,0,'福建省厦门市集美区','18888888888@163.com','18888888888','05922222222','','','','1569501393','街墙',4,'jieqiang','','',1,5),(6,'20170315124723967','佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）',1,1,0,1489553243,1489553243,'366200',0,0,0,0,'福建省厦门市集美区','18888888888@163.com','18888888888','05922222222','','','','1569501393','街墙',4,'jieqiang','阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发','',1,5);
/*!40000 ALTER TABLE `cps_exchange_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_file`
--

DROP TABLE IF EXISTS `cps_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` tinyint(4) unsigned NOT NULL,
  `title` varchar(255) NOT NULL COMMENT '标题',
  `orig` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL COMMENT '文件路径',
  `info` mediumtext NOT NULL COMMENT '信息',
  `add_time` datetime NOT NULL,
  `ordid` tinyint(4) NOT NULL,
  `is_hot` tinyint(1) NOT NULL DEFAULT '0',
  `is_best` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-待审核 1-已审核',
  `platform_id` int(10) unsigned NOT NULL COMMENT '分销机构（发布的时候可指定全部或者具体分行、子机构的人员能看到）',
  `data_state` tinyint(1) DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '创建人',
  `shop_id` int(10) unsigned DEFAULT '0' COMMENT '商户id',
  `item_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `origin_id` bigint(20) unsigned DEFAULT NULL COMMENT '商品原始id',
  `origin_name` varchar(32) DEFAULT NULL COMMENT '商品原始title',
  `name` varchar(32) DEFAULT NULL COMMENT '图片原始名称',
  `extension` varchar(32) DEFAULT NULL COMMENT '图片后缀',
  `size` varchar(32) DEFAULT NULL COMMENT '图片大小',
  `bimg` varchar(255) NOT NULL COMMENT '原图',
  `simg` varchar(255) NOT NULL COMMENT '缩略图',
  `cate_name` varchar(128) NOT NULL DEFAULT '1' COMMENT '分类名称',
  PRIMARY KEY (`id`),
  KEY `is_best` (`is_best`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `cate_id` (`cate_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=119 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='5.2.14文件图片管理表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_file`
--

LOCK TABLES `cps_file` WRITE;
/*!40000 ALTER TABLE `cps_file` DISABLE KEYS */;
INSERT INTO `cps_file` VALUES (114,0,'','','data/items/m_59aa4b23125d0.jpg','','','','2017-09-02 14:09:39',0,0,0,1,0,1,'2017-09-02 14:09:39',1,11,'200',5,'Sukin 苏芊 水润保湿护肤三件套 乳液 爽肤水 洗面奶 [1','m_5928327c669fe.jpg','jpg','50020','data/items/59aa4b23125d0.jpg','data/items/s_59aa4b23125d0.jpg','1'),(115,0,'','','data/items/m_59aa4b2d94454.jpg','','','','2017-09-02 14:09:49',0,0,0,1,0,1,'2017-09-02 14:09:49',1,11,'200',5,'Sukin 苏芊 水润保湿护肤三件套 乳液 爽肤水 洗面奶 [1','598c7da5cfb13.jpg','jpg','42354','data/items/59aa4b2d94454.jpg','data/items/s_59aa4b2d94454.jpg','1'),(116,0,'','','data/items/m_59aa4b33688e3.jpg','','','','2017-09-02 14:09:55',0,0,0,1,0,1,'2017-09-02 14:09:55',1,11,'200',5,'Sukin 苏芊 水润保湿护肤三件套 乳液 爽肤水 洗面奶 [1','598c7d9893fb2.jpg','jpg','47490','data/items/59aa4b33688e3.jpg','data/items/s_59aa4b33688e3.jpg','1'),(117,0,'','','data/items/m_59abbc80ccfce.jpg','','','','2017-09-03 16:25:36',0,0,0,1,0,1,'2017-09-03 16:25:36',1,11,'204',9,'格玛仕 韩版超薄 时尚潮流石英女式时装镶水钻腕表 [玫金色210','399712-4-24063-1-400_400.jpg','jpg','20511','data/items/59abbc80ccfce.jpg','data/items/s_59abbc80ccfce.jpg','1'),(118,0,'','','data/items/m_59abbc9061967.jpg','','','','2017-09-03 16:25:52',0,0,0,1,0,1,'2017-09-03 16:25:52',1,11,'204',9,'格玛仕 韩版超薄 时尚潮流石英女式时装镶水钻腕表 [玫金色210','m_59513ff59f919.jpg','jpg','36714','data/items/59abbc9061967.jpg','data/items/s_59abbc9061967.jpg','1');
/*!40000 ALTER TABLE `cps_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_find_password_log`
--

DROP TABLE IF EXISTS `cps_find_password_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_find_password_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `md5` char(32) NOT NULL,
  `create_time` varchar(20) NOT NULL,
  `ip` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `status` int(1) NOT NULL COMMENT '0表示没有激活，1表示激活',
  `address` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `message` varchar(1024) NOT NULL,
  `result` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_find_password_log`
--

LOCK TABLES `cps_find_password_log` WRITE;
/*!40000 ALTER TABLE `cps_find_password_log` DISABLE KEYS */;
INSERT INTO `cps_find_password_log` VALUES (1,'c3fcd98a123da79c81a88f72a71680ee','1496395404','127.0.0.1',2,0,'','','',''),(2,'636e6fca61078b2500d3407a7792418c','1496395535','127.0.0.1',2,0,'','','',''),(3,'7fbb8abbd0d7a2228d5e8e1c48a6d3e4','1496396247','127.0.0.1',2,0,'','','','');
/*!40000 ALTER TABLE `cps_find_password_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_flink`
--

DROP TABLE IF EXISTS `cps_flink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_flink` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` smallint(4) NOT NULL DEFAULT '1',
  `img` varchar(255) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `url` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `ordid` smallint(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_flink`
--

LOCK TABLES `cps_flink` WRITE;
/*!40000 ALTER TABLE `cps_flink` DISABLE KEYS */;
INSERT INTO `cps_flink` VALUES (2,1,'4f8ceab7e6f6c.jpg','微购官网','http://www.wego360.com',1,1),(5,2,NULL,'59秒开放平台','http://www.59miao.com',1,99),(6,2,NULL,'精品网','http://jingpin.59miao.com',1,99);
/*!40000 ALTER TABLE `cps_flink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_flink_cate`
--

DROP TABLE IF EXISTS `cps_flink_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_flink_cate` (
  `id` smallint(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_flink_cate`
--

LOCK TABLES `cps_flink_cate` WRITE;
/*!40000 ALTER TABLE `cps_flink_cate` DISABLE KEYS */;
INSERT INTO `cps_flink_cate` VALUES (1,'友情链接'),(2,'合作伙伴');
/*!40000 ALTER TABLE `cps_flink_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_focus`
--

DROP TABLE IF EXISTS `cps_focus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_focus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cate_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `abst` text NOT NULL,
  `clicks` int(10) NOT NULL DEFAULT '0',
  `ordid` smallint(4) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `ordid` (`ordid`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_focus`
--

LOCK TABLES `cps_focus` WRITE;
/*!40000 ALTER TABLE `cps_focus` DISABLE KEYS */;
INSERT INTO `cps_focus` VALUES (9,1,'NOP新秋新体验，8折购新品，限时一周。','?a=index&m=cate&cid=3','./data/focus/5051891a9e924.jpg','',154,0,1),(10,1,'格子控女生','?a=index&m=cate&cid=5','./data/focus/5051892acdd67.jpg','',105,0,1),(7,1,'悦己网时装周，2件6折，3件4折。','?a=index&m=cate&cid=7','./data/focus/50518986355f9.jpg','',95,0,1);
/*!40000 ALTER TABLE `cps_focus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_focus_cate`
--

DROP TABLE IF EXISTS `cps_focus_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_focus_cate` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `width` smallint(6) NOT NULL DEFAULT '0',
  `height` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_focus_cate`
--

LOCK TABLES `cps_focus_cate` WRITE;
/*!40000 ALTER TABLE `cps_focus_cate` DISABLE KEYS */;
INSERT INTO `cps_focus_cate` VALUES (1,'首页焦点',580,280);
/*!40000 ALTER TABLE `cps_focus_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_group`
--

DROP TABLE IF EXISTS `cps_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_group` (
  `id` smallint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `title` varchar(50) NOT NULL,
  `create_time` int(11) unsigned NOT NULL,
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `sort` (`sort`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_group`
--

LOCK TABLES `cps_group` WRITE;
/*!40000 ALTER TABLE `cps_group` DISABLE KEYS */;
INSERT INTO `cps_group` VALUES (4,'article','内容管理',1222841259,1222841259,1,3),(1,'system','系统设置',1222841259,1222841259,1,6),(6,'goods','商品管理',1222841259,0,1,2),(8,'member','会员管理',0,0,1,4),(9,'home','起始页',0,1341386748,1,0),(27,'seller','商家管理',1340586215,0,1,1),(28,'cash_back','返利管理',1340615780,0,1,2),(29,'other','其他管理',1345776358,0,1,7);
/*!40000 ALTER TABLE `cps_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_items`
--

DROP TABLE IF EXISTS `cps_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cid` smallint(4) DEFAULT NULL COMMENT '分类id',
  `item_key` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `img` varchar(255) DEFAULT '' COMMENT '商品图片URL',
  `simg` varchar(255) DEFAULT NULL,
  `bimg` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `url` varchar(1000) DEFAULT '' COMMENT '商品链接URL',
  `sid` smallint(4) NOT NULL DEFAULT '0',
  `hits` int(10) NOT NULL DEFAULT '0',
  `likes` int(10) NOT NULL DEFAULT '0' COMMENT '喜欢数',
  `browse_num` int(10) NOT NULL,
  `haves` int(10) NOT NULL DEFAULT '0' COMMENT '库存数',
  `comments` int(10) NOT NULL DEFAULT '0' COMMENT '评论数',
  `comments_last` text COMMENT '最近的N条评论',
  `is_index` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `add_time` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `uid` int(10) NOT NULL DEFAULT '0',
  `seo_title` varchar(255) DEFAULT NULL,
  `seo_keys` varchar(255) DEFAULT NULL,
  `sort_order` int(10) DEFAULT '0',
  `seo_desc` text,
  `cash_back_rate` varchar(40) NOT NULL,
  `seller_name` varchar(100) NOT NULL,
  `remark` varchar(50) DEFAULT NULL,
  `remark_status` tinyint(6) DEFAULT '1',
  `is_collect_comments` int(1) DEFAULT '0' COMMENT '是否采集了淘宝评论1表示已经采集了淘宝评论',
  `data_state` tinyint(1) DEFAULT '1' COMMENT '数据状态：0删除，1正常',
  `update_time` int(10) unsigned DEFAULT NULL COMMENT '修改时间',
  `item_id` varchar(32) NOT NULL COMMENT '对方商品库id',
  `shop_id` int(10) unsigned NOT NULL COMMENT '商城id',
  `qrcode` varchar(1000) DEFAULT NULL COMMENT '二维码图片URL',
  `cate_name` varchar(128) NOT NULL DEFAULT '1' COMMENT '分类名称',
  PRIMARY KEY (`id`),
  KEY `cid` (`cid`),
  KEY `is_index` (`is_index`),
  KEY `title` (`title`),
  KEY `index_sid` (`sid`),
  KEY `uid` (`uid`),
  KEY `item_key` (`item_key`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='5.2.6推广商品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_items`
--

LOCK TABLES `cps_items` WRITE;
/*!40000 ALTER TABLE `cps_items` DISABLE KEYS */;
INSERT INTO `cps_items` VALUES (5,0,NULL,'Sukin 苏芊 水润保湿护肤三件套 乳液+爽肤水+洗面奶 [125ml*3]','http://wx.adjyc.com/attachment/images/6/2017/09/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg',NULL,NULL,'0.01','http://wx.adjyc.com/app/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200',0,0,0,0,0,0,NULL,0,1,1504427081,1,NULL,NULL,0,NULL,'','',NULL,1,0,1,1504427081,'200',11,'./data/qrcode/poster___200_11_1504332595.jpg','美妆个护'),(6,0,NULL,'华为 Mate 9 4GB+64GB版 摩卡金 移动联通电信4G手机 双卡双待','http://wx.adjyc.com/attachment/images/6/2017/08/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg',NULL,NULL,'3599.00','http://wx.adjyc.com/app/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199',0,0,0,0,0,0,NULL,0,1,1504427081,1,NULL,NULL,0,NULL,'','',NULL,1,0,1,1504427081,'199',11,NULL,'手机'),(7,0,NULL,'奈唯 足金转运珠手链','http://shop.adjyc.com/attachment/images/5/2017/07/k0FQlfuTs0rfsqtz707tuBHubyUtl0.jpg',NULL,NULL,'829.00','http://shop.adjyc.com/app/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=23',0,0,0,0,0,0,NULL,0,1,1504426384,1,NULL,NULL,0,NULL,'','',NULL,1,0,1,1504426384,'23',11,NULL,'首饰'),(8,0,NULL,'华为 Mate9 手机 (6GB+128GB)','http://shop.adjyc.com/attachment/images/5/2017/08/jpm3sqxvMxq33S34Z3Amsx84XXTA32.jpg',NULL,NULL,'4188.00','http://shop.adjyc.com/app/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=28',0,0,0,0,0,0,NULL,0,1,1504426384,1,NULL,NULL,0,NULL,'','',NULL,1,0,1,1504426384,'28',11,NULL,'手机'),(9,0,NULL,'格玛仕 韩版超薄 时尚潮流石英女式时装镶水钻腕表 [玫金色2105-CR-B2-DW]','http://wx.adjyc.com/attachment/images/6/2017/09/V1yNIw1OErYwyliLlbtWe6oOyW6Ybb.jpg',NULL,NULL,'460.00','http://wx.adjyc.com/app/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=204',0,0,0,0,0,0,NULL,0,1,1504427354,12,NULL,NULL,0,NULL,'','',NULL,1,0,1,1504427354,'204',11,'./data/qrcode/poster_1_admin_204_11_1504427167.jpg','首饰');
/*!40000 ALTER TABLE `cps_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_items_cate`
--

DROP TABLE IF EXISTS `cps_items_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_items_cate` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类id',
  `name` varchar(50) NOT NULL COMMENT '分类名称',
  `keywords` varchar(128) NOT NULL COMMENT '分类关键字',
  `img` varchar(255) DEFAULT NULL,
  `pid` smallint(4) unsigned NOT NULL DEFAULT '0' COMMENT '父类id',
  `item_nums` int(10) NOT NULL DEFAULT '0',
  `item_likes` int(11) NOT NULL,
  `ordid` smallint(4) NOT NULL DEFAULT '0',
  `tags` varchar(50) NOT NULL COMMENT '标签',
  `is_hots` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `recommend` int(1) NOT NULL DEFAULT '0' COMMENT '0表示不推荐，1表示推荐',
  `import_status` int(1) NOT NULL DEFAULT '1',
  `seo_title` varchar(255) NOT NULL,
  `seo_keys` varchar(255) NOT NULL,
  `color` varchar(255) DEFAULT NULL,
  `seo_desc` text NOT NULL,
  `matching_title` varchar(2000) DEFAULT NULL,
  `add_time` int(11) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL COMMENT '更新时间',
  `data_state` tinyint(1) unsigned DEFAULT '1' COMMENT '数据状态：0删除，1正常',
  PRIMARY KEY (`id`),
  KEY `index_is_hots` (`is_hots`),
  KEY `ordid` (`ordid`),
  KEY `index_pid` (`pid`,`recommend`,`status`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='5.2.5推广商品分类表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_items_cate`
--

LOCK TABLES `cps_items_cate` WRITE;
/*!40000 ALTER TABLE `cps_items_cate` DISABLE KEYS */;
INSERT INTO `cps_items_cate` VALUES (2,'美妆个护','','http://wx.adjyc.com/attachment/images/6/2017/09/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg',0,0,0,0,'',0,1,0,1,'','',NULL,'',NULL,1504332409,1504332409,1),(3,'手机','','http://wx.adjyc.com/attachment/images/6/2017/08/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg',0,0,0,0,'',0,1,0,1,'','',NULL,'',NULL,1504332409,1504332409,1),(4,'首饰','','http://shop.adjyc.com/attachment/images/5/2017/07/k0FQlfuTs0rfsqtz707tuBHubyUtl0.jpg',0,0,0,0,'',0,1,0,1,'','',NULL,'',NULL,1504426384,1504426384,1);
/*!40000 ALTER TABLE `cps_items_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_items_comments`
--

DROP TABLE IF EXISTS `cps_items_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_items_comments` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `uid` int(10) NOT NULL,
  `uname` varchar(50) DEFAULT NULL,
  `info` text NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_items_comments`
--

LOCK TABLES `cps_items_comments` WRITE;
/*!40000 ALTER TABLE `cps_items_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_items_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_items_site`
--

DROP TABLE IF EXISTS `cps_items_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_items_site` (
  `id` smallint(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `site_domain` varchar(255) NOT NULL,
  `site_logo` varchar(255) NOT NULL,
  `collect_url` varchar(255) NOT NULL,
  `collect_time` int(10) NOT NULL DEFAULT '0',
  `item_nums` int(10) NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_items_site`
--

LOCK TABLES `cps_items_site` WRITE;
/*!40000 ALTER TABLE `cps_items_site` DISABLE KEYS */;
INSERT INTO `cps_items_site` VALUES (1,'淘宝','taobao','open.taobao.com','4f62c63e7b59d.jpg','',0,0,1),(2,'59秒','miao','www.59miao.com','4fe7cefb6dde7.png','www.59miao.com',0,0,1),(3,'微购api','wego','api.wego360.com','asdf',' ',0,0,0);
/*!40000 ALTER TABLE `cps_items_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_items_tags`
--

DROP TABLE IF EXISTS `cps_items_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_items_tags` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `item_nums` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `seo_title` varchar(255) NOT NULL,
  `seo_keys` varchar(255) NOT NULL,
  `seo_desc` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_items_tags`
--

LOCK TABLES `cps_items_tags` WRITE;
/*!40000 ALTER TABLE `cps_items_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_items_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_items_tags_cate`
--

DROP TABLE IF EXISTS `cps_items_tags_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_items_tags_cate` (
  `cate_id` smallint(4) NOT NULL,
  `tag_id` int(10) NOT NULL,
  KEY `cate_id` (`cate_id`),
  KEY `tag_id` (`tag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_items_tags_cate`
--

LOCK TABLES `cps_items_tags_cate` WRITE;
/*!40000 ALTER TABLE `cps_items_tags_cate` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_items_tags_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_items_tags_item`
--

DROP TABLE IF EXISTS `cps_items_tags_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_items_tags_item` (
  `item_id` varchar(32) NOT NULL,
  `tag_id` int(10) NOT NULL,
  KEY `item_id` (`item_id`),
  KEY `tag_id` (`tag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_items_tags_item`
--

LOCK TABLES `cps_items_tags_item` WRITE;
/*!40000 ALTER TABLE `cps_items_tags_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_items_tags_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_items_user`
--

DROP TABLE IF EXISTS `cps_items_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_items_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iid` int(11) NOT NULL,
  `item_id` varchar(32) NOT NULL,
  `uid` int(11) NOT NULL,
  `add_time` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`iid`),
  KEY `uid` (`uid`),
  KEY `item_id_2` (`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_items_user`
--

LOCK TABLES `cps_items_user` WRITE;
/*!40000 ALTER TABLE `cps_items_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_items_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_like_list`
--

DROP TABLE IF EXISTS `cps_like_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_like_list` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `items_id` int(10) NOT NULL DEFAULT '0',
  `uid` int(10) NOT NULL DEFAULT '0',
  `add_time` bigint(12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `add_time` (`add_time`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_like_list`
--

LOCK TABLES `cps_like_list` WRITE;
/*!40000 ALTER TABLE `cps_like_list` DISABLE KEYS */;
INSERT INTO `cps_like_list` VALUES (1,1,4,1489544165);
/*!40000 ALTER TABLE `cps_like_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_miao_order`
--

DROP TABLE IF EXISTS `cps_miao_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_miao_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_time` varchar(20) DEFAULT NULL,
  `seller_name` varchar(20) DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `order_code` varchar(50) DEFAULT NULL,
  `item_count` int(5) DEFAULT NULL,
  `item_price` varchar(10) DEFAULT NULL,
  `sales` varchar(20) DEFAULT NULL,
  `commission` varchar(10) DEFAULT NULL,
  `cash_back` varchar(10) DEFAULT NULL,
  `status` varchar(20) NOT NULL COMMENT '//订单状态',
  `is_update` int(1) NOT NULL DEFAULT '0' COMMENT '0表示未更新用户表，以及返现表，1表示已经更新，不需要再次更新',
  `jiesuan_data` datetime NOT NULL COMMENT '结算日期',
  `order_id` varchar(64) NOT NULL,
  `cash_back_jifenbao` varchar(10) DEFAULT NULL,
  `shop_id` bigint(10) unsigned NOT NULL COMMENT '商户id',
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `order_code` (`order_code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_miao_order`
--

LOCK TABLES `cps_miao_order` WRITE;
/*!40000 ALTER TABLE `cps_miao_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_miao_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_nav`
--

DROP TABLE IF EXISTS `cps_nav`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_nav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `alias` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `sort_order` smallint(4) NOT NULL,
  `system` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1-系统 0-自定义',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '导航位置1-顶部 2-底部',
  `in_site` tinyint(1) NOT NULL COMMENT '1-本站内 0-站外',
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  `seo_title` varchar(255) NOT NULL,
  `seo_keys` text NOT NULL,
  `seo_desc` text NOT NULL,
  `items_cate_id` int(11) DEFAULT NULL COMMENT '//分类id',
  PRIMARY KEY (`id`),
  KEY `is_show` (`is_show`),
  KEY `type` (`type`),
  KEY `sort_order` (`sort_order`),
  KEY `alias` (`alias`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_nav`
--

LOCK TABLES `cps_nav` WRITE;
/*!40000 ALTER TABLE `cps_nav` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_nav` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_node`
--

DROP TABLE IF EXISTS `cps_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_node` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `module` varchar(255) NOT NULL COMMENT '模块',
  `module_name` varchar(50) NOT NULL COMMENT '模块名称',
  `action` varchar(255) NOT NULL COMMENT '操作',
  `action_name` varchar(50) DEFAULT NULL COMMENT '操作名称',
  `data` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0' COMMENT '状态',
  `remark` varchar(255) DEFAULT NULL,
  `sort` smallint(6) unsigned NOT NULL DEFAULT '0',
  `auth_type` tinyint(1) NOT NULL DEFAULT '0',
  `group_id` tinyint(3) unsigned DEFAULT '0',
  `often` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-不常用 1-常用',
  `is_show` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-不常用 1-常用',
  `add_time` int(11) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL COMMENT '更新时间',
  `data_state` tinyint(1) DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `module` (`module`),
  KEY `auth_type` (`auth_type`),
  KEY `is_show` (`is_show`),
  KEY `group_id` (`group_id`),
  KEY `sort` (`sort`)
) ENGINE=MyISAM AUTO_INCREMENT=295 DEFAULT CHARSET=utf8 COMMENT='5.2.3节点表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_node`
--

LOCK TABLES `cps_node` WRITE;
/*!40000 ALTER TABLE `cps_node` DISABLE KEYS */;
INSERT INTO `cps_node` VALUES (1,'node','菜单管理','','','',0,'',0,0,1,0,0,0,0,NULL),(2,'node','菜单管理','index','菜单列表','',0,'',0,1,1,0,0,0,0,NULL),(3,'node','菜单管理','add','添加菜单','',0,'',0,2,1,0,0,0,0,NULL),(4,'node','菜单管理','edit','编辑菜单','',0,'',0,2,1,0,0,0,0,NULL),(5,'node','菜单管理','delete','删除菜单','',0,'',0,2,1,0,0,0,0,NULL),(6,'role','角色管理','','','',1,'',7,0,1,0,0,0,0,NULL),(7,'role','角色管理','index','权限管理','',1,'角色管理',7,1,1,0,0,0,0,NULL),(8,'role','角色管理','add','添加角色','',0,'',0,2,1,0,0,0,0,NULL),(9,'role','角色管理','edit','编辑角色','',0,'',0,2,1,0,0,0,0,NULL),(10,'role','角色管理','delete','删除角色','',0,'',0,2,1,0,0,0,0,NULL),(11,'role','角色管理','auth','角色授权','',0,'',0,2,1,0,0,0,0,NULL),(12,'admin','管理员管理','','','',1,'',97,0,1,0,0,0,0,NULL),(13,'admin','管理员管理','index','用户管理','',1,'管理员列表',98,1,1,0,0,0,0,NULL),(14,'admin','管理员管理','add','添加管理员','',0,'',0,2,1,0,0,0,0,NULL),(15,'admin','管理员管理','edit','编辑管理员','',0,'',0,2,1,0,0,0,0,NULL),(16,'admin','管理员管理','delete','删除管理员','',0,'',0,2,1,0,0,0,0,NULL),(50,'setting','网站设置','','','',0,'',399,0,1,0,0,0,0,NULL),(51,'setting','网站设置','index','网站设置','',0,'',0,1,1,0,0,0,0,NULL),(99,'flink','友情链接','','','',0,'',98,0,4,0,0,0,0,NULL),(100,'flink','友情链接','index','友情链接列表','',0,'',0,1,4,0,0,0,0,NULL),(101,'article','公告管理','','','',1,'',2,0,4,0,0,0,0,NULL),(102,'article','公告管理','index','公告管理','',1,'公告列表',3,1,4,0,0,0,0,NULL),(103,'article','公告管理','add','添加公告','',0,'',0,2,4,0,0,0,0,NULL),(104,'article_cate','公告分类','','','',0,'',99,0,4,0,0,0,0,NULL),(105,'article','公告管理','edit','编辑公告','',0,'',0,2,4,0,0,0,0,NULL),(106,'article','公告管理','delete','删除公告','',0,'',0,2,4,0,0,0,0,NULL),(107,'article_cate','公告分类','index','分类列表','',0,'',0,1,4,0,0,0,0,NULL),(108,'article_cate','公告分类','add','添加公告','',0,'',0,2,4,0,0,0,0,NULL),(109,'article_cate','公告分类','edit','编辑分类','',0,'',0,2,4,0,0,0,0,NULL),(110,'article_cate','公告分类','delete','删除分类','',0,'',0,2,4,0,0,0,0,NULL),(115,'items','商品管理','','','',1,'',2,0,4,0,0,0,0,NULL),(116,'items','商品管理','index','推广商品','',1,'商品列表',2,1,4,0,0,0,0,NULL),(117,'items_cate','商品分类','','','',0,'',0,0,4,0,0,0,0,NULL),(118,'items_cate','商品分类','index','商品分类','',0,'',0,1,4,0,0,0,0,NULL),(134,'items_tags','标签管理','index','标签列表','',0,'',0,1,6,0,0,0,0,NULL),(121,'nav','导航管理','','','',0,'',2,0,4,0,0,0,0,NULL),(122,'nav','导航管理','index','导航列表','',0,'',0,1,4,0,0,0,0,NULL),(123,'nav','导航管理','add','添加导航','',0,'',0,2,4,0,0,0,0,NULL),(124,'nav','导航管理','edit','编辑导航','',0,'',0,2,4,0,0,0,0,NULL),(125,'nav','导航管理','delete','删除导航','',0,'',0,2,4,0,0,0,0,NULL),(133,'items_tags','标签管理','','','',0,'',0,0,6,0,0,0,0,NULL),(132,'items_cate','商品管理','add','添加分类','',0,'',0,1,4,0,0,0,0,NULL),(131,'items','商品管理','add','添加商品','5',0,'',0,2,4,0,0,0,0,NULL),(135,'items_collect','商品采集','','','',0,'',0,0,6,0,0,0,0,NULL),(136,'items_collect','商品采集','index','商品采集','',0,'',6,1,6,0,0,0,0,NULL),(139,'adboard','广告位置','','','',0,'',90,0,4,0,0,0,0,NULL),(140,'adboard','广告位置','index','广告位置','',0,'',0,1,4,0,0,0,0,NULL),(141,'ad','广告管理','','','',0,'',90,0,4,0,0,0,0,NULL),(142,'ad','广告管理','index','广告列表','',0,'',0,1,4,0,0,0,0,NULL),(143,'template','模板管理','','','',0,'',0,0,1,0,0,0,0,NULL),(144,'template','模板管理','index','模板管理','',0,'',0,1,1,0,0,0,0,NULL),(145,'items','商品管理','batch_add','批量添加','',0,'',0,1,4,0,0,0,0,NULL),(148,'flink','友情链接','add','添加友情链接','',0,'',0,2,4,0,0,0,0,NULL),(149,'flink','友情链接','edit','编辑友情链接','',0,'',0,2,4,0,0,0,0,NULL),(150,'flink','友情链接','del','删除友情链接','',0,'',0,2,4,0,0,0,0,NULL),(151,'ad','广告管理','add','添加广告','',0,'',0,2,4,0,0,0,0,NULL),(152,'ad','广告管理','edit','编辑广告','',0,'',0,2,4,0,0,0,0,NULL),(153,'ad','广告管理','delete','删除广告','',0,'',0,2,4,0,0,0,0,NULL),(154,'adboard','广告位置','add','添加广告位置','',0,'',0,2,4,0,0,0,0,NULL),(155,'adboard','广告位置','edit','编辑广告位置','',0,'',0,2,4,0,0,0,0,NULL),(156,'adboard','广告位置','delete','删除广告位置','',0,'',0,2,4,0,0,0,0,NULL),(157,'focus','焦点图管理','','','',0,'',101,0,4,0,0,0,0,NULL),(158,'focus','焦点图管理','edit','编辑焦点图','',0,'',0,2,4,0,0,0,0,NULL),(159,'focus','焦点图管理','delete','删除焦点图','',0,'',0,2,4,0,0,0,0,NULL),(160,'items','商品管理','edit','编辑商品','',0,'',0,2,4,0,0,0,0,NULL),(161,'items','商品管理','delete','删除商品','',0,'',0,2,4,0,0,0,0,NULL),(162,'items_cate','商品管理','edit','编辑分类','',0,'',0,2,4,0,0,0,0,NULL),(163,'items_cate','商品管理','delete','删除分类','',0,'',0,2,4,0,0,0,0,NULL),(164,'items_tags','标签管理','add','添加标签','',0,'',0,2,1,0,0,0,0,NULL),(165,'items_tags','标签管理','edit','编辑标签','',0,'',0,2,1,0,0,0,0,NULL),(166,'items_tags','标签管理','delete','删除标签','',0,'',0,2,1,0,0,0,0,NULL),(167,'items_tags_cate','关联标签管理',' ','','',0,'',0,0,6,0,1,0,0,NULL),(168,'items_tags_cate','关联标签管理','index','关联标签列表','',0,'',0,1,6,0,1,0,0,NULL),(169,'items_tags_cate','关联标签管理','add','添加关联标签','',0,'',0,1,6,0,1,0,0,NULL),(181,'items_tags','标签管理','index','标签列表','',0,'',0,2,1,0,0,0,0,NULL),(171,'items_tags_cate','关联标签管理','del','删除关联标签','',0,'',0,2,6,0,1,0,0,NULL),(172,'items_collect','商品采集管理','edit','编辑采集设置','',0,'',0,2,6,0,0,0,0,NULL),(173,'items_collect','商品采集管理','collect','采集详情列表','',0,'',0,2,6,0,0,0,0,NULL),(174,'items_collect','商品采集管理','taobao_collect','采集','',0,'',0,2,6,0,0,0,0,NULL),(177,'cache','缓存管理',' ','','',0,'',0,0,1,0,1,0,0,NULL),(178,'cache','缓存管理','index','缓存管理','',0,'',0,2,1,0,1,0,0,NULL),(179,'items_collect','商品采集管理','add','添加来源','',0,'',0,1,6,0,1,0,0,NULL),(180,'items_collect','商品采集管理','delete','删除来源','',0,'',0,1,6,0,1,0,0,NULL),(182,'shop','商城管理','','','',0,'',399,0,7,0,0,0,0,NULL),(183,'shop','商城管理','index','商城列表','',0,'',0,1,7,0,0,0,0,NULL),(184,'shop','商城管理','add','添加商城','',0,'',0,1,7,0,0,0,0,NULL),(185,'shop','商城管理','edit','编辑商城','',0,'',0,1,7,0,1,0,0,NULL),(186,'shop','商城管理','delete','删除商城','',0,'',0,1,7,0,1,0,0,NULL),(187,'shop_cate','商城类别','','','',0,'',399,0,7,0,0,0,0,NULL),(188,'shop_cate','商城类别','index','类别列表','',0,'',0,1,7,0,0,0,0,NULL),(189,'shop_cate','商城类别','add','添加类别','',0,'',0,1,7,0,0,0,0,NULL),(190,'shop_cate','商城类别','edit','编辑类别','',0,'',0,1,7,0,1,0,0,NULL),(191,'shop_cate','商城类别','delete','删除类别','',0,'',0,1,7,0,1,0,0,NULL),(192,'user','会员管理','','','',0,'',399,0,8,0,0,0,0,NULL),(193,'user','会员管理','index','会员列表','',0,'',0,1,8,0,0,0,0,NULL),(194,'user','会员管理','delete','删除','',0,'',0,1,8,0,1,0,0,NULL),(195,'items','商品管理','poster','海报管理','',1,'',8,1,4,0,0,0,0,NULL),(197,'setting','网站设置','index','第三方登录','type=oauth',0,'',0,1,1,0,0,0,0,NULL),(198,'seo','SEO管理','rewrite','伪静态设置','',0,'',0,1,29,0,0,0,0,NULL),(199,'setting','网站设置','index','关注我们','type=guanzhu',0,'',0,1,1,0,0,0,0,NULL),(200,'album','专辑管理','','','',0,'',399,0,8,0,0,0,0,NULL),(201,'album','专辑管理','index','专辑列表','',0,'',0,1,8,0,0,0,0,NULL),(202,'album','专辑管理','edit','编辑专辑','',0,'',0,2,8,0,0,0,0,NULL),(203,'album','专辑管理','delete','删除专辑','',0,'',0,2,8,0,0,0,0,NULL),(204,'album_cate','专辑分类管理','index','分类列表','',0,'',0,1,8,0,0,0,0,NULL),(205,'album_cate','专辑分类管理','add','添加分类','',0,'',0,1,8,0,0,0,0,NULL),(206,'album_cate','专辑分类管理','edit','编辑分类','',0,'',0,2,8,0,0,0,0,NULL),(207,'album_cate','专辑分类管理','delete','删除分类','',0,'',0,2,8,0,0,0,0,NULL),(208,'database','数据库管理','','','',0,'',0,0,29,0,0,0,0,NULL),(209,'database','数据库管理','execute','执行','',0,'',0,1,29,0,0,0,0,NULL),(210,'group','菜单分类管理','','','',0,'菜单分类管理',10,0,1,0,0,0,0,NULL),(211,'group','菜单分类管理','index','分类列表','',0,'',0,1,1,0,0,0,0,NULL),(212,'public','起始页','','','',0,'',0,0,9,0,0,0,0,NULL),(213,'public','起始页','main','后台首页','',0,'',0,1,9,0,0,0,0,NULL),(214,'exchange_goods','积分商品管理','','','',0,'',0,0,8,0,0,0,0,NULL),(215,'exchange_goods','积分商品管理','index','商品列表','',0,'',0,1,8,0,0,0,0,NULL),(216,'exchange_goods','积分商品管理','add','增加商品','',0,'',0,1,8,0,0,0,0,NULL),(217,'word_cate','屏蔽关键词','','','',0,'',0,0,29,0,0,0,0,NULL),(218,'word_cate','屏蔽分类','index','分类列表','',0,'',0,1,29,0,0,0,0,NULL),(219,'items_collect','商品采集','miaoapi','59秒api设置','',0,'',5,1,6,0,0,0,0,NULL),(220,'miao_order','订单管理','','','',0,'',0,0,4,0,0,0,0,NULL),(221,'miao_order','订单管理','getorder','获取b2c订单','',0,'',2,1,4,0,0,0,0,NULL),(222,'cash_back_log','用户收支管理','','','',0,'',0,0,28,0,0,0,0,NULL),(223,'cash_back_log','用户收支管理','index','收支记录列表','',0,'',0,1,28,0,0,0,0,NULL),(224,'user_tixian','提现管理','','','',0,'',0,0,28,0,0,0,0,NULL),(225,'user_tixian','提现管理','index','提现列表','',0,'',0,1,28,0,0,0,0,NULL),(226,'miao_order','订单管理','index','订单列表','',0,'',1,1,4,0,0,0,0,NULL),(227,'word','屏蔽关键词','','','',0,'',0,0,29,0,0,0,0,NULL),(228,'word','屏蔽关键词','index','关键词列表','',0,'',0,1,29,0,0,0,0,NULL),(233,'seller_cate','商家分类管理','index','分类列表','',0,'',0,1,27,0,0,0,0,NULL),(232,'seller_cate','商家分类管理','','','',0,'',0,0,27,0,0,0,0,NULL),(231,'user','会员管理','setscore','积分设置','',0,'',0,1,8,0,0,0,0,NULL),(234,'seller_cate','商家分类管理','delete','删除分类','',0,'',0,2,6,0,0,0,0,NULL),(235,'seller_cate','商家分类管理','edit','编辑分类','',0,'',0,2,27,0,0,0,0,NULL),(236,'seller_cate','商家分类管理','add','增加分类','',0,'',0,2,27,0,0,0,0,NULL),(237,'seller_list','商家管理','','','',0,'',0,0,27,0,0,0,0,NULL),(238,'seller_list','商家管理','index','商家列表','',0,'',0,1,27,0,0,0,0,NULL),(239,'seller_list','商家管理','add','增加商家','',0,'',0,2,27,0,0,0,0,NULL),(240,'seller_list','增加商家','delete','删除商家','',0,'',0,2,6,0,0,0,0,NULL),(241,'group','菜单分类管理','add','增加分类','',0,'',0,2,1,0,0,0,0,NULL),(242,'group','菜单分类管理','edit','编辑分类','',0,'',0,2,1,0,0,0,0,NULL),(243,'group','菜单分类管理','delete','删除分类','',0,'',0,2,1,0,0,0,0,NULL),(244,'exchange_order','积分订单管理','','','',0,'',0,0,8,0,0,0,0,NULL),(245,'exchange_order','积分订单管理','index','订单列表','',0,'',0,1,8,0,0,0,0,NULL),(246,'setting','网站设置','msg','短信设置','',0,'',0,1,1,0,0,0,0,NULL),(247,'message','短信息管理','index','短信息列表','',0,'',0,0,8,0,0,0,0,NULL),(248,'database','数据库管理','backup','数据库备份','',0,'',0,1,29,0,0,0,0,NULL),(249,'database','数据库管理','restore','数据库恢复','',0,'',0,1,29,0,0,0,0,NULL),(250,'items_cate','商品分类','import','导入分类','',0,'',0,1,4,0,0,0,0,NULL),(251,'items','商品管理','delete_search','一键删除','',0,'',0,1,4,0,0,0,0,NULL),(252,'banspider','屏蔽蜘蛛管理','','','',0,'',0,0,29,0,0,0,0,NULL),(253,'banspider','屏蔽蜘蛛管理','index','屏蔽蜘蛛','',0,'',0,1,29,0,0,0,0,NULL),(254,'banip','屏蔽Ip管理','','','',0,'',0,0,29,0,0,0,0,NULL),(255,'banip','屏蔽Ip管理','index','屏蔽ip','',0,'',0,1,29,0,0,0,0,NULL),(266,'miao_order','订单管理','get_tao_order','获取淘宝订单','',0,'',3,1,4,0,0,0,0,NULL),(257,'seo','seo管理','index','SEO管理','',0,'',0,1,29,0,0,0,0,NULL),(259,'seo','网站地图','sitemap','网站地图','',0,'',0,1,29,0,0,0,0,NULL),(260,'seo','SEO管理','','','',0,'',0,0,29,0,0,0,0,NULL),(261,'focus','焦点图管理','index','焦点图列表','',0,'',0,1,4,0,0,0,0,NULL),(262,'focus','焦点图管理','add','增加焦点图','',0,'',0,1,4,0,0,0,0,NULL),(263,'ucenter','Ucenter设置','','','',0,'',0,1,29,0,0,0,0,NULL),(264,'ucenter','Ucenter设置','setucenter','Ucenter设置','',0,'',0,1,29,0,0,0,0,NULL),(265,'items_collect','商品采集','taobaoapi','淘宝Api设置','',0,'',4,1,6,0,0,0,0,NULL),(267,'items_collect','商品采集','collect_comments','评论采集','',0,'',1,0,6,0,0,0,0,NULL),(268,'cash_setting','返利设置','','','',0,'',0,0,28,0,0,0,0,NULL),(269,'cash_setting','返利设置','index','返利设置','',0,'',0,1,28,0,0,0,0,NULL),(270,'items_cate','商品分类','add_all','批量添加','',0,'',0,1,4,0,0,0,0,NULL),(271,'user','会员管理','add_all','批量添加','',0,'',0,1,8,0,0,0,0,NULL),(272,'items_collect','商品采集','set_collect_cate','一键采集分类','',0,'',2,1,6,0,0,0,0,NULL),(273,'items_collect','商品采集','wegoapi','微购api设置','',0,'',3,1,6,0,0,0,0,NULL),(274,'activity','活动管理','index','活动列表','',0,'',0,1,4,0,0,0,0,NULL),(275,'activity','活动管理','add','添加活动','',0,'',0,1,4,0,0,0,0,NULL),(276,'activity','活动管理','edit','编辑活动','',0,'',0,2,4,0,0,0,0,NULL),(277,'activity','活动管理','delete','删除活动','',0,'',0,2,4,0,0,0,0,NULL),(278,'analyse','数据分析','index','数据分析','type=1',1,'机构销售业绩 机构销售业绩',13,1,4,0,0,0,0,NULL),(279,'analyse','数据分析','','','',1,'',13,0,4,0,0,0,0,NULL),(280,'contract','合同管理','','','',1,'',1,0,4,0,0,0,0,NULL),(281,'contract','合同管理','index','合同管理','',1,'合同列表',0,1,4,0,0,0,0,NULL),(282,'contract','合同管理','add','添加合同','',0,'',0,2,4,0,0,0,0,NULL),(283,'contract','合同管理','delete','删除合同','',0,'',0,2,4,0,0,0,0,NULL),(284,'contract','合同管理','edit','编辑导航','',0,'',0,2,4,0,0,0,0,NULL),(285,'analyse','数据分析','index','机构销售佣金','type=2',0,'机构销售佣金收益',13,1,4,0,0,0,0,NULL),(286,'analyse','数据分析','index','热销商品','type=3',0,'热销商品',13,1,4,0,0,0,0,NULL),(287,'admin','管理员管理','pwd','账号管理','',1,'修改密码',99,1,1,0,0,0,0,NULL),(288,'finance','财务相关','','','',1,'',9,0,4,0,0,0,0,NULL),(289,'finance','财务相关','commission','佣金管理','',1,'',12,1,4,0,0,0,0,NULL),(290,'finance','财务相关','finance','财务管理','',1,'',9,1,4,0,0,0,0,NULL),(291,'finance','财务相关','push','推广管理','',1,'',11,1,4,0,0,0,0,NULL),(292,'finance','财务相关','settle','结算管理','',1,'',15,1,4,0,0,0,0,NULL),(293,'article','公告管理','view','联盟公告',NULL,0,'公告列表',3,1,4,0,0,0,0,NULL),(294,'contract','合同管理','log','日志管理',NULL,1,'日志管理',0,1,4,0,0,0,0,NULL);
/*!40000 ALTER TABLE `cps_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_op_log`
--

DROP TABLE IF EXISTS `cps_op_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_op_log` (
  `log_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(40) DEFAULT NULL,
  `op_time` datetime DEFAULT NULL,
  `op` varchar(66) DEFAULT NULL COMMENT '操作：增加、修改、删除、审核、回复',
  `op_object` varchar(256) DEFAULT NULL COMMENT '操作对象',
  `op_desc` text COMMENT '操作内容',
  `sql` text COMMENT '执行的sql语句 add update insert delete',
  `product` int(11) unsigned DEFAULT '0' COMMENT '商品id',
  `data_state` char(1) DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  `score` int(10) DEFAULT '0' COMMENT '所需积分',
  `user` int(10) unsigned DEFAULT '0' COMMENT '用户',
  `app` int(11) DEFAULT NULL COMMENT '活动',
  `status` char(1) DEFAULT '1' COMMENT '数据状态：2成功，1审核中',
  `remark` varchar(255) DEFAULT NULL,
  `reply_time` datetime DEFAULT NULL COMMENT '审核时间',
  `ip` varchar(64) DEFAULT NULL COMMENT 'ip',
  `op_table` varchar(256) DEFAULT NULL COMMENT '操作的表',
  `uid` bigint(40) unsigned NOT NULL,
  `op_time2` int(11) DEFAULT NULL,
  `op_content` varchar(256) DEFAULT NULL COMMENT '操作对象',
  `user_id` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COMMENT='5.2.12合同日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_op_log`
--

LOCK TABLES `cps_op_log` WRITE;
/*!40000 ALTER TABLE `cps_op_log` DISABLE KEYS */;
INSERT INTO `cps_op_log` VALUES (28,'admin','2017-09-02 13:48:14','添加','用户_民生商城','{\"user_name\":\"mingshengshangcheng\",\"user_id\":\"\\u6c11\\u751f\\u5546\\u57ce\",\"mobile\":\"18999999999\",\"address\":\"\\u6c11\\u751f\\u5546\\u57ce\",\"email\":\"ms@qq.com\",\"account\":\"ms@qq.com\",\"role_id\":\"3\",\"pid\":\"0\",\"status\":\"1\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\"}','INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`address`,`email`,`account`,`role_id`,`pid`,`status`,`password`,`add_time`,`last_time`) VALUES (\'mingshengshangcheng\',\'民生商城\',\'18999999999\',\'民生商城\',\'ms@qq.com\',\'ms@qq.com\',3,0,1,\'dc483e80a7a0bd9ef71d8cf973673924\',1504331294,1504331294)',0,NULL,0,NULL,0,'0',NULL,NULL,'120.41.220.107','admin',1,NULL,'添加用户_民生商城','cps平台'),(29,'admin','2017-09-02 13:48:56','添加','用户_北京分行','{\"user_name\":\"beijingfenghang\",\"user_id\":\"\\u5317\\u4eac\\u5206\\u884c\",\"mobile\":\"18999999999\",\"address\":\"\\u5317\\u4eac\\u5206\\u884c\",\"email\":\"bj@qq.com\",\"account\":\"bj123@qq.com\",\"role_id\":\"4\",\"pid\":\"0\",\"status\":\"1\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\"}','INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`address`,`email`,`account`,`role_id`,`pid`,`status`,`password`,`add_time`,`last_time`) VALUES (\'beijingfenghang\',\'北京分行\',\'18999999999\',\'北京分行\',\'bj@qq.com\',\'bj123@qq.com\',4,0,1,\'dc483e80a7a0bd9ef71d8cf973673924\',1504331336,1504331336)',0,NULL,0,NULL,0,'0',NULL,NULL,'120.41.220.107','admin',1,NULL,'添加用户_北京分行','cps平台'),(30,'admin','2017-09-02 13:49:50','添加','合同','{\"id\":\"\",\"con_id\":\"c1001\",\"con_type\":\"3\",\"shop_id\":\"11\",\"period\":\"1\",\"platform_id\":\"1\",\"begin_time\":1504281600,\"end_time\":\"1535817600\",\"period_account\":\"60\",\"freight\":\"8\",\"title\":\"\\u6c11\\u751f\\u5546\\u57ce\\u5408\\u540c\",\"dosubmit\":\"1\",\"uid\":\"1\",\"update_time\":1504331390,\"add_time\":1504331390}','INSERT INTO `cps_contract` (`id`,`con_id`,`con_type`,`shop_id`,`period`,`platform_id`,`begin_time`,`end_time`,`period_account`,`freight`,`title`,`uid`,`update_time`,`add_time`) VALUES (0,\'c1001\',\'3\',\'11\',\'1\',1,1504281600,\'1535817600\',\'60\',\'8\',\'民生商城合同\',1,1504331390,1504331390)',0,NULL,0,NULL,0,'0',NULL,NULL,'120.41.220.107','contract',1,NULL,'添加合同','cps平台'),(31,'admin','2017-09-02 14:06:49','修改','合同（导入商品佣金）','{\"id\":\"3\",\"shop_id\":\"11\",\"contract\":\"\\u6c11\\u751f\\u5546\\u57ce\\u5408\\u540c\",\"platform_id\":\"1\",\"dosubmit\":\"2\"}','[\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (11,\'\\u6c11\\u751f\\u5546\\u57ce\\u5408\\u540c\',1,200,20,0.002,\'\\u7f8e\\u5986\\u4e2a\\u62a4\',\'\\u7f8e\\u5986\\u4e2a\\u62a4\',0.01,\'Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\',\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\',\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\',\'3\',1,\'1\',1504332409,1504332409)\",\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (11,\'\\u6c11\\u751f\\u5546\\u57ce\\u5408\\u540c\',1,199,15,539.85,\'\\u624b\\u673a\',\'\\u624b\\u673a\',3599,\'\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\',\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\',\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\',\'3\',1,\'1\',1504332409,1504332409)\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'120.41.220.107','',1,NULL,'修改合同（导入商品佣金）','cps平台'),(32,'admin','2017-09-02 14:06:49','修改','合同（导入商品内容）','[{\"shop_id\":11,\"contract\":\"\\u6c11\\u751f\\u5546\\u57ce\\u5408\\u540c\",\"platform_id\":\"1\",\"dosubmit\":\"2\",\"item_id\":200,\"rate\":20,\"commission\":0.002,\"cate_name\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"cate_id\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"cid\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"price\":0.01,\"title\":\"Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\",\"img\":\"http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\",\"url\":\"http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\",\"con_id\":\"3\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1504332409,\"add_time\":1504332409,\"name\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\"},{\"shop_id\":11,\"contract\":\"\\u6c11\\u751f\\u5546\\u57ce\\u5408\\u540c\",\"platform_id\":\"1\",\"dosubmit\":\"2\",\"item_id\":199,\"rate\":15,\"commission\":539.85,\"cate_name\":\"\\u624b\\u673a\",\"cate_id\":\"\\u624b\\u673a\",\"cid\":\"\\u624b\\u673a\",\"price\":3599,\"title\":\"\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\",\"img\":\"http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\",\"url\":\"http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\",\"con_id\":\"3\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1504332409,\"add_time\":1504332409,\"name\":\"\\u624b\\u673a\"}]','[\"INSERT INTO `cps_items` (`shop_id`,`item_id`,`cate_name`,`cid`,`price`,`title`,`img`,`url`,`uid`,`update_time`,`add_time`) VALUES (11,200,\'\\u7f8e\\u5986\\u4e2a\\u62a4\',0,0.01,\'Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\',\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\',\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\',1,1504332409,1504332409)\",\"INSERT INTO `cps_items` (`shop_id`,`item_id`,`cate_name`,`cid`,`price`,`title`,`img`,`url`,`uid`,`update_time`,`add_time`) VALUES (11,199,\'\\u624b\\u673a\',0,3599,\'\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\',\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\',\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\',1,1504332409,1504332409)\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'120.41.220.107','',1,NULL,'修改合同（导入商品内容）','cps平台'),(33,'admin','2017-09-02 14:11:07','添加','合同','{\"id\":\"\",\"con_id\":\"b1001\",\"con_type\":\"4\",\"shop_id\":\"1\",\"period\":\"1\",\"platform_id\":\"12\",\"begin_time\":1504281600,\"end_time\":\"1535817600\",\"period_account\":\"60\",\"freight\":\"12\",\"title\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"dosubmit\":\"1\",\"uid\":\"1\",\"update_time\":1504332667,\"add_time\":1504332667}','INSERT INTO `cps_contract` (`id`,`con_id`,`con_type`,`shop_id`,`period`,`platform_id`,`begin_time`,`end_time`,`period_account`,`freight`,`title`,`uid`,`update_time`,`add_time`) VALUES (0,\'b1001\',\'4\',\'1\',\'1\',12,1504281600,\'1535817600\',\'60\',\'12\',\'北京分行合同\',1,1504332667,1504332667)',0,NULL,0,NULL,0,'0',NULL,NULL,'120.41.220.107','contract',1,NULL,'添加合同','cps平台'),(34,'admin','2017-09-02 14:11:55','修改','合同（导入商品佣金）','{\"id\":\"4\",\"shop_id\":\"1\",\"contract\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"12\",\"dosubmit\":\"2\"}','[\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (11,\'\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\',12,200,20,0.002,\'\\u7f8e\\u5986\\u4e2a\\u62a4\',\'\\u7f8e\\u5986\\u4e2a\\u62a4\',0.01,\'Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\',\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\',\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\',\'4\',1,\'1\',1504332715,1504332715)\",\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (11,\'\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\',12,199,15,539.85,\'\\u624b\\u673a\',\'\\u624b\\u673a\',3599,\'\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\',\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\',\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\',\'4\',1,\'1\',1504332715,1504332715)\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'120.41.220.107','',1,NULL,'修改合同（导入商品佣金）','cps平台'),(35,'admin','2017-09-02 14:11:55','修改','合同（导入商品内容）','[{\"shop_id\":11,\"contract\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":200,\"rate\":20,\"commission\":0.002,\"cate_name\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"cate_id\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"cid\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"price\":0.01,\"title\":\"Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\",\"img\":\"http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\",\"url\":\"http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\",\"con_id\":\"4\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1504332715,\"add_time\":1504332715},{\"shop_id\":11,\"contract\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":199,\"rate\":15,\"commission\":539.85,\"cate_name\":\"\\u624b\\u673a\",\"cate_id\":\"\\u624b\\u673a\",\"cid\":\"\\u624b\\u673a\",\"price\":3599,\"title\":\"\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\",\"img\":\"http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\",\"url\":\"http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\",\"con_id\":\"4\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1504332715,\"add_time\":1504332715}]','[\"UPDATE `cps_items` SET `shop_id`=11,`item_id`=200,`cate_name`=\'\\u7f8e\\u5986\\u4e2a\\u62a4\',`cid`=0,`price`=0.01,`title`=\'Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\',`img`=\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\',`url`=\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\',`uid`=1,`update_time`=1504332715,`add_time`=1504332715 WHERE (   item_id=\'200\'  AND  shop_id=11  )\",\"UPDATE `cps_items` SET `shop_id`=11,`item_id`=199,`cate_name`=\'\\u624b\\u673a\',`cid`=0,`price`=3599,`title`=\'\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\',`img`=\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\',`url`=\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\',`uid`=1,`update_time`=1504332715,`add_time`=1504332715 WHERE (   item_id=\'199\'  AND  shop_id=11  )\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'120.41.220.107','',1,NULL,'修改合同（导入商品内容）','cps平台'),(36,'admin','2017-09-02 14:12:30','修改','合同（导入商品佣金）','{\"id\":\"4\",\"shop_id\":\"1\",\"contract\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"12\",\"dosubmit\":\"2\"}','[\"UPDATE `cps_commission` SET `shop_id`=11,`contract`=\'\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\',`platform_id`=12,`item_id`=200,`rate`=18,`commission`=0.0018,`cate_name`=\'\\u7f8e\\u5986\\u4e2a\\u62a4\',`cate_id`=\'\\u7f8e\\u5986\\u4e2a\\u62a4\',`price`=0.01,`title`=\'Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\',`img`=\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\',`url`=\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\',`con_id`=\'4\',`uid`=1,`role_id`=\'1\',`update_time`=1504332750,`add_time`=1504332750 WHERE ( platform_id=12 AND  role_id=1 AND   item_id=\'200\'  AND  shop_id=11  )\",\"UPDATE `cps_commission` SET `shop_id`=11,`contract`=\'\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\',`platform_id`=12,`item_id`=199,`rate`=15,`commission`=539.85,`cate_name`=\'\\u624b\\u673a\',`cate_id`=\'\\u624b\\u673a\',`price`=3599,`title`=\'\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\',`img`=\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\',`url`=\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\',`con_id`=\'4\',`uid`=1,`role_id`=\'1\',`update_time`=1504332750,`add_time`=1504332750 WHERE ( platform_id=12 AND  role_id=1 AND   item_id=\'199\'  AND  shop_id=11  )\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'120.41.220.107','',1,NULL,'修改合同（导入商品佣金）','cps平台'),(37,'admin','2017-09-02 14:12:30','修改','合同（导入商品内容）','[{\"shop_id\":11,\"contract\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":200,\"rate\":18,\"commission\":0.0018,\"cate_name\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"cate_id\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"cid\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"price\":0.01,\"title\":\"Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\",\"img\":\"http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\",\"url\":\"http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\",\"con_id\":\"4\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1504332750,\"add_time\":1504332750},{\"shop_id\":11,\"contract\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":199,\"rate\":15,\"commission\":539.85,\"cate_name\":\"\\u624b\\u673a\",\"cate_id\":\"\\u624b\\u673a\",\"cid\":\"\\u624b\\u673a\",\"price\":3599,\"title\":\"\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\",\"img\":\"http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\",\"url\":\"http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\",\"con_id\":\"4\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1504332750,\"add_time\":1504332750}]','[\"UPDATE `cps_items` SET `shop_id`=11,`item_id`=200,`cate_name`=\'\\u7f8e\\u5986\\u4e2a\\u62a4\',`cid`=0,`price`=0.01,`title`=\'Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\',`img`=\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\',`url`=\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\',`uid`=1,`update_time`=1504332750,`add_time`=1504332750 WHERE (   item_id=\'200\'  AND  shop_id=11  )\",\"UPDATE `cps_items` SET `shop_id`=11,`item_id`=199,`cate_name`=\'\\u624b\\u673a\',`cid`=0,`price`=3599,`title`=\'\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\',`img`=\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\',`url`=\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\',`uid`=1,`update_time`=1504332750,`add_time`=1504332750 WHERE (   item_id=\'199\'  AND  shop_id=11  )\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'120.41.220.107','',1,NULL,'修改合同（导入商品内容）','cps平台'),(38,'admin','2017-09-02 14:13:42','修改','合同（导入商品佣金）','{\"id\":\"4\",\"shop_id\":\"1\",\"contract\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"12\",\"dosubmit\":\"2\"}','[\"UPDATE `cps_commission` SET `shop_id`=11,`contract`=\'\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\',`platform_id`=12,`item_id`=200,`rate`=20,`commission`=0.002,`cate_name`=\'\\u7f8e\\u5986\\u4e2a\\u62a4\',`cate_id`=\'\\u7f8e\\u5986\\u4e2a\\u62a4\',`price`=0.01,`title`=\'Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\',`img`=\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\',`url`=\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\',`con_id`=\'4\',`uid`=1,`role_id`=\'1\',`update_time`=1504332822,`add_time`=1504332822 WHERE ( platform_id=12 AND  role_id=1 AND   item_id=\'200\'  AND  shop_id=11  )\",\"UPDATE `cps_commission` SET `shop_id`=11,`contract`=\'\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\',`platform_id`=12,`item_id`=199,`rate`=15,`commission`=539.85,`cate_name`=\'\\u624b\\u673a\',`cate_id`=\'\\u624b\\u673a\',`price`=3599,`title`=\'\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\',`img`=\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\',`url`=\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\',`con_id`=\'4\',`uid`=1,`role_id`=\'1\',`update_time`=1504332822,`add_time`=1504332822 WHERE ( platform_id=12 AND  role_id=1 AND   item_id=\'199\'  AND  shop_id=11  )\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'120.41.220.107','',1,NULL,'修改合同（导入商品佣金）','cps平台'),(39,'admin','2017-09-02 14:13:42','修改','合同（导入商品内容）','[{\"shop_id\":11,\"contract\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":200,\"rate\":20,\"commission\":0.002,\"cate_name\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"cate_id\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"cid\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"price\":0.01,\"title\":\"Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\",\"img\":\"http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\",\"url\":\"http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\",\"con_id\":\"4\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1504332822,\"add_time\":1504332822},{\"shop_id\":11,\"contract\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":199,\"rate\":15,\"commission\":539.85,\"cate_name\":\"\\u624b\\u673a\",\"cate_id\":\"\\u624b\\u673a\",\"cid\":\"\\u624b\\u673a\",\"price\":3599,\"title\":\"\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\",\"img\":\"http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\",\"url\":\"http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\",\"con_id\":\"4\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1504332822,\"add_time\":1504332822}]','[\"UPDATE `cps_items` SET `shop_id`=11,`item_id`=200,`cate_name`=\'\\u7f8e\\u5986\\u4e2a\\u62a4\',`cid`=0,`price`=0.01,`title`=\'Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\',`img`=\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\',`url`=\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\',`uid`=1,`update_time`=1504332822,`add_time`=1504332822 WHERE (   item_id=\'200\'  AND  shop_id=11  )\",\"UPDATE `cps_items` SET `shop_id`=11,`item_id`=199,`cate_name`=\'\\u624b\\u673a\',`cid`=0,`price`=3599,`title`=\'\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\',`img`=\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\',`url`=\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\',`uid`=1,`update_time`=1504332822,`add_time`=1504332822 WHERE (   item_id=\'199\'  AND  shop_id=11  )\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'120.41.220.107','',1,NULL,'修改合同（导入商品内容）','cps平台'),(40,'beijingfenghang','2017-09-02 14:20:04','修改','合同（导入商品佣金）','{\"id\":\"\",\"shop_id\":\"\",\"contract\":\"\",\"platform_id\":\"\",\"dosubmit\":\"2\"}','[\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (11,\'\',12,199,10,359.9,\'\\u624b\\u673a\',\'\\u624b\\u673a\',3599,\'\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\',\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\',\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\',\'\',12,\'4\',1504333204,1504333204)\",\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (11,\'\',12,200,100,0.01,\'\\u7f8e\\u5986\\u4e2a\\u62a4\',\'\\u7f8e\\u5986\\u4e2a\\u62a4\',0.01,\'Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\',\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\',\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\',\'\',12,\'4\',1504333204,1504333204)\",\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (\'\',\'\',12,null,null,null,null,null,null,null,null,null,\'\',12,\'4\',1504333204,1504333204)\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'120.41.220.107','',12,NULL,'修改合同（导入商品佣金）','北京分行'),(41,'beijingfenghang','2017-09-02 14:20:04','修改','合同（导入商品内容）','[{\"shop_id\":11,\"contract\":\"\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":199,\"rate\":10,\"commission\":359.9,\"cate_name\":\"\\u624b\\u673a\",\"cate_id\":\"\\u624b\\u673a\",\"cid\":\"\\u624b\\u673a\",\"price\":3599,\"title\":\"\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\",\"img\":\"http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\",\"url\":\"http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\",\"con_id\":\"\",\"uid\":\"12\",\"role_id\":\"4\",\"update_time\":1504333204,\"add_time\":1504333204},{\"shop_id\":11,\"contract\":\"\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":200,\"rate\":100,\"commission\":0.01,\"cate_name\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"cate_id\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"cid\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"price\":0.01,\"title\":\"Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\",\"img\":\"http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\",\"url\":\"http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\",\"con_id\":\"\",\"uid\":\"12\",\"role_id\":\"4\",\"update_time\":1504333204,\"add_time\":1504333204},{\"shop_id\":\"\",\"contract\":\"\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":null,\"rate\":null,\"commission\":null,\"cate_name\":null,\"cate_id\":null,\"cid\":null,\"price\":null,\"title\":null,\"img\":null,\"url\":null,\"con_id\":\"\",\"uid\":\"12\",\"role_id\":\"4\",\"update_time\":1504333204,\"add_time\":1504333204,\"name\":null}]','[\"UPDATE `cps_items` SET `shop_id`=11,`item_id`=199,`cate_name`=\'\\u624b\\u673a\',`cid`=0,`price`=3599,`title`=\'\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\',`img`=\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\',`url`=\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\',`uid`=12,`update_time`=1504333204,`add_time`=1504333204 WHERE (   item_id=\'199\'  AND  shop_id=11  )\",\"UPDATE `cps_items` SET `shop_id`=11,`item_id`=200,`cate_name`=\'\\u7f8e\\u5986\\u4e2a\\u62a4\',`cid`=0,`price`=0.01,`title`=\'Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\',`img`=\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\',`url`=\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\',`uid`=12,`update_time`=1504333204,`add_time`=1504333204 WHERE (   item_id=\'200\'  AND  shop_id=11  )\",\"INSERT INTO `cps_items` (`shop_id`,`item_id`,`cate_name`,`cid`,`price`,`title`,`img`,`url`,`uid`,`update_time`,`add_time`) VALUES (0,null,null,null,null,null,null,null,12,1504333204,1504333204)\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'120.41.220.107','',12,NULL,'修改合同（导入商品内容）','北京分行'),(42,'beijingfenghang','2017-09-02 14:22:26','批量添加','用户','[{\"dosubmit\":\"2\",\"user_name\":\"zhangsan\",\"user_id\":\"\\u660c\\u5e73\\u652f\\u884c\",\"mobile\":\" 18958222222\",\"email\":\" bank_sub_xm@qq.com\",\"account\":\" bank_sub_xm@qq.com\",\"address\":\"\\u660c\\u5e73\\u652f\\u884c\",\"role_id\":5,\"pid\":\"12\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\",\"data_state\":1,\"status\":1,\"ip\":\"120.41.220.107\",\"update_time\":1504333346,\"last_time\":1504333346,\"add_time\":1504333346},{\"dosubmit\":\"2\",\"user_name\":\"chaoyang\",\"user_id\":\"\\u671d\\u9633\\u652f\\u884c\",\"mobile\":\" 18999990000\",\"email\":\" bank_sub_xm@qq.com\",\"account\":\" bank_sub_xm@qq.com\",\"address\":\"\\u671d\\u9633\\u652f\\u884c\",\"role_id\":5,\"pid\":\"12\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\",\"data_state\":1,\"status\":1,\"ip\":\"120.41.220.107\",\"update_time\":1504333346,\"last_time\":1504333346,\"add_time\":1504333346},{\"dosubmit\":\"2\",\"user_name\":\"xicheng\",\"user_id\":\"\\u897f\\u57ce\\u652f\\u884c\",\"mobile\":\" 18989898989\",\"email\":\" bank_sub_xm@qq.com\",\"account\":\" bank_sub_xm@qq.com\",\"address\":\"\\u897f\\u57ce\\u652f\\u884c\",\"role_id\":5,\"pid\":\"12\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\",\"data_state\":1,\"status\":1,\"ip\":\"120.41.220.107\",\"update_time\":1504333346,\"last_time\":1504333346,\"add_time\":1504333346},{\"dosubmit\":\"2\",\"user_name\":\"haidian\",\"user_id\":\"\\u6d77\\u6dc0\\u652f\\u884c\",\"mobile\":\" 18989898989\",\"email\":\" bank_sub_xm@qq.com\",\"account\":\" bank_sub_xm@qq.com\",\"address\":\"\\u6d77\\u6dc0\\u652f\\u884c\",\"role_id\":5,\"pid\":\"12\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\",\"data_state\":1,\"status\":1,\"ip\":\"120.41.220.107\",\"update_time\":1504333346,\"last_time\":1504333346,\"add_time\":1504333346}]','[\"INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`email`,`account`,`address`,`role_id`,`pid`,`password`,`data_state`,`status`,`ip`,`update_time`,`last_time`,`add_time`) VALUES (\'zhangsan\',\'\\u660c\\u5e73\\u652f\\u884c\',\' 18958222222\',\' bank_sub_xm@qq.com\',\' bank_sub_xm@qq.com\',\'\\u660c\\u5e73\\u652f\\u884c\',5,12,\'dc483e80a7a0bd9ef71d8cf973673924\',1,1,\'120.41.220.107\',1504333346,1504333346,1504333346)\",\"INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`email`,`account`,`address`,`role_id`,`pid`,`password`,`data_state`,`status`,`ip`,`update_time`,`last_time`,`add_time`) VALUES (\'chaoyang\',\'\\u671d\\u9633\\u652f\\u884c\',\' 18999990000\',\' bank_sub_xm@qq.com\',\' bank_sub_xm@qq.com\',\'\\u671d\\u9633\\u652f\\u884c\',5,12,\'dc483e80a7a0bd9ef71d8cf973673924\',1,1,\'120.41.220.107\',1504333346,1504333346,1504333346)\",\"INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`email`,`account`,`address`,`role_id`,`pid`,`password`,`data_state`,`status`,`ip`,`update_time`,`last_time`,`add_time`) VALUES (\'xicheng\',\'\\u897f\\u57ce\\u652f\\u884c\',\' 18989898989\',\' bank_sub_xm@qq.com\',\' bank_sub_xm@qq.com\',\'\\u897f\\u57ce\\u652f\\u884c\',5,12,\'dc483e80a7a0bd9ef71d8cf973673924\',1,1,\'120.41.220.107\',1504333346,1504333346,1504333346)\",\"INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`email`,`account`,`address`,`role_id`,`pid`,`password`,`data_state`,`status`,`ip`,`update_time`,`last_time`,`add_time`) VALUES (\'haidian\',\'\\u6d77\\u6dc0\\u652f\\u884c\',\' 18989898989\',\' bank_sub_xm@qq.com\',\' bank_sub_xm@qq.com\',\'\\u6d77\\u6dc0\\u652f\\u884c\',5,12,\'dc483e80a7a0bd9ef71d8cf973673924\',1,1,\'120.41.220.107\',1504333346,1504333346,1504333346)\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'120.41.220.107','admin',12,NULL,'批量添加用户','北京分行'),(43,'haidian','2017-09-02 14:26:04','批量添加','用户','[{\"dosubmit\":\"2\",\"user_name\":\"zhangsan\",\"user_id\":\"\\u5f20\\u4e09\",\"mobile\":\" 18958222222\",\"email\":\" bank_sub_xm@qq.com\",\"account\":\" bank_sub_xm@qq.com\",\"address\":\"\\u6d77\\u6dc0\\u652f\\u884c\",\"role_id\":6,\"pid\":\"16\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\",\"data_state\":1,\"status\":1,\"ip\":\"120.41.220.107\",\"update_time\":1504333564,\"last_time\":1504333564,\"add_time\":1504333564},{\"dosubmit\":\"2\",\"user_name\":\"lisi\",\"user_id\":\"\\u674e\\u56db\",\"mobile\":\" 18999990000\",\"email\":\" bank_sub_xm@qq.com\",\"account\":\" bank_sub_xm@qq.com\",\"address\":\"\\u6d77\\u6dc0\\u652f\\u884c\",\"role_id\":6,\"pid\":\"16\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\",\"data_state\":1,\"status\":1,\"ip\":\"120.41.220.107\",\"update_time\":1504333564,\"last_time\":1504333564,\"add_time\":1504333564}]','[\"SELECT * FROM `cps_admin` WHERE (  user_name=\'zhangsan\'  ) LIMIT 1  \",\"INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`email`,`account`,`address`,`role_id`,`pid`,`password`,`data_state`,`status`,`ip`,`update_time`,`last_time`,`add_time`) VALUES (\'lisi\',\'\\u674e\\u56db\',\' 18999990000\',\' bank_sub_xm@qq.com\',\' bank_sub_xm@qq.com\',\'\\u6d77\\u6dc0\\u652f\\u884c\',6,16,\'dc483e80a7a0bd9ef71d8cf973673924\',1,1,\'120.41.220.107\',1504333564,1504333564,1504333564)\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'120.41.220.107','admin',16,NULL,'批量添加用户','海淀支行'),(44,'admin','2017-09-03 16:10:11','添加','用户_福建分行','{\"user_name\":\"fujianfenhang\",\"user_id\":\"\\u798f\\u5efa\\u5206\\u884c\",\"mobile\":\"0592-23324343434\",\"address\":\"\\u53a6\\u95e8\",\"email\":\"179986365@qq.com\",\"account\":\"\",\"role_id\":\"4\",\"pid\":\"0\",\"status\":\"1\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\"}','INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`address`,`email`,`account`,`role_id`,`pid`,`status`,`password`,`add_time`,`last_time`) VALUES (\'fujianfenhang\',\'福建分行\',\'0592-23324343434\',\'厦门\',\'179986365@qq.com\',\'\',4,0,1,\'dc483e80a7a0bd9ef71d8cf973673924\',1504426211,1504426211)',0,NULL,0,NULL,0,'0',NULL,NULL,'219.143.150.29','admin',1,NULL,'添加用户_福建分行','cps平台'),(45,'admin','2017-09-03 16:11:47','添加','合同','{\"id\":\"\",\"con_id\":\"fjfh001\",\"con_type\":\"4\",\"shop_id\":\"1\",\"period\":\"1\",\"platform_id\":\"18\",\"begin_time\":1504368000,\"end_time\":\"1535904000\",\"period_account\":\"30\",\"freight\":\"0\",\"title\":\"\\u798f\\u5efa\\u5206\\u884c\\u5408\\u540c\",\"dosubmit\":\"1\",\"uid\":\"1\",\"update_time\":1504426307,\"add_time\":1504426307}','INSERT INTO `cps_contract` (`id`,`con_id`,`con_type`,`shop_id`,`period`,`platform_id`,`begin_time`,`end_time`,`period_account`,`freight`,`title`,`uid`,`update_time`,`add_time`) VALUES (0,\'fjfh001\',\'4\',\'1\',\'1\',18,1504368000,\'1535904000\',\'30\',\'0\',\'福建分行合同\',1,1504426307,1504426307)',0,NULL,0,NULL,0,'0',NULL,NULL,'219.143.150.29','contract',1,NULL,'添加合同','cps平台'),(46,'admin','2017-09-03 16:13:04','修改','合同（导入商品佣金）','{\"id\":\"5\",\"shop_id\":\"1\",\"contract\":\"\\u798f\\u5efa\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"18\",\"dosubmit\":\"2\"}','[\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (11,\'\\u798f\\u5efa\\u5206\\u884c\\u5408\\u540c\',18,23,20,165.8,\'\\u9996\\u9970\',\'\\u9996\\u9970\',829,\'\\u5948\\u552f \\u8db3\\u91d1\\u8f6c\\u8fd0\\u73e0\\u624b\\u94fe\',\'http:\\/\\/shop.adjyc.com\\/attachment\\/images\\/5\\/2017\\/07\\/k0FQlfuTs0rfsqtz707tuBHubyUtl0.jpg\',\'http:\\/\\/shop.adjyc.com\\/app\\/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=23\',\'5\',1,\'1\',1504426384,1504426384)\",\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (11,\'\\u798f\\u5efa\\u5206\\u884c\\u5408\\u540c\',18,28,10,418.8,\'\\u624b\\u673a\',\'\\u624b\\u673a\',4188,\'\\u534e\\u4e3a Mate9 \\u624b\\u673a (6GB+128GB)\',\'http:\\/\\/shop.adjyc.com\\/attachment\\/images\\/5\\/2017\\/08\\/jpm3sqxvMxq33S34Z3Amsx84XXTA32.jpg\',\'http:\\/\\/shop.adjyc.com\\/app\\/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=28\',\'5\',1,\'1\',1504426384,1504426384)\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'219.143.150.29','',1,NULL,'修改合同（导入商品佣金）','cps平台'),(47,'admin','2017-09-03 16:13:04','修改','合同（导入商品内容）','[{\"shop_id\":11,\"contract\":\"\\u798f\\u5efa\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"18\",\"dosubmit\":\"2\",\"item_id\":23,\"rate\":20,\"commission\":165.8,\"cate_name\":\"\\u9996\\u9970\",\"cate_id\":\"\\u9996\\u9970\",\"cid\":\"\\u9996\\u9970\",\"price\":829,\"title\":\"\\u5948\\u552f \\u8db3\\u91d1\\u8f6c\\u8fd0\\u73e0\\u624b\\u94fe\",\"img\":\"http:\\/\\/shop.adjyc.com\\/attachment\\/images\\/5\\/2017\\/07\\/k0FQlfuTs0rfsqtz707tuBHubyUtl0.jpg\",\"url\":\"http:\\/\\/shop.adjyc.com\\/app\\/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=23\",\"con_id\":\"5\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1504426384,\"add_time\":1504426384,\"name\":\"\\u9996\\u9970\"},{\"shop_id\":11,\"contract\":\"\\u798f\\u5efa\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"18\",\"dosubmit\":\"2\",\"item_id\":28,\"rate\":10,\"commission\":418.8,\"cate_name\":\"\\u624b\\u673a\",\"cate_id\":\"\\u624b\\u673a\",\"cid\":\"\\u624b\\u673a\",\"price\":4188,\"title\":\"\\u534e\\u4e3a Mate9 \\u624b\\u673a (6GB+128GB)\",\"img\":\"http:\\/\\/shop.adjyc.com\\/attachment\\/images\\/5\\/2017\\/08\\/jpm3sqxvMxq33S34Z3Amsx84XXTA32.jpg\",\"url\":\"http:\\/\\/shop.adjyc.com\\/app\\/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=28\",\"con_id\":\"5\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1504426384,\"add_time\":1504426384}]','[\"INSERT INTO `cps_items` (`shop_id`,`item_id`,`cate_name`,`cid`,`price`,`title`,`img`,`url`,`uid`,`update_time`,`add_time`) VALUES (11,23,\'\\u9996\\u9970\',0,829,\'\\u5948\\u552f \\u8db3\\u91d1\\u8f6c\\u8fd0\\u73e0\\u624b\\u94fe\',\'http:\\/\\/shop.adjyc.com\\/attachment\\/images\\/5\\/2017\\/07\\/k0FQlfuTs0rfsqtz707tuBHubyUtl0.jpg\',\'http:\\/\\/shop.adjyc.com\\/app\\/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=23\',1,1504426384,1504426384)\",\"INSERT INTO `cps_items` (`shop_id`,`item_id`,`cate_name`,`cid`,`price`,`title`,`img`,`url`,`uid`,`update_time`,`add_time`) VALUES (11,28,\'\\u624b\\u673a\',0,4188,\'\\u534e\\u4e3a Mate9 \\u624b\\u673a (6GB+128GB)\',\'http:\\/\\/shop.adjyc.com\\/attachment\\/images\\/5\\/2017\\/08\\/jpm3sqxvMxq33S34Z3Amsx84XXTA32.jpg\',\'http:\\/\\/shop.adjyc.com\\/app\\/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=28\',1,1504426384,1504426384)\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'219.143.150.29','',1,NULL,'修改合同（导入商品内容）','cps平台'),(48,'admin','2017-09-03 16:24:41','修改','合同（导入商品佣金）','{\"id\":\"4\",\"shop_id\":\"1\",\"contract\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"12\",\"dosubmit\":\"2\"}','[\"UPDATE `cps_commission` SET `shop_id`=11,`contract`=\'\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\',`platform_id`=12,`item_id`=199,`rate`=15,`commission`=539.85,`cate_name`=\'\\u624b\\u673a\',`cate_id`=\'\\u624b\\u673a\',`price`=3599,`title`=\'\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\',`img`=\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\',`url`=\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\',`con_id`=\'4\',`uid`=1,`role_id`=\'1\',`update_time`=1504427081,`add_time`=1504427081 WHERE ( platform_id=12 AND  role_id=1 AND   item_id=\'199\'  AND  shop_id=11  )\",\"UPDATE `cps_commission` SET `shop_id`=11,`contract`=\'\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\',`platform_id`=12,`item_id`=200,`rate`=20,`commission`=0.002,`cate_name`=\'\\u7f8e\\u5986\\u4e2a\\u62a4\',`cate_id`=\'\\u7f8e\\u5986\\u4e2a\\u62a4\',`price`=0.01,`title`=\'Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\',`img`=\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\',`url`=\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\',`con_id`=\'4\',`uid`=1,`role_id`=\'1\',`update_time`=1504427081,`add_time`=1504427081 WHERE ( platform_id=12 AND  role_id=1 AND   item_id=\'200\'  AND  shop_id=11  )\",\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (11,\'\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\',12,204,20,92,\'\\u9996\\u9970\',\'\\u9996\\u9970\',460,\'\\u683c\\u739b\\u4ed5 \\u97e9\\u7248\\u8d85\\u8584 \\u65f6\\u5c1a\\u6f6e\\u6d41\\u77f3\\u82f1\\u5973\\u5f0f\\u65f6\\u88c5\\u9576\\u6c34\\u94bb\\u8155\\u8868 [\\u73ab\\u91d1\\u82722105-CR-B2-DW]\',\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/V1yNIw1OErYwyliLlbtWe6oOyW6Ybb.jpg\',\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=204\',\'4\',1,\'1\',1504427081,1504427081)\",\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (\'1\',\'\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\',12,null,null,null,null,null,null,null,null,null,\'4\',1,\'1\',1504427081,1504427081)\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'219.143.150.29','',1,NULL,'修改合同（导入商品佣金）','cps平台'),(49,'admin','2017-09-03 16:24:41','修改','合同（导入商品内容）','[{\"shop_id\":11,\"contract\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":199,\"rate\":15,\"commission\":539.85,\"cate_name\":\"\\u624b\\u673a\",\"cate_id\":\"\\u624b\\u673a\",\"cid\":\"\\u624b\\u673a\",\"price\":3599,\"title\":\"\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\",\"img\":\"http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\",\"url\":\"http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\",\"con_id\":\"4\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1504427081,\"add_time\":1504427081},{\"shop_id\":11,\"contract\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":200,\"rate\":20,\"commission\":0.002,\"cate_name\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"cate_id\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"cid\":\"\\u7f8e\\u5986\\u4e2a\\u62a4\",\"price\":0.01,\"title\":\"Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\",\"img\":\"http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\",\"url\":\"http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\",\"con_id\":\"4\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1504427081,\"add_time\":1504427081},{\"shop_id\":11,\"contract\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":204,\"rate\":20,\"commission\":92,\"cate_name\":\"\\u9996\\u9970\",\"cate_id\":\"\\u9996\\u9970\",\"cid\":\"\\u9996\\u9970\",\"price\":460,\"title\":\"\\u683c\\u739b\\u4ed5 \\u97e9\\u7248\\u8d85\\u8584 \\u65f6\\u5c1a\\u6f6e\\u6d41\\u77f3\\u82f1\\u5973\\u5f0f\\u65f6\\u88c5\\u9576\\u6c34\\u94bb\\u8155\\u8868 [\\u73ab\\u91d1\\u82722105-CR-B2-DW]\",\"img\":\"http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/V1yNIw1OErYwyliLlbtWe6oOyW6Ybb.jpg\",\"url\":\"http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=204\",\"con_id\":\"4\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1504427081,\"add_time\":1504427081},{\"shop_id\":\"1\",\"contract\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":null,\"rate\":null,\"commission\":null,\"cate_name\":null,\"cate_id\":null,\"cid\":null,\"price\":null,\"title\":null,\"img\":null,\"url\":null,\"con_id\":\"4\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1504427081,\"add_time\":1504427081,\"name\":null}]','[\"UPDATE `cps_items` SET `shop_id`=11,`item_id`=199,`cate_name`=\'\\u624b\\u673a\',`cid`=0,`price`=3599,`title`=\'\\u534e\\u4e3a Mate 9 4GB+64GB\\u7248 \\u6469\\u5361\\u91d1 \\u79fb\\u52a8\\u8054\\u901a\\u7535\\u4fe14G\\u624b\\u673a \\u53cc\\u5361\\u53cc\\u5f85\',`img`=\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/08\\/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg\',`url`=\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=199\',`uid`=1,`update_time`=1504427081,`add_time`=1504427081 WHERE (   item_id=\'199\'  AND  shop_id=11  )\",\"UPDATE `cps_items` SET `shop_id`=11,`item_id`=200,`cate_name`=\'\\u7f8e\\u5986\\u4e2a\\u62a4\',`cid`=0,`price`=0.01,`title`=\'Sukin \\u82cf\\u828a \\u6c34\\u6da6\\u4fdd\\u6e7f\\u62a4\\u80a4\\u4e09\\u4ef6\\u5957 \\u4e73\\u6db2+\\u723d\\u80a4\\u6c34+\\u6d17\\u9762\\u5976 [125ml*3]\',`img`=\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg\',`url`=\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=200\',`uid`=1,`update_time`=1504427081,`add_time`=1504427081 WHERE (   item_id=\'200\'  AND  shop_id=11  )\",\"INSERT INTO `cps_items` (`shop_id`,`item_id`,`cate_name`,`cid`,`price`,`title`,`img`,`url`,`uid`,`update_time`,`add_time`) VALUES (11,204,\'\\u9996\\u9970\',0,460,\'\\u683c\\u739b\\u4ed5 \\u97e9\\u7248\\u8d85\\u8584 \\u65f6\\u5c1a\\u6f6e\\u6d41\\u77f3\\u82f1\\u5973\\u5f0f\\u65f6\\u88c5\\u9576\\u6c34\\u94bb\\u8155\\u8868 [\\u73ab\\u91d1\\u82722105-CR-B2-DW]\',\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/V1yNIw1OErYwyliLlbtWe6oOyW6Ybb.jpg\',\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=204\',1,1504427081,1504427081)\",\"INSERT INTO `cps_items` (`shop_id`,`item_id`,`cate_name`,`cid`,`price`,`title`,`img`,`url`,`uid`,`update_time`,`add_time`) VALUES (1,null,null,null,null,null,null,null,1,1504427081,1504427081)\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'219.143.150.29','',1,NULL,'修改合同（导入商品内容）','cps平台'),(50,'beijingfenghang','2017-09-03 16:29:14','修改','合同（导入商品佣金）','{\"id\":\"\",\"shop_id\":\"\",\"contract\":\"\",\"platform_id\":\"\",\"dosubmit\":\"2\"}','[\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (11,\'\',12,204,10,46,\'\\u9996\\u9970\',\'\\u9996\\u9970\',460,\'\\u683c\\u739b\\u4ed5 \\u97e9\\u7248\\u8d85\\u8584 \\u65f6\\u5c1a\\u6f6e\\u6d41\\u77f3\\u82f1\\u5973\\u5f0f\\u65f6\\u88c5\\u9576\\u6c34\\u94bb\\u8155\\u8868 [\\u73ab\\u91d1\\u82722105-CR-B2-DW]\',\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/V1yNIw1OErYwyliLlbtWe6oOyW6Ybb.jpg\',\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=204\',\'\',12,\'4\',1504427354,1504427354)\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'219.143.150.29','',12,NULL,'修改合同（导入商品佣金）','北京分行'),(51,'beijingfenghang','2017-09-03 16:29:14','修改','合同（导入商品内容）','[{\"shop_id\":11,\"contract\":\"\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":204,\"rate\":10,\"commission\":46,\"cate_name\":\"\\u9996\\u9970\",\"cate_id\":\"\\u9996\\u9970\",\"cid\":\"\\u9996\\u9970\",\"price\":460,\"title\":\"\\u683c\\u739b\\u4ed5 \\u97e9\\u7248\\u8d85\\u8584 \\u65f6\\u5c1a\\u6f6e\\u6d41\\u77f3\\u82f1\\u5973\\u5f0f\\u65f6\\u88c5\\u9576\\u6c34\\u94bb\\u8155\\u8868 [\\u73ab\\u91d1\\u82722105-CR-B2-DW]\",\"img\":\"http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/V1yNIw1OErYwyliLlbtWe6oOyW6Ybb.jpg\",\"url\":\"http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=204\",\"con_id\":\"\",\"uid\":\"12\",\"role_id\":\"4\",\"update_time\":1504427354,\"add_time\":1504427354}]','[\"UPDATE `cps_items` SET `shop_id`=11,`item_id`=204,`cate_name`=\'\\u9996\\u9970\',`cid`=0,`price`=460,`title`=\'\\u683c\\u739b\\u4ed5 \\u97e9\\u7248\\u8d85\\u8584 \\u65f6\\u5c1a\\u6f6e\\u6d41\\u77f3\\u82f1\\u5973\\u5f0f\\u65f6\\u88c5\\u9576\\u6c34\\u94bb\\u8155\\u8868 [\\u73ab\\u91d1\\u82722105-CR-B2-DW]\',`img`=\'http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/V1yNIw1OErYwyliLlbtWe6oOyW6Ybb.jpg\',`url`=\'http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=204\',`uid`=12,`update_time`=1504427354,`add_time`=1504427354 WHERE (   item_id=\'204\'  AND  shop_id=11  )\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'219.143.150.29','',12,NULL,'修改合同（导入商品内容）','北京分行'),(52,'beijingfenghang','2017-09-03 16:29:46','修改','佣金','{\"commission\":69,\"rate\":\"15\",\"id\":\"21\",\"shop_id\":\"11\",\"item_id\":\"204\",\"cate_name\":\"\\u9996\\u9970\",\"price\":\"460.00\",\"contract\":\"\",\"img\":\"http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/V1yNIw1OErYwyliLlbtWe6oOyW6Ybb.jpg\",\"url\":\"http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=204\",\"platform_id\":\"12\",\"title\":\"\\u683c\\u739b\\u4ed5 \\u97e9\\u7248\\u8d85\\u8584 \\u65f6\\u5c1a\\u6f6e\\u6d41\\u77f3\\u82f1\\u5973\\u5f0f\\u65f6\\u88c5\\u9576\\u6c34\\u94bb\\u8155\\u8868 [\\u73ab\\u91d1\\u82722105-CR-B2-DW]\",\"is_edit\":\"1\",\"dosubmit\":\" \",\"platfom_id\":\"12\",\"uid\":\"12\",\"role_id\":\"4\",\"update_time\":1504427386,\"add_time\":1504427386}','UPDATE `cps_commission` SET `commission`=69,`rate`=\'15\',`shop_id`=\'11\',`item_id`=\'204\',`cate_name`=\'首饰\',`price`=\'460.00\',`contract`=\'\',`img`=\'http://wx.adjyc.com/attachment/images/6/2017/09/V1yNIw1OErYwyliLlbtWe6oOyW6Ybb.jpg\',`url`=\'http://wx.adjyc.com/app/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=204\',`platform_id`=12,`title`=\'格玛仕 韩版超薄 时尚潮流石英女式时装镶水钻腕表 [玫金色2105-CR-B2-DW]\',`uid`=12,`role_id`=\'4\',`update_time`=1504427386,`add_time`=1504427386 WHERE ( `id` = 21 )',0,NULL,0,NULL,0,'0',NULL,NULL,'219.143.150.29','commission',12,NULL,'修改佣金','北京分行'),(53,'beijingfenghang','2017-09-03 16:30:10','修改','佣金','{\"commission\":46,\"rate\":\"10\",\"id\":\"21\",\"shop_id\":\"11\",\"item_id\":\"204\",\"cate_name\":\"\\u9996\\u9970\",\"price\":\"460.00\",\"contract\":\"\",\"img\":\"http:\\/\\/wx.adjyc.com\\/attachment\\/images\\/6\\/2017\\/09\\/V1yNIw1OErYwyliLlbtWe6oOyW6Ybb.jpg\",\"url\":\"http:\\/\\/wx.adjyc.com\\/app\\/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=204\",\"platform_id\":\"12\",\"title\":\"\\u683c\\u739b\\u4ed5 \\u97e9\\u7248\\u8d85\\u8584 \\u65f6\\u5c1a\\u6f6e\\u6d41\\u77f3\\u82f1\\u5973\\u5f0f\\u65f6\\u88c5\\u9576\\u6c34\\u94bb\\u8155\\u8868 [\\u73ab\\u91d1\\u82722105-CR-B2-DW]\",\"is_edit\":\"1\",\"dosubmit\":\" \",\"platfom_id\":\"12\",\"uid\":\"12\",\"role_id\":\"4\",\"update_time\":1504427410,\"add_time\":1504427410}','UPDATE `cps_commission` SET `commission`=46,`rate`=\'10\',`shop_id`=\'11\',`item_id`=\'204\',`cate_name`=\'首饰\',`price`=\'460.00\',`contract`=\'\',`img`=\'http://wx.adjyc.com/attachment/images/6/2017/09/V1yNIw1OErYwyliLlbtWe6oOyW6Ybb.jpg\',`url`=\'http://wx.adjyc.com/app/index.php?i=6&c=entry&m=ewei_shopv2&do=mobile&r=goods.detail&id=204\',`platform_id`=12,`title`=\'格玛仕 韩版超薄 时尚潮流石英女式时装镶水钻腕表 [玫金色2105-CR-B2-DW]\',`uid`=12,`role_id`=\'4\',`update_time`=1504427410,`add_time`=1504427410 WHERE ( `id` = 21 )',0,NULL,0,NULL,0,'0',NULL,NULL,'219.143.150.29','commission',12,NULL,'修改佣金','北京分行'),(54,'beijingfenghang','2017-09-03 16:34:15','批量添加','用户','[{\"dosubmit\":\"2\",\"user_name\":\"dongcheng\",\"user_id\":\"\\u4e1c\\u57ce\\u652f\\u884c\",\"mobile\":\" 18958222222\",\"email\":\" bank_sub_xm@qq.com\",\"account\":\" bank_sub_xm@qq.com\",\"address\":\"\\u4e1c\\u57ce\\u652f\\u884c\",\"role_id\":5,\"pid\":\"12\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\",\"data_state\":1,\"status\":1,\"ip\":\"219.143.150.29\",\"update_time\":1504427655,\"last_time\":1504427655,\"add_time\":1504427655},{\"dosubmit\":\"2\",\"user_name\":\"fentai\",\"user_id\":\"\\u4e30\\u53f0\\u652f\\u884c\",\"mobile\":\" 18999990000\",\"email\":\" bank_sub_xm@qq.com\",\"account\":\" bank_sub_xm@qq.com\",\"address\":\"\\u4e30\\u53f0\\u652f\\u884c\",\"role_id\":5,\"pid\":\"12\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\",\"data_state\":1,\"status\":1,\"ip\":\"219.143.150.29\",\"update_time\":1504427655,\"last_time\":1504427655,\"add_time\":1504427655}]','[\"INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`email`,`account`,`address`,`role_id`,`pid`,`password`,`data_state`,`status`,`ip`,`update_time`,`last_time`,`add_time`) VALUES (\'dongcheng\',\'\\u4e1c\\u57ce\\u652f\\u884c\',\' 18958222222\',\' bank_sub_xm@qq.com\',\' bank_sub_xm@qq.com\',\'\\u4e1c\\u57ce\\u652f\\u884c\',5,12,\'dc483e80a7a0bd9ef71d8cf973673924\',1,1,\'219.143.150.29\',1504427655,1504427655,1504427655)\",\"INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`email`,`account`,`address`,`role_id`,`pid`,`password`,`data_state`,`status`,`ip`,`update_time`,`last_time`,`add_time`) VALUES (\'fentai\',\'\\u4e30\\u53f0\\u652f\\u884c\',\' 18999990000\',\' bank_sub_xm@qq.com\',\' bank_sub_xm@qq.com\',\'\\u4e30\\u53f0\\u652f\\u884c\',5,12,\'dc483e80a7a0bd9ef71d8cf973673924\',1,1,\'219.143.150.29\',1504427655,1504427655,1504427655)\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'219.143.150.29','admin',12,NULL,'批量添加用户','北京分行'),(55,'chaoyang','2017-09-03 16:34:59','批量添加','用户','[{\"dosubmit\":\"2\",\"user_name\":\"wangwu\",\"user_id\":\"\\u738b\\u4e94\",\"mobile\":\" 18958222222\",\"email\":\" bank_sub_xm@qq.com\",\"account\":\" bank_sub_xm@qq.com\",\"address\":\"\\u671d\\u9633\\u652f\\u884c\",\"role_id\":6,\"pid\":\"14\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\",\"data_state\":1,\"status\":1,\"ip\":\"219.143.150.29\",\"update_time\":1504427699,\"last_time\":1504427699,\"add_time\":1504427699},{\"dosubmit\":\"2\",\"user_name\":\"zhaoliu\",\"user_id\":\"\\u8d75\\u516d\",\"mobile\":\" 18999990000\",\"email\":\" bank_sub_xm@qq.com\",\"account\":\" bank_sub_xm@qq.com\",\"address\":\"\\u671d\\u9633\\u652f\\u884c\",\"role_id\":6,\"pid\":\"14\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\",\"data_state\":1,\"status\":1,\"ip\":\"219.143.150.29\",\"update_time\":1504427699,\"last_time\":1504427699,\"add_time\":1504427699}]','[\"INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`email`,`account`,`address`,`role_id`,`pid`,`password`,`data_state`,`status`,`ip`,`update_time`,`last_time`,`add_time`) VALUES (\'wangwu\',\'\\u738b\\u4e94\',\' 18958222222\',\' bank_sub_xm@qq.com\',\' bank_sub_xm@qq.com\',\'\\u671d\\u9633\\u652f\\u884c\',6,14,\'dc483e80a7a0bd9ef71d8cf973673924\',1,1,\'219.143.150.29\',1504427699,1504427699,1504427699)\",\"INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`email`,`account`,`address`,`role_id`,`pid`,`password`,`data_state`,`status`,`ip`,`update_time`,`last_time`,`add_time`) VALUES (\'zhaoliu\',\'\\u8d75\\u516d\',\' 18999990000\',\' bank_sub_xm@qq.com\',\' bank_sub_xm@qq.com\',\'\\u671d\\u9633\\u652f\\u884c\',6,14,\'dc483e80a7a0bd9ef71d8cf973673924\',1,1,\'219.143.150.29\',1504427699,1504427699,1504427699)\"]',0,NULL,0,NULL,0,'0',NULL,NULL,'219.143.150.29','admin',14,NULL,'批量添加用户','朝阳支行');
/*!40000 ALTER TABLE `cps_op_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_orderlist`
--

DROP TABLE IF EXISTS `cps_orderlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_orderlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_time` varchar(20) DEFAULT '1444444231' COMMENT '下单时间',
  `seller_name` varchar(20) DEFAULT NULL COMMENT '推广人',
  `username` varchar(50) DEFAULT NULL,
  `order_code` varchar(50) DEFAULT NULL,
  `item_count` int(5) DEFAULT NULL,
  `item_price` varchar(10) DEFAULT NULL,
  `sales` varchar(20) DEFAULT NULL,
  `commission` varchar(10) DEFAULT NULL,
  `cash_back` varchar(10) DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT '1' COMMENT '//订单状态',
  `is_update` int(1) NOT NULL DEFAULT '0' COMMENT '0表示未更新用户表，以及返现表，1表示已经更新，不需要再次更新',
  `jiesuan_data` datetime NOT NULL COMMENT '结算日期',
  `order_id` varchar(64) NOT NULL COMMENT '对方订单号',
  `cash_back_jifenbao` varchar(10) DEFAULT NULL,
  `shop_id` bigint(10) unsigned NOT NULL COMMENT '商户id',
  `item_id` varchar(32) NOT NULL COMMENT '商品id',
  `sum_price` varchar(10) DEFAULT '0' COMMENT '商品总价',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `platform_id` int(10) unsigned DEFAULT '0' COMMENT '分销平台，指定到机构？对，必须对应机构。',
  `settle_time` varchar(20) DEFAULT '0' COMMENT '结算时间',
  `settle_price` varchar(10) DEFAULT '0' COMMENT '结算总价',
  `settle_status` tinyint(20) NOT NULL DEFAULT '0' COMMENT '//结算状态',
  `settle_status1_stc` tinyint(20) NOT NULL DEFAULT '0' COMMENT '//结算状态  商城对cps的结算',
  `settle_status2_cts` tinyint(20) NOT NULL DEFAULT '0' COMMENT '//结算状态 cps对商城的结算',
  `settle_status3_ctb` tinyint(20) NOT NULL DEFAULT '0' COMMENT '//结算状态 cps对分行的结算',
  `settle_status4_btc` tinyint(20) NOT NULL DEFAULT '0' COMMENT '//结算状态 分行对cps的结算',
  `sid` varchar(20) DEFAULT '1' COMMENT '推广员id',
  `bank_id` varchar(20) DEFAULT '1' COMMENT '分行id',
  `bank_subid` varchar(20) DEFAULT '1' COMMENT '支行id',
  `data_state` tinyint(1) DEFAULT '1' COMMENT '数据状态：0删除，1正常',
  `cate_id` bigint(10) unsigned NOT NULL DEFAULT '1' COMMENT '分类id',
  `cate_name` varchar(128) DEFAULT '1' COMMENT '分类名称',
  `commission2` varchar(10) DEFAULT NULL COMMENT '分润',
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `order_code` (`order_code`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='5.2.11订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_orderlist`
--

LOCK TABLES `cps_orderlist` WRITE;
/*!40000 ALTER TABLE `cps_orderlist` DISABLE KEYS */;
INSERT INTO `cps_orderlist` VALUES (1,'1504401527','lisi',NULL,NULL,1,'0.01',NULL,'0.002',NULL,0,'1',0,'0000-00-00 00:00:00','1504401527',NULL,11,'200','0.01','Sukin 苏芊 水润保湿护肤三件套 乳液+爽肤水+洗面奶 [125ml*3]',12,'0','0',0,0,0,0,0,'17','12','16',1,1,'美妆个护','0.01'),(2,'1504401544','lisi',NULL,NULL,1,'0.01',NULL,'0.002',NULL,0,'1',0,'0000-00-00 00:00:00','1504401544',NULL,11,'200','0.01','Sukin 苏芊 水润保湿护肤三件套 乳液+爽肤水+洗面奶 [125ml*3]',12,'0','0',0,0,0,0,0,'17','12','16',1,1,'美妆个护','0.01'),(3,'1504401567','lisi',NULL,NULL,1,'0.01',NULL,'0.002',NULL,0,'1',0,'0000-00-00 00:00:00','180',NULL,11,'200','0.01','Sukin 苏芊 水润保湿护肤三件套 乳液+爽肤水+洗面奶 [125ml*3]',12,'0','0',0,0,0,0,0,'17','12','16',1,1,'美妆个护','0.01'),(4,'1504402122','lisi',NULL,NULL,1,'0.01',NULL,'0.002',NULL,0,'1',0,'0000-00-00 00:00:00','1504402122',NULL,11,'200','0.01','Sukin 苏芊 水润保湿护肤三件套 乳液+爽肤水+洗面奶 [125ml*3]',12,'0','0',0,0,0,0,0,'17','12','16',1,1,'美妆个护','0.01'),(5,'1504402132','lisi',NULL,NULL,1,'0.01',NULL,'0.002',NULL,0,'1',0,'0000-00-00 00:00:00','181',NULL,11,'200','0.01','Sukin 苏芊 水润保湿护肤三件套 乳液+爽肤水+洗面奶 [125ml*3]',12,'0','0',0,0,0,0,0,'17','12','16',1,1,'美妆个护','0.01'),(6,'1504402373','lisi',NULL,NULL,1,'0.01',NULL,'0.002',NULL,0,'1',0,'0000-00-00 00:00:00','182',NULL,11,'200','0.01','Sukin 苏芊 水润保湿护肤三件套 乳液+爽肤水+洗面奶 [125ml*3]',12,'0','0',0,1,0,1,1,'17','12','16',1,1,'美妆个护','0.01'),(7,'1504427942','wangwu',NULL,NULL,1,'460.00',NULL,'92',NULL,0,'1',0,'0000-00-00 00:00:00','184',NULL,11,'204','460','格玛仕 韩版超薄 时尚潮流石英女式时装镶水钻腕表 [玫金色2105-CR-B2-DW]',12,'0','0',0,0,0,1,1,'21','12','14',1,1,'首饰','46');
/*!40000 ALTER TABLE `cps_orderlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_parameters`
--

DROP TABLE IF EXISTS `cps_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_parameters` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `parameter_name` varchar(256) NOT NULL COMMENT '参数名',
  `parameter_id` varchar(3) NOT NULL COMMENT '参数id',
  `parameter_value` varchar(256) NOT NULL,
  `parameter_desc` varchar(1024) NOT NULL COMMENT '参数描述',
  `APP_FLAG01` varchar(1024) DEFAULT NULL,
  `data_state` char(1) DEFAULT '1' COMMENT '数据状态：0删除，1正常',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=117 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_parameters`
--

LOCK TABLES `cps_parameters` WRITE;
/*!40000 ALTER TABLE `cps_parameters` DISABLE KEYS */;
INSERT INTO `cps_parameters` VALUES (39,'DONATE_STATUS','3','已申请','捐赠状态',NULL,'1'),(2,'period','1','半月','结算周期','','1'),(22,'ORDER_TIME','3','11:00-12:00','预约时间',NULL,'1'),(5,'period','2','一月','结算周期',NULL,'1'),(6,'period','3','季度','结算周期',NULL,'1'),(7,'period','4','年度','结算周期',NULL,'1'),(21,'ORDER_TIME','2','10:00-11:00','预约时间',NULL,'1'),(11,'check_status','1','已通过','审核状态',NULL,'1'),(12,'check_status','2','审核中','审核状态',NULL,'1'),(13,'check_status','3','已打回','审核状态',NULL,'1'),(14,'payee','1','民生银行信用卡中心1','收款方',NULL,'1'),(15,'payee','2','民生银行信用卡中心2','收款方',NULL,'1'),(16,'payee','3','民生银行信用卡中心3','收款方',NULL,'1'),(17,'payee','4','民生银行信用卡中心4','收款方',NULL,'1'),(18,'settle_status','0','未结算','结算状态',NULL,'1'),(19,'settle_status','1','已结算','结算状态',NULL,'1'),(20,'settle_status','2','待审批','结算状态',NULL,'0'),(23,'ORDER_TIME','4','14:30-15:30','预约时间',NULL,'1'),(24,'ORDER_TIME','5','15:30-16:30','预约时间',NULL,'1'),(25,'ORDER_TIME','6','16:30-17:30','预约时间',NULL,'1'),(26,'IDEA_STATUS','0','已处理','金点子状态',NULL,'1'),(27,'IDEA_STATUS','1','待处理','金点子状态',NULL,'1'),(28,'IDEA_STATUS','2','处理中','金点子状态',NULL,'1'),(34,'CAMP_STATE','1','进行中','活动状态',NULL,'1'),(33,'CAMP_STATE','0','已结束','活动状态',NULL,'1'),(40,'OBJECT_TYPE','1','生活必需品','置换类别',NULL,'1'),(41,'OBJECT_TYPE','2','装饰物品','置换类别',NULL,'1'),(42,'OBJECT_TYPE','3','学习用品','置换类别',NULL,'1'),(43,'OBJECT_TYPE','4','办公用品','置换类别',NULL,'1'),(44,'SERVICE_TYPE','1','交通','生活服务类型',NULL,'1'),(45,'SERVICE_TYPE','2','娱乐','生活服务类型',NULL,'1'),(46,'SERVICE_TYPE','3','餐饮','生活服务类型',NULL,'1'),(47,'SERVICE_TYPE','4','生活','生活服务类型',NULL,'1'),(48,'SERVICE_TYPE','5','银行','生活服务类型',NULL,'1'),(49,'SERVICE_TYPE','6','住宿','生活服务类型',NULL,'1'),(50,'SERVICE_TYPE','7','购物','生活服务类型',NULL,'1'),(92,'IDEA_TYPE','1','建议','金点子类型',NULL,'1'),(52,'SERVICE_TYPE','11','公交站','交通',NULL,'1'),(53,'SERVICE_TYPE','12','加油站','交通',NULL,'1'),(54,'SERVICE_TYPE','13','停车场','交通',NULL,'1'),(55,'SERVICE_TYPE','19','其他','交通',NULL,'1'),(56,'SERVICE_TYPE','21','KTV','娱乐',NULL,'1'),(57,'SERVICE_TYPE','22','电影院','娱乐',NULL,'1'),(58,'SERVICE_TYPE','23','酒吧','娱乐',NULL,'1'),(59,'SERVICE_TYPE','24','网吧','娱乐',NULL,'1'),(60,'SERVICE_TYPE','29','其他','娱乐',NULL,'1'),(61,'SERVICE_TYPE','31','餐馆','餐饮',NULL,'1'),(62,'SERVICE_TYPE','32','中餐','餐饮',NULL,'1'),(63,'SERVICE_TYPE','33','西餐','餐饮',NULL,'1'),(64,'SERVICE_TYPE','34','咖啡馆','餐饮',NULL,'1'),(65,'SERVICE_TYPE','39','其他','餐饮',NULL,'1'),(66,'SERVICE_TYPE','41','学校','生活',NULL,'1'),(67,'SERVICE_TYPE','42','医院','生活',NULL,'1'),(68,'SERVICE_TYPE','43','公园','生活',NULL,'1'),(69,'SERVICE_TYPE','49','其他','生活',NULL,'1'),(70,'SERVICE_TYPE','501','中国银行','银行',NULL,'1'),(71,'SERVICE_TYPE','502','建设银行','银行',NULL,'1'),(72,'SERVICE_TYPE','503','工商银行','银行',NULL,'1'),(73,'SERVICE_TYPE','504','农业银行','银行',NULL,'1'),(74,'SERVICE_TYPE','505','中国银行','银行',NULL,'1'),(75,'SERVICE_TYPE','506','兴业银行','银行',NULL,'1'),(76,'SERVICE_TYPE','507','招商银行','银行',NULL,'1'),(77,'SERVICE_TYPE','508','厦门银行','银行',NULL,'1'),(78,'SERVICE_TYPE','509','交通银行','银行',NULL,'1'),(79,'SERVICE_TYPE','510','平安银行','银行',NULL,'1'),(80,'SERVICE_TYPE','511','农村信用社','银行',NULL,'1'),(81,'SERVICE_TYPE','599','其他','银行',NULL,'1'),(82,'SERVICE_TYPE','61','宾馆','住宿',NULL,'1'),(83,'SERVICE_TYPE','62','酒店','住宿',NULL,'1'),(84,'SERVICE_TYPE','63','旅馆','住宿',NULL,'1'),(85,'SERVICE_TYPE','69','其他','住宿',NULL,'1'),(86,'SERVICE_TYPE','71','超市','购物',NULL,'1'),(87,'SERVICE_TYPE','72','商场','购物',NULL,'1'),(88,'SERVICE_TYPE','73','菜市场','购物',NULL,'1'),(89,'SERVICE_TYPE','74','书店','购物',NULL,'1'),(90,'SERVICE_TYPE','75','花店','购物',NULL,'1'),(91,'SERVICE_TYPE','79','其他','购物',NULL,'1'),(93,'EXCHANGE_STATUS','0','已处理','置换状态',NULL,'1'),(94,'EXCHANGE_STATUS','1','进行中','置换状态',NULL,'1'),(95,'EXCHANGE_STATUS','2','待审批','置换状态',NULL,'1'),(96,'LOVE_STATE','0','已结束','爱心帮扶状态',NULL,'1'),(97,'LOVE_STATE','1','进行中','爱心帮扶状态',NULL,'1'),(98,'LOVE_STATE','2','待审批','爱心帮扶状态',NULL,'1'),(99,'LOVE_TYPE','1','寻求帮助','爱心帮扶类型',NULL,'1'),(100,'LOVE_TYPE','2','提供帮助','爱心帮扶类型',NULL,'1'),(101,'APART_TYPE','1','一室一厅','户型',NULL,'1'),(102,'APART_TYPE','2','两室一厅','户型',NULL,'1'),(103,'APART_TYPE','3','三室一厅','户型',NULL,'1'),(104,'APART_TYPE','4','一房','户型',NULL,'1'),(105,'APART_TYPE','5','两房','户型',NULL,'1'),(106,'APART_TYPE','6','三房','户型',NULL,'1'),(107,'DECOR_TYPE','1','精装','装修',NULL,'1'),(108,'DECOR_TYPE','2','简装','装修',NULL,'1'),(109,'DECOR_TYPE','3','毛胚','装修',NULL,'1'),(111,'APART_TYPE','7','两室两厅','户型',NULL,'1'),(112,'Rentmoney_TYPE','1','0~500','租金',NULL,'1'),(113,'Rentmoney_TYPE','2','500~1000','租金',NULL,'1'),(114,'Rentmoney_TYPE','3','1000~2000','租金',NULL,'1'),(115,'Rentmoney_TYPE','4','2000~3000','租金',NULL,'1'),(116,'Rentmoney_TYPE','5','3000~10000','租金',NULL,'1');
/*!40000 ALTER TABLE `cps_parameters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_poster`
--

DROP TABLE IF EXISTS `cps_poster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_poster` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` tinyint(4) unsigned NOT NULL,
  `title` varchar(255) NOT NULL COMMENT '标题',
  `orig` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL COMMENT '文件路径',
  `info` mediumtext NOT NULL COMMENT '信息',
  `add_time` datetime NOT NULL,
  `ordid` tinyint(4) NOT NULL,
  `is_hot` tinyint(1) NOT NULL DEFAULT '0',
  `is_best` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-待审核 1-已审核',
  `platform_id` int(10) unsigned NOT NULL COMMENT '分销机构（发布的时候可指定全部或者具体分行、子机构的人员能看到）',
  `data_state` tinyint(1) DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '创建人',
  `shop_id` int(10) unsigned DEFAULT '0' COMMENT '商户id',
  `item_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `origin_id` bigint(20) unsigned DEFAULT NULL COMMENT '商品原始id',
  `origin_name` varchar(32) DEFAULT NULL COMMENT '商品原始title',
  `cate_name` varchar(128) NOT NULL DEFAULT '1' COMMENT '分类名称',
  PRIMARY KEY (`id`),
  KEY `is_best` (`is_best`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `cate_id` (`cate_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=154 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='5.2.15 海报二维码表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_poster`
--

LOCK TABLES `cps_poster` WRITE;
/*!40000 ALTER TABLE `cps_poster` DISABLE KEYS */;
INSERT INTO `cps_poster` VALUES (106,0,'','','data/items/m_5921aa70b469e.png','','','','0000-00-00 00:00:00',0,0,0,0,0,0,NULL,0,0,'61',1,'商品名称','1'),(107,0,'','','data/items/m_5921aa70b469e.png','','','','2017-05-21 23:02:33',0,0,0,1,0,1,'0000-00-00 00:00:00',1,0,'2',106,'商品名称','1'),(108,0,'','','data/items/m_5921aa70b469e.png','','','','2017-05-21 23:03:06',0,0,0,1,0,1,'0000-00-00 00:00:00',1,0,'3',106,'商品名称','1'),(109,0,'','','data/items/m_5921aa70b469e.png','','','','2017-05-21 23:05:36',0,0,0,1,0,1,'2017-05-21 23:05:36',1,0,'4',106,'商品名称','1'),(110,0,'','','data/items/m_5921aa70b469e.png','','','','2017-05-21 23:16:45',0,0,0,1,0,1,'2017-05-21 23:16:45',1,0,'8',106,'商品名称','1'),(130,0,'','','./data/qrcode/poster___200_11_1504332579.jpg','','','','2017-09-02 14:09:40',0,0,0,1,0,1,'2017-09-02 14:09:40',0,11,'200',5,NULL,'1'),(131,0,'','','./data/qrcode/poster___200_11_1504332590.jpg','','','','2017-09-02 14:09:50',0,0,0,1,0,1,'2017-09-02 14:09:50',0,11,'200',5,NULL,'1'),(132,0,'','','./data/qrcode/poster___200_11_1504332595.jpg','','','','2017-09-02 14:09:55',0,0,0,1,0,1,'2017-09-02 14:09:55',0,11,'200',5,NULL,'1'),(133,0,'','','./data/qrcode/poster_17__200_11_1504333752.jpg','','','','2017-09-02 14:29:13',0,0,0,1,0,1,'2017-09-02 14:29:13',0,11,'200',NULL,'Sukin 苏芊 水润保湿护肤三件套 乳液 爽肤水 洗面奶 [1','1'),(134,0,'','','./data/qrcode/poster_17__200_11_1504333762.jpg','','','','2017-09-02 14:29:22',0,0,0,1,0,1,'2017-09-02 14:29:22',0,11,'200',NULL,'Sukin 苏芊 水润保湿护肤三件套 乳液 爽肤水 洗面奶 [1','1'),(135,0,'','','./data/qrcode/poster_17__200_11_1504333767.jpg','','','','2017-09-02 14:29:27',0,0,0,1,0,1,'2017-09-02 14:29:27',0,11,'200',NULL,'Sukin 苏芊 水润保湿护肤三件套 乳液 爽肤水 洗面奶 [1','1'),(136,0,'','','./data/qrcode/poster___204_11_1504427137.jpg','','','','2017-09-03 16:25:37',0,0,0,1,0,1,'2017-09-03 16:25:37',0,11,'204',9,NULL,'1'),(137,0,'','','./data/qrcode/poster___204_11_1504427152.jpg','','','','2017-09-03 16:25:52',0,0,0,1,0,1,'2017-09-03 16:25:52',0,11,'204',9,NULL,'1'),(138,0,'','','./data/qrcode/poster_1_admin_204_11_1504427164.jpg','','','','2017-09-03 16:26:04',0,0,0,1,0,1,'2017-09-03 16:26:04',0,11,'204',9,'格玛仕 韩版超薄 时尚潮流石英女式时装镶水钻腕表 [玫金色210','1'),(139,0,'','','./data/qrcode/poster_1_admin_204_11_1504427167.jpg','','','','2017-09-03 16:26:07',0,0,0,1,0,1,'2017-09-03 16:26:07',0,11,'204',9,'格玛仕 韩版超薄 时尚潮流石英女式时装镶水钻腕表 [玫金色210','1'),(140,0,'','','./data/qrcode/poster_21__204_11_1504427781.jpg','','','','2017-09-03 16:36:21',0,0,0,1,0,1,'2017-09-03 16:36:21',0,11,'204',NULL,'格玛仕 韩版超薄 时尚潮流石英女式时装镶水钻腕表 [玫金色210','1'),(141,0,'','','./data/qrcode/poster_21__200_11_1504428313.jpg','','','','2017-09-03 16:45:13',0,0,0,1,0,1,'2017-09-03 16:45:13',0,11,'200',NULL,'Sukin 苏芊 水润保湿护肤三件套 乳液 爽肤水 洗面奶 [1','1'),(142,0,'','','./data/qrcode/poster_21__200_11_1504428495.jpg','','','','2017-09-03 16:48:15',0,0,0,1,0,1,'2017-09-03 16:48:15',0,11,'200',NULL,'Sukin 苏芊 水润保湿护肤三件套 乳液 爽肤水 洗面奶 [1','1'),(143,0,'','','./data/qrcode/poster_17__199_11_1504433656.jpg','','','','2017-09-03 18:14:16',0,0,0,1,0,1,'2017-09-03 18:14:16',0,11,'199',NULL,'华为 Mate 9 4GB 64GB版 摩卡金 移动联通电信4G','1'),(144,0,'','','./data/qrcode/poster_17__204_11_1504434420.jpg','','','','2017-09-03 18:27:00',0,0,0,1,0,1,'2017-09-03 18:27:00',0,11,'204',NULL,'格玛仕 韩版超薄 时尚潮流石英女式时装镶水钻腕表 [玫金色210','1'),(145,0,'','','./data/qrcode/poster_17__200_11_1504434438.jpg','','','','2017-09-03 18:27:18',0,0,0,1,0,1,'2017-09-03 18:27:18',0,11,'200',NULL,'Sukin 苏芊 水润保湿护肤三件套 乳液 爽肤水 洗面奶 [1','1'),(146,0,'','','./data/qrcode/poster_17__199_11_1504434454.jpg','','','','2017-09-03 18:27:34',0,0,0,1,0,1,'2017-09-03 18:27:34',0,11,'199',NULL,'华为 Mate 9 4GB 64GB版 摩卡金 移动联通电信4G','1'),(147,0,'','','./data/qrcode/poster_17__204_11_1504434786.jpg','','','','2017-09-03 18:33:06',0,0,0,1,0,1,'2017-09-03 18:33:06',0,11,'204',NULL,'格玛仕 韩版超薄 时尚潮流石英女式时装镶水钻腕表 [玫金色210','1'),(148,0,'','','./data/qrcode/poster_17__199_11_1504434857.jpg','','','','2017-09-03 18:34:17',0,0,0,1,0,1,'2017-09-03 18:34:17',0,11,'199',NULL,'华为 Mate 9 4GB 64GB版 摩卡金 移动联通电信4G','1'),(149,0,'','','./data/qrcode/poster_17__200_11_1504434905.jpg','','','','2017-09-03 18:35:05',0,0,0,1,0,1,'2017-09-03 18:35:05',0,11,'200',NULL,'Sukin 苏芊 水润保湿护肤三件套 乳液 爽肤水 洗面奶 [1','1'),(150,0,'','','./data/qrcode/poster_17__200_11_1504434928.jpg','','','','2017-09-03 18:35:28',0,0,0,1,0,1,'2017-09-03 18:35:28',0,11,'200',NULL,'Sukin 苏芊 水润保湿护肤三件套 乳液 爽肤水 洗面奶 [1','1'),(151,0,'','','./data/qrcode/poster_17__204_11_1504436508.jpg','','','','2017-09-03 19:01:48',0,0,0,1,0,1,'2017-09-03 19:01:48',0,11,'204',NULL,'格玛仕 韩版超薄 时尚潮流石英女式时装镶水钻腕表 [玫金色210','1'),(152,0,'','','./data/qrcode/poster_17__204_11_1504436677.jpg','','','','2017-09-03 19:04:37',0,0,0,1,0,1,'2017-09-03 19:04:37',0,11,'204',NULL,'格玛仕 韩版超薄 时尚潮流石英女式时装镶水钻腕表 [玫金色210','1'),(153,0,'','','./data/qrcode/poster_17__204_11_1504436684.jpg','','','','2017-09-03 19:04:44',0,0,0,1,0,1,'2017-09-03 19:04:44',0,11,'204',NULL,'格玛仕 韩版超薄 时尚潮流石英女式时装镶水钻腕表 [玫金色210','1');
/*!40000 ALTER TABLE `cps_poster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_push_log`
--

DROP TABLE IF EXISTS `cps_push_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_push_log` (
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `sname` varchar(40) DEFAULT NULL,
  `op_time` datetime DEFAULT NULL,
  `con_id` bigint(10) DEFAULT NULL COMMENT '合同编号id=cps_contract.id',
  `cate_id` bigint(10) DEFAULT NULL COMMENT '商品类别id',
  `item_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `bank_id` bigint(20) DEFAULT NULL COMMENT '推广分行id',
  `bank_subid` int(11) unsigned DEFAULT '0' COMMENT '子机构id',
  `data_state` char(1) DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  `score` int(10) DEFAULT '0' COMMENT '所需积分',
  `sid` int(10) unsigned DEFAULT '0' COMMENT '推广人id',
  `app` int(11) DEFAULT NULL COMMENT '活动',
  `status` char(1) DEFAULT NULL COMMENT '数据状态：2成功，1审核中',
  `content` varchar(255) DEFAULT NULL,
  `reply_time` datetime DEFAULT NULL COMMENT '审核时间',
  `add_time` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `ip` varchar(255) DEFAULT NULL,
  `update_time` int(10) unsigned DEFAULT NULL COMMENT '修改时间',
  `commission_id` int(10) DEFAULT NULL,
  `cate_name` varchar(128) NOT NULL DEFAULT '1' COMMENT '分类名称',
  `shop_id` varchar(10) DEFAULT NULL COMMENT '商城id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COMMENT='5.2.13推广记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_push_log`
--

LOCK TABLES `cps_push_log` WRITE;
/*!40000 ALTER TABLE `cps_push_log` DISABLE KEYS */;
INSERT INTO `cps_push_log` VALUES (15,NULL,NULL,NULL,NULL,'204',12,14,NULL,0,21,NULL,NULL,NULL,NULL,1504427809,NULL,NULL,21,'1','11'),(2,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504334391,NULL,NULL,17,'1','11'),(16,NULL,NULL,NULL,NULL,'204',12,14,NULL,0,21,NULL,NULL,NULL,NULL,1504427922,NULL,NULL,21,'1','11'),(17,NULL,NULL,NULL,NULL,'204',12,14,NULL,0,21,NULL,NULL,NULL,NULL,1504427923,NULL,NULL,21,'1','11'),(18,NULL,NULL,NULL,NULL,'204',12,14,NULL,0,21,NULL,NULL,NULL,NULL,1504427932,NULL,NULL,21,'1','11'),(19,NULL,NULL,NULL,NULL,'204',12,14,NULL,0,21,NULL,NULL,NULL,NULL,1504427936,NULL,NULL,21,'1','11'),(8,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504400689,NULL,NULL,17,'1','11'),(9,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504400903,NULL,NULL,17,'1','11'),(10,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504400909,NULL,NULL,17,'1','11'),(11,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504400936,NULL,NULL,17,'1','11'),(12,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504401543,NULL,NULL,17,'1','11'),(13,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504402122,NULL,NULL,17,'1','11'),(14,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504402360,NULL,NULL,17,'1','11'),(20,NULL,NULL,NULL,NULL,'204',12,14,NULL,0,21,NULL,NULL,NULL,NULL,1504427946,NULL,NULL,21,'1','11'),(21,NULL,NULL,NULL,NULL,'200',12,14,NULL,0,21,NULL,NULL,NULL,NULL,1504428359,NULL,NULL,17,'1','11'),(22,NULL,NULL,NULL,NULL,'200',12,14,NULL,0,21,NULL,NULL,NULL,NULL,1504428388,NULL,NULL,17,'1','11'),(23,NULL,NULL,NULL,NULL,'200',12,14,NULL,0,21,NULL,NULL,NULL,NULL,1504428410,NULL,NULL,17,'1','11'),(24,NULL,NULL,NULL,NULL,'200',12,14,NULL,0,21,NULL,NULL,NULL,NULL,1504428411,NULL,NULL,17,'1','11'),(25,NULL,NULL,NULL,NULL,'200',12,14,NULL,0,21,NULL,NULL,NULL,NULL,1504428415,NULL,NULL,17,'1','11'),(26,NULL,NULL,NULL,NULL,'200',12,14,NULL,0,21,NULL,NULL,NULL,NULL,1504428942,NULL,NULL,17,'1','11'),(27,NULL,NULL,NULL,NULL,'199',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504434096,NULL,NULL,16,'1','11'),(28,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504434390,NULL,NULL,17,'1','11'),(29,NULL,NULL,NULL,NULL,'204',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504434406,NULL,NULL,21,'1','11'),(30,NULL,NULL,NULL,NULL,'204',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504436707,NULL,NULL,21,'1','11'),(31,NULL,NULL,NULL,NULL,'204',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504436716,NULL,NULL,21,'1','11');
/*!40000 ALTER TABLE `cps_push_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_push_log_copy`
--

DROP TABLE IF EXISTS `cps_push_log_copy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_push_log_copy` (
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `sname` varchar(40) DEFAULT NULL,
  `op_time` datetime DEFAULT NULL,
  `con_id` bigint(10) DEFAULT NULL COMMENT '合同编号id=cps_contract.id',
  `cate_id` bigint(10) DEFAULT NULL COMMENT '商品类别id',
  `item_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `bank_id` bigint(20) DEFAULT NULL COMMENT '推广分行id',
  `bank_subid` int(11) unsigned DEFAULT '0' COMMENT '子机构id',
  `data_state` char(1) DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  `score` int(10) DEFAULT '0' COMMENT '所需积分',
  `sid` int(10) unsigned DEFAULT '0' COMMENT '推广人id',
  `app` int(11) DEFAULT NULL COMMENT '活动',
  `status` char(1) DEFAULT NULL COMMENT '数据状态：2成功，1审核中',
  `content` varchar(255) DEFAULT NULL,
  `reply_time` datetime DEFAULT NULL COMMENT '审核时间',
  `add_time` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `ip` varchar(255) DEFAULT NULL,
  `update_time` int(10) unsigned DEFAULT NULL COMMENT '修改时间',
  `commission_id` int(10) DEFAULT NULL,
  `cate_name` varchar(128) NOT NULL DEFAULT '1' COMMENT '分类名称',
  `shop_id` varchar(10) DEFAULT NULL COMMENT '商城id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='5.2.13推广记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_push_log_copy`
--

LOCK TABLES `cps_push_log_copy` WRITE;
/*!40000 ALTER TABLE `cps_push_log_copy` DISABLE KEYS */;
INSERT INTO `cps_push_log_copy` VALUES (1,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504333810,NULL,NULL,0,'1','11'),(2,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504334391,NULL,NULL,17,'1','11'),(3,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504334781,NULL,NULL,0,'1','11'),(4,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504335132,NULL,NULL,0,'1','11'),(5,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504335441,NULL,NULL,0,'1','11'),(6,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504339444,NULL,NULL,0,'1','11'),(7,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504339890,NULL,NULL,0,'1','11'),(8,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504400689,NULL,NULL,17,'1','11'),(9,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504400903,NULL,NULL,17,'1','11'),(10,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504400909,NULL,NULL,17,'1','11'),(11,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504400936,NULL,NULL,17,'1','11'),(12,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504401543,NULL,NULL,17,'1','11'),(13,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504402122,NULL,NULL,17,'1','11'),(14,NULL,NULL,NULL,NULL,'200',12,16,NULL,0,17,NULL,NULL,NULL,NULL,1504402360,NULL,NULL,17,'1','11');
/*!40000 ALTER TABLE `cps_push_log_copy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_role`
--

DROP TABLE IF EXISTS `cps_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(20) NOT NULL COMMENT '角色名称',
  `status` tinyint(1) unsigned DEFAULT NULL COMMENT '状态',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` int(11) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL COMMENT '更新时间',
  `data_state` tinyint(1) unsigned DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='5.2.2角色表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_role`
--

LOCK TABLES `cps_role` WRITE;
/*!40000 ALTER TABLE `cps_role` DISABLE KEYS */;
INSERT INTO `cps_role` VALUES (1,'管理员(CPS)',1,'CPS平台666',1208784792,1254325558,NULL),(3,'商城',1,'商城',0,0,NULL),(4,'分行',1,'分行',0,0,NULL),(5,'支行',1,'支行（机构）',0,0,NULL),(6,'客户经理',1,'客户经理',0,0,NULL);
/*!40000 ALTER TABLE `cps_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_seller_cate`
--

DROP TABLE IF EXISTS `cps_seller_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_seller_cate` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `cid` int(8) NOT NULL,
  `name` varchar(200) NOT NULL,
  `count` int(8) NOT NULL,
  `seller_status` int(1) NOT NULL DEFAULT '1',
  `status` int(1) NOT NULL,
  `sort` int(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cid` (`cid`),
  KEY `index_status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=123 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_seller_cate`
--

LOCK TABLES `cps_seller_cate` WRITE;
/*!40000 ALTER TABLE `cps_seller_cate` DISABLE KEYS */;
INSERT INTO `cps_seller_cate` VALUES (122,22,'食品饮料',20,1,1,10),(121,21,'箱包皮具',22,1,1,10),(120,20,'宠物用品',1,0,1,10),(119,19,'成人保健',3,0,1,10),(118,18,'饰品配饰',14,1,1,10),(117,17,'汽车用品',4,0,1,10),(116,16,'旅游订票',2,0,1,10),(115,15,'钟表眼镜',8,1,1,10),(103,3,'电脑笔记本',14,1,1,10),(102,2,'手机数码',24,1,1,10),(114,14,'药品保健',8,1,1,10),(113,13,'数字卡软件',3,0,1,10),(112,12,'玩具礼品',8,0,1,10),(111,11,'办公用品',1,0,1,10),(110,10,'母婴用品',14,1,1,10),(109,9,'居家生活',18,1,1,10),(108,8,'家用电器',16,1,1,10),(107,7,'户外休闲',2,0,1,10),(106,6,'综合百货',15,1,1,10),(105,5,'化妆美容',31,1,1,10),(104,4,'服装服饰',79,1,1,10),(101,1,'图书音像',9,1,1,10);
/*!40000 ALTER TABLE `cps_seller_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_seller_list`
--

DROP TABLE IF EXISTS `cps_seller_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_seller_list` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `sid` int(8) NOT NULL,
  `cate_id` int(8) NOT NULL,
  `name` varchar(200) NOT NULL,
  `site_logo` varchar(200) DEFAULT NULL,
  `net_logo` varchar(200) NOT NULL,
  `recommend` int(1) NOT NULL,
  `click_url` varchar(400) NOT NULL,
  `sort` int(6) NOT NULL,
  `description` varchar(200) NOT NULL,
  `freeshipment` int(1) NOT NULL,
  `installment` int(1) NOT NULL,
  `has_invoice` int(1) NOT NULL,
  `cash_back_rate` varchar(64) NOT NULL,
  `status` int(1) NOT NULL,
  `update_time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_status` (`status`),
  KEY `index_recommend` (`recommend`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_seller_list`
--

LOCK TABLES `cps_seller_list` WRITE;
/*!40000 ALTER TABLE `cps_seller_list` DISABLE KEYS */;
INSERT INTO `cps_seller_list` VALUES (1,0,0,'测试商家','./data/seller_list/58be96a17c57e.jpg','',1,'',0,'测试商家\r\n测试商家\r\n测试商家\r\n测试商家\r\n测试商家',1,1,1,'11',1,0),(2,0,0,'测试商家2','./data/seller_list/58c89dc76a889.jpg','',1,'',0,'测试商家2测试商家2测试商家2',1,0,0,'1',1,0);
/*!40000 ALTER TABLE `cps_seller_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_seller_list_cate`
--

DROP TABLE IF EXISTS `cps_seller_list_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_seller_list_cate` (
  `list_id` int(11) NOT NULL,
  `cate_id` int(11) NOT NULL,
  KEY `list_id` (`list_id`),
  KEY `cate_id` (`cate_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_seller_list_cate`
--

LOCK TABLES `cps_seller_list_cate` WRITE;
/*!40000 ALTER TABLE `cps_seller_list_cate` DISABLE KEYS */;
INSERT INTO `cps_seller_list_cate` VALUES (1,101),(1,118),(1,104),(1,110),(2,122),(2,112),(2,111),(2,110),(2,108),(2,106),(2,105),(2,104),(2,114),(2,120),(2,119),(2,118),(2,116),(2,103),(2,102),(2,101);
/*!40000 ALTER TABLE `cps_seller_list_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_seller_list_goods`
--

DROP TABLE IF EXISTS `cps_seller_list_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_seller_list_goods` (
  `id` int(11) NOT NULL,
  `seller_list_id` int(11) NOT NULL,
  `seller_cate_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `seller_name` varchar(100) NOT NULL,
  `pic_url` varchar(400) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `original_price` decimal(10,2) NOT NULL,
  `desc` tinytext NOT NULL,
  `click_url` varchar(400) NOT NULL,
  `seller_url` varchar(400) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `seller_list_id` (`seller_list_id`),
  KEY `seller_cate_id` (`seller_cate_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_seller_list_goods`
--

LOCK TABLES `cps_seller_list_goods` WRITE;
/*!40000 ALTER TABLE `cps_seller_list_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_seller_list_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_send_email_log`
--

DROP TABLE IF EXISTS `cps_send_email_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_send_email_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `md5` char(32) NOT NULL,
  `create_time` varchar(20) NOT NULL,
  `ip` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `status` int(1) NOT NULL COMMENT '0表示没有激活，1表示激活',
  `address` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `message` varchar(1024) NOT NULL,
  `result` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_send_email_log`
--

LOCK TABLES `cps_send_email_log` WRITE;
/*!40000 ALTER TABLE `cps_send_email_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_send_email_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_seo`
--

DROP TABLE IF EXISTS `cps_seo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_seo` (
  `description` text,
  `keywords` text,
  `title` varchar(250) DEFAULT NULL,
  `actionname` varchar(30) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `actionname` (`actionname`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_seo`
--

LOCK TABLES `cps_seo` WRITE;
/*!40000 ALTER TABLE `cps_seo` DISABLE KEYS */;
INSERT INTO `cps_seo` VALUES ('{$site_name}是国内最大的优质商品购物分享社区，{$site_name}支持300多家b2c商家的商品发布。各路扮美达人与你分享购物经验、搭配秘笈、美人心计，发现喜欢，逛宝贝，逛街无处不做，让你感受逛街的乐趣吧。','{$site_name}，逛宝贝，促销活动，购物返现，购物返利','{$site_name}（htt）_ 发现喜欢，逛宝贝，逛街无处不在,让你感受逛街的乐趣','index',6),('{$site_name}2012火热促销活动，包括服装服饰数码产品、美妆配饰、家用电器、居家生活、母婴用品、户外用品、食品饮料、图书音像等热门促销活动，便宜，优惠，值得信赖，尽在{$site_name}\r\n','2012，火热促销活动，便宜，优惠，{$site_name}','2012火热促销活动，进行中 - {$site_name}','promo',10),('返现商家','返现商家','返现商家 - {$site_name}','seller',13),('{$site_name}是中国最大的购物分享社区。各路扮美达人与你分享购物经验、搭配秘笈、美人心计，发现喜欢，逛宝贝，逛街无处不做，让你感受逛街的乐趣吧。\r\n','{$site_name}开放平台，购物分享，逛宝贝，淘宝网购物,淘宝网女装,衣服搭配','发现喜欢，逛宝贝 -24小时最热 - {$site_name}','search',14),('{$site_name}专辑，收录美好点滴，记录你的美丽成长。你也可以在这里成为最受关注的专辑达人，享受粉丝们的热情追随。\r\n','专辑，逛街，时尚，{$site_name}','{$name}{$uname}{$title}{$album} 分享 - {$site_name}','album',15),('{$name}让你发现当前流行的服饰搭配元素，喜欢逛街，逛宝贝，想要把衣服搭得美丽，来{$site_name}看时尚网友精心挑选出的当季最流行的衣服单品、最佳搭配、购买心得、购物链接，购物分享，逛街分享无处不做，让你感受逛街的乐趣。\r\n','{$name}最热单品','{$name}{$pname}{$lname}{$site_name}','cate',16),('{$site_name}让你发现当前流行的服饰搭配元素，喜欢逛街，逛宝贝，想要把衣服搭得美丽，来{$site_name}看时尚网友精心挑选出的当季最流行的衣服单品、最佳搭配、购买心得、购物链接，购物分享，逛街分享无处不做，让你感受逛街的乐趣。\r\n','{$tags}','【图】{$title}{$site_name}','item',17),('积分兑换','积分兑换','积分兑换 - {$site_name}','exchange_goods',18);
/*!40000 ALTER TABLE `cps_seo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_setting`
--

DROP TABLE IF EXISTS `cps_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=80 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_setting`
--

LOCK TABLES `cps_setting` WRITE;
/*!40000 ALTER TABLE `cps_setting` DISABLE KEYS */;
INSERT INTO `cps_setting` VALUES (1,'site_name','CPS联盟系统'),(2,'site_title','CPS联盟系统'),(3,'site_keyword','CPS联盟系统'),(4,'site_description','CPS联盟系统'),(5,'site_status','1'),(6,'site_icp','京ICP备88888888号'),(7,'statistics_code',''),(8,'closed_reason','升级'),(9,'site_domain','http://msec.jieqiangtec.com'),(10,'taobao_usernick',''),(11,'taobao_pid',''),(12,'taobao_appkey',''),(13,'taobao_appsecret',''),(14,'weibo_url','http://www.weibo.com'),(15,'qqweibo_url','http://www.qq.com'),(16,'renren_url',''),(17,'163_url',''),(18,'qqzone_url',''),(19,'douban_url',''),(20,'default_kw','欧美,复古,日系,古典,女装,时尚'),(21,'template','default'),(22,'taobao_app_key','12504724'),(23,'qq_app_key',''),(24,'qq_app_Secret',''),(25,'sina_app_key','100308089'),(26,'sina_app_Secret','25ee4d31ca98edea230885985e1cf2e1'),(27,'taobao_app_secret','9d6877190386092d4288dcae32811081'),(28,'url_model','0'),(29,'waterfall_sp','15'),(30,'waterfall_items_num','5'),(31,'client_hash',''),(32,'search_words','欧美,复古,日系,古典,女装,时尚,韩版'),(33,'miao_appkey','1003336'),(34,'miao_appsecret','0847c5008f99150de65fad8e8ec342fa'),(35,'is_cashback','0'),(36,'cashback_rate','50'),(37,'lowest_get_cash','1'),(38,'integralback_rate','12'),(39,'user_register_score','51'),(40,'user_login_score','2'),(41,'share_goods_score','21'),(42,'delete_share_goods_score','21'),(43,'mail_smtp','smtp.exmail.qq.com'),(44,'mail_username','cps@adjyc.com'),(45,'mail_password','Cps@017'),(46,'mail_port','25'),(47,'mail_fromname','CPS管理员'),(48,'register_send_mail','1'),(49,'lately_like_max','10'),(50,'goods_save_images','0'),(51,'lately_like_rand','1,10'),(52,'check_code','0'),(53,'comment_time','10'),(54,'site_share','<meta property=\"qc:admins\" content=\"271503564761116217636\" /> '),(55,'ban_sipder','youdaobot|bingbot'),(56,'ban_ip','192.168.1.50'),(57,'site_logo','./data/setting/58d9d2b3a7db9.jpg'),(58,'collect_time','2'),(59,'goods_collect','0'),(60,'article_count','10'),(61,'show_masonry','0'),(62,'seller_list_collect','0'),(63,'seller_list_collect_time','1'),(64,'html_suffix','.html'),(65,'ucenterlogin','0'),(66,'commission_rate_min','500'),(67,'commission_rate_max','2000'),(68,'levelstart','1crown'),(69,'levelend','2goldencrown'),(70,'tao_session','6200712ae4ddb31d4cdegi04ee44b79a43a81cad4606ee0673992689'),(71,'lowest_get_jifen_cash','100'),(72,'cashback_type','1'),(73,'tb_fanxian_name','红包'),(74,'tb_fanxian_unit','个'),(75,'tb_fanxian_bili','100'),(76,'display_b2c_ad','1'),(77,'collect_cate',''),(78,'tao_collect_set','0'),(79,'taobao_search_pid','');
/*!40000 ALTER TABLE `cps_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_ucenter`
--

DROP TABLE IF EXISTS `cps_ucenter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_ucenter` (
  `name` varchar(255) DEFAULT NULL,
  `value` varchar(10000) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_ucenter`
--

LOCK TABLES `cps_ucenter` WRITE;
/*!40000 ALTER TABLE `cps_ucenter` DISABLE KEYS */;
INSERT INTO `cps_ucenter` VALUES ('dbcharset','utf8'),('charset','utf-8'),('dbconnect','0'),('ppp','20'),('appid','2'),('key','123456'),('api','http://192.168.1.53/vgoubbs/uc_server'),('ip',''),('connect','mysql'),('dbhost','192.168.1.100'),('dbuser','root'),('dbpw','123456'),('dbname','vgou_bbs'),('dbtablepre','`vgou_bbs`.pre_ucenter_'),('uc_config',NULL);
/*!40000 ALTER TABLE `cps_ucenter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_user`
--

DROP TABLE IF EXISTS `cps_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '0',
  `passwd` varchar(50) NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `last_time` int(11) NOT NULL DEFAULT '0',
  `last_ip` varchar(15) DEFAULT '0',
  `is_majia` int(1) DEFAULT '0' COMMENT '0表示普通用户 1表示马甲',
  `login_count` int(10) DEFAULT '0',
  `mobile` varchar(13) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `add_time` (`add_time`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_user`
--

LOCK TABLES `cps_user` WRITE;
/*!40000 ALTER TABLE `cps_user` DISABLE KEYS */;
INSERT INTO `cps_user` VALUES (4,'jieqiang','de562e3ceca28974c305237f2751ee6c','jieqiang@qq.com','127.0.0.1',1489051295,1,1489543034,'127.0.0.1',0,1,'18959269002');
/*!40000 ALTER TABLE `cps_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_user_comments`
--

DROP TABLE IF EXISTS `cps_user_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_user_comments` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `uname` varchar(100) NOT NULL,
  `pid` int(10) NOT NULL DEFAULT '0',
  `info` text,
  `type` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `add_time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `index_pid` (`pid`),
  KEY `index_status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_user_comments`
--

LOCK TABLES `cps_user_comments` WRITE;
/*!40000 ALTER TABLE `cps_user_comments` DISABLE KEYS */;
INSERT INTO `cps_user_comments` VALUES (1,4,'jieqiang',1,'ggggggggggggggg','item,index',1,1489544161);
/*!40000 ALTER TABLE `cps_user_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_user_consignee`
--

DROP TABLE IF EXISTS `cps_user_consignee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_user_consignee` (
  `uid` int(11) NOT NULL,
  `region_lv1` int(11) NOT NULL DEFAULT '0',
  `region_lv2` int(11) NOT NULL DEFAULT '0',
  `region_lv3` int(11) NOT NULL DEFAULT '0',
  `region_lv4` int(11) NOT NULL DEFAULT '0',
  `address` varchar(255) NOT NULL DEFAULT '',
  `mobile_phone` varchar(255) NOT NULL DEFAULT '',
  `fix_phone` varchar(255) NOT NULL DEFAULT '',
  `consignee` varchar(255) NOT NULL DEFAULT '',
  `zip` varchar(255) NOT NULL DEFAULT '',
  `qq` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `create_time` int(11) NOT NULL DEFAULT '0',
  `fax_phone` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_user_consignee`
--

LOCK TABLES `cps_user_consignee` WRITE;
/*!40000 ALTER TABLE `cps_user_consignee` DISABLE KEYS */;
INSERT INTO `cps_user_consignee` VALUES (4,0,0,0,0,'福建省厦门市集美区','18888888888','','街墙','366200','1569501393','18888888888@163.com',1489553243,'05922222222');
/*!40000 ALTER TABLE `cps_user_consignee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_user_follow`
--

DROP TABLE IF EXISTS `cps_user_follow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_user_follow` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fans_id` int(10) NOT NULL DEFAULT '0',
  `uid` int(10) NOT NULL DEFAULT '0',
  `add_time` int(10) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fans_id` (`fans_id`,`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_user_follow`
--

LOCK TABLES `cps_user_follow` WRITE;
/*!40000 ALTER TABLE `cps_user_follow` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_user_follow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_user_history`
--

DROP TABLE IF EXISTS `cps_user_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_user_history` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `uname` varchar(100) NOT NULL,
  `add_time` int(10) NOT NULL DEFAULT '0',
  `info` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_user_history`
--

LOCK TABLES `cps_user_history` WRITE;
/*!40000 ALTER TABLE `cps_user_history` DISABLE KEYS */;
INSERT INTO `cps_user_history` VALUES (1,4,'jieqiang',1489544165,'喜欢了一个宝贝~<br/><a href=\'http://www.ctw.com/index.php?a=index&m=item&id=1\' target=\'_blank\'><img src=\'http://www.ctw.com/data/items/m_58c8a3a5417e5.jpg\'/></a>'),(2,4,'',1489544175,'添加了一个宝贝到专辑中~<br/><a href=\'http://www.ctw.com/index.php?a=index&m=item&id=1\' target=\'_blank\'><img src=\'http://www.ctw.com/data/items/m_58c8a3a5417e5.jpg\'/></a>');
/*!40000 ALTER TABLE `cps_user_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_user_info`
--

DROP TABLE IF EXISTS `cps_user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_user_info` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `sex` tinyint(4) NOT NULL DEFAULT '0' COMMENT '//0表示男，1表示女，2表示未知',
  `brithday` varchar(50) NOT NULL DEFAULT '1985|1|1',
  `address` varchar(50) NOT NULL DEFAULT '请选择|请选择',
  `blog` varchar(200) NOT NULL DEFAULT 'http://',
  `info` varchar(500) NOT NULL DEFAULT '自我介绍',
  `share_num` int(11) DEFAULT '0',
  `like_num` int(11) DEFAULT '0',
  `follow_num` int(10) DEFAULT '0',
  `fans_num` int(10) DEFAULT '0',
  `album_num` int(10) DEFAULT '0',
  `exchange_num` int(8) NOT NULL DEFAULT '0',
  `integral` int(10) DEFAULT '0',
  `money` decimal(10,2) DEFAULT '0.00' COMMENT '用户资金',
  `jifenbao` decimal(10,0) DEFAULT '0',
  `constellation` tinyint(4) NOT NULL DEFAULT '0' COMMENT '星座',
  `job` tinyint(4) NOT NULL DEFAULT '0' COMMENT '职业',
  `qq` varchar(20) DEFAULT NULL,
  `realname` varchar(64) DEFAULT NULL,
  `alipay` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `integral` (`integral`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_user_info`
--

LOCK TABLES `cps_user_info` WRITE;
/*!40000 ALTER TABLE `cps_user_info` DISABLE KEYS */;
INSERT INTO `cps_user_info` VALUES (4,4,2,'1985|1|1','1|1','http://','自我介绍',0,1,0,0,0,6,49,'0.00','0',0,0,'655555555','街墙','jieqiangzhifubao@qq.com');
/*!40000 ALTER TABLE `cps_user_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_user_msg`
--

DROP TABLE IF EXISTS `cps_user_msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_user_msg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `to_user` varchar(40) NOT NULL,
  `from_user` varchar(40) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `del` tinyint(1) NOT NULL,
  `date` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_user_msg`
--

LOCK TABLES `cps_user_msg` WRITE;
/*!40000 ALTER TABLE `cps_user_msg` DISABLE KEYS */;
INSERT INTO `cps_user_msg` VALUES (1,'jieqiang','admin','用户注册短信','尊敬的jieqiang您好:欢迎注册v购,凡是通过v购提供的链接去淘宝购物进行购物，都将享受到1%到50%成交额的返现，推广其他用户，即可获取被推广用户返现额的50%的推广佣金，推广越多挣钱越轻松。祝您购物愉快！也欢迎您把我们的网站告诉更多的淘宝买家，谢谢！',0,1489051295),(2,'jieqiang','admin','赠送积分短信','恭喜您，您获得本站注册赠送积分51。',0,1489051295),(3,'jieqiang','','积分兑换短信','',0,1490240337),(4,'jieqiang','','积分兑换短信','',0,1490240344);
/*!40000 ALTER TABLE `cps_user_msg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_user_openid`
--

DROP TABLE IF EXISTS `cps_user_openid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_user_openid` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `uname` varchar(100) NOT NULL,
  `openid` varchar(50) NOT NULL DEFAULT '0',
  `info` text,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `openid` (`openid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_user_openid`
--

LOCK TABLES `cps_user_openid` WRITE;
/*!40000 ALTER TABLE `cps_user_openid` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_user_openid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_user_setmsg`
--

DROP TABLE IF EXISTS `cps_user_setmsg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_user_setmsg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(20) NOT NULL,
  `val` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_user_setmsg`
--

LOCK TABLES `cps_user_setmsg` WRITE;
/*!40000 ALTER TABLE `cps_user_setmsg` DISABLE KEYS */;
INSERT INTO `cps_user_setmsg` VALUES (51,'msg_zhuce','尊敬的[name]您好:欢迎注册[WEBTITLE],凡是通过[WEBTITLE]提供的链接去淘宝购物进行购物，都将享受到1%到50%成交额的返现，推广其他用户，即可获取被推广用户返现额的[tg]%的推广佣金，推广越多挣钱越轻松。祝您购物愉快！也欢迎您把我们的网站告诉更多的淘宝买家，谢谢！'),(52,'msg_zhucesong','恭喜您，您获得本站注册赠送现金[ZHUCESONG]元。'),(53,'msg_zsjifen','恭喜您，您获得本站注册赠送积分[ZSJIFEN]。'),(54,'msg_tabao','交易号为：[trade_id]的交易确认完毕，您获得了[fxje]元的返现！'),(55,'msg_taobaotuiguang','您推荐的会员[ddusername]，完成一笔交易，交易号为：[trade_id]确认完毕，您获得了[tgje]元的推广佣金！'),(56,'msg_tixianok','尊敬的[ddusername]，您好：您的提现申请已经受理完毕！本次提现金额[txje]已经支付到您提供的账户，查看明细进入“我的账户明细”！[addition]'),(57,'msg_tixianfail','您有一笔提现申请失败，原因是：[why]'),(58,'msg_deltrade','交易号为：[trade_id]的交易确被取消，您减少了[fxje]元的返现！'),(59,'msg_deltradetuiguang','您推荐的会员[ddusername]，取消了一笔交易，交易号为[trade_id]被确认无效，您减少了[tgje]元的推广佣金！'),(60,'msg_dhjifen','您在本站使用积分兑换的商品订单[STATE]。');
/*!40000 ALTER TABLE `cps_user_setmsg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_user_tixian`
--

DROP TABLE IF EXISTS `cps_user_tixian`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_user_tixian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `money` decimal(10,2) DEFAULT NULL,
  `jifenbao` decimal(10,0) DEFAULT '0',
  `remark` varchar(1000) NOT NULL,
  `addtime` varchar(40) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `reply` varchar(1000) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '//0表示没正在处理，1表示已经审核，2表示退回',
  `realname` varchar(64) DEFAULT NULL,
  `alipay` varchar(255) DEFAULT NULL,
  `is_money` int(1) DEFAULT '1' COMMENT '1表示钱2表示集分宝',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_user_tixian`
--

LOCK TABLES `cps_user_tixian` WRITE;
/*!40000 ALTER TABLE `cps_user_tixian` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_user_tixian` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_wegoapi`
--

DROP TABLE IF EXISTS `cps_wegoapi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_wegoapi` (
  `name` varchar(100) NOT NULL,
  `data` text NOT NULL,
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_wegoapi`
--

LOCK TABLES `cps_wegoapi` WRITE;
/*!40000 ALTER TABLE `cps_wegoapi` DISABLE KEYS */;
INSERT INTO `cps_wegoapi` VALUES ('username',''),('password',''),('weburl',''),('token',''),('commission_rate_min',''),('commission_rate_max',''),('levelstart','1heart'),('levelend','5goldencrown'),('tao_collect_set','0'),('order','3'),('price_min',''),('price_max','200'),('sign','123456789');
/*!40000 ALTER TABLE `cps_wegoapi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_word`
--

DROP TABLE IF EXISTS `cps_word`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_word` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `cid` smallint(6) NOT NULL DEFAULT '0',
  `word` varchar(255) NOT NULL DEFAULT '',
  `replacement` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(2) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `sort` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `cid` (`cid`),
  KEY `word` (`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_word`
--

LOCK TABLES `cps_word` WRITE;
/*!40000 ALTER TABLE `cps_word` DISABLE KEYS */;
/*!40000 ALTER TABLE `cps_word` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cps_word_cate`
--

DROP TABLE IF EXISTS `cps_word_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_word_cate` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cps_word_cate`
--

LOCK TABLES `cps_word_cate` WRITE;
/*!40000 ALTER TABLE `cps_word_cate` DISABLE KEYS */;
INSERT INTO `cps_word_cate` VALUES (3,'政治',1),(4,'时政',1);
/*!40000 ALTER TABLE `cps_word_cate` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-09-05 21:35:02
