-- MySQL dump 10.13  Distrib 5.1.73, for pc-linux-gnu (i686)
--
-- Host: localhost    Database: wc2
-- ------------------------------------------------------
-- Server version	5.1.63

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ims_account`
--

DROP TABLE IF EXISTS `ims_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_account` (
  `acid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `hash` varchar(8) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `isconnect` tinyint(4) NOT NULL,
  `isdeleted` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`acid`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_account`
--

LOCK TABLES `ims_account` WRITE;
/*!40000 ALTER TABLE `ims_account` DISABLE KEYS */;
INSERT INTO `ims_account` VALUES (1,1,'uRr8qvQV',1,0,0),(2,2,'x7Tg7pF0',1,0,0),(3,3,'Ys1dbzGy',1,0,1),(4,4,'ieDDv5K6',1,0,0),(5,5,'L99l2HC5',1,0,0),(6,6,'YD9MYmVm',1,1,0);
/*!40000 ALTER TABLE `ims_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_account_wechats`
--

DROP TABLE IF EXISTS `ims_account_wechats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_account_wechats` (
  `acid` int(10) unsigned NOT NULL,
  `uniacid` int(10) unsigned NOT NULL,
  `token` varchar(32) NOT NULL,
  `encodingaeskey` varchar(255) NOT NULL,
  `level` tinyint(4) unsigned NOT NULL,
  `name` varchar(30) NOT NULL,
  `account` varchar(30) NOT NULL,
  `original` varchar(50) NOT NULL,
  `signature` varchar(100) NOT NULL,
  `country` varchar(10) NOT NULL,
  `province` varchar(3) NOT NULL,
  `city` varchar(15) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `lastupdate` int(10) unsigned NOT NULL,
  `key` varchar(50) NOT NULL,
  `secret` varchar(50) NOT NULL,
  `styleid` int(10) unsigned NOT NULL,
  `subscribeurl` varchar(120) NOT NULL,
  `auth_refresh_token` varchar(255) NOT NULL,
  PRIMARY KEY (`acid`),
  KEY `idx_key` (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_account_wechats`
--

LOCK TABLES `ims_account_wechats` WRITE;
/*!40000 ALTER TABLE `ims_account_wechats` DISABLE KEYS */;
INSERT INTO `ims_account_wechats` VALUES (2,2,'smV2jZYvv54NqVMv2Z6Zv9nY9b92l2mc','oEoDo1cXX2Px1lt2Xq6xEzxxI62Q42xr12iTp2QCqk4',4,'test','test','test','','','','','','',0,'test','test',0,'',''),(3,3,'G9blR9sbibPY9r7sS7VlBim75M5hVhmr','BB9Dmz4llDi7EF84fePL0dFZp74ne7D77IbIfDL3ffM',4,'adjyctest','adjyc','gh_dca636eab4ce','','','','','','',0,'wxb797d06f10b3f641','ab235bf8be745b7d2c268ed8723020e2',0,'',''),(4,4,'B5i52RGoI5ItZohiCL2gIZlZIrn9KGNh','E3XL77vfUew7FFKO5973eF1FUu33mgO7ZL515w6715X',1,'adjyc2','','','','','','','','',0,'','',0,'',''),(5,5,'s74F6bfPt6mBBblFtPBppUfp2t7PoB2p','UQJJzC96Iiga6XSQRS8DFRAxQ63I9JagG6FaaccxJaG',1,'adjyc','adjyc','gh_dca636eab4ce','','','','','','',0,'wxb797d06f10b3f641','ab235bf8be745b7d2c268ed8723020e2',0,'',''),(6,6,'s74F6bfPt6mBBblFtPBppUfp2t7PoB2p','UQJJzC96Iiga6XSQRS8DFRAxQ63I9JagG6FaaccxJaG',4,'融惠联','adjyc','gh_dca636eab4ce','','','','','','',0,'wxb797d06f10b3f641','ab235bf8be745b7d2c268ed8723020e2',0,'','');
/*!40000 ALTER TABLE `ims_account_wechats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_account_wechats_微信配置`
--

DROP TABLE IF EXISTS `ims_account_wechats_微信配置`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_account_wechats_微信配置` (
  `acid` int(10) unsigned NOT NULL,
  `uniacid` int(10) unsigned NOT NULL,
  `token` varchar(32) NOT NULL,
  `encodingaeskey` varchar(255) NOT NULL,
  `level` tinyint(4) unsigned NOT NULL,
  `name` varchar(30) NOT NULL,
  `account` varchar(30) NOT NULL,
  `original` varchar(50) NOT NULL,
  `signature` varchar(100) NOT NULL,
  `country` varchar(10) NOT NULL,
  `province` varchar(3) NOT NULL,
  `city` varchar(15) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `lastupdate` int(10) unsigned NOT NULL,
  `key` varchar(50) NOT NULL,
  `secret` varchar(50) NOT NULL,
  `styleid` int(10) unsigned NOT NULL,
  `subscribeurl` varchar(120) NOT NULL,
  `auth_refresh_token` varchar(255) NOT NULL,
  PRIMARY KEY (`acid`),
  KEY `idx_key` (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_account_wechats_微信配置`
--

LOCK TABLES `ims_account_wechats_微信配置` WRITE;
/*!40000 ALTER TABLE `ims_account_wechats_微信配置` DISABLE KEYS */;
INSERT INTO `ims_account_wechats_微信配置` VALUES (2,2,'smV2jZYvv54NqVMv2Z6Zv9nY9b92l2mc','oEoDo1cXX2Px1lt2Xq6xEzxxI62Q42xr12iTp2QCqk4',4,'test','test','test','','','','','','',0,'test','test',0,'',''),(3,3,'G9blR9sbibPY9r7sS7VlBim75M5hVhmr','BB9Dmz4llDi7EF84fePL0dFZp74ne7D77IbIfDL3ffM',4,'adjyctest','adjyc','gh_dca636eab4ce','','','','','','',0,'wxb797d06f10b3f641','ab235bf8be745b7d2c268ed8723020e2',0,'',''),(4,4,'B5i52RGoI5ItZohiCL2gIZlZIrn9KGNh','E3XL77vfUew7FFKO5973eF1FUu33mgO7ZL515w6715X',1,'adjyc2','','','','','','','','',0,'','',0,'',''),(5,5,'s74F6bfPt6mBBblFtPBppUfp2t7PoB2p','UQJJzC96Iiga6XSQRS8DFRAxQ63I9JagG6FaaccxJaG',1,'adjyc','adjyc','gh_dca636eab4ce','','','','','','',0,'wxb797d06f10b3f641','ab235bf8be745b7d2c268ed8723020e2',0,'',''),(6,6,'s74F6bfPt6mBBblFtPBppUfp2t7PoB2p','UQJJzC96Iiga6XSQRS8DFRAxQ63I9JagG6FaaccxJaG',4,'adjyc','adjyc','gh_dca636eab4ce','','','','','','',0,'wxb797d06f10b3f641','ab235bf8be745b7d2c268ed8723020e2',0,'','');
/*!40000 ALTER TABLE `ims_account_wechats_微信配置` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_account_wxapp`
--

DROP TABLE IF EXISTS `ims_account_wxapp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_account_wxapp` (
  `acid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) NOT NULL,
  `token` varchar(32) NOT NULL,
  `encodingaeskey` varchar(43) NOT NULL,
  `level` tinyint(4) NOT NULL,
  `account` varchar(30) NOT NULL,
  `original` varchar(50) NOT NULL,
  `key` varchar(50) NOT NULL,
  `secret` varchar(50) NOT NULL,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`acid`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_account_wxapp`
--

LOCK TABLES `ims_account_wxapp` WRITE;
/*!40000 ALTER TABLE `ims_account_wxapp` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_account_wxapp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_activity_clerk_menu`
--

DROP TABLE IF EXISTS `ims_activity_clerk_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_activity_clerk_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `displayorder` int(4) NOT NULL,
  `pid` int(6) NOT NULL,
  `group_name` varchar(20) NOT NULL,
  `title` varchar(20) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `permission` varchar(50) NOT NULL,
  `system` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_activity_clerk_menu`
--

LOCK TABLES `ims_activity_clerk_menu` WRITE;
/*!40000 ALTER TABLE `ims_activity_clerk_menu` DISABLE KEYS */;
INSERT INTO `ims_activity_clerk_menu` VALUES (1,0,0,0,'mc','快捷交易','','','','mc_manage',1),(2,0,0,1,'','积分充值','fa fa-money','credit1','modal','mc_credit1',1),(3,0,0,1,'','余额充值','fa fa-cny','credit2','modal','mc_credit2',1),(4,0,0,1,'','消费','fa fa-usd','consume','modal','mc_consume',1),(5,0,0,1,'','发放会员卡','fa fa-credit-card','card','modal','mc_card',1),(6,0,0,0,'stat','数据统计','','','','stat_manage',1),(7,0,0,6,'','积分统计','fa fa-bar-chart','./index.php?c=site&a=entry&op=chart&do=statcredit1&m=we7_coupon','url','stat_credit1',1),(8,0,0,6,'','余额统计','fa fa-bar-chart','./index.php?c=site&a=entry&op=chart&do=statcredit2&m=we7_coupon','url','stat_credit2',1),(9,0,0,6,'','现金消费统计','fa fa-bar-chart','./index.php?c=site&a=entry&op=chart&do=statcash&m=we7_coupon','url','stat_cash',1),(10,0,0,6,'','会员卡统计','fa fa-bar-chart','./index.php?c=site&a=entry&op=chart&do=statcard&m=we7_coupon','url','stat_card',1),(11,0,0,6,'','收银台收款统计','fa fa-bar-chart','./index.php?c=site&a=entry&op=chart&do=statpaycenter&m=we7_coupon','url','stat_paycenter',1),(12,0,0,0,'activity','卡券核销','','','','activity_card_manage',1),(16,0,0,12,'','卡券核销','fa fa-money','cardconsume','modal','coupon_consume',1),(17,0,0,0,'paycenter','收银台','','','','paycenter_manage',1),(18,0,0,17,'','微信刷卡收款','fa fa-money','./index.php?c=paycenter&a=wxmicro&do=pay','url','paycenter_wxmicro_pay',1);
/*!40000 ALTER TABLE `ims_activity_clerk_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_activity_clerks`
--

DROP TABLE IF EXISTS `ims_activity_clerks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_activity_clerks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联users表uid',
  `storeid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `openid` varchar(50) NOT NULL,
  `nickname` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `password` (`password`),
  KEY `openid` (`openid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='积分兑换店员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_activity_clerks`
--

LOCK TABLES `ims_activity_clerks` WRITE;
/*!40000 ALTER TABLE `ims_activity_clerks` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_activity_clerks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_activity_exchange`
--

DROP TABLE IF EXISTS `ims_activity_exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_activity_exchange` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `title` varchar(100) NOT NULL COMMENT '物品名称',
  `description` text NOT NULL COMMENT '描述信息',
  `thumb` varchar(500) NOT NULL COMMENT '缩略图',
  `type` tinyint(1) unsigned NOT NULL COMMENT '物品类型，1系统卡券，2微信呢卡券，3实物，4虚拟物品(未启用)，5营销模块操作次数',
  `extra` varchar(3000) NOT NULL DEFAULT '' COMMENT '兑换产品属性 卡券自增id',
  `credit` int(10) unsigned NOT NULL COMMENT '兑换积分数量',
  `credittype` varchar(10) NOT NULL COMMENT '兑换积分类型',
  `pretotal` int(11) NOT NULL COMMENT '每个人最大兑换次数',
  `num` int(11) NOT NULL COMMENT '已兑换礼品数量',
  `total` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '总量',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  `starttime` int(10) unsigned NOT NULL,
  `endtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `extra` (`extra`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='真实物品兑换表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_activity_exchange`
--

LOCK TABLES `ims_activity_exchange` WRITE;
/*!40000 ALTER TABLE `ims_activity_exchange` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_activity_exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_activity_exchange_trades`
--

DROP TABLE IF EXISTS `ims_activity_exchange_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_activity_exchange_trades` (
  `tid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL COMMENT '统一公号',
  `uid` int(10) unsigned NOT NULL COMMENT '用户(粉丝)id',
  `exid` int(10) unsigned NOT NULL COMMENT '兑换产品 exchangeid',
  `type` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '交换记录创建时间',
  PRIMARY KEY (`tid`),
  KEY `uniacid` (`uniacid`,`uid`,`exid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='真实物品兑换记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_activity_exchange_trades`
--

LOCK TABLES `ims_activity_exchange_trades` WRITE;
/*!40000 ALTER TABLE `ims_activity_exchange_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_activity_exchange_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_activity_exchange_trades_shipping`
--

DROP TABLE IF EXISTS `ims_activity_exchange_trades_shipping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_activity_exchange_trades_shipping` (
  `tid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `exid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '订单状态，0为正常，-1为关闭，1为已发货，2为已完成',
  `createtime` int(10) unsigned NOT NULL,
  `province` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `district` varchar(30) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zipcode` varchar(6) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL COMMENT '收件人',
  PRIMARY KEY (`tid`),
  KEY `uniacid` (`uniacid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='真实物品兑换发货表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_activity_exchange_trades_shipping`
--

LOCK TABLES `ims_activity_exchange_trades_shipping` WRITE;
/*!40000 ALTER TABLE `ims_activity_exchange_trades_shipping` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_activity_exchange_trades_shipping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_activity_stores`
--

DROP TABLE IF EXISTS `ims_activity_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_activity_stores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `business_name` varchar(50) NOT NULL,
  `branch_name` varchar(50) NOT NULL,
  `category` varchar(255) NOT NULL,
  `province` varchar(15) NOT NULL,
  `city` varchar(15) NOT NULL,
  `district` varchar(15) NOT NULL,
  `address` varchar(50) NOT NULL,
  `longitude` varchar(15) NOT NULL,
  `latitude` varchar(15) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `photo_list` varchar(10000) NOT NULL,
  `avg_price` int(10) unsigned NOT NULL,
  `recommend` varchar(255) NOT NULL,
  `special` varchar(255) NOT NULL,
  `introduction` varchar(255) NOT NULL,
  `open_time` varchar(50) NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL COMMENT '1 审核通过 2 审核中 3审核未通过',
  `source` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1为系统门店，2为微信门店',
  `message` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `location_id` (`location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_activity_stores`
--

LOCK TABLES `ims_activity_stores` WRITE;
/*!40000 ALTER TABLE `ims_activity_stores` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_activity_stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_article_category`
--

DROP TABLE IF EXISTS `ims_article_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_article_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  `type` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_article_category`
--

LOCK TABLES `ims_article_category` WRITE;
/*!40000 ALTER TABLE `ims_article_category` DISABLE KEYS */;
INSERT INTO `ims_article_category` VALUES (1,'公告',100,'notice'),(2,'新闻',99,'notice');
/*!40000 ALTER TABLE `ims_article_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_article_news`
--

DROP TABLE IF EXISTS `ims_article_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_article_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cateid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `source` varchar(255) NOT NULL,
  `author` varchar(50) NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  `is_display` tinyint(3) unsigned NOT NULL,
  `is_show_home` tinyint(3) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `click` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `title` (`title`),
  KEY `cateid` (`cateid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_article_news`
--

LOCK TABLES `ims_article_news` WRITE;
/*!40000 ALTER TABLE `ims_article_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_article_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_article_notice`
--

DROP TABLE IF EXISTS `ims_article_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_article_notice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cateid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  `is_display` tinyint(3) unsigned NOT NULL,
  `is_show_home` tinyint(3) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `click` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `title` (`title`),
  KEY `cateid` (`cateid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_article_notice`
--

LOCK TABLES `ims_article_notice` WRITE;
/*!40000 ALTER TABLE `ims_article_notice` DISABLE KEYS */;
INSERT INTO `ims_article_notice` VALUES (1,1,'我的公告','<p style=\"padding: 0px; margin-top: 15px; margin-bottom: 15px; line-height: 25px; font-size: 14px; font-family: Verdana, Arial, Tahoma; white-space: normal; background-color: rgb(255, 255, 255);\">人的一生会遇到无数个对手，也要面临各种各样的挑战。而最强的对手则是自己。最难的挑战则是打败自己心中的惰性。当你还在安于现状碌碌不为时，不妨去看看身边那些正在拼搏的人。</p><p style=\"padding: 0px; margin-top: 15px; margin-bottom: 15px; line-height: 25px; font-size: 14px; font-family: Verdana, Arial, Tahoma; white-space: normal; background-color: rgb(255, 255, 255);\">冬日的早晨，出奇的好睡。丙一觉睡到早上十点才在昏昏沉沉中醒来。可又留念被窝的温暖不愿起床。迷迷糊糊中准备再次睡去时，却发现同寝室的室友甲和乙已经坐在书桌前了。他也一下子清醒了起来，发现乙正在书桌前做着作业，而且快要做完了。而甲已经把作业做完了，正在复习功课。比自己优秀的人比自己还要努力的多，那时的丙，还睡的着吗?甲与乙给予丙的无形压力正化为丙学习的动力，并一点点地敲击着丙心中的惰性。试想一下，如果丙没有像甲和乙这样优秀且勤奋的舍友，那他要在醒来睡，睡完醒再复睡去消磨掉多少时光?估计连早饭午饭都省了，那学业又怎么办呢?</p><p><br/></p>',0,1,1,1504102482,898);
/*!40000 ALTER TABLE `ims_article_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_article_unread_notice`
--

DROP TABLE IF EXISTS `ims_article_unread_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_article_unread_notice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `notice_id` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `is_new` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `notice_id` (`notice_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_article_unread_notice`
--

LOCK TABLES `ims_article_unread_notice` WRITE;
/*!40000 ALTER TABLE `ims_article_unread_notice` DISABLE KEYS */;
INSERT INTO `ims_article_unread_notice` VALUES (1,1,1,1);
/*!40000 ALTER TABLE `ims_article_unread_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_basic_reply`
--

DROP TABLE IF EXISTS `ims_basic_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_basic_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `content` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_basic_reply`
--

LOCK TABLES `ims_basic_reply` WRITE;
/*!40000 ALTER TABLE `ims_basic_reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_basic_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_bm_top_reply`
--

DROP TABLE IF EXISTS `ims_bm_top_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_bm_top_reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL DEFAULT '0',
  `weid` int(11) NOT NULL,
  `n` int(10) NOT NULL DEFAULT '0',
  `desc` varchar(500) NOT NULL,
  `pictype` int(1) NOT NULL DEFAULT '0',
  `picurl` varchar(100) DEFAULT NULL,
  `urlx` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_bm_top_reply`
--

LOCK TABLES `ims_bm_top_reply` WRITE;
/*!40000 ALTER TABLE `ims_bm_top_reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_bm_top_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_business`
--

DROP TABLE IF EXISTS `ims_business`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_business` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `content` varchar(1000) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `qq` varchar(15) NOT NULL,
  `province` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `dist` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `lng` varchar(10) NOT NULL,
  `lat` varchar(10) NOT NULL,
  `industry1` varchar(10) NOT NULL,
  `industry2` varchar(10) NOT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lat_lng` (`lng`,`lat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_business`
--

LOCK TABLES `ims_business` WRITE;
/*!40000 ALTER TABLE `ims_business` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_business` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_core_attachment`
--

DROP TABLE IF EXISTS `ims_core_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_core_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `attachment` varchar(255) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_core_attachment`
--

LOCK TABLES `ims_core_attachment` WRITE;
/*!40000 ALTER TABLE `ims_core_attachment` DISABLE KEYS */;
INSERT INTO `ims_core_attachment` VALUES (1,2,0,'421508-1-30092-26-400_400.jpg','images/2/2017/08/S2nb86zld66n4mZd84qmq686mjMU08.jpg',1,1504100084),(2,2,1,'qrcode_5.jpg','images/global/QfV5hTviIz3r51ifTrg3v1fVRa5VrW.jpg',1,1504100189),(3,2,1,'getheadimg.jpg','images/global/o1Znky1Nz25qZM5NZ4zynnmK5K1N4V.jpg',1,1504100195),(4,5,1,'getheadimg.jpg','images/5/2017/08/GHyqlS19yDA9saqsaHLh9q1DyaaZ19.jpg',1,1504101020),(5,5,1,'qrcode_5.jpg','images/5/2017/08/qn6g63tSLL46kd6k6ylltGG638ZrZ6.jpg',1,1504101026),(6,6,1,'getheadimg.jpg','images/6/2017/08/gV9xXX9sUB88fv5lteHHHFBxfH5Hk5.jpg',1,1504103479),(7,6,1,'503474ff36995.jpg','images/6/2017/08/o2w9ICzi7W3u9c7IC0Q11z9z9Z2yu9.jpg',1,1504105743),(8,6,1,'5034749736066.jpg','images/6/2017/08/rh67772225uY2s02S5wQzDgJ2w6ihG.jpg',1,1504105837),(9,6,1,'417495-1-30092-3-400_400.jpg','images/6/2017/08/NtB2H42d5qWSswJRSqSedrSD1fS2fF.jpg',1,1504106547),(10,6,1,'421508-1-30092-26-400_400.jpg','images/6/2017/08/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg',1,1504106547),(11,6,1,'421508-1-30092-27-400_400.jpg','images/6/2017/08/Hsaztc6GfcD1DfGyF3vGTY1G1fJ11D.jpg',1,1504106547),(12,6,1,'421508-1-30092-28-400_400.jpg','images/6/2017/08/iX1157L8SLvQV6L5wWlQQx8isIh5IV.jpg',1,1504106547),(13,6,1,'417495-1-30092-1-400_400.jpg','images/6/2017/08/a46LO6o4wOoSPnqSslloA4n1m7SgxX.jpg',1,1504106547),(14,6,1,'417495-1-30092-2-400_400.jpg','images/6/2017/08/iVcEq4v1LWqRzbRqV4XbeE5tXECZJq.jpg',1,1504106547),(15,6,1,'nav-sj-0621.jpg','images/6/2017/09/qJjG2YfkZJD5KKa6TGg3n3jW32j2J2.jpg',1,1504322255),(16,6,1,'H-gb-0822.jpg','images/6/2017/09/Sj96Wi726WwH210Itzk6xx1Y2uxht6.jpg',1,1504322291),(17,6,1,'H-jf-0626.jpg','images/6/2017/09/nnNjMAgGqNgs3g800ZnDY40AM8QSam.jpg',1,1504322407),(18,6,1,'H-jjg-0822.jpg','images/6/2017/09/a9Jw7fAhmwzvF7t98P70W11VAaxXZf.jpg',1,1504322421),(19,6,1,'H-jsj-0901.jpg','images/6/2017/09/KM997qmpN8M9N078DHiM88mhp90q8H.jpg',1,1504322449),(20,6,1,'H-kj-0718.jpg','images/6/2017/09/Xj5aP3Zk7r3J3p3Vt33Yt8K86R0KIu.jpg',1,1504322473),(21,6,1,'nav-jj-0621.jpg','images/6/2017/09/NIJc7aCmdk72AXM7DL3czqWxANCD7c.jpg',1,1504322506),(22,6,1,'nav-js-0621.jpg','images/6/2017/09/o94DHq1tHIiiMz89AT1oh55QqEiyzm.jpg',1,1504322528),(23,6,1,'nav-kq-0621.jpg','images/6/2017/09/TV2sfQxQsosw23eWQeeIv5vzfZ7Kos.jpg',1,1504322545),(24,6,1,'nav-mz-0621.jpg','images/6/2017/09/Z2LrZwPT1zXtGx2MTwlAZWWp16PRP2.jpg',1,1504322602),(25,6,1,'nav-nw-0621.jpg','images/6/2017/09/Yg0WRKtCTwUUBHhpHx00KWPCw11ru4.jpg',1,1504322618),(26,6,1,'nav-xb-0621.jpg','images/6/2017/09/I46GWeh8e76m5mQz4Tw7QezV6htT4g.jpg',1,1504322663),(27,6,1,'H-ppt-0901手袋.jpg','images/6/2017/09/NOs96ZbI0u0cZ7sS77o7rk59rY99UV.jpg',1,1504323358),(28,6,1,'H-xp-0829新品.jpg','images/6/2017/09/bNO6q4BzEj55KmJZNx3j56hL0qRXNn.jpg',1,1504323374),(29,6,1,'H-xsq-0901手镯.jpg','images/6/2017/09/ed5J57Z3sSc7JWC5583lDrdrwDH5wL.jpg',1,1504323391),(30,6,1,'5954cf81N3294a71c.png','images/6/2017/09/rEuz781u0YrcqAi0AARJZAiEAcAq1J.png',1,1504323591),(31,6,1,'59263c71Nc7d16503京东生鲜.png','images/6/2017/09/Oy86u6Y26U6BY2KZ6duVEb2DuUe6D6.png',1,1504323729),(32,6,1,'591d94c4N79a488cc领券.png','images/6/2017/09/z7VvDvEvlYfwifYvUVv5vVvyFvDwjG.png',1,1504323747),(33,6,1,'591d94c6Nc4711ad2惠赚钱.png','images/6/2017/09/F4e55cvi5wnWEuhJCl5EjecJe4gcLg.png',1,1504323779),(34,6,1,'591d94c4N79a488cc领券.png','images/6/2017/09/Z96Q5yC5ZhyeQq16r1g6qURWcWzW5H.png',1,1504323937),(35,6,1,'591d94edNc42fb94d物流查询.png','images/6/2017/09/ypzZt6SIPoTV8ipov2u62Uriu8jSVZ.png',1,1504323937),(36,6,1,'591d94c6Nc4711ad2惠赚钱.png','images/6/2017/09/uXTxaYNZ7tPa7Tqynn7XwbEPp0gYPB.png',1,1504323937),(37,6,1,'591d9424N068a7ad0京东超市.png','images/6/2017/09/voGzUgUnDj6ounWbzObct63coNdrt6.png',1,1504323937),(38,6,1,'59a775a5Ne19d982c服装城.png','images/6/2017/09/K0I0ZK3kR6uRYYzya13717RYJ6YIRR.png',1,1504323938),(39,6,1,'5954cf81N3294a71c进口.png','images/6/2017/09/HHr4WV2UsRN4Ph4hCvHZk2tFT4TiTw.png',1,1504323938),(40,6,1,'59263c71Nc7d16503京东生鲜.png','images/6/2017/09/ZYZHIA4aJ90hEUe3au4Ey3JLLaIuEi.png',1,1504323938),(41,6,1,'H-xsq-0901手镯.jpg','images/6/2017/09/svr2DEsD9F9V2eN91sRzT9cvN5EFl1.jpg',1,1504323938),(42,6,1,'H-xp-0829新品.jpg','images/6/2017/09/sRpERnuzuPwUypRID8yD8DZPVUwAtZ.jpg',1,1504323938),(43,6,1,'H-ppt-0901手袋.jpg','images/6/2017/09/c8WWw8plOw99wyZ98RQWQ2I55wlQG8.jpg',1,1504323938),(44,6,1,'428777-4-32026-1-400_400.jpg','images/6/2017/09/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg',1,1504323958),(45,6,1,'428777-4-32026-2-400_400.jpg','images/6/2017/09/rXW75MjxaZ5xqVxs83WtSz63iAX5lI.jpg',1,1504323958),(46,6,1,'428777-4-32026-3-400_400.jpg','images/6/2017/09/vDi5Ra2nn0r22SNJAn5ry0orarrRrN.jpg',1,1504323958),(47,6,1,'422868-4-17202-1-400_400.jpg','images/6/2017/09/ZV20RVomRy5v2Koyr595i23YK53k3r.jpg',1,1504324233),(48,6,1,'422868-4-17202-4-400_400.jpg','images/6/2017/09/rlyyAkyaVK8KNMA3o33F1yyF81nQKa.jpg',1,1504324233),(49,6,1,'422868-4-17202-2-400_400.jpg','images/6/2017/09/Az3Wbbt4P4r9tg3TPGczCPrL3bRJ9T.jpg',1,1504324236),(50,6,1,'432040-4-1470-14-400_400.jpg','images/6/2017/09/z80g1eA5ijs6SG0ZsiZ5zeziSJz555.jpg',1,1504324586),(51,6,1,'432040-4-1470-15-400_400.jpg','images/6/2017/09/Oo1M1enny99084Z1y14loO4M18Uc71.jpg',1,1504324586),(52,6,1,'432040-4-1470-13-400_400.jpg','images/6/2017/09/k7rllslYzm24ldq9ZlL742l79Ms2R1.jpg',1,1504324586),(53,6,1,'mmexport1504195257547.jpg','images/6/2017/09/BucY4YMU62e6wklTLP4YMkg23uwN62.jpg',1,1504324886),(54,6,1,'融惠联微信图片_20170902133942.png','images/6/2017/09/cl3i11TLIgn22sl9K56STSLZ1L0A1S.png',1,1504423512),(55,6,1,'融惠联.png','images/6/2017/09/sTK6rdRr2d2T8m2AAireBB82MAMZpM.png',1,1504423743),(56,6,1,'438310-1-31991-7-400_400.jpg','images/6/2017/09/NgLM2LbCR9C0l9dr9BBH03k3CpBCpR.jpg',1,1504424344),(57,6,1,'438310-1-31991-6-400_400.jpg','images/6/2017/09/De417eS19TARZSl1hY5e704eU7C45E.jpg',1,1504424344),(58,6,1,'438310-1-31991-8-400_400.jpg','images/6/2017/09/Djjf0ApMQ03Zr8rvMm3F8qn8tr8pvD.jpg',1,1504424344),(59,6,1,'438310-1-31991-9-400_400.jpg','images/6/2017/09/rjZZ0NQOy2N1Y1JwMSI0nOCnpMYqDz.jpg',1,1504424344),(60,6,1,'438310-1-31991-10-400_400.jpg','images/6/2017/09/z2J97xJ2RPlI792J0J5D25R2W29L7r.jpg',1,1504424344),(61,6,1,'436502-1-31989-5-400_400.jpg','images/6/2017/09/V1yNIw1OErYwyliLlbtWe6oOyW6Ybb.jpg',1,1504425309),(62,6,1,'格玛仕2.jpg','images/6/2017/09/KKzrEcac22C28u6R8ARECCec666666.jpg',1,1504425309),(63,6,1,'436502-1-31989-8-400_400.jpg','images/6/2017/09/W9O99t515KfTKXb28koTYtO52VB5Oo.jpg',1,1504425309),(64,6,1,'格玛仕.jpg','images/6/2017/09/IrnOOxtTXv2mLsRtzzdjjvSxJJyS2t.jpg',1,1504425309),(65,6,1,'qrcode_5.jpg','images/global/mz1w4jmlQlom6IWl0O1a6pf00jo8cE.jpg',1,1504447233),(66,6,1,'融惠联400-100.png','images/global/Fkp8067FX8K72AbS8cx2BSY2sSb1YF.png',1,1504532566),(67,6,1,'融惠联195_40.png','images/global/f22kf6228kd8ztKXk6826Mmul66d8F.png',1,1504534455);
/*!40000 ALTER TABLE `ims_core_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_core_cache`
--

DROP TABLE IF EXISTS `ims_core_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_core_cache` (
  `key` varchar(50) NOT NULL,
  `value` longtext NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_core_cache`
--

LOCK TABLES `ims_core_cache` WRITE;
/*!40000 ALTER TABLE `ims_core_cache` DISABLE KEYS */;
INSERT INTO `ims_core_cache` VALUES ('account:ticket','s:0:\"\";'),('userbasefields','a:45:{s:7:\"uniacid\";s:17:\"同一公众号id\";s:7:\"groupid\";s:8:\"分组id\";s:7:\"credit1\";s:6:\"积分\";s:7:\"credit2\";s:6:\"余额\";s:7:\"credit3\";s:19:\"预留积分类型3\";s:7:\"credit4\";s:19:\"预留积分类型4\";s:7:\"credit5\";s:19:\"预留积分类型5\";s:7:\"credit6\";s:19:\"预留积分类型6\";s:10:\"createtime\";s:12:\"加入时间\";s:6:\"mobile\";s:12:\"手机号码\";s:5:\"email\";s:12:\"电子邮箱\";s:8:\"realname\";s:12:\"真实姓名\";s:8:\"nickname\";s:6:\"昵称\";s:6:\"avatar\";s:6:\"头像\";s:2:\"qq\";s:5:\"QQ号\";s:6:\"gender\";s:6:\"性别\";s:5:\"birth\";s:6:\"生日\";s:13:\"constellation\";s:6:\"星座\";s:6:\"zodiac\";s:6:\"生肖\";s:9:\"telephone\";s:12:\"固定电话\";s:6:\"idcard\";s:12:\"证件号码\";s:9:\"studentid\";s:6:\"学号\";s:5:\"grade\";s:6:\"班级\";s:7:\"address\";s:6:\"地址\";s:7:\"zipcode\";s:6:\"邮编\";s:11:\"nationality\";s:6:\"国籍\";s:6:\"reside\";s:9:\"居住地\";s:14:\"graduateschool\";s:12:\"毕业学校\";s:7:\"company\";s:6:\"公司\";s:9:\"education\";s:6:\"学历\";s:10:\"occupation\";s:6:\"职业\";s:8:\"position\";s:6:\"职位\";s:7:\"revenue\";s:9:\"年收入\";s:15:\"affectivestatus\";s:12:\"情感状态\";s:10:\"lookingfor\";s:13:\" 交友目的\";s:9:\"bloodtype\";s:6:\"血型\";s:6:\"height\";s:6:\"身高\";s:6:\"weight\";s:6:\"体重\";s:6:\"alipay\";s:15:\"支付宝帐号\";s:3:\"msn\";s:3:\"MSN\";s:6:\"taobao\";s:12:\"阿里旺旺\";s:4:\"site\";s:6:\"主页\";s:3:\"bio\";s:12:\"自我介绍\";s:8:\"interest\";s:12:\"兴趣爱好\";s:8:\"password\";s:6:\"密码\";}'),('usersfields','a:46:{s:8:\"realname\";s:12:\"真实姓名\";s:8:\"nickname\";s:6:\"昵称\";s:6:\"avatar\";s:6:\"头像\";s:2:\"qq\";s:5:\"QQ号\";s:6:\"mobile\";s:12:\"手机号码\";s:3:\"vip\";s:9:\"VIP级别\";s:6:\"gender\";s:6:\"性别\";s:9:\"birthyear\";s:12:\"出生生日\";s:13:\"constellation\";s:6:\"星座\";s:6:\"zodiac\";s:6:\"生肖\";s:9:\"telephone\";s:12:\"固定电话\";s:6:\"idcard\";s:12:\"证件号码\";s:9:\"studentid\";s:6:\"学号\";s:5:\"grade\";s:6:\"班级\";s:7:\"address\";s:12:\"邮寄地址\";s:7:\"zipcode\";s:6:\"邮编\";s:11:\"nationality\";s:6:\"国籍\";s:14:\"resideprovince\";s:12:\"居住地址\";s:14:\"graduateschool\";s:12:\"毕业学校\";s:7:\"company\";s:6:\"公司\";s:9:\"education\";s:6:\"学历\";s:10:\"occupation\";s:6:\"职业\";s:8:\"position\";s:6:\"职位\";s:7:\"revenue\";s:9:\"年收入\";s:15:\"affectivestatus\";s:12:\"情感状态\";s:10:\"lookingfor\";s:13:\" 交友目的\";s:9:\"bloodtype\";s:6:\"血型\";s:6:\"height\";s:6:\"身高\";s:6:\"weight\";s:6:\"体重\";s:6:\"alipay\";s:15:\"支付宝帐号\";s:3:\"msn\";s:3:\"MSN\";s:5:\"email\";s:12:\"电子邮箱\";s:6:\"taobao\";s:12:\"阿里旺旺\";s:4:\"site\";s:6:\"主页\";s:3:\"bio\";s:12:\"自我介绍\";s:8:\"interest\";s:12:\"兴趣爱好\";s:7:\"uniacid\";s:17:\"同一公众号id\";s:7:\"groupid\";s:8:\"分组id\";s:7:\"credit1\";s:6:\"积分\";s:7:\"credit2\";s:6:\"余额\";s:7:\"credit3\";s:19:\"预留积分类型3\";s:7:\"credit4\";s:19:\"预留积分类型4\";s:7:\"credit5\";s:19:\"预留积分类型5\";s:7:\"credit6\";s:19:\"预留积分类型6\";s:10:\"createtime\";s:12:\"加入时间\";s:8:\"password\";s:12:\"用户密码\";}'),('setting','a:10:{s:9:\"copyright\";a:28:{s:6:\"status\";s:1:\"0\";s:10:\"verifycode\";s:1:\"0\";s:6:\"reason\";s:0:\"\";s:8:\"sitename\";s:9:\"融惠联\";s:3:\"url\";s:7:\"http://\";s:8:\"statcode\";s:0:\"\";s:10:\"footerleft\";s:26:\"融惠联版权所有 2017\";s:11:\"footerright\";s:21:\"融惠联版权所有\";s:4:\"icon\";s:0:\"\";s:6:\"flogo1\";s:48:\"images/global/f22kf6228kd8ztKXk6826Mmul66d8F.png\";s:6:\"flogo2\";s:48:\"images/global/f22kf6228kd8ztKXk6826Mmul66d8F.png\";s:6:\"slides\";s:2:\"N;\";s:6:\"notice\";s:9:\"融惠联\";s:5:\"blogo\";s:48:\"images/global/f22kf6228kd8ztKXk6826Mmul66d8F.png\";s:6:\"qrcode\";s:48:\"images/global/mz1w4jmlQlom6IWl0O1a6pf00jo8cE.jpg\";s:8:\"baidumap\";a:2:{s:3:\"lng\";s:0:\"\";s:3:\"lat\";s:0:\"\";}s:7:\"company\";s:9:\"融惠联\";s:4:\"skin\";s:7:\"default\";s:14:\"companyprofile\";s:0:\"\";s:7:\"address\";s:15:\"融惠联地址\";s:6:\"person\";s:3:\"jie\";s:5:\"phone\";s:11:\"18959269002\";s:2:\"qq\";s:10:\"1569501393\";s:5:\"email\";s:17:\"1569501393@qq.com\";s:8:\"keywords\";s:9:\"融惠联\";s:11:\"description\";s:9:\"融惠联\";s:12:\"showhomepage\";i:0;s:13:\"leftmenufixed\";i:0;}s:8:\"authmode\";i:1;s:5:\"close\";a:2:{s:6:\"status\";s:1:\"0\";s:6:\"reason\";s:0:\"\";}s:8:\"register\";a:4:{s:4:\"open\";i:1;s:6:\"verify\";i:0;s:4:\"code\";i:1;s:7:\"groupid\";i:1;}s:4:\"site\";a:5:{s:3:\"key\";s:6:\"888888\";s:5:\"token\";s:23:\"shop33453630.taobao.com\";s:3:\"url\";s:30:\"http://shop33453630.taobao.com\";s:7:\"version\";s:5:\"1.4.0\";s:15:\"profile_perfect\";i:1;}s:10:\"module_ban\";a:0:{}s:14:\"module_upgrade\";a:0:{}s:5:\"basic\";a:1:{s:8:\"template\";s:10:\"affordable\";}s:8:\"platform\";a:5:{s:5:\"token\";s:32:\"Q3gAV93Pe9t11lVi30eBgfAIrLK39r03\";s:14:\"encodingaeskey\";s:43:\"kf4TaD48eG4CSE38cUtA4Tc4sSdacE4cdADGGJs0SaF\";s:9:\"appsecret\";s:0:\"\";s:5:\"appid\";s:0:\"\";s:9:\"authstate\";i:1;}s:7:\"cloudip\";a:0:{}}'),('we7:all_cloud_upgrade_module:','a:2:{s:6:\"expire\";i:1504276437;s:4:\"data\";a:0:{}}'),('we7:lastaccount:ALin7','a:1:{s:7:\"account\";i:6;}'),('we7:lastaccount:GD9Ll','a:1:{s:7:\"account\";i:6;}'),('we7:module:all_uninstall','a:2:{s:6:\"expire\";i:1504614258;s:4:\"data\";a:4:{s:13:\"cloud_m_count\";N;s:7:\"modules\";a:2:{s:7:\"recycle\";a:0:{}s:11:\"uninstalled\";a:0:{}}s:9:\"app_count\";i:0;s:11:\"wxapp_count\";i:0;}}'),('we7:user_modules:1','a:15:{i:0;s:10:\"we7_coupon\";i:1;s:18:\"stonefish_bigwheel\";i:2;s:6:\"bm_top\";i:3;s:11:\"ewei_shopv2\";i:4;s:6:\"wxcard\";i:5;s:5:\"chats\";i:6;s:5:\"voice\";i:7;s:5:\"video\";i:8;s:6:\"images\";i:9;s:6:\"custom\";i:10;s:8:\"recharge\";i:11;s:7:\"userapi\";i:12;s:5:\"music\";i:13;s:4:\"news\";i:14;s:5:\"basic\";}'),('unisetting:3','a:22:{s:7:\"uniacid\";s:1:\"3\";s:8:\"passport\";s:0:\"\";s:5:\"oauth\";a:2:{s:7:\"account\";s:1:\"3\";s:4:\"host\";s:0:\"\";}s:11:\"jsauth_acid\";s:1:\"0\";s:2:\"uc\";s:0:\"\";s:6:\"notify\";s:0:\"\";s:11:\"creditnames\";a:2:{s:7:\"credit1\";a:2:{s:5:\"title\";s:6:\"积分\";s:7:\"enabled\";i:1;}s:7:\"credit2\";a:2:{s:5:\"title\";s:6:\"余额\";s:7:\"enabled\";i:1;}}s:15:\"creditbehaviors\";a:2:{s:8:\"activity\";s:7:\"credit1\";s:8:\"currency\";s:7:\"credit2\";}s:7:\"welcome\";s:0:\"\";s:7:\"default\";s:0:\"\";s:15:\"default_message\";s:0:\"\";s:7:\"payment\";s:0:\"\";s:4:\"stat\";s:0:\"\";s:12:\"default_site\";s:1:\"3\";s:4:\"sync\";s:1:\"0\";s:8:\"recharge\";s:0:\"\";s:9:\"tplnotice\";s:0:\"\";s:10:\"grouplevel\";s:1:\"0\";s:8:\"mcplugin\";s:0:\"\";s:15:\"exchange_enable\";s:1:\"0\";s:11:\"coupon_type\";s:1:\"0\";s:7:\"menuset\";s:0:\"\";}'),('system_frame','a:4:{s:7:\"account\";a:5:{s:5:\"title\";s:9:\"公众号\";s:3:\"url\";s:29:\"./index.php?c=home&a=welcome&\";s:7:\"section\";a:5:{s:6:\"renren\";a:2:{s:5:\"title\";s:9:\"人人店\";s:4:\"menu\";a:1:{s:7:\"mc_fans\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"人人店\";s:3:\"url\";s:54:\"./index.php?c=site&a=entry&m=ewei_shopv2&do=web&r=shop\";s:15:\"permission_name\";s:7:\"mc_fans\";s:4:\"icon\";s:16:\"wi wi-fansmanage\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:15:\"platform_module\";a:3:{s:5:\"title\";s:12:\"应用模块\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}s:13:\"platform_plus\";a:2:{s:5:\"title\";s:12:\"增强功能\";s:4:\"menu\";a:6:{s:14:\"platform_reply\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"自动回复\";s:3:\"url\";s:31:\"./index.php?c=platform&a=reply&\";s:15:\"permission_name\";s:14:\"platform_reply\";s:4:\"icon\";s:11:\"wi wi-reply\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";a:3:{i:0;a:2:{s:5:\"title\";s:22:\"关键字自动回复 \";s:15:\"permission_name\";s:14:\"platform_reply\";}i:1;a:2:{s:5:\"title\";s:25:\"非关键字自动回复 \";s:15:\"permission_name\";s:22:\"platform_reply_special\";}i:2;a:2:{s:5:\"title\";s:19:\"欢迎/默认回复\";s:15:\"permission_name\";s:21:\"platform_reply_system\";}}}s:13:\"platform_menu\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"自定义菜单\";s:3:\"url\";s:30:\"./index.php?c=platform&a=menu&\";s:15:\"permission_name\";s:13:\"platform_menu\";s:4:\"icon\";s:16:\"wi wi-custommenu\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:11:\"platform_qr\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:22:\"二维码/转化链接\";s:3:\"url\";s:28:\"./index.php?c=platform&a=qr&\";s:15:\"permission_name\";s:11:\"platform_qr\";s:4:\"icon\";s:12:\"wi wi-qrcode\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{i:0;a:2:{s:5:\"title\";s:9:\"二维码\";s:15:\"permission_name\";s:11:\"platform_qr\";}i:1;a:2:{s:5:\"title\";s:12:\"转化链接\";s:15:\"permission_name\";s:15:\"platform_url2qr\";}}}s:18:\"platform_mass_task\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"定时群发\";s:3:\"url\";s:30:\"./index.php?c=platform&a=mass&\";s:15:\"permission_name\";s:18:\"platform_mass_task\";s:4:\"icon\";s:13:\"wi wi-crontab\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:17:\"platform_material\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:16:\"素材/编辑器\";s:3:\"url\";s:34:\"./index.php?c=platform&a=material&\";s:15:\"permission_name\";s:17:\"platform_material\";s:4:\"icon\";s:12:\"wi wi-redact\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:13:\"platform_site\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:16:\"微官网-文章\";s:3:\"url\";s:38:\"./index.php?c=site&a=multi&do=display&\";s:15:\"permission_name\";s:13:\"platform_site\";s:4:\"icon\";s:10:\"wi wi-home\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{i:0;a:2:{s:5:\"title\";s:13:\"添加/编辑\";s:15:\"permission_name\";s:18:\"platform_site_post\";}i:1;a:2:{s:5:\"title\";s:6:\"删除\";s:15:\"permission_name\";s:20:\"platform_site_delete\";}}}}}s:2:\"mc\";a:2:{s:5:\"title\";s:6:\"粉丝\";s:4:\"menu\";a:2:{s:7:\"mc_fans\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"粉丝管理\";s:3:\"url\";s:24:\"./index.php?c=mc&a=fans&\";s:15:\"permission_name\";s:7:\"mc_fans\";s:4:\"icon\";s:16:\"wi wi-fansmanage\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:9:\"mc_member\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"会员管理\";s:3:\"url\";s:26:\"./index.php?c=mc&a=member&\";s:15:\"permission_name\";s:9:\"mc_member\";s:4:\"icon\";s:10:\"wi wi-fans\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:7:\"profile\";a:2:{s:5:\"title\";s:6:\"配置\";s:4:\"menu\";a:1:{s:7:\"profile\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"参数配置\";s:3:\"url\";s:33:\"./index.php?c=profile&a=passport&\";s:15:\"permission_name\";s:15:\"profile_setting\";s:4:\"icon\";s:22:\"wi wi-parameter-stting\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;}s:5:\"wxapp\";a:5:{s:5:\"title\";s:9:\"小程序\";s:3:\"url\";s:38:\"./index.php?c=wxapp&a=display&do=home&\";s:7:\"section\";a:2:{s:12:\"wxapp_module\";a:3:{s:5:\"title\";s:6:\"应用\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}s:20:\"platform_manage_menu\";a:2:{s:5:\"title\";s:6:\"管理\";s:4:\"menu\";a:2:{s:11:\"module_link\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:21:\"模块关联公众号\";s:3:\"url\";s:53:\"./index.php?c=wxapp&a=version&do=module_link_uniacid&\";s:15:\"permission_name\";s:25:\"wxapp_module_link_uniacid\";s:4:\"icon\";s:16:\"wi wi-appsetting\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:13:\"wxapp_profile\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"支付参数\";s:3:\"url\";s:30:\"./index.php?c=wxapp&a=payment&\";s:15:\"permission_name\";s:13:\"wxapp_payment\";s:4:\"icon\";s:16:\"wi wi-appsetting\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;}s:6:\"system\";a:5:{s:5:\"title\";s:12:\"系统管理\";s:3:\"url\";s:45:\"./index.php?c=account&a=manage&account_type=1\";s:7:\"section\";a:6:{s:10:\"wxplatform\";a:2:{s:5:\"title\";s:9:\"公众号\";s:4:\"menu\";a:4:{s:14:\"system_account\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:16:\" 微信公众号\";s:3:\"url\";s:45:\"./index.php?c=account&a=manage&account_type=1\";s:15:\"permission_name\";s:14:\"system_account\";s:4:\"icon\";s:12:\"wi wi-wechat\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:6:{i:0;a:2:{s:5:\"title\";s:21:\"公众号管理设置\";s:15:\"permission_name\";s:21:\"system_account_manage\";}i:1;a:2:{s:5:\"title\";s:15:\"添加公众号\";s:15:\"permission_name\";s:19:\"system_account_post\";}i:2;a:2:{s:5:\"title\";s:15:\"公众号停用\";s:15:\"permission_name\";s:19:\"system_account_stop\";}i:3;a:2:{s:5:\"title\";s:18:\"公众号回收站\";s:15:\"permission_name\";s:22:\"system_account_recycle\";}i:4;a:2:{s:5:\"title\";s:15:\"公众号删除\";s:15:\"permission_name\";s:21:\"system_account_delete\";}i:5;a:2:{s:5:\"title\";s:15:\"公众号恢复\";s:15:\"permission_name\";s:22:\"system_account_recover\";}}}s:13:\"system_module\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"应用管理\";s:3:\"url\";s:44:\"./index.php?c=system&a=module&account_type=1\";s:15:\"permission_name\";s:13:\"system_module\";s:4:\"icon\";s:14:\"wi wi-wx-apply\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:15:\"system_template\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"微官网模板\";s:3:\"url\";s:32:\"./index.php?c=system&a=template&\";s:15:\"permission_name\";s:15:\"system_template\";s:4:\"icon\";s:17:\"wi wi-wx-template\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:15:\"system_platform\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:19:\" 微信开放平台\";s:3:\"url\";s:32:\"./index.php?c=system&a=platform&\";s:15:\"permission_name\";s:15:\"system_platform\";s:4:\"icon\";s:20:\"wi wi-exploitsetting\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:6:\"module\";a:2:{s:5:\"title\";s:9:\"小程序\";s:4:\"menu\";a:2:{s:12:\"system_wxapp\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"微信小程序\";s:3:\"url\";s:45:\"./index.php?c=account&a=manage&account_type=4\";s:15:\"permission_name\";s:12:\"system_wxapp\";s:4:\"icon\";s:11:\"wi wi-wxapp\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"system_module_wxapp\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"小程序应用\";s:3:\"url\";s:44:\"./index.php?c=system&a=module&account_type=4\";s:15:\"permission_name\";s:19:\"system_module_wxapp\";s:4:\"icon\";s:17:\"wi wi-wxapp-apply\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:4:\"user\";a:2:{s:5:\"title\";s:13:\"帐户/用户\";s:4:\"menu\";a:2:{s:9:\"system_my\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"我的帐户\";s:3:\"url\";s:29:\"./index.php?c=user&a=profile&\";s:15:\"permission_name\";s:9:\"system_my\";s:4:\"icon\";s:10:\"wi wi-user\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:11:\"system_user\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"用户管理\";s:3:\"url\";s:29:\"./index.php?c=user&a=display&\";s:15:\"permission_name\";s:11:\"system_user\";s:4:\"icon\";s:16:\"wi wi-user-group\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:6:{i:0;a:2:{s:5:\"title\";s:12:\"编辑用户\";s:15:\"permission_name\";s:16:\"system_user_post\";}i:1;a:2:{s:5:\"title\";s:12:\"审核用户\";s:15:\"permission_name\";s:17:\"system_user_check\";}i:2;a:2:{s:5:\"title\";s:15:\"用户回收站\";s:15:\"permission_name\";s:19:\"system_user_recycle\";}i:3;a:2:{s:5:\"title\";s:18:\"用户属性设置\";s:15:\"permission_name\";s:18:\"system_user_fields\";}i:4;a:2:{s:5:\"title\";s:31:\"用户属性设置-编辑字段\";s:15:\"permission_name\";s:23:\"system_user_fields_post\";}i:5;a:2:{s:5:\"title\";s:18:\"用户注册设置\";s:15:\"permission_name\";s:23:\"system_user_registerset\";}}}}}s:10:\"permission\";a:2:{s:5:\"title\";s:12:\"权限管理\";s:4:\"menu\";a:2:{s:19:\"system_module_group\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"应用权限组\";s:3:\"url\";s:36:\"./index.php?c=system&a=module-group&\";s:15:\"permission_name\";s:19:\"system_module_group\";s:4:\"icon\";s:21:\"wi wi-appjurisdiction\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:17:\"system_user_group\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"用户权限组\";s:3:\"url\";s:27:\"./index.php?c=user&a=group&\";s:15:\"permission_name\";s:17:\"system_user_group\";s:4:\"icon\";s:22:\"wi wi-userjurisdiction\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{i:0;a:2:{s:5:\"title\";s:15:\"编辑用户组\";s:15:\"permission_name\";s:22:\"system_user_group_post\";}i:1;a:2:{s:5:\"title\";s:15:\"删除用户组\";s:15:\"permission_name\";s:21:\"system_user_group_del\";}}}}}s:7:\"acticle\";a:2:{s:5:\"title\";s:13:\"文章/公告\";s:4:\"menu\";a:2:{s:14:\"system_article\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"文章管理\";s:3:\"url\";s:29:\"./index.php?c=article&a=news&\";s:15:\"permission_name\";s:19:\"system_article_news\";s:4:\"icon\";s:13:\"wi wi-article\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:21:\"system_article_notice\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"公告管理\";s:3:\"url\";s:31:\"./index.php?c=article&a=notice&\";s:15:\"permission_name\";s:21:\"system_article_notice\";s:4:\"icon\";s:12:\"wi wi-notice\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:5:\"cache\";a:2:{s:5:\"title\";s:6:\"缓存\";s:4:\"menu\";a:1:{s:26:\"system_setting_updatecache\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"更新缓存\";s:3:\"url\";s:35:\"./index.php?c=system&a=updatecache&\";s:15:\"permission_name\";s:26:\"system_setting_updatecache\";s:4:\"icon\";s:12:\"wi wi-update\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;}s:4:\"site\";a:6:{s:5:\"title\";s:12:\"站点管理\";s:3:\"url\";s:30:\"./index.php?c=cloud&a=upgrade&\";s:7:\"section\";a:2:{s:7:\"setting\";a:2:{s:5:\"title\";s:6:\"设置\";s:4:\"menu\";a:5:{s:19:\"system_setting_site\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"站点设置\";s:3:\"url\";s:28:\"./index.php?c=system&a=site&\";s:15:\"permission_name\";s:19:\"system_setting_site\";s:4:\"icon\";s:18:\"wi wi-site-setting\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"system_setting_menu\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"菜单设置\";s:3:\"url\";s:28:\"./index.php?c=system&a=menu&\";s:15:\"permission_name\";s:19:\"system_setting_menu\";s:4:\"icon\";s:18:\"wi wi-menu-setting\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"system_setting_attachment\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"附件设置\";s:3:\"url\";s:34:\"./index.php?c=system&a=attachment&\";s:15:\"permission_name\";s:25:\"system_setting_attachment\";s:4:\"icon\";s:16:\"wi wi-attachment\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"system_setting_systeminfo\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"系统信息\";s:3:\"url\";s:34:\"./index.php?c=system&a=systeminfo&\";s:15:\"permission_name\";s:25:\"system_setting_systeminfo\";s:4:\"icon\";s:17:\"wi wi-system-info\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"system_setting_logs\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"查看日志\";s:3:\"url\";s:28:\"./index.php?c=system&a=logs&\";s:15:\"permission_name\";s:19:\"system_setting_logs\";s:4:\"icon\";s:9:\"wi wi-log\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:7:\"utility\";a:2:{s:5:\"title\";s:12:\"常用工具\";s:4:\"menu\";a:1:{s:23:\"system_utility_database\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"数据库\";s:3:\"url\";s:32:\"./index.php?c=system&a=database&\";s:15:\"permission_name\";s:23:\"system_utility_database\";s:4:\"icon\";s:9:\"wi wi-sql\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:7:\"founder\";b:1;s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;}}'),('module_receive_enable','a:13:{s:5:\"image\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:5:\"voice\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:5:\"video\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:10:\"shortvideo\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:8:\"location\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:4:\"link\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:9:\"subscribe\";a:2:{i:0;s:11:\"ewei_shopv2\";i:1;s:6:\"bm_top\";}s:11:\"unsubscribe\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:2:\"qr\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:5:\"trace\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:5:\"click\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:4:\"view\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:14:\"merchant_order\";a:1:{i:0;s:11:\"ewei_shopv2\";}}'),('accesstoken:6','a:2:{s:5:\"token\";s:138:\"DgxUneKDdADNeT5eWGxgoBcGyNUn0rNpmuy5im2mDbwkxUCRC-CG1Bs9GJ38tFzsag6E2H6-h68eZqaVUrdIc0mNOcatmbHEKiN4wS9pw7kubT0f82fyHOjgfWtDjy4fEXLhAGAJCQ\";s:6:\"expire\";i:1504624641;}'),('jsticket:6','a:2:{s:6:\"ticket\";s:86:\"kgt8ON7yVITDhtdwci0qeV6aDYSYlPQg1jlKZ3vSXZ3fUap-LJ4GlH4WW3I5UMLMYvuBNulC7bnTzk8NX1p4Ag\";s:6:\"expire\";i:1504623755;}'),('unisetting:6','a:22:{s:7:\"uniacid\";s:1:\"6\";s:8:\"passport\";s:0:\"\";s:5:\"oauth\";a:2:{s:4:\"host\";s:0:\"\";s:7:\"account\";s:1:\"6\";}s:11:\"jsauth_acid\";s:1:\"0\";s:2:\"uc\";s:0:\"\";s:6:\"notify\";s:0:\"\";s:11:\"creditnames\";a:2:{s:7:\"credit1\";a:2:{s:5:\"title\";s:6:\"积分\";s:7:\"enabled\";i:1;}s:7:\"credit2\";a:2:{s:5:\"title\";s:6:\"余额\";s:7:\"enabled\";i:1;}}s:15:\"creditbehaviors\";a:2:{s:8:\"activity\";s:7:\"credit1\";s:8:\"currency\";s:7:\"credit2\";}s:7:\"welcome\";s:0:\"\";s:7:\"default\";s:0:\"\";s:15:\"default_message\";s:0:\"\";s:7:\"payment\";a:4:{s:8:\"delivery\";a:1:{s:6:\"switch\";b:1;}s:6:\"credit\";a:1:{s:6:\"switch\";b:0;}s:6:\"wechat\";a:6:{s:6:\"switch\";s:1:\"1\";s:7:\"version\";s:1:\"2\";s:5:\"mchid\";s:10:\"1485461622\";s:6:\"apikey\";s:32:\"ab235bf8be745b7d2c268ed8723020e2\";s:7:\"account\";s:1:\"6\";s:7:\"signkey\";s:32:\"ab235bf8be745b7d2c268ed8723020e2\";}s:6:\"alipay\";a:4:{s:7:\"account\";s:6:\"666666\";s:7:\"partner\";s:8:\"88888888\";s:6:\"secret\";s:9:\"88e6dghgf\";s:6:\"switch\";b:0;}}s:4:\"stat\";s:0:\"\";s:12:\"default_site\";s:1:\"6\";s:4:\"sync\";s:1:\"1\";s:8:\"recharge\";s:0:\"\";s:9:\"tplnotice\";s:0:\"\";s:10:\"grouplevel\";s:1:\"0\";s:8:\"mcplugin\";s:0:\"\";s:15:\"exchange_enable\";s:1:\"0\";s:11:\"coupon_type\";s:1:\"0\";s:7:\"menuset\";s:0:\"\";}'),('unisetting:5','a:22:{s:7:\"uniacid\";s:1:\"5\";s:8:\"passport\";s:0:\"\";s:5:\"oauth\";a:2:{s:7:\"account\";s:1:\"6\";s:4:\"host\";s:0:\"\";}s:11:\"jsauth_acid\";s:1:\"0\";s:2:\"uc\";s:0:\"\";s:6:\"notify\";s:0:\"\";s:11:\"creditnames\";a:2:{s:7:\"credit1\";a:2:{s:5:\"title\";s:6:\"积分\";s:7:\"enabled\";i:1;}s:7:\"credit2\";a:2:{s:5:\"title\";s:6:\"余额\";s:7:\"enabled\";i:1;}}s:15:\"creditbehaviors\";a:2:{s:8:\"activity\";s:7:\"credit1\";s:8:\"currency\";s:7:\"credit2\";}s:7:\"welcome\";s:0:\"\";s:7:\"default\";s:0:\"\";s:15:\"default_message\";s:0:\"\";s:7:\"payment\";a:4:{s:8:\"delivery\";a:1:{s:6:\"switch\";b:1;}s:6:\"credit\";a:1:{s:6:\"switch\";b:0;}s:6:\"wechat\";a:6:{s:6:\"switch\";s:1:\"1\";s:7:\"version\";s:1:\"2\";s:5:\"mchid\";s:10:\"1485461622\";s:6:\"apikey\";s:32:\"ab235bf8be745b7d2c268ed8723020e2\";s:7:\"account\";s:1:\"6\";s:7:\"signkey\";s:32:\"ab235bf8be745b7d2c268ed8723020e2\";}s:6:\"alipay\";a:4:{s:7:\"account\";s:6:\"666666\";s:7:\"partner\";s:8:\"88888888\";s:6:\"secret\";s:9:\"88e6dghgf\";s:6:\"switch\";b:0;}}s:4:\"stat\";s:0:\"\";s:12:\"default_site\";s:1:\"5\";s:4:\"sync\";s:1:\"0\";s:8:\"recharge\";s:0:\"\";s:9:\"tplnotice\";s:0:\"\";s:10:\"grouplevel\";s:1:\"0\";s:8:\"mcplugin\";s:0:\"\";s:15:\"exchange_enable\";s:1:\"0\";s:11:\"coupon_type\";s:1:\"0\";s:7:\"menuset\";s:0:\"\";}'),('unisetting:4','a:22:{s:7:\"uniacid\";s:1:\"4\";s:8:\"passport\";s:0:\"\";s:5:\"oauth\";s:0:\"\";s:11:\"jsauth_acid\";s:1:\"0\";s:2:\"uc\";s:0:\"\";s:6:\"notify\";s:0:\"\";s:11:\"creditnames\";a:2:{s:7:\"credit1\";a:2:{s:5:\"title\";s:6:\"积分\";s:7:\"enabled\";i:1;}s:7:\"credit2\";a:2:{s:5:\"title\";s:6:\"余额\";s:7:\"enabled\";i:1;}}s:15:\"creditbehaviors\";a:2:{s:8:\"activity\";s:7:\"credit1\";s:8:\"currency\";s:7:\"credit2\";}s:7:\"welcome\";s:0:\"\";s:7:\"default\";s:0:\"\";s:15:\"default_message\";s:0:\"\";s:7:\"payment\";s:0:\"\";s:4:\"stat\";s:0:\"\";s:12:\"default_site\";s:1:\"4\";s:4:\"sync\";s:1:\"0\";s:8:\"recharge\";s:0:\"\";s:9:\"tplnotice\";s:0:\"\";s:10:\"grouplevel\";s:1:\"0\";s:8:\"mcplugin\";s:0:\"\";s:15:\"exchange_enable\";s:1:\"0\";s:11:\"coupon_type\";s:1:\"0\";s:7:\"menuset\";s:0:\"\";}'),('unisetting:2','a:22:{s:7:\"uniacid\";s:1:\"2\";s:8:\"passport\";s:0:\"\";s:5:\"oauth\";a:2:{s:7:\"account\";s:1:\"2\";s:4:\"host\";s:0:\"\";}s:11:\"jsauth_acid\";s:1:\"0\";s:2:\"uc\";s:0:\"\";s:6:\"notify\";s:0:\"\";s:11:\"creditnames\";a:2:{s:7:\"credit1\";a:2:{s:5:\"title\";s:6:\"积分\";s:7:\"enabled\";i:1;}s:7:\"credit2\";a:2:{s:5:\"title\";s:6:\"余额\";s:7:\"enabled\";i:1;}}s:15:\"creditbehaviors\";a:2:{s:8:\"activity\";s:7:\"credit1\";s:8:\"currency\";s:7:\"credit2\";}s:7:\"welcome\";s:0:\"\";s:7:\"default\";s:0:\"\";s:15:\"default_message\";s:0:\"\";s:7:\"payment\";s:0:\"\";s:4:\"stat\";s:0:\"\";s:12:\"default_site\";s:1:\"2\";s:4:\"sync\";s:1:\"0\";s:8:\"recharge\";s:0:\"\";s:9:\"tplnotice\";s:0:\"\";s:10:\"grouplevel\";s:1:\"0\";s:8:\"mcplugin\";s:0:\"\";s:15:\"exchange_enable\";s:1:\"0\";s:11:\"coupon_type\";s:1:\"0\";s:7:\"menuset\";s:0:\"\";}'),('we7:unimodules::','a:15:{s:5:\"basic\";a:1:{s:4:\"name\";s:5:\"basic\";}s:4:\"news\";a:1:{s:4:\"name\";s:4:\"news\";}s:5:\"music\";a:1:{s:4:\"name\";s:5:\"music\";}s:7:\"userapi\";a:1:{s:4:\"name\";s:7:\"userapi\";}s:8:\"recharge\";a:1:{s:4:\"name\";s:8:\"recharge\";}s:6:\"custom\";a:1:{s:4:\"name\";s:6:\"custom\";}s:6:\"images\";a:1:{s:4:\"name\";s:6:\"images\";}s:5:\"video\";a:1:{s:4:\"name\";s:5:\"video\";}s:5:\"voice\";a:1:{s:4:\"name\";s:5:\"voice\";}s:5:\"chats\";a:1:{s:4:\"name\";s:5:\"chats\";}s:6:\"wxcard\";a:1:{s:4:\"name\";s:6:\"wxcard\";}s:11:\"ewei_shopv2\";a:1:{s:4:\"name\";s:11:\"ewei_shopv2\";}s:6:\"bm_top\";a:1:{s:4:\"name\";s:6:\"bm_top\";}s:18:\"stonefish_bigwheel\";a:1:{s:4:\"name\";s:18:\"stonefish_bigwheel\";}s:10:\"we7_coupon\";a:1:{s:4:\"name\";s:10:\"we7_coupon\";}}'),('we7:module_info:basic','a:25:{s:3:\"mid\";s:1:\"1\";s:4:\"name\";s:5:\"basic\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:18:\"基本文字回复\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:24:\"和您进行简单对话\";s:11:\"description\";s:201:\"一问一答得简单对话. 当访客的对话语句中包含指定关键字, 或对话语句完全等于特定关键字, 或符合某些特定的格式时. 系统自动应答设定好的回复内容.\";s:6:\"author\";s:9:\"WEB7 Club\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:54:\"http://wx.adjyc.com/addons/basic/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}'),('we7:module_info:news','a:25:{s:3:\"mid\";s:1:\"2\";s:4:\"name\";s:4:\"news\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:24:\"基本混合图文回复\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:33:\"为你提供生动的图文资讯\";s:11:\"description\";s:272:\"一问一答得简单对话, 但是回复内容包括图片文字等更生动的媒体内容. 当访客的对话语句中包含指定关键字, 或对话语句完全等于特定关键字, 或符合某些特定的格式时. 系统自动应答设定好的图文回复内容.\";s:6:\"author\";s:6:\"We7 CC\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:53:\"http://wx.adjyc.com/addons/news/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}'),('we7:module_info:music','a:25:{s:3:\"mid\";s:1:\"3\";s:4:\"name\";s:5:\"music\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:18:\"基本音乐回复\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:39:\"提供语音、音乐等音频类回复\";s:11:\"description\";s:183:\"在回复规则中可选择具有语音、音乐等音频类的回复内容，并根据用户所设置的特定关键字精准的返回给粉丝，实现一问一答得简单对话。\";s:6:\"author\";s:6:\"We7 CC\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:54:\"http://wx.adjyc.com/addons/music/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}'),('we7:module_info:userapi','a:25:{s:3:\"mid\";s:1:\"4\";s:4:\"name\";s:7:\"userapi\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:21:\"自定义接口回复\";s:7:\"version\";s:3:\"1.1\";s:7:\"ability\";s:33:\"更方便的第三方接口设置\";s:11:\"description\";s:141:\"自定义接口又称第三方接口，可以让开发者更方便的接入微信系统，高效的与微信公众平台进行对接整合。\";s:6:\"author\";s:6:\"We7 CC\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:56:\"http://wx.adjyc.com/addons/userapi/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}'),('we7:module_info:recharge','a:25:{s:3:\"mid\";s:1:\"5\";s:4:\"name\";s:8:\"recharge\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:24:\"会员中心充值模块\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:24:\"提供会员充值功能\";s:11:\"description\";s:0:\"\";s:6:\"author\";s:6:\"We7 CC\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"0\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:57:\"http://wx.adjyc.com/addons/recharge/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}'),('we7:module_info:custom','a:25:{s:3:\"mid\";s:1:\"6\";s:4:\"name\";s:6:\"custom\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:15:\"多客服转接\";s:7:\"version\";s:5:\"1.0.0\";s:7:\"ability\";s:36:\"用来接入腾讯的多客服系统\";s:11:\"description\";s:0:\"\";s:6:\"author\";s:6:\"We7 CC\";s:3:\"url\";s:17:\"http://www.we7.cc\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";a:0:{}s:7:\"handles\";a:6:{i:0;s:5:\"image\";i:1;s:5:\"voice\";i:2;s:5:\"video\";i:3;s:8:\"location\";i:4;s:4:\"link\";i:5;s:4:\"text\";}s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:55:\"http://wx.adjyc.com/addons/custom/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}'),('we7:module_info:images','a:25:{s:3:\"mid\";s:1:\"7\";s:4:\"name\";s:6:\"images\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:18:\"基本图片回复\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:18:\"提供图片回复\";s:11:\"description\";s:132:\"在回复规则中可选择具有图片的回复内容，并根据用户所设置的特定关键字精准的返回给粉丝图片。\";s:6:\"author\";s:6:\"We7 CC\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:55:\"http://wx.adjyc.com/addons/images/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}'),('we7:module_info:video','a:25:{s:3:\"mid\";s:1:\"8\";s:4:\"name\";s:5:\"video\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:18:\"基本视频回复\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:18:\"提供图片回复\";s:11:\"description\";s:132:\"在回复规则中可选择具有视频的回复内容，并根据用户所设置的特定关键字精准的返回给粉丝视频。\";s:6:\"author\";s:6:\"We7 CC\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:54:\"http://wx.adjyc.com/addons/video/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}'),('we7:module_info:voice','a:25:{s:3:\"mid\";s:1:\"9\";s:4:\"name\";s:5:\"voice\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:18:\"基本语音回复\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:18:\"提供语音回复\";s:11:\"description\";s:132:\"在回复规则中可选择具有语音的回复内容，并根据用户所设置的特定关键字精准的返回给粉丝语音。\";s:6:\"author\";s:6:\"We7 CC\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:54:\"http://wx.adjyc.com/addons/voice/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}'),('we7:module_info:chats','a:25:{s:3:\"mid\";s:2:\"10\";s:4:\"name\";s:5:\"chats\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:18:\"发送客服消息\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:77:\"公众号可以在粉丝最后发送消息的48小时内无限制发送消息\";s:11:\"description\";s:0:\"\";s:6:\"author\";s:6:\"We7 CC\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"0\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:54:\"http://wx.adjyc.com/addons/chats/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}'),('we7:module_info:wxcard','a:25:{s:3:\"mid\";s:2:\"11\";s:4:\"name\";s:6:\"wxcard\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:18:\"微信卡券回复\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:18:\"微信卡券回复\";s:11:\"description\";s:18:\"微信卡券回复\";s:6:\"author\";s:6:\"We7 CC\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:55:\"http://wx.adjyc.com/addons/wxcard/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}'),('we7:module_info:ewei_shopv2','a:25:{s:3:\"mid\";s:2:\"12\";s:4:\"name\";s:11:\"ewei_shopv2\";s:4:\"type\";s:8:\"business\";s:5:\"title\";s:9:\"人人店\";s:7:\"version\";s:5:\"3.5.4\";s:7:\"ability\";s:9:\"人人店\";s:11:\"description\";s:9:\"人人店\";s:6:\"author\";s:12:\"weichengtech\";s:3:\"url\";s:12:\"weichengtech\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";a:14:{i:0;s:4:\"text\";i:1;s:5:\"image\";i:2;s:5:\"voice\";i:3;s:5:\"video\";i:4;s:10:\"shortvideo\";i:5;s:8:\"location\";i:6;s:4:\"link\";i:7;s:9:\"subscribe\";i:8;s:11:\"unsubscribe\";i:9;s:2:\"qr\";i:10;s:5:\"trace\";i:11;s:5:\"click\";i:12;s:4:\"view\";i:13;s:14:\"merchant_order\";}s:7:\"handles\";a:12:{i:0;s:4:\"text\";i:1;s:5:\"image\";i:2;s:5:\"voice\";i:3;s:5:\"video\";i:4;s:10:\"shortvideo\";i:5;s:8:\"location\";i:6;s:4:\"link\";i:7;s:9:\"subscribe\";i:8;s:2:\"qr\";i:9;s:5:\"trace\";i:10;s:5:\"click\";i:11;s:14:\"merchant_order\";}s:12:\"isrulefields\";s:1:\"0\";s:8:\"issystem\";s:1:\"0\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:6:\"a:0:{}\";s:13:\"title_initial\";s:1:\"R\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:60:\"http://wx.adjyc.com/addons/ewei_shopv2/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}'),('we7:module_info:bm_top','a:25:{s:3:\"mid\";s:2:\"13\";s:4:\"name\";s:6:\"bm_top\";s:4:\"type\";s:8:\"business\";s:5:\"title\";s:9:\"粉丝榜\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:9:\"粉丝榜\";s:11:\"description\";s:9:\"粉丝榜\";s:6:\"author\";s:24:\"折翼天使资源社区\";s:3:\"url\";s:20:\"www.zheyitianshi.com\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";a:1:{i:0;s:9:\"subscribe\";}s:7:\"handles\";a:1:{i:0;s:4:\"text\";}s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"0\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:2:\"N;\";s:13:\"title_initial\";s:1:\"F\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:55:\"http://wx.adjyc.com/addons/bm_top/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}'),('we7:module_info:stonefish_bigwheel','a:25:{s:3:\"mid\";s:2:\"14\";s:4:\"name\";s:18:\"stonefish_bigwheel\";s:4:\"type\";s:8:\"activity\";s:5:\"title\";s:15:\"幸运大转盘\";s:7:\"version\";s:3:\"1.6\";s:7:\"ability\";s:27:\"幸运大转盘营销抽奖\";s:11:\"description\";s:128:\"幸运大转盘营销抽奖-结合商家网点模块，每个商家可送抽奖机会,分享还可以额外获得抽奖机会哟\";s:6:\"author\";s:24:\"折翼天使资源社区\";s:3:\"url\";s:28:\"http://www.zheyitianshi.com/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";a:0:{}s:7:\"handles\";a:1:{i:0;s:4:\"text\";}s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"0\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:2:\"N;\";s:13:\"title_initial\";s:1:\"X\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:67:\"http://wx.adjyc.com/addons/stonefish_bigwheel/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}'),('we7:module_info:we7_coupon','a:25:{s:3:\"mid\";s:2:\"15\";s:4:\"name\";s:10:\"we7_coupon\";s:4:\"type\";s:8:\"business\";s:5:\"title\";s:12:\"系统卡券\";s:7:\"version\";s:3:\"3.8\";s:7:\"ability\";s:12:\"微信卡券\";s:11:\"description\";s:12:\"微信卡券\";s:6:\"author\";s:12:\"蓝梦社区\";s:3:\"url\";s:0:\"\";s:8:\"settings\";s:1:\"1\";s:10:\"subscribes\";a:0:{}s:7:\"handles\";a:0:{}s:12:\"isrulefields\";s:1:\"0\";s:8:\"issystem\";s:1:\"0\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:6:\"a:0:{}\";s:13:\"title_initial\";s:1:\"X\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:59:\"http://wx.adjyc.com/addons/we7_coupon/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}'),('checkupgrade:system','a:1:{s:10:\"lastupdate\";i:1504616020;}'),('we7:lastaccount:QH5my','a:1:{s:7:\"account\";i:6;}'),('we7:unimodules:6:','a:15:{s:11:\"ewei_shopv2\";a:1:{s:4:\"name\";s:11:\"ewei_shopv2\";}s:6:\"bm_top\";a:1:{s:4:\"name\";s:6:\"bm_top\";}s:18:\"stonefish_bigwheel\";a:1:{s:4:\"name\";s:18:\"stonefish_bigwheel\";}s:10:\"we7_coupon\";a:1:{s:4:\"name\";s:10:\"we7_coupon\";}s:4:\"news\";a:1:{s:4:\"name\";s:4:\"news\";}s:6:\"images\";a:1:{s:4:\"name\";s:6:\"images\";}s:5:\"music\";a:1:{s:4:\"name\";s:5:\"music\";}s:5:\"video\";a:1:{s:4:\"name\";s:5:\"video\";}s:7:\"userapi\";a:1:{s:4:\"name\";s:7:\"userapi\";}s:5:\"voice\";a:1:{s:4:\"name\";s:5:\"voice\";}s:8:\"recharge\";a:1:{s:4:\"name\";s:8:\"recharge\";}s:5:\"chats\";a:1:{s:4:\"name\";s:5:\"chats\";}s:5:\"basic\";a:1:{s:4:\"name\";s:5:\"basic\";}s:6:\"custom\";a:1:{s:4:\"name\";s:6:\"custom\";}s:6:\"wxcard\";a:1:{s:4:\"name\";s:6:\"wxcard\";}}'),('we7:module_setting:6:ewei_shopv2','a:7:{s:2:\"id\";s:2:\"24\";s:7:\"uniacid\";s:1:\"6\";s:6:\"module\";s:11:\"ewei_shopv2\";s:7:\"enabled\";s:1:\"1\";s:8:\"settings\";s:0:\"\";s:8:\"shortcut\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";}'),('we7:module_setting:6:bm_top','a:7:{s:2:\"id\";s:2:\"23\";s:7:\"uniacid\";s:1:\"6\";s:6:\"module\";s:6:\"bm_top\";s:7:\"enabled\";s:1:\"1\";s:8:\"settings\";s:0:\"\";s:8:\"shortcut\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";}'),('we7:module_setting:6:stonefish_bigwheel','a:7:{s:2:\"id\";s:2:\"22\";s:7:\"uniacid\";s:1:\"6\";s:6:\"module\";s:18:\"stonefish_bigwheel\";s:7:\"enabled\";s:1:\"1\";s:8:\"settings\";s:0:\"\";s:8:\"shortcut\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";}'),('we7:module_setting:6:we7_coupon','a:7:{s:2:\"id\";s:2:\"21\";s:7:\"uniacid\";s:1:\"6\";s:6:\"module\";s:10:\"we7_coupon\";s:7:\"enabled\";s:1:\"1\";s:8:\"settings\";s:0:\"\";s:8:\"shortcut\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";}'),('unicount:6','s:1:\"1\";'),('we7:unimodules:6:1','a:15:{s:11:\"ewei_shopv2\";a:1:{s:4:\"name\";s:11:\"ewei_shopv2\";}s:6:\"bm_top\";a:1:{s:4:\"name\";s:6:\"bm_top\";}s:18:\"stonefish_bigwheel\";a:1:{s:4:\"name\";s:18:\"stonefish_bigwheel\";}s:10:\"we7_coupon\";a:1:{s:4:\"name\";s:10:\"we7_coupon\";}s:4:\"news\";a:1:{s:4:\"name\";s:4:\"news\";}s:6:\"images\";a:1:{s:4:\"name\";s:6:\"images\";}s:5:\"music\";a:1:{s:4:\"name\";s:5:\"music\";}s:5:\"video\";a:1:{s:4:\"name\";s:5:\"video\";}s:7:\"userapi\";a:1:{s:4:\"name\";s:7:\"userapi\";}s:5:\"voice\";a:1:{s:4:\"name\";s:5:\"voice\";}s:8:\"recharge\";a:1:{s:4:\"name\";s:8:\"recharge\";}s:5:\"chats\";a:1:{s:4:\"name\";s:5:\"chats\";}s:5:\"basic\";a:1:{s:4:\"name\";s:5:\"basic\";}s:6:\"custom\";a:1:{s:4:\"name\";s:6:\"custom\";}s:6:\"wxcard\";a:1:{s:4:\"name\";s:6:\"wxcard\";}}'),('ewei_shop_fc7363d7a42e85fde52ad752308d9a0d','a:5:{s:2:\"id\";s:2:\"11\";s:7:\"uniacid\";s:1:\"6\";s:4:\"sets\";s:2765:\"a:5:{s:4:\"shop\";a:19:{s:4:\"name\";s:9:\"融惠联\";s:4:\"logo\";s:51:\"images/6/2017/09/sTK6rdRr2d2T8m2AAireBB82MAMZpM.png\";s:11:\"description\";s:9:\"融惠联\";s:3:\"img\";s:0:\"\";s:7:\"signimg\";s:0:\"\";s:7:\"getinfo\";s:1:\"1\";s:7:\"saleout\";s:0:\"\";s:7:\"loading\";s:0:\"\";s:7:\"diycode\";s:0:\"\";s:6:\"funbar\";s:1:\"0\";s:5:\"style\";s:3:\"new\";s:8:\"catlevel\";s:1:\"3\";s:7:\"catshow\";s:1:\"0\";s:9:\"catadvimg\";s:0:\"\";s:9:\"catadvurl\";s:0:\"\";s:11:\"bannerswipe\";i:0;s:5:\"cubes\";a:4:{i:0;a:2:{s:3:\"img\";s:51:\"images/6/2017/09/nnNjMAgGqNgs3g800ZnDY40AM8QSam.jpg\";s:3:\"url\";s:0:\"\";}i:1;a:2:{s:3:\"img\";s:51:\"images/6/2017/09/a9Jw7fAhmwzvF7t98P70W11VAaxXZf.jpg\";s:3:\"url\";s:0:\"\";}i:2;a:2:{s:3:\"img\";s:51:\"images/6/2017/09/Xj5aP3Zk7r3J3p3Vt33Yt8K86R0KIu.jpg\";s:3:\"url\";s:0:\"\";}i:3;a:2:{s:3:\"img\";s:51:\"images/6/2017/09/KM997qmpN8M9N078DHiM88mhp90q8H.jpg\";s:3:\"url\";s:0:\"\";}}s:15:\"indexrecommands\";a:2:{i:0;s:3:\"199\";i:1;s:3:\"203\";}s:9:\"indexsort\";a:8:{s:3:\"adv\";a:2:{s:4:\"text\";s:9:\"幻灯片\";s:7:\"visible\";i:1;}s:6:\"search\";a:2:{s:4:\"text\";s:9:\"搜索栏\";s:7:\"visible\";i:1;}s:3:\"nav\";a:2:{s:4:\"text\";s:9:\"导航栏\";s:7:\"visible\";i:1;}s:6:\"notice\";a:2:{s:4:\"text\";s:9:\"公告栏\";s:7:\"visible\";i:1;}s:7:\"seckill\";a:2:{s:4:\"text\";s:9:\"秒杀栏\";s:7:\"visible\";i:1;}s:4:\"cube\";a:2:{s:4:\"text\";s:9:\"魔方栏\";s:7:\"visible\";i:1;}s:6:\"banner\";a:2:{s:4:\"text\";s:9:\"广告栏\";s:7:\"visible\";i:1;}s:5:\"goods\";a:2:{s:4:\"text\";s:9:\"推荐栏\";s:7:\"visible\";i:1;}}}s:8:\"template\";a:2:{s:5:\"style\";s:3:\"new\";s:11:\"detail_temp\";s:1:\"0\";}s:5:\"trade\";a:30:{s:12:\"set_realname\";s:1:\"0\";s:10:\"set_mobile\";s:1:\"0\";s:10:\"closeorder\";i:3;s:14:\"willcloseorder\";s:0:\"\";s:9:\"stockwarn\";s:0:\"\";s:7:\"receive\";s:0:\"\";s:10:\"refunddays\";s:0:\"\";s:13:\"refundcontent\";s:0:\"\";s:10:\"credittext\";s:6:\"积分\";s:9:\"moneytext\";s:6:\"余额\";s:13:\"closerecharge\";s:1:\"0\";s:5:\"money\";s:0:\"\";s:6:\"credit\";s:1:\"0\";s:13:\"minimumcharge\";d:0;s:8:\"withdraw\";s:1:\"0\";s:13:\"withdrawmoney\";s:0:\"\";s:14:\"withdrawcharge\";s:0:\"\";s:13:\"withdrawbegin\";d:0;s:11:\"withdrawend\";d:0;s:9:\"maxcredit\";s:1:\"0\";s:12:\"closecomment\";s:1:\"0\";s:16:\"closecommentshow\";s:1:\"0\";s:14:\"commentchecked\";s:1:\"0\";s:12:\"shareaddress\";s:1:\"1\";s:10:\"istimetext\";s:9:\"限时购\";s:15:\"nodispatchareas\";s:7:\"s:0:\"\";\";s:20:\"nodispatchareas_code\";s:7:\"s:0:\"\";\";s:18:\"withdrawcashweixin\";i:0;s:18:\"withdrawcashalipay\";i:0;s:16:\"withdrawcashcard\";i:0;}s:8:\"category\";a:5:{s:5:\"level\";s:1:\"3\";s:4:\"show\";s:1:\"0\";s:5:\"style\";s:1:\"0\";s:6:\"advimg\";s:0:\"\";s:6:\"advurl\";s:0:\"\";}s:3:\"pay\";a:11:{s:9:\"weixin_id\";i:0;s:6:\"weixin\";i:1;s:10:\"weixin_sub\";i:0;s:10:\"weixin_jie\";i:0;s:14:\"weixin_jie_sub\";i:0;s:6:\"alipay\";i:0;s:6:\"credit\";i:1;s:4:\"cash\";i:1;s:10:\"app_wechat\";i:0;s:10:\"app_alipay\";i:0;s:7:\"paytype\";a:3:{s:10:\"commission\";s:1:\"0\";s:8:\"withdraw\";s:1:\"0\";s:7:\"redpack\";s:1:\"0\";}}}\";s:7:\"plugins\";s:881:\"a:1:{s:4:\"sale\";a:9:{s:11:\"enoughmoney\";d:100;s:12:\"enoughdeduct\";d:2;s:7:\"enoughs\";a:2:{i:0;a:2:{s:6:\"enough\";d:200;s:4:\"give\";d:5;}i:1;a:2:{s:6:\"enough\";d:500;s:4:\"give\";d:20;}}s:10:\"enoughfree\";i:1;s:11:\"enoughorder\";d:99;s:11:\"enoughareas\";s:0:\"\";s:8:\"goodsids\";N;s:9:\"recharges\";s:162:\"a:3:{i:0;a:2:{s:6:\"enough\";s:3:\"100\";s:4:\"give\";s:1:\"1\";}i:1;a:2:{s:6:\"enough\";s:3:\"200\";s:4:\"give\";s:1:\"3\";}i:2;a:2:{s:6:\"enough\";s:3:\"300\";s:4:\"give\";s:1:\"5\";}}\";s:7:\"credit1\";s:401:\"a:3:{s:7:\"enough1\";a:2:{i:0;a:3:{s:9:\"enough1_1\";d:100;s:9:\"enough1_2\";d:199;s:5:\"give1\";d:10;}i:1;a:3:{s:9:\"enough1_1\";d:200;s:9:\"enough1_2\";d:9999;s:5:\"give1\";d:20;}}s:7:\"enough2\";a:2:{i:0;a:3:{s:9:\"enough2_1\";d:100;s:9:\"enough2_2\";d:199;s:5:\"give2\";d:10;}i:1;a:3:{s:9:\"enough2_1\";d:200;s:9:\"enough2_2\";d:999;s:5:\"give2\";d:20;}}s:7:\"paytype\";a:4:{i:1;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:3;s:1:\"1\";}}\";}}\";s:3:\"sec\";s:338:\"a:3:{s:10:\"app_wechat\";a:5:{s:5:\"appid\";s:0:\"\";s:9:\"appsecret\";s:0:\"\";s:9:\"merchname\";s:0:\"\";s:7:\"merchid\";s:0:\"\";s:6:\"apikey\";s:0:\"\";}s:10:\"alipay_pay\";a:4:{s:7:\"partner\";s:0:\"\";s:12:\"account_name\";s:0:\"\";s:5:\"email\";s:0:\"\";s:3:\"key\";s:0:\"\";}s:10:\"app_alipay\";a:3:{s:10:\"public_key\";s:0:\"\";s:11:\"private_key\";s:0:\"\";s:5:\"appid\";s:0:\"\";}}\";}'),('ewei_shop_46d6600d2ebf7065b95b3682e51654da','a:6:{s:4:\"shop\";a:19:{s:4:\"name\";s:9:\"融惠联\";s:4:\"logo\";s:51:\"images/6/2017/09/sTK6rdRr2d2T8m2AAireBB82MAMZpM.png\";s:11:\"description\";s:9:\"融惠联\";s:3:\"img\";s:0:\"\";s:7:\"signimg\";s:0:\"\";s:7:\"getinfo\";s:1:\"1\";s:7:\"saleout\";s:0:\"\";s:7:\"loading\";s:0:\"\";s:7:\"diycode\";s:0:\"\";s:6:\"funbar\";s:1:\"0\";s:5:\"style\";s:3:\"new\";s:8:\"catlevel\";s:1:\"3\";s:7:\"catshow\";s:1:\"0\";s:9:\"catadvimg\";s:0:\"\";s:9:\"catadvurl\";s:0:\"\";s:11:\"bannerswipe\";i:0;s:5:\"cubes\";a:4:{i:0;a:2:{s:3:\"img\";s:51:\"images/6/2017/09/nnNjMAgGqNgs3g800ZnDY40AM8QSam.jpg\";s:3:\"url\";s:0:\"\";}i:1;a:2:{s:3:\"img\";s:51:\"images/6/2017/09/a9Jw7fAhmwzvF7t98P70W11VAaxXZf.jpg\";s:3:\"url\";s:0:\"\";}i:2;a:2:{s:3:\"img\";s:51:\"images/6/2017/09/Xj5aP3Zk7r3J3p3Vt33Yt8K86R0KIu.jpg\";s:3:\"url\";s:0:\"\";}i:3;a:2:{s:3:\"img\";s:51:\"images/6/2017/09/KM997qmpN8M9N078DHiM88mhp90q8H.jpg\";s:3:\"url\";s:0:\"\";}}s:15:\"indexrecommands\";a:2:{i:0;s:3:\"199\";i:1;s:3:\"203\";}s:9:\"indexsort\";a:8:{s:3:\"adv\";a:2:{s:4:\"text\";s:9:\"幻灯片\";s:7:\"visible\";i:1;}s:6:\"search\";a:2:{s:4:\"text\";s:9:\"搜索栏\";s:7:\"visible\";i:1;}s:3:\"nav\";a:2:{s:4:\"text\";s:9:\"导航栏\";s:7:\"visible\";i:1;}s:6:\"notice\";a:2:{s:4:\"text\";s:9:\"公告栏\";s:7:\"visible\";i:1;}s:7:\"seckill\";a:2:{s:4:\"text\";s:9:\"秒杀栏\";s:7:\"visible\";i:1;}s:4:\"cube\";a:2:{s:4:\"text\";s:9:\"魔方栏\";s:7:\"visible\";i:1;}s:6:\"banner\";a:2:{s:4:\"text\";s:9:\"广告栏\";s:7:\"visible\";i:1;}s:5:\"goods\";a:2:{s:4:\"text\";s:9:\"推荐栏\";s:7:\"visible\";i:1;}}}s:8:\"template\";a:2:{s:5:\"style\";s:3:\"new\";s:11:\"detail_temp\";s:1:\"0\";}s:5:\"trade\";a:30:{s:12:\"set_realname\";s:1:\"0\";s:10:\"set_mobile\";s:1:\"0\";s:10:\"closeorder\";i:3;s:14:\"willcloseorder\";s:0:\"\";s:9:\"stockwarn\";s:0:\"\";s:7:\"receive\";s:0:\"\";s:10:\"refunddays\";s:0:\"\";s:13:\"refundcontent\";s:0:\"\";s:10:\"credittext\";s:6:\"积分\";s:9:\"moneytext\";s:6:\"余额\";s:13:\"closerecharge\";s:1:\"0\";s:5:\"money\";s:0:\"\";s:6:\"credit\";s:1:\"0\";s:13:\"minimumcharge\";d:0;s:8:\"withdraw\";s:1:\"0\";s:13:\"withdrawmoney\";s:0:\"\";s:14:\"withdrawcharge\";s:0:\"\";s:13:\"withdrawbegin\";d:0;s:11:\"withdrawend\";d:0;s:9:\"maxcredit\";s:1:\"0\";s:12:\"closecomment\";s:1:\"0\";s:16:\"closecommentshow\";s:1:\"0\";s:14:\"commentchecked\";s:1:\"0\";s:12:\"shareaddress\";s:1:\"1\";s:10:\"istimetext\";s:9:\"限时购\";s:15:\"nodispatchareas\";s:7:\"s:0:\"\";\";s:20:\"nodispatchareas_code\";s:7:\"s:0:\"\";\";s:18:\"withdrawcashweixin\";i:0;s:18:\"withdrawcashalipay\";i:0;s:16:\"withdrawcashcard\";i:0;}s:8:\"category\";a:5:{s:5:\"level\";s:1:\"3\";s:4:\"show\";s:1:\"0\";s:5:\"style\";s:1:\"0\";s:6:\"advimg\";s:0:\"\";s:6:\"advurl\";s:0:\"\";}s:3:\"pay\";a:11:{s:9:\"weixin_id\";i:0;s:6:\"weixin\";i:1;s:10:\"weixin_sub\";i:0;s:10:\"weixin_jie\";i:0;s:14:\"weixin_jie_sub\";i:0;s:6:\"alipay\";i:0;s:6:\"credit\";i:1;s:4:\"cash\";i:1;s:10:\"app_wechat\";i:0;s:10:\"app_alipay\";i:0;s:7:\"paytype\";a:3:{s:10:\"commission\";s:1:\"0\";s:8:\"withdraw\";s:1:\"0\";s:7:\"redpack\";s:1:\"0\";}}s:4:\"sale\";a:9:{s:11:\"enoughmoney\";d:100;s:12:\"enoughdeduct\";d:2;s:7:\"enoughs\";a:2:{i:0;a:2:{s:6:\"enough\";d:200;s:4:\"give\";d:5;}i:1;a:2:{s:6:\"enough\";d:500;s:4:\"give\";d:20;}}s:10:\"enoughfree\";i:1;s:11:\"enoughorder\";d:99;s:11:\"enoughareas\";s:0:\"\";s:8:\"goodsids\";N;s:9:\"recharges\";s:162:\"a:3:{i:0;a:2:{s:6:\"enough\";s:3:\"100\";s:4:\"give\";s:1:\"1\";}i:1;a:2:{s:6:\"enough\";s:3:\"200\";s:4:\"give\";s:1:\"3\";}i:2;a:2:{s:6:\"enough\";s:3:\"300\";s:4:\"give\";s:1:\"5\";}}\";s:7:\"credit1\";s:401:\"a:3:{s:7:\"enough1\";a:2:{i:0;a:3:{s:9:\"enough1_1\";d:100;s:9:\"enough1_2\";d:199;s:5:\"give1\";d:10;}i:1;a:3:{s:9:\"enough1_1\";d:200;s:9:\"enough1_2\";d:9999;s:5:\"give1\";d:20;}}s:7:\"enough2\";a:2:{i:0;a:3:{s:9:\"enough2_1\";d:100;s:9:\"enough2_2\";d:199;s:5:\"give2\";d:10;}i:1;a:3:{s:9:\"enough2_1\";d:200;s:9:\"enough2_2\";d:999;s:5:\"give2\";d:20;}}s:7:\"paytype\";a:4:{i:1;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:3;s:1:\"1\";}}\";}}'),('ewei_shop_9a52bfbf32243c1f30edc58b89a2935a','a:0:{}'),('ewei_shop_a4676ec36c0e61443f52f5bf9c711135','a:12:{i:0;a:13:{s:2:\"id\";s:1:\"1\";s:12:\"displayorder\";s:1:\"1\";s:8:\"identity\";s:5:\"qiniu\";s:4:\"name\";s:12:\"七牛存储\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"tool\";s:5:\"thumb\";s:45:\"../addons/ewei_shopv2/static/images/qiniu.jpg\";s:4:\"desc\";N;s:5:\"iscom\";s:1:\"1\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:1;a:13:{s:2:\"id\";s:1:\"5\";s:12:\"displayorder\";s:1:\"5\";s:8:\"identity\";s:6:\"verify\";s:4:\"name\";s:9:\"O2O核销\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:3:\"biz\";s:5:\"thumb\";s:46:\"../addons/ewei_shopv2/static/images/verify.jpg\";s:4:\"desc\";N;s:5:\"iscom\";s:1:\"1\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:2;a:13:{s:2:\"id\";s:1:\"6\";s:12:\"displayorder\";s:1:\"6\";s:8:\"identity\";s:8:\"tmessage\";s:4:\"name\";s:12:\"会员群发\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"tool\";s:5:\"thumb\";s:48:\"../addons/ewei_shopv2/static/images/tmessage.jpg\";s:4:\"desc\";N;s:5:\"iscom\";s:1:\"1\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:3;a:13:{s:2:\"id\";s:1:\"7\";s:12:\"displayorder\";s:1:\"7\";s:8:\"identity\";s:4:\"perm\";s:4:\"name\";s:12:\"分权系统\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"help\";s:5:\"thumb\";s:44:\"../addons/ewei_shopv2/static/images/perm.jpg\";s:4:\"desc\";N;s:5:\"iscom\";s:1:\"1\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:4;a:13:{s:2:\"id\";s:1:\"8\";s:12:\"displayorder\";s:1:\"8\";s:8:\"identity\";s:4:\"sale\";s:4:\"name\";s:9:\"营销宝\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"sale\";s:5:\"thumb\";s:44:\"../addons/ewei_shopv2/static/images/sale.jpg\";s:4:\"desc\";N;s:5:\"iscom\";s:1:\"1\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:5;a:13:{s:2:\"id\";s:2:\"11\";s:12:\"displayorder\";s:2:\"11\";s:8:\"identity\";s:7:\"virtual\";s:4:\"name\";s:12:\"虚拟物品\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:3:\"biz\";s:5:\"thumb\";s:47:\"../addons/ewei_shopv2/static/images/virtual.jpg\";s:4:\"desc\";N;s:5:\"iscom\";s:1:\"1\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:6;a:13:{s:2:\"id\";s:2:\"13\";s:12:\"displayorder\";s:2:\"13\";s:8:\"identity\";s:6:\"coupon\";s:4:\"name\";s:9:\"超级券\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"sale\";s:5:\"thumb\";s:46:\"../addons/ewei_shopv2/static/images/coupon.jpg\";s:4:\"desc\";N;s:5:\"iscom\";s:1:\"1\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:7;a:13:{s:2:\"id\";s:2:\"24\";s:12:\"displayorder\";s:2:\"27\";s:8:\"identity\";s:3:\"sms\";s:4:\"name\";s:12:\"短信提醒\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"tool\";s:5:\"thumb\";s:43:\"../addons/ewei_shopv2/static/images/sms.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"1\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:8;a:13:{s:2:\"id\";s:2:\"27\";s:12:\"displayorder\";s:2:\"33\";s:8:\"identity\";s:3:\"wap\";s:4:\"name\";s:9:\"全网通\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"tool\";s:5:\"thumb\";s:0:\"\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"1\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:9;a:13:{s:2:\"id\";s:2:\"30\";s:12:\"displayorder\";s:2:\"33\";s:8:\"identity\";s:7:\"printer\";s:4:\"name\";s:15:\"小票打印机\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"tool\";s:5:\"thumb\";s:0:\"\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"1\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:10;a:13:{s:2:\"id\";s:2:\"28\";s:12:\"displayorder\";s:2:\"34\";s:8:\"identity\";s:5:\"h5app\";s:4:\"name\";s:5:\"H5APP\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"tool\";s:5:\"thumb\";s:0:\"\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"1\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:11;a:13:{s:2:\"id\";s:2:\"38\";s:12:\"displayorder\";s:2:\"41\";s:8:\"identity\";s:6:\"wxcard\";s:4:\"name\";s:12:\"微信卡券\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"sale\";s:5:\"thumb\";s:0:\"\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"1\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}}'),('ewei_shop_09110ee6c3659ae7c87f306b6c6a8616','a:28:{i:0;a:13:{s:2:\"id\";s:1:\"2\";s:12:\"displayorder\";s:1:\"2\";s:8:\"identity\";s:6:\"taobao\";s:4:\"name\";s:12:\"商品助手\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"tool\";s:5:\"thumb\";s:46:\"../addons/ewei_shopv2/static/images/taobao.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:1;a:13:{s:2:\"id\";s:1:\"3\";s:12:\"displayorder\";s:1:\"3\";s:8:\"identity\";s:10:\"commission\";s:4:\"name\";s:12:\"人人分销\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:3:\"biz\";s:5:\"thumb\";s:50:\"../addons/ewei_shopv2/static/images/commission.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:2;a:13:{s:2:\"id\";s:1:\"4\";s:12:\"displayorder\";s:1:\"4\";s:8:\"identity\";s:6:\"poster\";s:4:\"name\";s:12:\"超级海报\";s:7:\"version\";s:3:\"1.2\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"sale\";s:5:\"thumb\";s:46:\"../addons/ewei_shopv2/static/images/poster.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:3;a:13:{s:2:\"id\";s:2:\"10\";s:12:\"displayorder\";s:2:\"10\";s:8:\"identity\";s:10:\"creditshop\";s:4:\"name\";s:12:\"积分商城\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:3:\"biz\";s:5:\"thumb\";s:50:\"../addons/ewei_shopv2/static/images/creditshop.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:4;a:13:{s:2:\"id\";s:2:\"12\";s:12:\"displayorder\";s:2:\"11\";s:8:\"identity\";s:7:\"article\";s:4:\"name\";s:12:\"文章营销\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"help\";s:5:\"thumb\";s:47:\"../addons/ewei_shopv2/static/images/article.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:5;a:13:{s:2:\"id\";s:2:\"14\";s:12:\"displayorder\";s:2:\"14\";s:8:\"identity\";s:7:\"postera\";s:4:\"name\";s:12:\"活动海报\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"sale\";s:5:\"thumb\";s:47:\"../addons/ewei_shopv2/static/images/postera.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:6;a:13:{s:2:\"id\";s:2:\"16\";s:12:\"displayorder\";s:2:\"15\";s:8:\"identity\";s:7:\"diyform\";s:4:\"name\";s:12:\"自定表单\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"help\";s:5:\"thumb\";s:47:\"../addons/ewei_shopv2/static/images/diyform.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:7;a:13:{s:2:\"id\";s:2:\"17\";s:12:\"displayorder\";s:2:\"16\";s:8:\"identity\";s:8:\"exhelper\";s:4:\"name\";s:12:\"快递助手\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"help\";s:5:\"thumb\";s:48:\"../addons/ewei_shopv2/static/images/exhelper.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:8;a:13:{s:2:\"id\";s:2:\"18\";s:12:\"displayorder\";s:2:\"19\";s:8:\"identity\";s:6:\"groups\";s:4:\"name\";s:12:\"人人拼团\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:3:\"biz\";s:5:\"thumb\";s:46:\"../addons/ewei_shopv2/static/images/groups.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:9;a:13:{s:2:\"id\";s:2:\"19\";s:12:\"displayorder\";s:2:\"20\";s:8:\"identity\";s:7:\"diypage\";s:4:\"name\";s:12:\"店铺装修\";s:7:\"version\";s:3:\"2.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"help\";s:5:\"thumb\";s:48:\"../addons/ewei_shopv2/static/images/designer.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:10;a:13:{s:2:\"id\";s:2:\"20\";s:12:\"displayorder\";s:2:\"22\";s:8:\"identity\";s:8:\"globonus\";s:4:\"name\";s:12:\"全民股东\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:3:\"biz\";s:5:\"thumb\";s:48:\"../addons/ewei_shopv2/static/images/globonus.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:11;a:13:{s:2:\"id\";s:2:\"21\";s:12:\"displayorder\";s:2:\"23\";s:8:\"identity\";s:5:\"merch\";s:4:\"name\";s:9:\"多商户\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:3:\"biz\";s:5:\"thumb\";s:45:\"../addons/ewei_shopv2/static/images/merch.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:12;a:13:{s:2:\"id\";s:2:\"22\";s:12:\"displayorder\";s:2:\"26\";s:8:\"identity\";s:2:\"qa\";s:4:\"name\";s:12:\"帮助中心\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"help\";s:5:\"thumb\";s:42:\"../addons/ewei_shopv2/static/images/qa.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:13;a:13:{s:2:\"id\";s:2:\"29\";s:12:\"displayorder\";s:2:\"26\";s:8:\"identity\";s:6:\"abonus\";s:4:\"name\";s:12:\"区域代理\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:3:\"biz\";s:5:\"thumb\";s:46:\"../addons/ewei_shopv2/static/images/abonus.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:14;a:13:{s:2:\"id\";s:2:\"25\";s:12:\"displayorder\";s:2:\"29\";s:8:\"identity\";s:4:\"sign\";s:4:\"name\";s:12:\"积分签到\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"tool\";s:5:\"thumb\";s:44:\"../addons/ewei_shopv2/static/images/sign.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:15;a:13:{s:2:\"id\";s:2:\"26\";s:12:\"displayorder\";s:2:\"30\";s:8:\"identity\";s:3:\"sns\";s:4:\"name\";s:12:\"全民社区\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"sale\";s:5:\"thumb\";s:43:\"../addons/ewei_shopv2/static/images/sns.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:16;a:13:{s:2:\"id\";s:2:\"31\";s:12:\"displayorder\";s:2:\"34\";s:8:\"identity\";s:7:\"bargain\";s:4:\"name\";s:12:\"砍价活动\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"tool\";s:5:\"thumb\";s:47:\"../addons/ewei_shopv2/static/images/bargain.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:17;a:13:{s:2:\"id\";s:2:\"32\";s:12:\"displayorder\";s:2:\"35\";s:8:\"identity\";s:4:\"task\";s:4:\"name\";s:12:\"任务中心\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"sale\";s:5:\"thumb\";s:44:\"../addons/ewei_shopv2/static/images/task.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:18;a:13:{s:2:\"id\";s:2:\"33\";s:12:\"displayorder\";s:2:\"36\";s:8:\"identity\";s:7:\"cashier\";s:4:\"name\";s:9:\"收银台\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:3:\"biz\";s:5:\"thumb\";s:47:\"../addons/ewei_shopv2/static/images/cashier.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:19;a:13:{s:2:\"id\";s:2:\"34\";s:12:\"displayorder\";s:2:\"37\";s:8:\"identity\";s:8:\"messages\";s:4:\"name\";s:12:\"消息群发\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"tool\";s:5:\"thumb\";s:48:\"../addons/ewei_shopv2/static/images/messages.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:20;a:13:{s:2:\"id\";s:2:\"35\";s:12:\"displayorder\";s:2:\"38\";s:8:\"identity\";s:7:\"seckill\";s:4:\"name\";s:12:\"整点秒杀\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"sale\";s:5:\"thumb\";s:47:\"../addons/ewei_shopv2/static/images/seckill.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:21;a:13:{s:2:\"id\";s:2:\"36\";s:12:\"displayorder\";s:2:\"39\";s:8:\"identity\";s:8:\"exchange\";s:4:\"name\";s:12:\"兑换中心\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:3:\"biz\";s:5:\"thumb\";s:48:\"../addons/ewei_shopv2/static/images/exchange.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:22;a:13:{s:2:\"id\";s:2:\"37\";s:12:\"displayorder\";s:2:\"40\";s:8:\"identity\";s:7:\"lottery\";s:4:\"name\";s:12:\"游戏营销\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:3:\"biz\";s:5:\"thumb\";s:47:\"../addons/ewei_shopv2/static/images/lottery.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:23;a:13:{s:2:\"id\";s:2:\"39\";s:12:\"displayorder\";s:2:\"42\";s:8:\"identity\";s:5:\"quick\";s:4:\"name\";s:12:\"快速购买\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:3:\"biz\";s:5:\"thumb\";s:45:\"../addons/ewei_shopv2/static/images/quick.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:24;a:13:{s:2:\"id\";s:2:\"40\";s:12:\"displayorder\";s:2:\"43\";s:8:\"identity\";s:7:\"mmanage\";s:4:\"name\";s:27:\"手机端商家管理中心\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"tool\";s:5:\"thumb\";s:47:\"../addons/ewei_shopv2/static/images/mmanage.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:25;a:13:{s:2:\"id\";s:2:\"41\";s:12:\"displayorder\";s:2:\"44\";s:8:\"identity\";s:2:\"pc\";s:4:\"name\";s:5:\"PC端\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"二开\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"tool\";s:5:\"thumb\";s:42:\"../addons/ewei_shopv2/static/images/pc.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"0\";}i:26;a:13:{s:2:\"id\";s:2:\"42\";s:12:\"displayorder\";s:2:\"45\";s:8:\"identity\";s:4:\"live\";s:4:\"name\";s:12:\"互动直播\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"sale\";s:5:\"thumb\";s:44:\"../addons/ewei_shopv2/static/images/live.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}i:27;a:13:{s:2:\"id\";s:2:\"43\";s:12:\"displayorder\";s:2:\"46\";s:8:\"identity\";s:13:\"universalform\";s:4:\"name\";s:12:\"调研报名\";s:7:\"version\";s:3:\"1.0\";s:6:\"author\";s:6:\"官方\";s:6:\"status\";s:1:\"1\";s:8:\"category\";s:4:\"sale\";s:5:\"thumb\";s:42:\"../addons/ewei_shopv2/static/images/dy.jpg\";s:4:\"desc\";s:0:\"\";s:5:\"iscom\";s:1:\"0\";s:10:\"deprecated\";s:1:\"0\";s:4:\"isv2\";s:1:\"1\";}}'),('stat:todaylock:6','a:1:{s:6:\"expire\";i:1504592637;}'),('ewei_shop_02b72fcc49fb8916836f109352f05d59','s:19:\"2017-09-05 20:58:15\";'),('ewei_shop_52285de7717f2d78ca6623c56da33f82','s:19:\"2017-09-05 20:58:15\";'),('ewei_shop_106d0296ca686e59fdfbf235c85a1569','s:19:\"2017-09-05 20:58:15\";'),('ewei_shop_3b67348a577d9548c80c1015085a5c72','s:19:\"2017-09-05 20:58:15\";'),('ewei_shop_2f815720a2f517136716dbb1096bea5d','s:19:\"2017-09-05 21:19:05\";'),('ewei_shop_d45488b13ce1f38aa2bba754b153037f','s:19:\"2017-09-05 20:58:15\";'),('ewei_shop_0911efc078ad5f1d1b9287ef20d15ac2','s:19:\"2017-09-05 20:58:15\";'),('ewei_shop_38220aea94c7235faf501f4f7b391b16','s:19:\"2017-09-05 20:58:15\";'),('ewei_shop_ea6faf4b5220ae84fad4509b6e8af8ed','s:19:\"2017-09-05 20:58:15\";'),('ewei_shop_7396644c107af96d3c865357820dbd61','a:2:{s:6:\"parent\";a:4:{i:0;a:13:{s:2:\"id\";s:4:\"1174\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:6:\"手机\";s:5:\"thumb\";s:0:\"\";s:8:\"parentid\";s:1:\"0\";s:11:\"isrecommand\";s:1:\"0\";s:11:\"description\";s:6:\"手机\";s:12:\"displayorder\";s:1:\"0\";s:7:\"enabled\";s:1:\"1\";s:6:\"ishome\";s:1:\"0\";s:6:\"advimg\";s:51:\"images/6/2017/09/qJjG2YfkZJD5KKa6TGg3n3jW32j2J2.jpg\";s:6:\"advurl\";s:0:\"\";s:5:\"level\";i:1;}i:1;a:13:{s:2:\"id\";s:4:\"1175\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:6:\"红酒\";s:5:\"thumb\";s:0:\"\";s:8:\"parentid\";s:1:\"0\";s:11:\"isrecommand\";s:1:\"0\";s:11:\"description\";s:6:\"红酒\";s:12:\"displayorder\";s:1:\"0\";s:7:\"enabled\";s:1:\"1\";s:6:\"ishome\";s:1:\"0\";s:6:\"advimg\";s:0:\"\";s:6:\"advurl\";s:0:\"\";s:5:\"level\";i:1;}i:2;a:13:{s:2:\"id\";s:4:\"1176\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:6:\"首饰\";s:5:\"thumb\";s:0:\"\";s:8:\"parentid\";s:1:\"0\";s:11:\"isrecommand\";s:1:\"0\";s:11:\"description\";s:6:\"首饰\";s:12:\"displayorder\";s:1:\"0\";s:7:\"enabled\";s:1:\"1\";s:6:\"ishome\";s:1:\"0\";s:6:\"advimg\";s:0:\"\";s:6:\"advurl\";s:0:\"\";s:5:\"level\";i:1;}i:3;a:13:{s:2:\"id\";s:4:\"1183\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:12:\"美妆个护\";s:5:\"thumb\";s:0:\"\";s:8:\"parentid\";s:1:\"0\";s:11:\"isrecommand\";s:1:\"0\";s:11:\"description\";s:12:\"美妆个护\";s:12:\"displayorder\";s:1:\"0\";s:7:\"enabled\";s:1:\"1\";s:6:\"ishome\";s:1:\"0\";s:6:\"advimg\";s:0:\"\";s:6:\"advurl\";s:0:\"\";s:5:\"level\";i:1;}}s:8:\"children\";a:3:{i:1174;a:3:{i:0;a:14:{s:2:\"id\";s:4:\"1177\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:6:\"华为\";s:5:\"thumb\";s:0:\"\";s:8:\"parentid\";s:4:\"1174\";s:11:\"isrecommand\";s:1:\"1\";s:11:\"description\";s:0:\"\";s:12:\"displayorder\";s:1:\"0\";s:7:\"enabled\";s:1:\"1\";s:6:\"ishome\";s:1:\"1\";s:6:\"advimg\";s:0:\"\";s:6:\"advurl\";s:0:\"\";s:5:\"level\";s:1:\"2\";i:1174;a:1:{s:5:\"level\";i:2;}}i:1;a:14:{s:2:\"id\";s:4:\"1178\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:6:\"小米\";s:5:\"thumb\";s:0:\"\";s:8:\"parentid\";s:4:\"1174\";s:11:\"isrecommand\";s:1:\"0\";s:11:\"description\";s:0:\"\";s:12:\"displayorder\";s:1:\"0\";s:7:\"enabled\";s:1:\"1\";s:6:\"ishome\";s:1:\"0\";s:6:\"advimg\";s:0:\"\";s:6:\"advurl\";s:0:\"\";s:5:\"level\";s:1:\"2\";i:1174;a:1:{s:5:\"level\";i:2;}}i:2;a:14:{s:2:\"id\";s:4:\"1179\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:6:\"苹果\";s:5:\"thumb\";s:0:\"\";s:8:\"parentid\";s:4:\"1174\";s:11:\"isrecommand\";s:1:\"0\";s:11:\"description\";s:0:\"\";s:12:\"displayorder\";s:1:\"0\";s:7:\"enabled\";s:1:\"1\";s:6:\"ishome\";s:1:\"0\";s:6:\"advimg\";s:0:\"\";s:6:\"advurl\";s:0:\"\";s:5:\"level\";s:1:\"2\";i:1174;a:1:{s:5:\"level\";i:2;}}}i:1177;a:3:{i:0;a:14:{s:2:\"id\";s:4:\"1180\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:10:\"Mate系列\";s:5:\"thumb\";s:0:\"\";s:8:\"parentid\";s:4:\"1177\";s:11:\"isrecommand\";s:1:\"0\";s:11:\"description\";s:0:\"\";s:12:\"displayorder\";s:1:\"0\";s:7:\"enabled\";s:1:\"1\";s:6:\"ishome\";s:1:\"0\";s:6:\"advimg\";s:0:\"\";s:6:\"advurl\";s:0:\"\";s:5:\"level\";s:1:\"3\";i:1177;a:1:{s:5:\"level\";i:2;}}i:1;a:14:{s:2:\"id\";s:4:\"1181\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:7:\"P系列\";s:5:\"thumb\";s:0:\"\";s:8:\"parentid\";s:4:\"1177\";s:11:\"isrecommand\";s:1:\"0\";s:11:\"description\";s:0:\"\";s:12:\"displayorder\";s:1:\"0\";s:7:\"enabled\";s:1:\"1\";s:6:\"ishome\";s:1:\"0\";s:6:\"advimg\";s:0:\"\";s:6:\"advurl\";s:0:\"\";s:5:\"level\";s:1:\"3\";i:1177;a:1:{s:5:\"level\";i:2;}}i:2;a:14:{s:2:\"id\";s:4:\"1182\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:7:\"G系列\";s:5:\"thumb\";s:0:\"\";s:8:\"parentid\";s:4:\"1177\";s:11:\"isrecommand\";s:1:\"0\";s:11:\"description\";s:0:\"\";s:12:\"displayorder\";s:1:\"0\";s:7:\"enabled\";s:1:\"1\";s:6:\"ishome\";s:1:\"0\";s:6:\"advimg\";s:0:\"\";s:6:\"advurl\";s:0:\"\";s:5:\"level\";s:1:\"3\";i:1177;a:1:{s:5:\"level\";i:2;}}}i:1183;a:3:{i:0;a:14:{s:2:\"id\";s:4:\"1184\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:12:\"护肤套装\";s:5:\"thumb\";s:0:\"\";s:8:\"parentid\";s:4:\"1183\";s:11:\"isrecommand\";s:1:\"1\";s:11:\"description\";s:12:\"护肤套装\";s:12:\"displayorder\";s:1:\"0\";s:7:\"enabled\";s:1:\"1\";s:6:\"ishome\";s:1:\"1\";s:6:\"advimg\";s:0:\"\";s:6:\"advurl\";s:0:\"\";s:5:\"level\";s:1:\"2\";i:1183;a:1:{s:5:\"level\";i:2;}}i:1;a:14:{s:2:\"id\";s:4:\"1185\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:13:\"精华/原液\";s:5:\"thumb\";s:0:\"\";s:8:\"parentid\";s:4:\"1183\";s:11:\"isrecommand\";s:1:\"1\";s:11:\"description\";s:13:\"精华/原液\";s:12:\"displayorder\";s:1:\"0\";s:7:\"enabled\";s:1:\"1\";s:6:\"ishome\";s:1:\"1\";s:6:\"advimg\";s:0:\"\";s:6:\"advurl\";s:0:\"\";s:5:\"level\";s:1:\"2\";i:1183;a:1:{s:5:\"level\";i:2;}}i:2;a:14:{s:2:\"id\";s:4:\"1186\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:13:\"乳液/面霜\";s:5:\"thumb\";s:0:\"\";s:8:\"parentid\";s:4:\"1183\";s:11:\"isrecommand\";s:1:\"1\";s:11:\"description\";s:13:\"乳液/面霜\";s:12:\"displayorder\";s:1:\"0\";s:7:\"enabled\";s:1:\"1\";s:6:\"ishome\";s:1:\"1\";s:6:\"advimg\";s:0:\"\";s:6:\"advurl\";s:0:\"\";s:5:\"level\";s:1:\"2\";i:1183;a:1:{s:5:\"level\";i:2;}}}}}'),('ewei_shop_4052df8f3b86f4ca9a6014d44cc884e3','a:13:{i:1174;a:5:{s:2:\"id\";s:4:\"1174\";s:8:\"parentid\";s:1:\"0\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:6:\"手机\";s:5:\"thumb\";s:0:\"\";}i:1175;a:5:{s:2:\"id\";s:4:\"1175\";s:8:\"parentid\";s:1:\"0\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:6:\"红酒\";s:5:\"thumb\";s:0:\"\";}i:1176;a:5:{s:2:\"id\";s:4:\"1176\";s:8:\"parentid\";s:1:\"0\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:6:\"首饰\";s:5:\"thumb\";s:0:\"\";}i:1177;a:5:{s:2:\"id\";s:4:\"1177\";s:8:\"parentid\";s:4:\"1174\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:6:\"华为\";s:5:\"thumb\";s:0:\"\";}i:1178;a:5:{s:2:\"id\";s:4:\"1178\";s:8:\"parentid\";s:4:\"1174\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:6:\"小米\";s:5:\"thumb\";s:0:\"\";}i:1179;a:5:{s:2:\"id\";s:4:\"1179\";s:8:\"parentid\";s:4:\"1174\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:6:\"苹果\";s:5:\"thumb\";s:0:\"\";}i:1180;a:5:{s:2:\"id\";s:4:\"1180\";s:8:\"parentid\";s:4:\"1177\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:10:\"Mate系列\";s:5:\"thumb\";s:0:\"\";}i:1181;a:5:{s:2:\"id\";s:4:\"1181\";s:8:\"parentid\";s:4:\"1177\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:7:\"P系列\";s:5:\"thumb\";s:0:\"\";}i:1182;a:5:{s:2:\"id\";s:4:\"1182\";s:8:\"parentid\";s:4:\"1177\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:7:\"G系列\";s:5:\"thumb\";s:0:\"\";}i:1183;a:5:{s:2:\"id\";s:4:\"1183\";s:8:\"parentid\";s:1:\"0\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:12:\"美妆个护\";s:5:\"thumb\";s:0:\"\";}i:1184;a:5:{s:2:\"id\";s:4:\"1184\";s:8:\"parentid\";s:4:\"1183\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:12:\"护肤套装\";s:5:\"thumb\";s:0:\"\";}i:1185;a:5:{s:2:\"id\";s:4:\"1185\";s:8:\"parentid\";s:4:\"1183\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:13:\"精华/原液\";s:5:\"thumb\";s:0:\"\";}i:1186;a:5:{s:2:\"id\";s:4:\"1186\";s:8:\"parentid\";s:4:\"1183\";s:7:\"uniacid\";s:1:\"6\";s:4:\"name\";s:13:\"乳液/面霜\";s:5:\"thumb\";s:0:\"\";}}'),('ewei_shop_ac042c8e29eaded1f9bff2e9c4229b36','s:783:\"<!DOCTYPE html>\r\n                <html>\r\n                    <head>\r\n                        <meta name=\'viewport\' content=\'width=device-width, initial-scale=1, user-scalable=0\'>\r\n                        <title>抱歉，出错了</title><meta charset=\'utf-8\'><meta name=\'viewport\' content=\'width=device-width, initial-scale=1, user-scalable=0\'><link rel=\'stylesheet\' type=\'text/css\' href=\'https://res.wx.qq.com/connect/zh_CN/htmledition/style/wap_err1a9853.css\'>\r\n                    </head>\r\n                    <body>\r\n                    <div class=\'page_msg\'><div class=\'inner\'><span class=\'msg_icon_wrp\'><i class=\'icon80_smile\'></i></span><div class=\'msg_content\'><h4>请在微信客户端打开链接</h4></div></div></div>\r\n                    </body>\r\n                </html>\";'),('uniaccount:6','a:30:{s:4:\"acid\";s:1:\"6\";s:7:\"uniacid\";s:1:\"6\";s:5:\"token\";s:32:\"s74F6bfPt6mBBblFtPBppUfp2t7PoB2p\";s:14:\"encodingaeskey\";s:43:\"UQJJzC96Iiga6XSQRS8DFRAxQ63I9JagG6FaaccxJaG\";s:5:\"level\";s:1:\"4\";s:4:\"name\";s:9:\"融惠联\";s:7:\"account\";s:5:\"adjyc\";s:8:\"original\";s:15:\"gh_dca636eab4ce\";s:9:\"signature\";s:0:\"\";s:7:\"country\";s:0:\"\";s:8:\"province\";s:0:\"\";s:4:\"city\";s:0:\"\";s:8:\"username\";s:0:\"\";s:8:\"password\";s:0:\"\";s:10:\"lastupdate\";s:1:\"0\";s:3:\"key\";s:18:\"wxb797d06f10b3f641\";s:6:\"secret\";s:32:\"ab235bf8be745b7d2c268ed8723020e2\";s:7:\"styleid\";s:1:\"0\";s:12:\"subscribeurl\";s:0:\"\";s:18:\"auth_refresh_token\";s:0:\"\";s:4:\"type\";s:1:\"1\";s:9:\"isconnect\";s:1:\"1\";s:9:\"isdeleted\";s:1:\"0\";s:3:\"uid\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:6:\"groups\";a:1:{i:6;a:5:{s:7:\"groupid\";s:1:\"6\";s:7:\"uniacid\";s:1:\"6\";s:5:\"title\";s:15:\"默认会员组\";s:6:\"credit\";s:1:\"0\";s:9:\"isdefault\";s:1:\"1\";}}s:10:\"grouplevel\";s:1:\"0\";s:4:\"logo\";s:60:\"http://wx.adjyc.com/attachment/headimg_6.jpg?time=1504423745\";s:6:\"qrcode\";s:59:\"http://wx.adjyc.com/attachment/qrcode_6.jpg?time=1504423745\";}'),('defaultgroupid:6','s:1:\"6\";'),('uniaccount:0','a:8:{s:3:\"uid\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:6:\"groups\";a:0:{}s:10:\"grouplevel\";b:0;s:4:\"logo\";s:59:\"http://wx.adjyc.com/attachment/headimg_.jpg?time=1504405393\";s:6:\"qrcode\";s:58:\"http://wx.adjyc.com/attachment/qrcode_.jpg?time=1504405393\";s:9:\"isconnect\";b:0;}'),('unisetting:0','b:0;'),('we7:memberinfo:3','a:52:{s:3:\"uid\";s:1:\"3\";s:7:\"uniacid\";s:1:\"6\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"f8c68a2664c1f081904d3f6c041e7d7f@we7.cc\";s:8:\"password\";s:32:\"d24f2bfff6b18d8438822411b9e2666b\";s:4:\"salt\";s:8:\"FuPX1Pf1\";s:7:\"groupid\";s:1:\"6\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:9999999;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1504164620\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:6:\"冯颖\";s:6:\"avatar\";s:125:\"http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTL2Y9PUbicZcT9I8B9vDsNZGxsHCOticXbYJhdGuvZ7TPVOewFzbafn9PRia15IA2qkdq30LqJtqGjOQ/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"北京省\";s:10:\"residecity\";s:3:\"市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";}'),('we7:lastaccount:y38oA','a:1:{s:7:\"account\";i:6;}'),('we7:uni_group','a:2:{i:1;a:6:{s:2:\"id\";s:1:\"1\";s:4:\"name\";s:18:\"体验套餐服务\";s:7:\"modules\";a:4:{s:11:\"ewei_shopv2\";a:25:{s:3:\"mid\";s:2:\"12\";s:4:\"name\";s:11:\"ewei_shopv2\";s:4:\"type\";s:8:\"business\";s:5:\"title\";s:9:\"人人店\";s:7:\"version\";s:5:\"3.5.4\";s:7:\"ability\";s:9:\"人人店\";s:11:\"description\";s:9:\"人人店\";s:6:\"author\";s:12:\"weichengtech\";s:3:\"url\";s:12:\"weichengtech\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";a:14:{i:0;s:4:\"text\";i:1;s:5:\"image\";i:2;s:5:\"voice\";i:3;s:5:\"video\";i:4;s:10:\"shortvideo\";i:5;s:8:\"location\";i:6;s:4:\"link\";i:7;s:9:\"subscribe\";i:8;s:11:\"unsubscribe\";i:9;s:2:\"qr\";i:10;s:5:\"trace\";i:11;s:5:\"click\";i:12;s:4:\"view\";i:13;s:14:\"merchant_order\";}s:7:\"handles\";a:12:{i:0;s:4:\"text\";i:1;s:5:\"image\";i:2;s:5:\"voice\";i:3;s:5:\"video\";i:4;s:10:\"shortvideo\";i:5;s:8:\"location\";i:6;s:4:\"link\";i:7;s:9:\"subscribe\";i:8;s:2:\"qr\";i:9;s:5:\"trace\";i:10;s:5:\"click\";i:11;s:14:\"merchant_order\";}s:12:\"isrulefields\";s:1:\"0\";s:8:\"issystem\";s:1:\"0\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:6:\"a:0:{}\";s:13:\"title_initial\";s:1:\"R\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:60:\"http://wx.adjyc.com/addons/ewei_shopv2/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}s:6:\"bm_top\";a:25:{s:3:\"mid\";s:2:\"13\";s:4:\"name\";s:6:\"bm_top\";s:4:\"type\";s:8:\"business\";s:5:\"title\";s:9:\"粉丝榜\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:9:\"粉丝榜\";s:11:\"description\";s:9:\"粉丝榜\";s:6:\"author\";s:24:\"折翼天使资源社区\";s:3:\"url\";s:20:\"www.zheyitianshi.com\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";a:1:{i:0;s:9:\"subscribe\";}s:7:\"handles\";a:1:{i:0;s:4:\"text\";}s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"0\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:2:\"N;\";s:13:\"title_initial\";s:1:\"F\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:55:\"http://wx.adjyc.com/addons/bm_top/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}s:18:\"stonefish_bigwheel\";a:25:{s:3:\"mid\";s:2:\"14\";s:4:\"name\";s:18:\"stonefish_bigwheel\";s:4:\"type\";s:8:\"activity\";s:5:\"title\";s:15:\"幸运大转盘\";s:7:\"version\";s:3:\"1.6\";s:7:\"ability\";s:27:\"幸运大转盘营销抽奖\";s:11:\"description\";s:128:\"幸运大转盘营销抽奖-结合商家网点模块，每个商家可送抽奖机会,分享还可以额外获得抽奖机会哟\";s:6:\"author\";s:24:\"折翼天使资源社区\";s:3:\"url\";s:28:\"http://www.zheyitianshi.com/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";a:0:{}s:7:\"handles\";a:1:{i:0;s:4:\"text\";}s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"0\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:2:\"N;\";s:13:\"title_initial\";s:1:\"X\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:67:\"http://wx.adjyc.com/addons/stonefish_bigwheel/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}s:10:\"we7_coupon\";a:25:{s:3:\"mid\";s:2:\"15\";s:4:\"name\";s:10:\"we7_coupon\";s:4:\"type\";s:8:\"business\";s:5:\"title\";s:12:\"系统卡券\";s:7:\"version\";s:3:\"3.8\";s:7:\"ability\";s:12:\"微信卡券\";s:11:\"description\";s:12:\"微信卡券\";s:6:\"author\";s:12:\"蓝梦社区\";s:3:\"url\";s:0:\"\";s:8:\"settings\";s:1:\"1\";s:10:\"subscribes\";a:0:{}s:7:\"handles\";a:0:{}s:12:\"isrulefields\";s:1:\"0\";s:8:\"issystem\";s:1:\"0\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:6:\"a:0:{}\";s:13:\"title_initial\";s:1:\"X\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:9:\"isdisplay\";i:1;s:4:\"logo\";s:59:\"http://wx.adjyc.com/addons/we7_coupon/icon.jpg?v=1504321709\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:11:\"is_relation\";b:0;}}s:9:\"templates\";a:3:{s:6:\"style1\";a:3:{s:2:\"id\";s:1:\"2\";s:4:\"name\";s:6:\"style1\";s:5:\"title\";s:13:\"微站模板1\";}s:7:\"style13\";a:3:{s:2:\"id\";s:1:\"3\";s:4:\"name\";s:7:\"style13\";s:5:\"title\";s:14:\"微站模板13\";}s:7:\"style88\";a:3:{s:2:\"id\";s:1:\"5\";s:4:\"name\";s:7:\"style88\";s:5:\"title\";s:14:\"微站模板88\";}}s:7:\"uniacid\";s:1:\"0\";s:5:\"wxapp\";a:0:{}}i:-1;a:3:{s:2:\"id\";i:-1;s:4:\"name\";s:12:\"所有服务\";s:5:\"wxapp\";a:0:{}}}'),('we7:lastaccount:MOFEU','a:1:{s:7:\"account\";i:6;}'),('we7:memberinfo:5','a:52:{s:3:\"uid\";s:1:\"5\";s:7:\"uniacid\";s:1:\"6\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"39880da131c0a19c996545479de15b83@we7.cc\";s:8:\"password\";s:32:\"d24f2bfff6b18d8438822411b9e2666b\";s:4:\"salt\";s:8:\"jSbfF0Ee\";s:7:\"groupid\";s:1:\"6\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1504522105\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:6:\"郝叶\";s:6:\"avatar\";s:127:\"http://wx.qlogo.cn/mmopen/vi_32/PiajxSqBRaEJ236KCicoePibtMh3bhoxVsbWyTKhquFDxyf4uaVBlg4OofGYBNDCtBX4icCadSyxcxSq9rNUunrvicQ/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:9:\"安道尔\";s:14:\"resideprovince\";s:3:\"省\";s:10:\"residecity\";s:3:\"市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";}'),('we7:lastaccount:rz4f3','a:1:{s:7:\"account\";i:6;}'),('we7:lastaccount:ygKk2','a:1:{s:7:\"account\";i:6;}');
/*!40000 ALTER TABLE `ims_core_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_core_cache_copy`
--

DROP TABLE IF EXISTS `ims_core_cache_copy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_core_cache_copy` (
  `key` varchar(50) NOT NULL,
  `value` longtext NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_core_cache_copy`
--

LOCK TABLES `ims_core_cache_copy` WRITE;
/*!40000 ALTER TABLE `ims_core_cache_copy` DISABLE KEYS */;
INSERT INTO `ims_core_cache_copy` VALUES ('account:ticket','s:0:\"\";'),('userbasefields','a:45:{s:7:\"uniacid\";s:17:\"同一公众号id\";s:7:\"groupid\";s:8:\"分组id\";s:7:\"credit1\";s:6:\"积分\";s:7:\"credit2\";s:6:\"余额\";s:7:\"credit3\";s:19:\"预留积分类型3\";s:7:\"credit4\";s:19:\"预留积分类型4\";s:7:\"credit5\";s:19:\"预留积分类型5\";s:7:\"credit6\";s:19:\"预留积分类型6\";s:10:\"createtime\";s:12:\"加入时间\";s:6:\"mobile\";s:12:\"手机号码\";s:5:\"email\";s:12:\"电子邮箱\";s:8:\"realname\";s:12:\"真实姓名\";s:8:\"nickname\";s:6:\"昵称\";s:6:\"avatar\";s:6:\"头像\";s:2:\"qq\";s:5:\"QQ号\";s:6:\"gender\";s:6:\"性别\";s:5:\"birth\";s:6:\"生日\";s:13:\"constellation\";s:6:\"星座\";s:6:\"zodiac\";s:6:\"生肖\";s:9:\"telephone\";s:12:\"固定电话\";s:6:\"idcard\";s:12:\"证件号码\";s:9:\"studentid\";s:6:\"学号\";s:5:\"grade\";s:6:\"班级\";s:7:\"address\";s:6:\"地址\";s:7:\"zipcode\";s:6:\"邮编\";s:11:\"nationality\";s:6:\"国籍\";s:6:\"reside\";s:9:\"居住地\";s:14:\"graduateschool\";s:12:\"毕业学校\";s:7:\"company\";s:6:\"公司\";s:9:\"education\";s:6:\"学历\";s:10:\"occupation\";s:6:\"职业\";s:8:\"position\";s:6:\"职位\";s:7:\"revenue\";s:9:\"年收入\";s:15:\"affectivestatus\";s:12:\"情感状态\";s:10:\"lookingfor\";s:13:\" 交友目的\";s:9:\"bloodtype\";s:6:\"血型\";s:6:\"height\";s:6:\"身高\";s:6:\"weight\";s:6:\"体重\";s:6:\"alipay\";s:15:\"支付宝帐号\";s:3:\"msn\";s:3:\"MSN\";s:6:\"taobao\";s:12:\"阿里旺旺\";s:4:\"site\";s:6:\"主页\";s:3:\"bio\";s:12:\"自我介绍\";s:8:\"interest\";s:12:\"兴趣爱好\";s:8:\"password\";s:6:\"密码\";}'),('usersfields','a:46:{s:8:\"realname\";s:12:\"真实姓名\";s:8:\"nickname\";s:6:\"昵称\";s:6:\"avatar\";s:6:\"头像\";s:2:\"qq\";s:5:\"QQ号\";s:6:\"mobile\";s:12:\"手机号码\";s:3:\"vip\";s:9:\"VIP级别\";s:6:\"gender\";s:6:\"性别\";s:9:\"birthyear\";s:12:\"出生生日\";s:13:\"constellation\";s:6:\"星座\";s:6:\"zodiac\";s:6:\"生肖\";s:9:\"telephone\";s:12:\"固定电话\";s:6:\"idcard\";s:12:\"证件号码\";s:9:\"studentid\";s:6:\"学号\";s:5:\"grade\";s:6:\"班级\";s:7:\"address\";s:12:\"邮寄地址\";s:7:\"zipcode\";s:6:\"邮编\";s:11:\"nationality\";s:6:\"国籍\";s:14:\"resideprovince\";s:12:\"居住地址\";s:14:\"graduateschool\";s:12:\"毕业学校\";s:7:\"company\";s:6:\"公司\";s:9:\"education\";s:6:\"学历\";s:10:\"occupation\";s:6:\"职业\";s:8:\"position\";s:6:\"职位\";s:7:\"revenue\";s:9:\"年收入\";s:15:\"affectivestatus\";s:12:\"情感状态\";s:10:\"lookingfor\";s:13:\" 交友目的\";s:9:\"bloodtype\";s:6:\"血型\";s:6:\"height\";s:6:\"身高\";s:6:\"weight\";s:6:\"体重\";s:6:\"alipay\";s:15:\"支付宝帐号\";s:3:\"msn\";s:3:\"MSN\";s:5:\"email\";s:12:\"电子邮箱\";s:6:\"taobao\";s:12:\"阿里旺旺\";s:4:\"site\";s:6:\"主页\";s:3:\"bio\";s:12:\"自我介绍\";s:8:\"interest\";s:12:\"兴趣爱好\";s:7:\"uniacid\";s:17:\"同一公众号id\";s:7:\"groupid\";s:8:\"分组id\";s:7:\"credit1\";s:6:\"积分\";s:7:\"credit2\";s:6:\"余额\";s:7:\"credit3\";s:19:\"预留积分类型3\";s:7:\"credit4\";s:19:\"预留积分类型4\";s:7:\"credit5\";s:19:\"预留积分类型5\";s:7:\"credit6\";s:19:\"预留积分类型6\";s:10:\"createtime\";s:12:\"加入时间\";s:8:\"password\";s:12:\"用户密码\";}'),('setting','a:10:{s:9:\"copyright\";a:28:{s:6:\"status\";s:1:\"0\";s:10:\"verifycode\";s:1:\"0\";s:6:\"reason\";s:0:\"\";s:8:\"sitename\";s:0:\"\";s:3:\"url\";s:7:\"http://\";s:8:\"statcode\";s:0:\"\";s:10:\"footerleft\";s:0:\"\";s:11:\"footerright\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"flogo1\";N;s:6:\"flogo2\";N;s:6:\"slides\";s:216:\"a:3:{i:0;s:58:\"https://img.alicdn.com/tps/TB1pfG4IFXXXXc6XXXXXXXXXXXX.jpg\";i:1;s:58:\"https://img.alicdn.com/tps/TB1sXGYIFXXXXc5XpXXXXXXXXXX.jpg\";i:2;s:58:\"https://img.alicdn.com/tps/TB1h9xxIFXXXXbKXXXXXXXXXXXX.jpg\";}\";s:6:\"notice\";s:0:\"\";s:5:\"blogo\";s:0:\"\";s:6:\"qrcode\";N;s:8:\"baidumap\";a:2:{s:3:\"lng\";s:0:\"\";s:3:\"lat\";s:0:\"\";}s:7:\"company\";s:0:\"\";s:4:\"skin\";s:7:\"default\";s:14:\"companyprofile\";s:0:\"\";s:7:\"address\";s:0:\"\";s:6:\"person\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:2:\"qq\";s:0:\"\";s:5:\"email\";s:0:\"\";s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";s:12:\"showhomepage\";i:0;s:13:\"leftmenufixed\";i:0;}s:8:\"authmode\";i:1;s:5:\"close\";a:2:{s:6:\"status\";s:1:\"0\";s:6:\"reason\";s:0:\"\";}s:8:\"register\";a:4:{s:4:\"open\";i:1;s:6:\"verify\";i:0;s:4:\"code\";i:1;s:7:\"groupid\";i:1;}s:4:\"site\";a:5:{s:3:\"key\";s:6:\"888888\";s:5:\"token\";s:23:\"shop33453630.taobao.com\";s:3:\"url\";s:30:\"http://shop33453630.taobao.com\";s:7:\"version\";s:5:\"1.4.0\";s:15:\"profile_perfect\";i:1;}s:10:\"module_ban\";a:0:{}s:14:\"module_upgrade\";a:0:{}s:5:\"basic\";a:1:{s:8:\"template\";s:10:\"affordable\";}s:8:\"platform\";a:5:{s:5:\"token\";s:32:\"Q3gAV93Pe9t11lVi30eBgfAIrLK39r03\";s:14:\"encodingaeskey\";s:43:\"kf4TaD48eG4CSE38cUtA4Tc4sSdacE4cdADGGJs0SaF\";s:9:\"appsecret\";s:0:\"\";s:5:\"appid\";s:0:\"\";s:9:\"authstate\";i:1;}s:7:\"cloudip\";a:0:{}}'),('we7:all_cloud_upgrade_module:','a:2:{s:6:\"expire\";i:1504274978;s:4:\"data\";a:0:{}}'),('system_frame','a:4:{s:7:\"account\";a:5:{s:5:\"title\";s:9:\"公众号\";s:3:\"url\";s:29:\"./index.php?c=home&a=welcome&\";s:7:\"section\";a:5:{s:6:\"renren\";a:2:{s:5:\"title\";s:9:\"人人店\";s:4:\"menu\";a:1:{s:7:\"mc_fans\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"人人店\";s:3:\"url\";s:54:\"./index.php?c=site&a=entry&m=ewei_shopv2&do=web&r=shop\";s:15:\"permission_name\";s:7:\"mc_fans\";s:4:\"icon\";s:16:\"wi wi-fansmanage\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:15:\"platform_module\";a:3:{s:5:\"title\";s:12:\"应用模块\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}s:13:\"platform_plus\";a:2:{s:5:\"title\";s:12:\"增强功能\";s:4:\"menu\";a:6:{s:14:\"platform_reply\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"自动回复\";s:3:\"url\";s:31:\"./index.php?c=platform&a=reply&\";s:15:\"permission_name\";s:14:\"platform_reply\";s:4:\"icon\";s:11:\"wi wi-reply\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";a:3:{i:0;a:2:{s:5:\"title\";s:22:\"关键字自动回复 \";s:15:\"permission_name\";s:14:\"platform_reply\";}i:1;a:2:{s:5:\"title\";s:25:\"非关键字自动回复 \";s:15:\"permission_name\";s:22:\"platform_reply_special\";}i:2;a:2:{s:5:\"title\";s:19:\"欢迎/默认回复\";s:15:\"permission_name\";s:21:\"platform_reply_system\";}}}s:13:\"platform_menu\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"自定义菜单\";s:3:\"url\";s:30:\"./index.php?c=platform&a=menu&\";s:15:\"permission_name\";s:13:\"platform_menu\";s:4:\"icon\";s:16:\"wi wi-custommenu\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:11:\"platform_qr\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:22:\"二维码/转化链接\";s:3:\"url\";s:28:\"./index.php?c=platform&a=qr&\";s:15:\"permission_name\";s:11:\"platform_qr\";s:4:\"icon\";s:12:\"wi wi-qrcode\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{i:0;a:2:{s:5:\"title\";s:9:\"二维码\";s:15:\"permission_name\";s:11:\"platform_qr\";}i:1;a:2:{s:5:\"title\";s:12:\"转化链接\";s:15:\"permission_name\";s:15:\"platform_url2qr\";}}}s:18:\"platform_mass_task\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"定时群发\";s:3:\"url\";s:30:\"./index.php?c=platform&a=mass&\";s:15:\"permission_name\";s:18:\"platform_mass_task\";s:4:\"icon\";s:13:\"wi wi-crontab\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:17:\"platform_material\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:16:\"素材/编辑器\";s:3:\"url\";s:34:\"./index.php?c=platform&a=material&\";s:15:\"permission_name\";s:17:\"platform_material\";s:4:\"icon\";s:12:\"wi wi-redact\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:13:\"platform_site\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:16:\"微官网-文章\";s:3:\"url\";s:38:\"./index.php?c=site&a=multi&do=display&\";s:15:\"permission_name\";s:13:\"platform_site\";s:4:\"icon\";s:10:\"wi wi-home\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{i:0;a:2:{s:5:\"title\";s:13:\"添加/编辑\";s:15:\"permission_name\";s:18:\"platform_site_post\";}i:1;a:2:{s:5:\"title\";s:6:\"删除\";s:15:\"permission_name\";s:20:\"platform_site_delete\";}}}}}s:2:\"mc\";a:2:{s:5:\"title\";s:6:\"粉丝\";s:4:\"menu\";a:2:{s:7:\"mc_fans\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"粉丝管理\";s:3:\"url\";s:24:\"./index.php?c=mc&a=fans&\";s:15:\"permission_name\";s:7:\"mc_fans\";s:4:\"icon\";s:16:\"wi wi-fansmanage\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:9:\"mc_member\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"会员管理\";s:3:\"url\";s:26:\"./index.php?c=mc&a=member&\";s:15:\"permission_name\";s:9:\"mc_member\";s:4:\"icon\";s:10:\"wi wi-fans\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:7:\"profile\";a:2:{s:5:\"title\";s:6:\"配置\";s:4:\"menu\";a:1:{s:7:\"profile\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"参数配置\";s:3:\"url\";s:33:\"./index.php?c=profile&a=passport&\";s:15:\"permission_name\";s:15:\"profile_setting\";s:4:\"icon\";s:22:\"wi wi-parameter-stting\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;}s:5:\"wxapp\";a:5:{s:5:\"title\";s:9:\"小程序\";s:3:\"url\";s:38:\"./index.php?c=wxapp&a=display&do=home&\";s:7:\"section\";a:2:{s:12:\"wxapp_module\";a:3:{s:5:\"title\";s:6:\"应用\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}s:20:\"platform_manage_menu\";a:2:{s:5:\"title\";s:6:\"管理\";s:4:\"menu\";a:2:{s:11:\"module_link\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:21:\"模块关联公众号\";s:3:\"url\";s:53:\"./index.php?c=wxapp&a=version&do=module_link_uniacid&\";s:15:\"permission_name\";s:25:\"wxapp_module_link_uniacid\";s:4:\"icon\";s:16:\"wi wi-appsetting\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:13:\"wxapp_profile\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"支付参数\";s:3:\"url\";s:30:\"./index.php?c=wxapp&a=payment&\";s:15:\"permission_name\";s:13:\"wxapp_payment\";s:4:\"icon\";s:16:\"wi wi-appsetting\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;}s:6:\"system\";a:5:{s:5:\"title\";s:12:\"系统管理\";s:3:\"url\";s:45:\"./index.php?c=account&a=manage&account_type=1\";s:7:\"section\";a:6:{s:10:\"wxplatform\";a:2:{s:5:\"title\";s:9:\"公众号\";s:4:\"menu\";a:4:{s:14:\"system_account\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:16:\" 微信公众号\";s:3:\"url\";s:45:\"./index.php?c=account&a=manage&account_type=1\";s:15:\"permission_name\";s:14:\"system_account\";s:4:\"icon\";s:12:\"wi wi-wechat\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:6:{i:0;a:2:{s:5:\"title\";s:21:\"公众号管理设置\";s:15:\"permission_name\";s:21:\"system_account_manage\";}i:1;a:2:{s:5:\"title\";s:15:\"添加公众号\";s:15:\"permission_name\";s:19:\"system_account_post\";}i:2;a:2:{s:5:\"title\";s:15:\"公众号停用\";s:15:\"permission_name\";s:19:\"system_account_stop\";}i:3;a:2:{s:5:\"title\";s:18:\"公众号回收站\";s:15:\"permission_name\";s:22:\"system_account_recycle\";}i:4;a:2:{s:5:\"title\";s:15:\"公众号删除\";s:15:\"permission_name\";s:21:\"system_account_delete\";}i:5;a:2:{s:5:\"title\";s:15:\"公众号恢复\";s:15:\"permission_name\";s:22:\"system_account_recover\";}}}s:13:\"system_module\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"应用管理\";s:3:\"url\";s:44:\"./index.php?c=system&a=module&account_type=1\";s:15:\"permission_name\";s:13:\"system_module\";s:4:\"icon\";s:14:\"wi wi-wx-apply\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:15:\"system_template\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"微官网模板\";s:3:\"url\";s:32:\"./index.php?c=system&a=template&\";s:15:\"permission_name\";s:15:\"system_template\";s:4:\"icon\";s:17:\"wi wi-wx-template\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:15:\"system_platform\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:19:\" 微信开放平台\";s:3:\"url\";s:32:\"./index.php?c=system&a=platform&\";s:15:\"permission_name\";s:15:\"system_platform\";s:4:\"icon\";s:20:\"wi wi-exploitsetting\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:6:\"module\";a:2:{s:5:\"title\";s:9:\"小程序\";s:4:\"menu\";a:2:{s:12:\"system_wxapp\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"微信小程序\";s:3:\"url\";s:45:\"./index.php?c=account&a=manage&account_type=4\";s:15:\"permission_name\";s:12:\"system_wxapp\";s:4:\"icon\";s:11:\"wi wi-wxapp\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"system_module_wxapp\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"小程序应用\";s:3:\"url\";s:44:\"./index.php?c=system&a=module&account_type=4\";s:15:\"permission_name\";s:19:\"system_module_wxapp\";s:4:\"icon\";s:17:\"wi wi-wxapp-apply\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:4:\"user\";a:2:{s:5:\"title\";s:13:\"帐户/用户\";s:4:\"menu\";a:2:{s:9:\"system_my\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"我的帐户\";s:3:\"url\";s:29:\"./index.php?c=user&a=profile&\";s:15:\"permission_name\";s:9:\"system_my\";s:4:\"icon\";s:10:\"wi wi-user\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:11:\"system_user\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"用户管理\";s:3:\"url\";s:29:\"./index.php?c=user&a=display&\";s:15:\"permission_name\";s:11:\"system_user\";s:4:\"icon\";s:16:\"wi wi-user-group\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:6:{i:0;a:2:{s:5:\"title\";s:12:\"编辑用户\";s:15:\"permission_name\";s:16:\"system_user_post\";}i:1;a:2:{s:5:\"title\";s:12:\"审核用户\";s:15:\"permission_name\";s:17:\"system_user_check\";}i:2;a:2:{s:5:\"title\";s:15:\"用户回收站\";s:15:\"permission_name\";s:19:\"system_user_recycle\";}i:3;a:2:{s:5:\"title\";s:18:\"用户属性设置\";s:15:\"permission_name\";s:18:\"system_user_fields\";}i:4;a:2:{s:5:\"title\";s:31:\"用户属性设置-编辑字段\";s:15:\"permission_name\";s:23:\"system_user_fields_post\";}i:5;a:2:{s:5:\"title\";s:18:\"用户注册设置\";s:15:\"permission_name\";s:23:\"system_user_registerset\";}}}}}s:10:\"permission\";a:2:{s:5:\"title\";s:12:\"权限管理\";s:4:\"menu\";a:2:{s:19:\"system_module_group\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"应用权限组\";s:3:\"url\";s:36:\"./index.php?c=system&a=module-group&\";s:15:\"permission_name\";s:19:\"system_module_group\";s:4:\"icon\";s:21:\"wi wi-appjurisdiction\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:17:\"system_user_group\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"用户权限组\";s:3:\"url\";s:27:\"./index.php?c=user&a=group&\";s:15:\"permission_name\";s:17:\"system_user_group\";s:4:\"icon\";s:22:\"wi wi-userjurisdiction\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{i:0;a:2:{s:5:\"title\";s:15:\"编辑用户组\";s:15:\"permission_name\";s:22:\"system_user_group_post\";}i:1;a:2:{s:5:\"title\";s:15:\"删除用户组\";s:15:\"permission_name\";s:21:\"system_user_group_del\";}}}}}s:7:\"acticle\";a:2:{s:5:\"title\";s:13:\"文章/公告\";s:4:\"menu\";a:2:{s:14:\"system_article\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"文章管理\";s:3:\"url\";s:29:\"./index.php?c=article&a=news&\";s:15:\"permission_name\";s:19:\"system_article_news\";s:4:\"icon\";s:13:\"wi wi-article\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:21:\"system_article_notice\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"公告管理\";s:3:\"url\";s:31:\"./index.php?c=article&a=notice&\";s:15:\"permission_name\";s:21:\"system_article_notice\";s:4:\"icon\";s:12:\"wi wi-notice\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:5:\"cache\";a:2:{s:5:\"title\";s:6:\"缓存\";s:4:\"menu\";a:1:{s:26:\"system_setting_updatecache\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"更新缓存\";s:3:\"url\";s:35:\"./index.php?c=system&a=updatecache&\";s:15:\"permission_name\";s:26:\"system_setting_updatecache\";s:4:\"icon\";s:12:\"wi wi-update\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;}s:4:\"site\";a:6:{s:5:\"title\";s:12:\"站点管理\";s:3:\"url\";s:30:\"./index.php?c=cloud&a=upgrade&\";s:7:\"section\";a:2:{s:7:\"setting\";a:2:{s:5:\"title\";s:6:\"设置\";s:4:\"menu\";a:5:{s:19:\"system_setting_site\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"站点设置\";s:3:\"url\";s:28:\"./index.php?c=system&a=site&\";s:15:\"permission_name\";s:19:\"system_setting_site\";s:4:\"icon\";s:18:\"wi wi-site-setting\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"system_setting_menu\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"菜单设置\";s:3:\"url\";s:28:\"./index.php?c=system&a=menu&\";s:15:\"permission_name\";s:19:\"system_setting_menu\";s:4:\"icon\";s:18:\"wi wi-menu-setting\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"system_setting_attachment\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"附件设置\";s:3:\"url\";s:34:\"./index.php?c=system&a=attachment&\";s:15:\"permission_name\";s:25:\"system_setting_attachment\";s:4:\"icon\";s:16:\"wi wi-attachment\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"system_setting_systeminfo\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"系统信息\";s:3:\"url\";s:34:\"./index.php?c=system&a=systeminfo&\";s:15:\"permission_name\";s:25:\"system_setting_systeminfo\";s:4:\"icon\";s:17:\"wi wi-system-info\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"system_setting_logs\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"查看日志\";s:3:\"url\";s:28:\"./index.php?c=system&a=logs&\";s:15:\"permission_name\";s:19:\"system_setting_logs\";s:4:\"icon\";s:9:\"wi wi-log\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:7:\"utility\";a:2:{s:5:\"title\";s:12:\"常用工具\";s:4:\"menu\";a:1:{s:23:\"system_utility_database\";a:9:{s:9:\"is_system\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"数据库\";s:3:\"url\";s:32:\"./index.php?c=system&a=database&\";s:15:\"permission_name\";s:23:\"system_utility_database\";s:4:\"icon\";s:9:\"wi wi-sql\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:7:\"founder\";b:1;s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;}}'),('module_receive_enable','a:13:{s:5:\"image\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:5:\"voice\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:5:\"video\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:10:\"shortvideo\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:8:\"location\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:4:\"link\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:9:\"subscribe\";a:2:{i:0;s:11:\"ewei_shopv2\";i:1;s:6:\"bm_top\";}s:11:\"unsubscribe\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:2:\"qr\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:5:\"trace\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:5:\"click\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:4:\"view\";a:1:{i:0;s:11:\"ewei_shopv2\";}s:14:\"merchant_order\";a:1:{i:0;s:11:\"ewei_shopv2\";}}'),('uniaccount:6','a:30:{s:4:\"acid\";s:1:\"6\";s:7:\"uniacid\";s:1:\"6\";s:5:\"token\";s:32:\"s74F6bfPt6mBBblFtPBppUfp2t7PoB2p\";s:14:\"encodingaeskey\";s:43:\"UQJJzC96Iiga6XSQRS8DFRAxQ63I9JagG6FaaccxJaG\";s:5:\"level\";s:1:\"4\";s:4:\"name\";s:5:\"adjyc\";s:7:\"account\";s:5:\"adjyc\";s:8:\"original\";s:15:\"gh_dca636eab4ce\";s:9:\"signature\";s:0:\"\";s:7:\"country\";s:0:\"\";s:8:\"province\";s:0:\"\";s:4:\"city\";s:0:\"\";s:8:\"username\";s:0:\"\";s:8:\"password\";s:0:\"\";s:10:\"lastupdate\";s:1:\"0\";s:3:\"key\";s:18:\"wxb797d06f10b3f641\";s:6:\"secret\";s:32:\"ab235bf8be745b7d2c268ed8723020e2\";s:7:\"styleid\";s:1:\"0\";s:12:\"subscribeurl\";s:0:\"\";s:18:\"auth_refresh_token\";s:0:\"\";s:4:\"type\";s:1:\"1\";s:9:\"isconnect\";s:1:\"1\";s:9:\"isdeleted\";s:1:\"0\";s:3:\"uid\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:6:\"groups\";a:1:{i:6;a:5:{s:7:\"groupid\";s:1:\"6\";s:7:\"uniacid\";s:1:\"6\";s:5:\"title\";s:15:\"默认会员组\";s:6:\"credit\";s:1:\"0\";s:9:\"isdefault\";s:1:\"1\";}}s:10:\"grouplevel\";s:1:\"0\";s:4:\"logo\";s:60:\"http://wx.adjyc.com/attachment/headimg_6.jpg?time=1504273182\";s:6:\"qrcode\";s:59:\"http://wx.adjyc.com/attachment/qrcode_6.jpg?time=1504273182\";}'),('unisetting:6','a:22:{s:7:\"uniacid\";s:1:\"6\";s:8:\"passport\";s:0:\"\";s:5:\"oauth\";a:2:{s:4:\"host\";s:0:\"\";s:7:\"account\";s:1:\"6\";}s:11:\"jsauth_acid\";s:1:\"0\";s:2:\"uc\";s:0:\"\";s:6:\"notify\";s:0:\"\";s:11:\"creditnames\";a:2:{s:7:\"credit1\";a:2:{s:5:\"title\";s:6:\"积分\";s:7:\"enabled\";i:1;}s:7:\"credit2\";a:2:{s:5:\"title\";s:6:\"余额\";s:7:\"enabled\";i:1;}}s:15:\"creditbehaviors\";a:2:{s:8:\"activity\";s:7:\"credit1\";s:8:\"currency\";s:7:\"credit2\";}s:7:\"welcome\";s:0:\"\";s:7:\"default\";s:0:\"\";s:15:\"default_message\";s:0:\"\";s:7:\"payment\";a:4:{s:8:\"delivery\";a:1:{s:6:\"switch\";b:1;}s:6:\"credit\";a:1:{s:6:\"switch\";b:0;}s:6:\"wechat\";a:6:{s:6:\"switch\";s:1:\"1\";s:7:\"version\";s:1:\"2\";s:5:\"mchid\";s:10:\"1485461622\";s:6:\"apikey\";s:32:\"ab235bf8be745b7d2c268ed8723020e2\";s:7:\"account\";s:1:\"6\";s:7:\"signkey\";s:32:\"ab235bf8be745b7d2c268ed8723020e2\";}s:6:\"alipay\";a:4:{s:7:\"account\";s:6:\"666666\";s:7:\"partner\";s:8:\"88888888\";s:6:\"secret\";s:9:\"88e6dghgf\";s:6:\"switch\";b:0;}}s:4:\"stat\";s:0:\"\";s:12:\"default_site\";s:1:\"6\";s:4:\"sync\";s:1:\"1\";s:8:\"recharge\";s:0:\"\";s:9:\"tplnotice\";s:0:\"\";s:10:\"grouplevel\";s:1:\"0\";s:8:\"mcplugin\";s:0:\"\";s:15:\"exchange_enable\";s:1:\"0\";s:11:\"coupon_type\";s:1:\"0\";s:7:\"menuset\";s:0:\"\";}'),('accesstoken:6','a:2:{s:5:\"token\";s:117:\"ruovnui4NpTU5nyR2eN-LmKXiY3SNYOUVujBIbqqKyMT6SuKDu9TCvu9xSy1x_o9lKwJhdy-WykCW8P9arkcV0k5Tovj8jGyYT2ebzM0oVQIGGeACAWUU\";s:6:\"expire\";i:1504280204;}');
/*!40000 ALTER TABLE `ims_core_cache_copy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_core_cron`
--

DROP TABLE IF EXISTS `ims_core_cron`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_core_cron` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cloudid` int(10) unsigned NOT NULL,
  `module` varchar(50) NOT NULL,
  `uniacid` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `filename` varchar(50) NOT NULL,
  `lastruntime` int(10) unsigned NOT NULL,
  `nextruntime` int(10) unsigned NOT NULL,
  `weekday` tinyint(3) NOT NULL,
  `day` tinyint(3) NOT NULL,
  `hour` tinyint(3) NOT NULL,
  `minute` varchar(255) NOT NULL,
  `extra` varchar(5000) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `createtime` (`createtime`),
  KEY `nextruntime` (`nextruntime`),
  KEY `uniacid` (`uniacid`),
  KEY `cloudid` (`cloudid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_core_cron`
--

LOCK TABLES `ims_core_cron` WRITE;
/*!40000 ALTER TABLE `ims_core_cron` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_core_cron` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_core_cron_record`
--

DROP TABLE IF EXISTS `ims_core_cron_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_core_cron_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `module` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `tid` int(10) unsigned NOT NULL,
  `note` varchar(500) NOT NULL,
  `tag` varchar(5000) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `tid` (`tid`),
  KEY `module` (`module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_core_cron_record`
--

LOCK TABLES `ims_core_cron_record` WRITE;
/*!40000 ALTER TABLE `ims_core_cron_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_core_cron_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_core_menu`
--

DROP TABLE IF EXISTS `ims_core_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_core_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL,
  `title` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `url` varchar(255) NOT NULL,
  `append_title` varchar(30) NOT NULL,
  `append_url` varchar(255) NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  `type` varchar(15) NOT NULL,
  `is_display` tinyint(3) unsigned NOT NULL,
  `is_system` tinyint(3) unsigned NOT NULL,
  `permission_name` varchar(50) NOT NULL,
  `group_name` varchar(30) NOT NULL,
  `icon` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_core_menu`
--

LOCK TABLES `ims_core_menu` WRITE;
/*!40000 ALTER TABLE `ims_core_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_core_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_core_paylog`
--

DROP TABLE IF EXISTS `ims_core_paylog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_core_paylog` (
  `plid` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `acid` int(10) NOT NULL,
  `openid` varchar(40) NOT NULL,
  `uniontid` varchar(64) NOT NULL,
  `tid` varchar(128) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `module` varchar(50) NOT NULL,
  `tag` varchar(2000) NOT NULL,
  `is_usecard` tinyint(3) unsigned NOT NULL,
  `card_type` tinyint(3) unsigned NOT NULL,
  `card_id` varchar(50) NOT NULL,
  `card_fee` decimal(10,2) unsigned NOT NULL,
  `encrypt_code` varchar(100) NOT NULL,
  PRIMARY KEY (`plid`),
  KEY `idx_openid` (`openid`),
  KEY `idx_tid` (`tid`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `uniontid` (`uniontid`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_core_paylog`
--

LOCK TABLES `ims_core_paylog` WRITE;
/*!40000 ALTER TABLE `ims_core_paylog` DISABLE KEYS */;
INSERT INTO `ims_core_paylog` VALUES (5,'',6,0,'1','','SH20170831124433986260','3579.00',0,'ewei_shopv2','',0,0,'','0.00',''),(7,'',6,0,'1','','SH20170831193048721249','3579.00',0,'ewei_shopv2','',0,0,'','0.00',''),(9,'',6,0,'1','','SH20170831193134060256','3579.00',0,'ewei_shopv2','',0,0,'','0.00',''),(11,'',6,0,'1','','SH20170901202942011838','3579.00',0,'ewei_shopv2','',0,0,'','0.00',''),(12,'',6,0,'1','','SH20170901203229727825','3579.00',0,'ewei_shopv2','',0,0,'','0.00',''),(13,'',6,0,'1','','SH20170901203229727825','3579.00',0,'ewei_shopv2','',0,0,'','0.00',''),(15,'',6,0,'0','','SH20170901211719862658','3579.00',0,'ewei_shopv2','',0,0,'','0.00',''),(17,'',6,0,'1','','SH20170902114913414004','137.00',0,'ewei_shopv2','',0,0,'','0.00',''),(19,'',6,0,'1','','SH20170902120029923499','0.01',1,'ewei_shopv2','a:1:{s:14:\"transaction_id\";s:28:\"4006922001201709029703568321\";}',0,0,'','0.00',''),(21,'',6,0,'0','','SH20170902151753676864','0.01',0,'ewei_shopv2','',0,0,'','0.00',''),(23,'',6,0,'0','','SH20170902151854828237','0.01',1,'ewei_shopv2','a:1:{s:14:\"transaction_id\";s:28:\"4005002001201709029741979144\";}',0,0,'','0.00',''),(25,'',6,0,'1','','SH20170902152431473627','0.01',0,'ewei_shopv2','',0,0,'','0.00',''),(26,'',6,0,'1','','SH20170902152501168947','1079.00',0,'ewei_shopv2','',0,0,'','0.00',''),(47,'',6,0,'1','','SH20170902154037810162','0.01',0,'ewei_shopv2','',0,0,'','0.00',''),(34,'',6,0,'0','','SH20170902161023144224','0.01',0,'ewei_shopv2','',0,0,'','0.00',''),(36,'',6,0,'1','','SH20170903091927868054','0.01',0,'ewei_shopv2','',0,0,'','0.00',''),(38,'',6,0,'1','','SH20170903092852014204','0.01',0,'ewei_shopv2','',0,0,'','0.00',''),(41,'cash',6,0,'1','','SH20170903093253617402','0.01',1,'ewei_shopv2','',0,0,'','0.00',''),(43,'',6,0,'2','','SH20170903120755615843','7178.00',0,'ewei_shopv2','',0,0,'','0.00',''),(45,'',6,0,'1','','SH20170902154037810162','0.01',0,'ewei_shopv2','',0,0,'','0.00',''),(49,'cash',6,0,'2','','SH20170903163902499845','455.00',1,'ewei_shopv2','',0,0,'','0.00',''),(51,'cash',6,0,'1','','SH20170904124554822621','244.00',1,'ewei_shopv2','',0,0,'','0.00',''),(53,'cash',6,0,'1','','SH20170904125049787377','10777.00',1,'ewei_shopv2','',0,0,'','0.00','');
/*!40000 ALTER TABLE `ims_core_paylog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_core_performance`
--

DROP TABLE IF EXISTS `ims_core_performance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_core_performance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL,
  `runtime` varchar(10) NOT NULL,
  `runurl` varchar(512) NOT NULL,
  `runsql` varchar(512) NOT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_core_performance`
--

LOCK TABLES `ims_core_performance` WRITE;
/*!40000 ALTER TABLE `ims_core_performance` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_core_performance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_core_queue`
--

DROP TABLE IF EXISTS `ims_core_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_core_queue` (
  `qid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `message` varchar(2000) NOT NULL,
  `params` varchar(1000) NOT NULL,
  `keyword` varchar(1000) NOT NULL,
  `response` varchar(2000) NOT NULL,
  `module` varchar(50) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `dateline` int(10) unsigned NOT NULL,
  PRIMARY KEY (`qid`),
  KEY `uniacid` (`uniacid`,`acid`),
  KEY `module` (`module`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_core_queue`
--

LOCK TABLES `ims_core_queue` WRITE;
/*!40000 ALTER TABLE `ims_core_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_core_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_core_resource`
--

DROP TABLE IF EXISTS `ims_core_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_core_resource` (
  `mid` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `media_id` varchar(100) NOT NULL,
  `trunk` int(10) unsigned NOT NULL,
  `type` varchar(10) NOT NULL,
  `dateline` int(10) unsigned NOT NULL,
  PRIMARY KEY (`mid`),
  KEY `acid` (`uniacid`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_core_resource`
--

LOCK TABLES `ims_core_resource` WRITE;
/*!40000 ALTER TABLE `ims_core_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_core_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_core_sendsms_log`
--

DROP TABLE IF EXISTS `ims_core_sendsms_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_core_sendsms_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `content` varchar(255) NOT NULL,
  `result` varchar(255) NOT NULL,
  `createtime` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_core_sendsms_log`
--

LOCK TABLES `ims_core_sendsms_log` WRITE;
/*!40000 ALTER TABLE `ims_core_sendsms_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_core_sendsms_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_core_sessions`
--

DROP TABLE IF EXISTS `ims_core_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_core_sessions` (
  `sid` char(32) NOT NULL,
  `uniacid` int(10) unsigned NOT NULL,
  `openid` varchar(50) NOT NULL,
  `data` varchar(5000) NOT NULL,
  `expiretime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_core_sessions`
--

LOCK TABLES `ims_core_sessions` WRITE;
/*!40000 ALTER TABLE `ims_core_sessions` DISABLE KEYS */;
INSERT INTO `ims_core_sessions` VALUES ('8f61591dec9bbc1cfd2d29397c5908de',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"Zgeg\";i:1504154231;}dest_url|s:121:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods%26cate%3D1180\";',1504157831),('17c4e524f0666de3b8bbe14818b76711',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"Y9s9\";i:1504428063;}dest_url|s:146:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay.success%26id%3D184%26result%3Dtrue\";',1504431663),('b0c17f6d1c69c8d84f5959b40cbb6fe5',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"x0cj\";i:1504411473;}dest_url|s:118:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26from%3Dsinglemessage\";',1504415073),('06589e2d242ae5c782d0d93791b20a42',6,'oZo4hw8Wt565YLamn2TJqGExQirA','openid|s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";',1504620354),('02f41ac94b14cb8d21695f4f5d088eb8',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"gl2F\";i:1504172600;}dest_url|s:113:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dsale.coupon\";',1504176200),('74733105f2a050822b2bbb83ec675189',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"ZBeX\";i:1504442261;}dest_url|s:107:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods\";',1504445861),('c5de2d8964f522a2b2bed746f34459a3',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"GnQa\";i:1504179058;}dest_url|s:122:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay%26id%3D158\";',1504182658),('efc4aa81ee06572ea7336b28df3b7c39',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"YuUG\";i:1504179105;}dest_url|s:122:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay%26id%3D159\";',1504182705),('1e3e112d6c7d816b3dca12f9f37e2817',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"u7t6\";i:1504179110;}dest_url|s:174:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.create%26id%3D199%26optionid%3D0%26total%3D1%26giftid%26liveid%3D0\";',1504182710),('e8d20e1b748758451c8ca839fef8199b',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"IDww\";i:1504180105;}dest_url|s:73:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26eid%3D1\";',1504183705),('8c0aa9e2bc6f8fe26fdcffc12ef3227a',6,'127.0.0.1','acid|s:1:\"6\";uniacid|i:6;token|a:3:{s:4:\"F21F\";i:1504179929;s:4:\"RpbM\";i:1504180087;s:4:\"ZhhO\";i:1504180218;}newstoreid|i:0;',1504183818),('df39fdd406b8a2f96db9487dffc83dfe',6,'101.226.66.172','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"pZjS\";i:1504154675;}dest_url|s:108:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember\";',1504158275),('f12dba31f2bc7eced16ec876e5a6088f',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"y9PU\";i:1504154637;}dest_url|s:121:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.address.post\";',1504158237),('8f176230938210f97786b00a3c8beac3',6,'218.6.78.20','acid|s:1:\"6\";uniacid|i:6;token|a:3:{s:4:\"Z0ke\";i:1504180776;s:4:\"lP1G\";i:1504180776;s:4:\"P0XH\";i:1504180779;}dest_url|s:122:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay%26id%3D159\";oauth_openid|s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";uid|s:1:\"1\";userinfo|s:844:\"YToxNDp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib1pvNGh3OFd0NTY1WUxhbW4yVEpxR0V4UWlyQSI7czo4OiJuaWNrbmFtZSI7czo2OiLooZflopkiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuWOpumXqCI7czo4OiJwcm92aW5jZSI7czo2OiLnpo/lu7oiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTI3OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL0hJbVRyOVk1YkpYT1E0TWVwdmtIMzBYR2lhODZLTFdDdU1oN3RJZW9QMUVGZUNVRmxIQW5GbmRQZUxrZzlnTmtUQVA1cExjdlJhbTBUVHhnb2Jyc1FKd2xURG5MY0NEd00vMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNDk5NzkwNjIxO3M6NjoicmVtYXJrIjtzOjA6IiI7czo3OiJncm91cGlkIjtpOjI7czoxMDoidGFnaWRfbGlzdCI7YToxOntpOjA7aToyO31zOjY6ImF2YXRhciI7czoxMjc6Imh0dHA6Ly93eC5xbG9nby5jbi9tbW9wZW4vSEltVHI5WTViSlhPUTRNZXB2a0gzMFhHaWE4NktMV0N1TWg3dEllb1AxRUZlQ1VGbEhBbkZuZFBlTGtnOWdOa1RBUDVwTGN2UmFtMFRUeGdvYnJzUUp3bFREbkxjQ0R3TS8xMzIiO30=\";newstoreid|i:0;',1504184379),('6315c39b0068492e325cc2871f3318b4',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"NqPc\";i:1504179092;}dest_url|s:146:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay.success%26id%3D158%26result%3Dtrue\";',1504182692),('4aec05cd7d3bb098f5ac2664e7dc07b2',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"Tfpn\";i:1504154855;}dest_url|s:146:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay.success%26id%3D157%26result%3Dtrue\";',1504158455),('23994fd468db9a0053a7906cc257145a',6,'101.226.33.223','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"bDpD\";i:1504155135;}dest_url|s:121:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.address.post\";',1504158735),('04929fc987cf75e64f38b9a1e794ad7c',6,'223.104.3.201','acid|s:1:\"6\";uniacid|i:6;token|a:6:{s:4:\"Z13S\";i:1504164639;s:4:\"jAAG\";i:1504164640;s:4:\"VnnN\";i:1504164643;s:4:\"z77p\";i:1504164643;s:4:\"H8l2\";i:1504164645;s:4:\"JXow\";i:1504164646;}dest_url|s:144:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26from%3Dgroupmessage%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oZo4hw7Rho-Val4FIVX5oKc2OTUI\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw7Rho-Val4FIVX5oKc2OTUI\";userinfo|s:692:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im9abzRodzdSaG8tVmFsNEZJVlg1b0tjMk9UVUkiO3M6ODoibmlja25hbWUiO3M6Njoi5Yav6aKWIjtzOjM6InNleCI7aToyO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czowOiIiO3M6ODoicHJvdmluY2UiO3M6Njoi5YyX5LqsIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyNToiaHR0cDovL3d4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUTDJZOVBVYmljWmNUOUk4Qjl2RHNOWkd4c0hDT3RpY1hiWUpoZEd1dlo3VFBWT2V3RnpiYWZuOVBSaWExNUlBMnFrZHEzMExxSnRxR2pPUS8xMzIiO3M6OToicHJpdmlsZWdlIjthOjA6e31zOjY6ImF2YXRhciI7czoxMjU6Imh0dHA6Ly93eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvUTBqNFR3R1RmVEwyWTlQVWJpY1pjVDlJOEI5dkRzTlpHeHNIQ090aWNYYllKaGRHdXZaN1RQVk9ld0Z6YmFmbjlQUmlhMTVJQTJxa2RxMzBMcUp0cUdqT1EvMTMyIjt9\";uid|s:1:\"3\";newstoreid|i:0;',1504168246),('1e56db04875380557cf1f8d38d8f4fe1',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"lIiS\";i:1504164655;}dest_url|s:108:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember\";',1504168255),('a0a5ad4facd9a57998eebe89e28284e7',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"S8F5\";i:1504164865;}',1504168465),('147c065f313db54cf6df3d2524a76af9',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"IVZS\";i:1504165208;}dest_url|s:115:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dshop.category\";',1504168808),('a54e3d1180378970f79b0d0db168d79a',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"J1Iz\";i:1504172618;}dest_url|s:125:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods.detail%26id%3D199\";',1504176218),('7c72010dc1c26824a77681bb1f1c31b8',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"xPVH\";i:1504172850;}dest_url|s:113:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dverifygoods\";',1504176450),('11847509de2714bb12eac12e45f25c27',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"zRrV\";i:1504172854;}dest_url|s:117:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.favorite\";',1504176454),('88b74ef94dc146503407345f48eb733f',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"zenR\";i:1504172872;}dest_url|s:116:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.history\";',1504176472),('adcfde061c13e771cef16b7b7d0f8cc7',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"PlNK\";i:1504172928;}dest_url|s:120:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder%26status%3D4\";',1504176528),('8c6194acd8ebbd6d368acfef26767c8f',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"ngZs\";i:1504173001;}dest_url|s:117:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.fullback\";',1504176601),('a958a6854477ed695130071e1e51d2b2',6,'101.226.125.100','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"YEtl\";i:1504173099;}dest_url|s:121:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.address.post\";',1504176699),('06bfeb97a430bdf7af9882b90a34ad0b',6,'101.226.125.104','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"Oe93\";i:1504173455;}dest_url|s:117:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.fullback\";',1504177055),('cd712a8716231c2cb59819db47c7a524',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"FM2p\";i:1504173517;}dest_url|s:112:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.log\";',1504177117),('087f5a300fe9dcb3ee7d9fe141225919',0,'218.6.78.20','acid|N;uniacid|i:0;token|a:2:{s:4:\"RZZs\";i:1504180097;s:4:\"j886\";i:1504180099;}',1504183699),('8ed2ea63c1b2b7440508f3a9febbfc4b',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"xBpw\";i:1504180098;}dest_url|s:65:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dhome%26\";',1504183698),('6bac82b80ea5fb6d6e8bb6fd0309e664',0,'117.185.27.115','acid|N;uniacid|i:0;token|a:1:{s:4:\"fSEj\";i:1504180107;}',1504183707),('bd38eeaeb84a88365bd0a03138a779fa',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"M95l\";i:1504269156;}dest_url|s:114:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.create\";',1504272756),('ae6b4ea81f1a0a68f34167a18dbec54b',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"O8sT\";i:1504269159;}dest_url|s:122:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay%26id%3D161\";',1504272759),('7e4417790f2e022d7b71d727aa78c195',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"NZjr\";i:1504269190;}dest_url|s:174:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.create%26id%3D199%26optionid%3D0%26total%3D1%26giftid%26liveid%3D0\";',1504272790),('54bca7ca3e88ec475947b7df6234c1e2',6,'101.226.33.201','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"hamq\";i:1504269628;}dest_url|s:125:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.detail%26id%3D157\";',1504273228),('ee64e83e5d54837d608011dd4de4c381',6,'101.226.33.226','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"G4Zh\";i:1504269682;}dest_url|s:95:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile\";',1504273282),('18f5234981b84506b27a9e9e69e1a4c0',6,'218.6.78.20','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"RGT2\";i:1504241806;}',1504245406),('84e46565bd590b9da85c1ac7a3c06133',0,'117.185.27.113','acid|N;uniacid|i:0;token|a:1:{s:4:\"a7Ju\";i:1504241819;}',1504245419),('4b4e7cc3ef30f601b539b8021211e3f9',6,'127.0.0.1','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"QVco\";i:1504241837;}',1504245437),('2e13c44930cdbf3bb1b81eb15c4c2ca0',6,'127.0.0.1','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"GJdd\";i:1504257760;}prom|a:6:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"199\";}',1504261360),('f07b71a99029f949f24cca7eb83dd5fc',6,'127.0.0.1','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"k70C\";i:1504258830;}prom|a:6:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"199\";}',1504262430),('a2a374c9762d78e44fac95545ce9dc06',6,'127.0.0.1','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"ZkaA\";i:1504258973;}prom|a:6:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"199\";}',1504262573),('06031cb632e4f094d6f163c1e1901f44',6,'127.0.0.1','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"WTpO\";i:1504259586;}prom|a:6:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"199\";}',1504263186),('51854a81912102adfd73add421d1d310',6,'127.0.0.1','acid|s:1:\"6\";uniacid|i:6;token|a:2:{s:4:\"g06g\";i:1504259811;s:4:\"sgoo\";i:1504259841;}',1504263441),('ba26c88d1faf7cf0c7b63648ccf06195',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"ye2L\";i:1504271867;}dest_url|s:125:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.detail%26id%3D162\";',1504275467),('fd45dd2d9308ea52b329202ccbefc267',6,'120.41.220.107','acid|s:1:\"6\";uniacid|i:6;token|a:3:{s:4:\"XxaT\";i:1504271915;s:4:\"p0rE\";i:1504271918;s:4:\"ouNr\";i:1504271923;}newstoreid|i:0;',1504275523),('6ae88a8391150d464173f677ee8657ff',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"Khbj\";i:1504442408;}dest_url|s:117:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.fullback\";',1504446008),('efa1d82a1a1c5a58087ee106a04de10f',6,'59.56.69.152','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"cY1v\";i:1504322509;}',1504326109),('f233439c1d36a31e4c07a0b92ceabddc',6,'59.56.69.152','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"NC6n\";i:1504322530;}',1504326130),('ba235a397b9afd4f4000bdd38916ea99',6,'59.56.69.152','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"to1a\";i:1504322547;}',1504326147),('1078a2cb544240bea808fee787f47d0a',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"P7Nh\";i:1504324874;}dest_url|s:125:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.refund%26id%3D164\";',1504328474),('ef749f2d91db0e6887f6d5e053fe0698',6,'112.65.193.14','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"Qkot\";i:1504324928;}dest_url|s:121:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods%26cate%3D1184\";',1504328528),('09e5ed6fb99e98818477e1fd22c890bb',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"aaBt\";i:1504268391;}',1504271991),('131fff00795bbe28d5b5e7df76ef70dd',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"J686\";i:1504268993;}dest_url|s:122:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay%26id%3D160\";',1504272593),('902426678eb03289a9fd590d4361f63a',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"y481\";i:1504268995;}dest_url|s:122:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay%26id%3D160\";',1504272595),('bf787bf481c10c7586b19ca1c7150257',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"AxYw\";i:1504269119;}dest_url|s:125:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.detail%26id%3D157\";',1504272719),('23f5b8ebe8c5174b304bd369908c8d92',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"Udpx\";i:1504404374;}dest_url|s:125:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.detail%26id%3D182\";',1504407974),('7b4ebb3a6f43dd9d5894addd14dcbd08',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"nmtO\";i:1504404393;}dest_url|s:112:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.log\";',1504407993),('a93e57b2e860a47e6237275a374eb9c0',6,'101.226.33.216','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"M8w7\";i:1504404794;}dest_url|s:112:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.log\";',1504408394),('d36d3741a739016c3522317849b95748',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"POEe\";i:1504401578;}dest_url|s:122:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay%26id%3D180\";',1504405178),('d2c4b3211f1eb35562338a79a8ed82bf',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"XAw6\";i:1504324858;}dest_url|s:146:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay.success%26id%3D164%26result%3Dtrue\";',1504328458),('6c1cfae871dbc7220ede3ffeb73135d0',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"Vkzk\";i:1504324806;}dest_url|s:121:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.address.post\";',1504328406),('e2505f80564c7800a76b98985caf7852',6,'120.41.220.107','acid|s:1:\"6\";uniacid|i:6;token|a:6:{s:4:\"d42Y\";i:1504272686;s:4:\"EQq5\";i:1504272686;s:4:\"S63N\";i:1504272688;s:4:\"OS6b\";i:1504272690;s:4:\"sDx0\";i:1504272690;s:4:\"Chz7\";i:1504272693;}dest_url|s:122:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay%26id%3D162\";oauth_openid|s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";uid|s:1:\"1\";peerpay|N;newstoreid|i:0;userinfo|s:832:\"YToxNDp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib1pvNGh3OFd0NTY1WUxhbW4yVEpxR0V4UWlyQSI7czo4OiJuaWNrbmFtZSI7czo2OiLooZflopkiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuWOpumXqCI7czo4OiJwcm92aW5jZSI7czo2OiLnpo/lu7oiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTI3OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL0hJbVRyOVk1YkpYT1E0TWVwdmtIMzBYR2lhODZLTFdDdU1oN3RJZW9QMUVGZUNVRmxIQW5GbmRQZUxrZzlnTmtUQVA1cExjdlJhbTBUVHhnb2Jyc1FKd2xURG5MY0NEd00vMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTA0MjcxNTc5O3M6NjoicmVtYXJrIjtzOjA6IiI7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI3OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL0hJbVRyOVk1YkpYT1E0TWVwdmtIMzBYR2lhODZLTFdDdU1oN3RJZW9QMUVGZUNVRmxIQW5GbmRQZUxrZzlnTmtUQVA1cExjdlJhbTBUVHhnb2Jyc1FKd2xURG5MY0NEd00vMTMyIjt9\";',1504276293),('e4338c9370e4d7a1b6690efb0a85334f',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"ZphJ\";i:1504324451;}dest_url|s:115:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dshop.category\";',1504328051),('10898e3add02b00dbb58aaa84e2da1a5',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"IX9u\";i:1504324456;}dest_url|s:121:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods%26cate%3D1184\";',1504328056),('b52e91cac2298ae16c403ca5aa123c1f',6,'59.56.69.152','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"NAtW\";i:1504323361;}',1504326961),('aa9081282032e1646c2756f7d6169bee',6,'59.56.69.152','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"eG4Q\";i:1504323375;}',1504326975),('030ec17faca3040753e26a1e332fb280',6,'59.56.69.152','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"W11v\";i:1504323564;}',1504327164),('71b5adc81e06c396d7aa13fbc1279d19',6,'59.56.69.152','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"hF7B\";i:1504323594;}',1504327194),('61a41be7c88a82078c435669d7329989',6,'59.56.69.152','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"bu1g\";i:1504323731;}',1504327331),('c51b5785ab533c42aa240dec95f9fb52',6,'59.56.69.152','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"dN7F\";i:1504323762;}',1504327362),('c48addb14a6b7c3a0036d46c6afa09a9',6,'59.56.69.152','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"gE23\";i:1504323783;}',1504327383),('37e3e6bde42ac2ecfbb08966f0a18865',0,'180.163.2.118','acid|N;uniacid|i:0;token|a:1:{s:4:\"v29F\";i:1504405842;}',1504409442),('eb242b830ffe301ca9de7f20d1faa9da',6,'127.0.0.1','acid|s:1:\"6\";uniacid|i:6;token|a:6:{s:4:\"fhMA\";i:1504407072;s:4:\"kGBo\";i:1504407171;s:4:\"mFaF\";i:1504407174;s:4:\"Er3E\";i:1504407178;s:4:\"jv45\";i:1504407179;s:4:\"D3F5\";i:1504407181;}newstoreid|i:0;prom_cps|a:6:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"200\";}',1504410781),('8721a5fb72da27c27024bb20eafed339',6,'120.41.220.107','acid|s:1:\"6\";uniacid|i:6;token|a:5:{s:4:\"xB19\";i:1504340001;s:4:\"Qafr\";i:1504340069;s:4:\"YQVS\";i:1504340070;s:4:\"cvsR\";i:1504340071;s:4:\"ajaj\";i:1504340199;}dest_url|s:122:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay%26id%3D177\";oauth_openid|s:28:\"oZo4hw84Jkl14EOT-D0UP7IWrrFY\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw84Jkl14EOT-D0UP7IWrrFY\";userinfo|s:844:\"YToxNDp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib1pvNGh3ODRKa2wxNEVPVC1EMFVQN0lXcnJGWSI7czo4OiJuaWNrbmFtZSI7czo1OiJMaW5MaSI7czozOiJzZXgiO2k6MjtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi5Y6m6ZeoIjtzOjg6InByb3ZpbmNlIjtzOjY6Iuemj+W7uiI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMzI6Imh0dHA6Ly93eC5xbG9nby5jbi9tbW9wZW4vckdzdUdSZ0xBUGlhZHZxb3g1NW1sVFBYdE9CaWJ0Ujh4eUR4TnpwZ3VYTnpkNzVOZlI5OGVMQWlhYnZmUjNEWUFPbkVFdFQyaDNYTlUzczVUcEVqcVlNZU8zTmlha2lib0FWSGlhLzEzMiI7czoxNDoic3Vic2NyaWJlX3RpbWUiO2k6MTUwMDA4NjMwNjtzOjY6InJlbWFyayI7czowOiIiO3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMjoiaHR0cDovL3d4LnFsb2dvLmNuL21tb3Blbi9yR3N1R1JnTEFQaWFkdnFveDU1bWxUUFh0T0JpYnRSOHh5RHhOenBndVhOemQ3NU5mUjk4ZUxBaWFidmZSM0RZQU9uRUV0VDJoM1hOVTNzNVRwRWpxWU1lTzNOaWFraWJvQVZIaWEvMTMyIjt9\";bargain_id|N;prom_cps|a:15:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:4:\"desk\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:3:\"sid\";s:2:\"17\";s:7:\"item_id\";s:3:\"200\";s:13:\"commission_id\";s:9:\"undefined\";s:6:\"con_id\";s:0:\"\";s:7:\"shop_id\";s:2:\"11\";s:7:\"bank_id\";s:2:\"12\";s:10:\"bank_subid\";s:2:\"16\";s:1:\"a\";s:3:\"buy\";s:8:\"order_id\";s:3:\"178\";s:6:\"status\";s:1:\"1\";}',1504343799),('9e41eefc251283b8b8e6397e6d9911ac',6,'120.41.220.107','acid|s:1:\"6\";uniacid|i:6;token|a:6:{s:4:\"uv0J\";i:1504434393;s:4:\"RmZ2\";i:1504434393;s:4:\"Vwyw\";i:1504434406;s:4:\"Npw7\";i:1504434406;s:4:\"zoiQ\";i:1504434409;s:4:\"J9qD\";i:1504434409;}prom_cps|a:13:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"204\";s:3:\"sid\";s:2:\"17\";s:7:\"item_id\";s:3:\"204\";s:13:\"commission_id\";s:2:\"21\";s:6:\"con_id\";s:0:\"\";s:7:\"shop_id\";s:2:\"11\";s:7:\"bank_id\";s:2:\"12\";s:10:\"bank_subid\";s:2:\"16\";}',1504438009),('238dd021b304e3d5254b8aa9784f0452',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"voYU\";i:1504337112;}dest_url|s:174:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.create%26id%3D202%26optionid%3D0%26total%3D1%26giftid%26liveid%3D0\";',1504340712),('799bb9dcbd7efde5da3d9c6b1c127dfe',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"vK5m\";i:1504337176;}dest_url|s:122:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay%26id%3D170\";',1504340776),('bbbc6bcb7a378880370a67d138872a31',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"gzAQ\";i:1504337192;}dest_url|s:125:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods.detail%26id%3D199\";',1504340792),('7a759fc450300916aa868e7ef0746c4f',6,'101.226.66.172','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"CN8W\";i:1504337222;}',1504340822),('53c30a1c632328c4048d10fa4598f004',6,'120.41.220.107','acid|s:1:\"6\";uniacid|i:6;token|a:3:{s:4:\"xz02\";i:1504432323;s:4:\"iW5J\";i:1504432323;s:4:\"sF6m\";i:1504432326;}prom_cps|a:6:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"204\";}',1504435926),('8ae526395db1c8da31dd21c5775c8113',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"K861\";i:1504326015;}dest_url|s:113:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.cart\";',1504329615),('83dea7ede3cfe74f5b25d8853507bc20',6,'219.143.150.29','acid|s:1:\"6\";uniacid|i:6;token|a:3:{s:4:\"ubHl\";i:1504426821;s:4:\"aNxQ\";i:1504426968;s:4:\"BCdx\";i:1504426971;}prom_cps|a:6:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"203\";}',1504430571),('bd7a9f88ca8d5d53e16eea98acb66c78',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"q0mM\";i:1504400717;}dest_url|s:233:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods.detail%26id%3D200%26sid%3D17%26item_id%3D200%26commission_id%3D17%26con_id%3D%26shop_id%3D11%26bank_id%3D12%26bank_subid%3D16\";',1504404317),('7afc427501bb6de0c2ae5d1cf8cdd515',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"u8nN\";i:1504333842;}dest_url|s:240:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods.detail%26id%3D200%26sid%3D17%26item_id%3D200%26commission_id%3Dundefined%26con_id%3D%26shop_id%3D11%26bank_id%3D12%26bank_subid%3D16\";',1504337442),('0b2c7a3ba445ef9f501b4a29ad2a40b9',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"e7E1\";i:1504339834;}',1504343434),('73c5805f80bc144a7bed2ab151aa8943',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"b06M\";i:1504395837;}dest_url|s:118:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26from%3Dsinglemessage\";',1504399437),('62471465801c16dd9c4f43968529793d',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"DPms\";i:1504395898;}dest_url|s:125:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods.detail%26id%3D201\";',1504399498),('af08b215f2ac85d7b79c9062b9e850dd',6,'oZo4hw84Jkl14EOT-D0UP7IWrrFY','openid|s:28:\"oZo4hw84Jkl14EOT-D0UP7IWrrFY\";',1504340409),('0e90445c05bbab9f9548515b012d3520',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"Y8km\";i:1504336810;}dest_url|s:146:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay.success%26id%3D169%26result%3Dtrue\";',1504340410),('c4187b446678ffc5b4d900b4abc1a70b',6,'101.226.68.161','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"j16e\";i:1504337227;}dest_url|s:122:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay%26id%3D169\";',1504340827),('bab9ea768244ae5d0079fd1ad7ad5de4',6,'101.226.33.206','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"sJKi\";i:1504337617;}dest_url|s:117:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.recharge\";',1504341217),('483541878f823da77e2019dfbb2ff9b7',6,'120.41.220.107','acid|s:1:\"6\";uniacid|i:6;token|a:6:{s:4:\"wlh1\";i:1504447030;s:4:\"lJ9n\";i:1504447031;s:4:\"x2DU\";i:1504447033;s:4:\"jH2h\";i:1504447068;s:4:\"vkKz\";i:1504447068;s:4:\"uWww\";i:1504447071;}dest_url|s:73:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26eid%3D1\";oauth_openid|s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";uid|s:1:\"1\";userinfo|s:832:\"YToxNDp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib1pvNGh3OFd0NTY1WUxhbW4yVEpxR0V4UWlyQSI7czo4OiJuaWNrbmFtZSI7czo2OiLooZflopkiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuWOpumXqCI7czo4OiJwcm92aW5jZSI7czo2OiLnpo/lu7oiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTI3OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL0hJbVRyOVk1YkpYT1E0TWVwdmtIMzBYR2lhODZLTFdDdU1oN3RJZW9QMUVGZUNVRmxIQW5GbmRQZUxrZzlnTmtUQVA1cExjdlJhbTBUVHhnb2Jyc1FKd2xURG5MY0NEd00vMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTA0MjcxNTc5O3M6NjoicmVtYXJrIjtzOjA6IiI7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI3OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL0hJbVRyOVk1YkpYT1E0TWVwdmtIMzBYR2lhODZLTFdDdU1oN3RJZW9QMUVGZUNVRmxIQW5GbmRQZUxrZzlnTmtUQVA1cExjdlJhbTBUVHhnb2Jyc1FKd2xURG5MY0NEd00vMTMyIjt9\";newstoreid|i:0;',1504450671),('ce88f08ad9cf2241ab01c893f0ac5145',6,'180.153.160.24','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"YwVv\";i:1504396147;}dest_url|s:118:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26from%3Dsinglemessage\";',1504399747),('928afa8e4f5256711b4d921b98f7cbde',6,'101.226.64.177','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"peuW\";i:1504396209;}dest_url|s:125:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods.detail%26id%3D201\";',1504399809),('28a270abc4231c5bcb68130002375513',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"Brr0\";i:1504400913;}dest_url|s:233:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods.detail%26id%3D200%26sid%3D17%26item_id%3D200%26commission_id%3D17%26con_id%3D%26shop_id%3D11%26bank_id%3D12%26bank_subid%3D16\";',1504404513),('d7679dbaa46cd58c9f769864d3017658',6,'120.41.220.107','acid|s:1:\"6\";uniacid|i:6;token|a:5:{s:4:\"XTos\";i:1504436707;s:4:\"cHRT\";i:1504436707;s:4:\"o6Hs\";i:1504436708;s:4:\"DT2I\";i:1504436709;s:4:\"Ny0d\";i:1504436712;}dest_url|s:233:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods.detail%26id%3D204%26sid%3D17%26item_id%3D204%26commission_id%3D21%26con_id%3D%26shop_id%3D11%26bank_id%3D12%26bank_subid%3D16\";oauth_openid|s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";uid|s:1:\"1\";userinfo|s:832:\"YToxNDp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib1pvNGh3OFd0NTY1WUxhbW4yVEpxR0V4UWlyQSI7czo4OiJuaWNrbmFtZSI7czo2OiLooZflopkiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuWOpumXqCI7czo4OiJwcm92aW5jZSI7czo2OiLnpo/lu7oiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTI3OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL0hJbVRyOVk1YkpYT1E0TWVwdmtIMzBYR2lhODZLTFdDdU1oN3RJZW9QMUVGZUNVRmxIQW5GbmRQZUxrZzlnTmtUQVA1cExjdlJhbTBUVHhnb2Jyc1FKd2xURG5MY0NEd00vMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTA0MjcxNTc5O3M6NjoicmVtYXJrIjtzOjA6IiI7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI3OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL0hJbVRyOVk1YkpYT1E0TWVwdmtIMzBYR2lhODZLTFdDdU1oN3RJZW9QMUVGZUNVRmxIQW5GbmRQZUxrZzlnTmtUQVA1cExjdlJhbTBUVHhnb2Jyc1FKd2xURG5MY0NEd00vMTMyIjt9\";prom_cps|a:14:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"204\";s:3:\"sid\";s:2:\"17\";s:7:\"item_id\";s:3:\"204\";s:13:\"commission_id\";s:2:\"21\";s:6:\"con_id\";s:0:\"\";s:7:\"shop_id\";s:2:\"11\";s:7:\"bank_id\";s:2:\"12\";s:10:\"bank_subid\";s:2:\"16\";s:5:\"wxref\";s:16:\"mp.weixin.qq.com\";}',1504440312),('44391419bc5ead5ce79c511ce7641c9a',6,'112.65.193.15','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"zRDZ\";i:1504402782;}dest_url|s:122:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay%26id%3D182\";',1504406382),('6d7987759d93ac61d14a632653fadea6',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"uGwL\";i:1504404198;}dest_url|s:146:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay.success%26id%3D182%26result%3Dtrue\";',1504407798),('508b479caca0599f4f381d3136d908dd',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"P4VO\";i:1504411477;}',1504415077),('952bc5f95b5d5e508e8ed16afac3ceb1',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"fcDZ\";i:1504411495;}dest_url|s:113:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.cart\";',1504415095),('9befb41f5b4b4832db9c94e38b3a8104',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"K82M\";i:1504411495;}dest_url|s:113:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.cart\";',1504415095),('9943c087d60c821df483aad5088b7fe6',6,'219.143.150.29','acid|s:1:\"6\";uniacid|i:6;token|a:3:{s:4:\"fR5I\";i:1504423569;s:4:\"m5tT\";i:1504423569;s:4:\"m22y\";i:1504423569;}dest_url|s:122:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oZo4hw-Dv3uxhgBm549mY7-ikdyc\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw-Dv3uxhgBm549mY7-ikdyc\";uid|s:1:\"2\";',1504427169),('09a4290955f248fd930b3e1aaf967fb3',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"E7c1\";i:1504485101;}dest_url|s:115:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dshop.category\";',1504488701),('2a03f5d8f8ccc8055139b0bd0cedbef2',6,'183.3.239.162','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"dFrz\";i:1504426772;}prom_cps|a:6:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"203\";}',1504430372),('b501cc95b43dc66751466c04feb5cf8b',6,'120.92.32.140','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"cI73\";i:1504426837;}prom_cps|a:6:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"203\";}',1504430437),('o3k3726v0l6f6a42a2kjq86516',6,'106.120.232.153','acid|s:1:\"6\";uniacid|i:6;token|a:6:{s:4:\"UFBB\";i:1504519718;s:4:\"aeKh\";i:1504519719;s:4:\"Ueqy\";i:1504519721;s:4:\"gq3r\";i:1504519722;s:4:\"gF5F\";i:1504519723;s:4:\"IwPn\";i:1504519724;}dest_url|s:145:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26from%3Dsinglemessage%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oZo4hw-Dv3uxhgBm549mY7-ikdyc\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw-Dv3uxhgBm549mY7-ikdyc\";uid|s:1:\"2\";userinfo|s:712:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im9abzRody1EdjN1eGhnQm01NDltWTctaWtkeWMiO3M6ODoibmlja25hbWUiO3M6Njoi5o+t5p6cIjtzOjM6InNleCI7aToxO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLmtbfmt4AiO3M6ODoicHJvdmluY2UiO3M6Njoi5YyX5LqsIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyOToiaHR0cDovL3d4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUTHVvbGIzYXdsNW9KOWFNc1VxUnlzWXR0TUhKTmlhN2VUMjhIb3hpYjJpYnQ2bWppYmtpY3JJNHd6ZGZ1ZWxERmliMlMwSlZIVGliSkIwTHRZRncvMTMyIjtzOjk6InByaXZpbGVnZSI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI5OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL1EwajRUd0dUZlRMdW9sYjNhd2w1b0o5YU1zVXFSeXNZdHRNSEpOaWE3ZVQyOEhveGliMmlidDZtamlia2ljckk0d3pkZnVlbERGaWIyUzBKVkhUaWJKQjBMdFlGdy8xMzIiO30=\";newstoreid|i:0;',1504523324),('pp0qftrkme1511ipc8jebbhu82',6,'183.3.239.168','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"wEZG\";i:1504427923;}prom_cps|a:13:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"204\";s:3:\"sid\";s:2:\"21\";s:7:\"item_id\";s:3:\"204\";s:13:\"commission_id\";s:2:\"21\";s:6:\"con_id\";s:0:\"\";s:7:\"shop_id\";s:2:\"11\";s:7:\"bank_id\";s:2:\"12\";s:10:\"bank_subid\";s:2:\"14\";}',1504431523),('f917d071cdf951abe82ed0616c28a2f4',6,'14.17.21.58','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"qsBe\";i:1504427923;}prom_cps|a:13:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"204\";s:3:\"sid\";s:2:\"21\";s:7:\"item_id\";s:3:\"204\";s:13:\"commission_id\";s:2:\"21\";s:6:\"con_id\";s:0:\"\";s:7:\"shop_id\";s:2:\"11\";s:7:\"bank_id\";s:2:\"12\";s:10:\"bank_subid\";s:2:\"14\";}',1504431523),('569cde91058eac94c41b2a40da8e54c7',6,'101.226.33.221','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"T78E\";i:1504427932;}prom_cps|a:13:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"204\";s:3:\"sid\";s:2:\"21\";s:7:\"item_id\";s:3:\"204\";s:13:\"commission_id\";s:2:\"21\";s:6:\"con_id\";s:0:\"\";s:7:\"shop_id\";s:2:\"11\";s:7:\"bank_id\";s:2:\"12\";s:10:\"bank_subid\";s:2:\"14\";}',1504431532),('d4dd137555292642386e02208551f31b',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"ilii\";i:1504428070;}dest_url|s:125:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.detail%26id%3D184\";',1504431670),('1ffdcf994bddc7577d10c3e7b08e26e6',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"I0Ot\";i:1504428335;}dest_url|s:107:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder\";',1504431935),('d599d7cd9e9797f1867852561b1cc2e9',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"JaSw\";i:1504428373;}dest_url|s:240:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods.detail%26id%3D200%26sid%3D21%26item_id%3D200%26commission_id%3Dundefined%26con_id%3D%26shop_id%3D11%26bank_id%3D12%26bank_subid%3D14\";',1504431973),('j3bvoo8ma6e1k001tbab1eb5j6',6,'183.3.239.158','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"EERI\";i:1504428410;}prom_cps|a:13:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"200\";s:3:\"sid\";s:2:\"21\";s:7:\"item_id\";s:3:\"200\";s:13:\"commission_id\";s:2:\"17\";s:6:\"con_id\";s:0:\"\";s:7:\"shop_id\";s:2:\"11\";s:7:\"bank_id\";s:2:\"12\";s:10:\"bank_subid\";s:2:\"14\";}',1504432010),('b0e828de804ed72c2a7a28a4958b9e37',6,'183.57.53.197','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"nnkb\";i:1504428411;}prom_cps|a:13:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"200\";s:3:\"sid\";s:2:\"21\";s:7:\"item_id\";s:3:\"200\";s:13:\"commission_id\";s:2:\"17\";s:6:\"con_id\";s:0:\"\";s:7:\"shop_id\";s:2:\"11\";s:7:\"bank_id\";s:2:\"12\";s:10:\"bank_subid\";s:2:\"14\";}',1504432011),('f51e1a2a1fba3ab458ee05348bbb050d',6,'219.143.150.29','acid|s:1:\"6\";uniacid|i:6;token|a:4:{s:4:\"vHTr\";i:1504428415;s:4:\"w8nj\";i:1504428418;s:4:\"Onla\";i:1504428422;s:4:\"DlzP\";i:1504428422;}prom_cps|a:13:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"200\";s:3:\"sid\";s:2:\"21\";s:7:\"item_id\";s:3:\"200\";s:13:\"commission_id\";s:2:\"17\";s:6:\"con_id\";s:0:\"\";s:7:\"shop_id\";s:2:\"11\";s:7:\"bank_id\";s:2:\"12\";s:10:\"bank_subid\";s:2:\"14\";}',1504432022),('95b08afcf7374793d03dcd758f3b38d5',6,'61.151.226.199','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"gbg0\";i:1504428944;}prom_cps|a:13:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"200\";s:3:\"sid\";s:2:\"21\";s:7:\"item_id\";s:3:\"200\";s:13:\"commission_id\";s:2:\"17\";s:6:\"con_id\";s:0:\"\";s:7:\"shop_id\";s:2:\"11\";s:7:\"bank_id\";s:2:\"12\";s:10:\"bank_subid\";s:2:\"14\";}',1504432544),('da9aeafdebbd5c497c3e4d72338ab12d',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"SqS3\";i:1504436717;}dest_url|s:233:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods.detail%26id%3D204%26sid%3D17%26item_id%3D204%26commission_id%3D21%26con_id%3D%26shop_id%3D11%26bank_id%3D12%26bank_subid%3D16\";',1504440317),('0c3ca8211fba9d679d7a7c22fc03ecfc',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"hz2j\";i:1504436729;}dest_url|s:233:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods.detail%26id%3D204%26sid%3D17%26item_id%3D204%26commission_id%3D21%26con_id%3D%26shop_id%3D11%26bank_id%3D12%26bank_subid%3D16\";',1504440329),('032b6115cd3a897fb89601c0212f9dac',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"TBAH\";i:1504436735;}dest_url|s:233:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods.detail%26id%3D204%26sid%3D17%26item_id%3D204%26commission_id%3D21%26con_id%3D%26shop_id%3D11%26bank_id%3D12%26bank_subid%3D16\";',1504440335),('4e38c66c02359777dbb4183719cb8795',6,'101.226.33.217','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"dcIc\";i:1504485390;}dest_url|s:113:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.cart\";',1504488990),('2fd8e41997cfcc88619024cb28ff16ed',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"ShAV\";i:1504500364;}dest_url|s:122:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay%26id%3D185\";',1504503964),('f41cf0e6cb96dc96c04371718285739c',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"Z77k\";i:1504500330;}dest_url|s:125:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods.detail%26id%3D201\";',1504503930),('e4bc8422622e08c162da0a94abda2759',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"v5D7\";i:1504500337;}dest_url|s:125:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.address.selector\";',1504503937),('2052d860a8e06225c13833de2b6687b6',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"ZcO5\";i:1504500338;}dest_url|s:121:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.address.post\";',1504503938),('dfa688f45228f864efd0c751df8a198a',6,'120.41.220.107','acid|s:1:\"6\";uniacid|i:6;token|a:6:{s:4:\"sp8a\";i:1504616798;s:4:\"Og1V\";i:1504616800;s:4:\"owv0\";i:1504616810;s:4:\"pqbl\";i:1504616810;s:4:\"dYkz\";i:1504616811;s:4:\"goGF\";i:1504616814;}dest_url|s:73:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26eid%3D1\";oauth_openid|s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";uid|s:1:\"1\";userinfo|s:832:\"YToxNDp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib1pvNGh3OFd0NTY1WUxhbW4yVEpxR0V4UWlyQSI7czo4OiJuaWNrbmFtZSI7czo2OiLooZflopkiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuWOpumXqCI7czo4OiJwcm92aW5jZSI7czo2OiLnpo/lu7oiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTI3OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL0hJbVRyOVk1YkpYT1E0TWVwdmtIMzBYR2lhODZLTFdDdU1oN3RJZW9QMUVGZUNVRmxIQW5GbmRQZUxrZzlnTmtUQVA1cExjdlJhbTBUVHhnb2Jyc1FKd2xURG5MY0NEd00vMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTA0MjcxNTc5O3M6NjoicmVtYXJrIjtzOjA6IiI7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI3OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL0hJbVRyOVk1YkpYT1E0TWVwdmtIMzBYR2lhODZLTFdDdU1oN3RJZW9QMUVGZUNVRmxIQW5GbmRQZUxrZzlnTmtUQVA1cExjdlJhbTBUVHhnb2Jyc1FKd2xURG5MY0NEd00vMTMyIjt9\";newstoreid|i:0;prom_cps|a:6:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"206\";}',1504620414),('db02baf6283702d1204d5fa695f3bf4b',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"M09D\";i:1504500648;}dest_url|s:131:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.address.post%26id%3D87\";',1504504248),('473afcfde57124f97806903d262bab06',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"XAWE\";i:1504500659;}',1504504259),('03559d7065fbdf11ed215c4c18328c44',6,'101.226.66.187','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"InzC\";i:1504500811;}dest_url|s:125:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.address.selector\";',1504504411),('de98b73d829d3104cc3340077191aad3',6,'61.151.226.199','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"lBw4\";i:1504500812;}dest_url|s:125:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods.detail%26id%3D201\";',1504504412),('e5b80eebcf6c5141264b82b33f1c1e23',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"KmF6\";i:1504500973;}dest_url|s:125:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.refund%26id%3D186\";',1504504573),('5e954be225fadb16c8488edeb9e8b7ee',6,'218.6.78.20','acid|s:1:\"6\";uniacid|i:6;token|a:4:{s:4:\"GF7Q\";i:1504500990;s:4:\"tUXL\";i:1504500991;s:4:\"H22W\";i:1504500992;s:4:\"f999\";i:1504500996;}dest_url|s:108:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember\";oauth_openid|s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";uid|s:1:\"1\";userinfo|s:832:\"YToxNDp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib1pvNGh3OFd0NTY1WUxhbW4yVEpxR0V4UWlyQSI7czo4OiJuaWNrbmFtZSI7czo2OiLooZflopkiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuWOpumXqCI7czo4OiJwcm92aW5jZSI7czo2OiLnpo/lu7oiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTI3OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL0hJbVRyOVk1YkpYT1E0TWVwdmtIMzBYR2lhODZLTFdDdU1oN3RJZW9QMUVGZUNVRmxIQW5GbmRQZUxrZzlnTmtUQVA1cExjdlJhbTBUVHhnb2Jyc1FKd2xURG5MY0NEd00vMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTA0MjcxNTc5O3M6NjoicmVtYXJrIjtzOjA6IiI7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI3OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL0hJbVRyOVk1YkpYT1E0TWVwdmtIMzBYR2lhODZLTFdDdU1oN3RJZW9QMUVGZUNVRmxIQW5GbmRQZUxrZzlnTmtUQVA1cExjdlJhbTBUVHhnb2Jyc1FKd2xURG5MY0NEd00vMTMyIjt9\";',1504504596),('fa7e4d2ab141242e995e611e7ce7a353',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"XbPf\";i:1504501010;}dest_url|s:146:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dorder.pay.success%26id%3D185%26result%3Dtrue\";',1504504610),('f411afe85843c1aa1b122979bb459a2e',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"W2xR\";i:1504501058;}dest_url|s:73:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26eid%3D1\";',1504504658),('ddd8f85f3728d4ba0fd18e9ba1e3fb64',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"hS2E\";i:1504501217;}dest_url|s:121:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.address.post\";',1504504817),('df2dc67d385aeed113da3d3e0bf02e1f',6,'180.163.2.117','acid|s:1:\"6\";uniacid|i:6;token|a:2:{s:4:\"z0kk\";i:1504501562;s:4:\"Dp00\";i:1504501564;}',1504505164),('bed4412027d40edf61acbc204b4365c8',6,'219.143.226.66','acid|s:1:\"6\";uniacid|i:6;token|a:5:{s:4:\"ckkz\";i:1504520475;s:4:\"Xsmq\";i:1504520478;s:4:\"EWxk\";i:1504520479;s:4:\"RXQf\";i:1504520483;s:4:\"JMHD\";i:1504520488;}dest_url|s:95:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile\";oauth_openid|s:28:\"oZo4hw7Rho-Val4FIVX5oKc2OTUI\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw7Rho-Val4FIVX5oKc2OTUI\";uid|s:1:\"3\";userinfo|s:692:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im9abzRodzdSaG8tVmFsNEZJVlg1b0tjMk9UVUkiO3M6ODoibmlja25hbWUiO3M6Njoi5Yav6aKWIjtzOjM6InNleCI7aToyO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czowOiIiO3M6ODoicHJvdmluY2UiO3M6Njoi5YyX5LqsIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyNToiaHR0cDovL3d4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUTDJZOVBVYmljWmNUOUk4Qjl2RHNOWkd4c0hDT3RpY1hiWUpoZEd1dlo3VFBWT2V3RnpiYWZuOVBSaWExNUlBMnFrZHEzMExxSnRxR2pPUS8xMzIiO3M6OToicHJpdmlsZWdlIjthOjA6e31zOjY6ImF2YXRhciI7czoxMjU6Imh0dHA6Ly93eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvUTBqNFR3R1RmVEwyWTlQVWJpY1pjVDlJOEI5dkRzTlpHeHNIQ090aWNYYllKaGRHdXZaN1RQVk9ld0Z6YmFmbjlQUmlhMTVJQTJxa2RxMzBMcUp0cUdqT1EvMTMyIjt9\";newstoreid|i:0;',1504524088),('70892652ffde00bec9ba16044afdfdf7',6,'219.143.226.66','acid|s:1:\"6\";uniacid|i:6;token|a:6:{s:4:\"GMk9\";i:1504519916;s:4:\"cg7y\";i:1504519948;s:4:\"sB15\";i:1504519968;s:4:\"VWts\";i:1504519969;s:4:\"dS3q\";i:1504519972;s:4:\"yW0z\";i:1504519974;}dest_url|s:144:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26from%3Dgroupmessage%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oZo4hw7Rho-Val4FIVX5oKc2OTUI\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw7Rho-Val4FIVX5oKc2OTUI\";uid|s:1:\"3\";userinfo|s:692:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im9abzRodzdSaG8tVmFsNEZJVlg1b0tjMk9UVUkiO3M6ODoibmlja25hbWUiO3M6Njoi5Yav6aKWIjtzOjM6InNleCI7aToyO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czowOiIiO3M6ODoicHJvdmluY2UiO3M6Njoi5YyX5LqsIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyNToiaHR0cDovL3d4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUTDJZOVBVYmljWmNUOUk4Qjl2RHNOWkd4c0hDT3RpY1hiWUpoZEd1dlo3VFBWT2V3RnpiYWZuOVBSaWExNUlBMnFrZHEzMExxSnRxR2pPUS8xMzIiO3M6OToicHJpdmlsZWdlIjthOjA6e31zOjY6ImF2YXRhciI7czoxMjU6Imh0dHA6Ly93eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvUTBqNFR3R1RmVEwyWTlQVWJpY1pjVDlJOEI5dkRzTlpHeHNIQ090aWNYYllKaGRHdXZaN1RQVk9ld0Z6YmFmbjlQUmlhMTVJQTJxa2RxMzBMcUp0cUdqT1EvMTMyIjt9\";newstoreid|i:0;',1504523574),('fa28f410a6ff16b42f4970f2227d10a1',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"WfU9\";i:1504519860;}dest_url|s:113:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dverifygoods\";',1504523460),('5466f03ae80ca011373e5c392059b0ad',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"iJb1\";i:1504519886;}dest_url|s:116:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember.address\";',1504523486),('ce401b05aa02411597ca2b09cbe3a313',6,'114.242.248.2','acid|s:1:\"6\";uniacid|i:6;token|a:4:{s:4:\"MKE6\";i:1504520823;s:4:\"LN73\";i:1504520851;s:4:\"t9Z9\";i:1504520851;s:4:\"zeR3\";i:1504520854;}dest_url|s:165:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26from%3Dgroupmessage%26isappinstalled%3D0%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oZo4hw8_uBuJA4We7GGNc8oeU_RQ\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw8_uBuJA4We7GGNc8oeU_RQ\";userinfo|s:744:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im9abzRodzhfdUJ1SkE0V2U3R0dOYzhvZVVfUlEiO3M6ODoibmlja25hbWUiO3M6MjE6IuS4reayu+W+i+aJgOmXteeAmumcliI7czozOiJzZXgiO2k6MTtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6MDoiIjtzOjg6InByb3ZpbmNlIjtzOjY6IuWMl+S6rCI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMjU6Imh0dHA6Ly93eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvRFlBSU9ncTgzZW9DOWJlUFBFTHV4aG9nQjRjU2gyNTc1bTNFR2U4TzVVaDJOaWN1Mm1vNXBNeklGTUxFSWdNVExvc2UzS2ljWXYyZzFUWEFFaWNybHR1dXcvMTMyIjtzOjk6InByaXZpbGVnZSI7YToxOntpOjA7czoxMToiY2hpbmF1bmljb20iO31zOjY6ImF2YXRhciI7czoxMjU6Imh0dHA6Ly93eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvRFlBSU9ncTgzZW9DOWJlUFBFTHV4aG9nQjRjU2gyNTc1bTNFR2U4TzVVaDJOaWN1Mm1vNXBNeklGTUxFSWdNVExvc2UzS2ljWXYyZzFUWEFFaWNybHR1dXcvMTMyIjt9\";uid|s:1:\"4\";newstoreid|i:0;',1504524454),('8c6b35aac4b8008e9b68c2f7d31ef8eb',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"DK22\";i:1504520865;}dest_url|s:138:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26from%3Dgroupmessage%26isappinstalled%3D0\";',1504524465),('12b707cdefdaab902d5ea5a18b37608a',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"y5d3\";i:1504520309;}dest_url|s:117:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26from%3Dgroupmessage\";',1504523909),('a23e3a69b0462fff8486e98a11102aa2',6,'219.143.226.66','acid|s:1:\"6\";uniacid|i:6;token|a:3:{s:4:\"BInM\";i:1504520364;s:4:\"vTQc\";i:1504520365;s:4:\"tyYr\";i:1504520366;}dest_url|s:144:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26from%3Dgroupmessage%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oZo4hw0q7jqbeovBG-V9Rlmmou3k\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw0q7jqbeovBG-V9Rlmmou3k\";',1504523966),('f28aa6dc95862da29117e73d04771d73',6,'114.242.250.154','acid|s:1:\"6\";uniacid|i:6;token|a:6:{s:4:\"uett\";i:1504522100;s:4:\"HGoI\";i:1504522101;s:4:\"a0g3\";i:1504522102;s:4:\"AZ7j\";i:1504522105;s:4:\"Zo83\";i:1504522107;s:4:\"GZH9\";i:1504522111;}dest_url|s:166:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26from%3Dsinglemessage%26isappinstalled%3D0%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oZo4hw2mx_hd2cIa4_doocGay7-w\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw2mx_hd2cIa4_doocGay7-w\";userinfo|s:696:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im9abzRodzJteF9oZDJjSWE0X2Rvb2NHYXk3LXciO3M6ODoibmlja25hbWUiO3M6Njoi6YOd5Y+2IjtzOjM6InNleCI7aToyO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czowOiIiO3M6ODoicHJvdmluY2UiO3M6MDoiIjtzOjc6ImNvdW50cnkiO3M6OToi5a6J6YGT5bCUIjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyNzoiaHR0cDovL3d4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9QaWFqeFNxQlJhRUoyMzZLQ2ljb2VQaWJ0TWgzYmhveFZzYld5VEtocXVGRHh5ZjR1YVZCbGc0T29mR1lCTkRDdEJYNGljQ2FkU3l4Y3hTcTlyTlV1bnJ2aWNRLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEyNzoiaHR0cDovL3d4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9QaWFqeFNxQlJhRUoyMzZLQ2ljb2VQaWJ0TWgzYmhveFZzYld5VEtocXVGRHh5ZjR1YVZCbGc0T29mR1lCTkRDdEJYNGljQ2FkU3l4Y3hTcTlyTlV1bnJ2aWNRLzEzMiI7fQ==\";uid|s:1:\"5\";newstoreid|i:0;',1504525711),('be1e32a1bc83e2957a67a60865f95436',6,'114.242.250.23','acid|s:1:\"6\";uniacid|i:6;token|a:6:{s:4:\"lIS8\";i:1504565822;s:4:\"iJod\";i:1504565845;s:4:\"Om8F\";i:1504565846;s:4:\"U4o6\";i:1504565846;s:4:\"wHmk\";i:1504565871;s:4:\"wdmM\";i:1504565871;}dest_url|s:166:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26from%3Dsinglemessage%26isappinstalled%3D0%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oZo4hw2mx_hd2cIa4_doocGay7-w\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw2mx_hd2cIa4_doocGay7-w\";uid|s:1:\"5\";userinfo|s:696:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im9abzRodzJteF9oZDJjSWE0X2Rvb2NHYXk3LXciO3M6ODoibmlja25hbWUiO3M6Njoi6YOd5Y+2IjtzOjM6InNleCI7aToyO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czowOiIiO3M6ODoicHJvdmluY2UiO3M6MDoiIjtzOjc6ImNvdW50cnkiO3M6OToi5a6J6YGT5bCUIjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyNzoiaHR0cDovL3d4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9QaWFqeFNxQlJhRUoyMzZLQ2ljb2VQaWJ0TWgzYmhveFZzYld5VEtocXVGRHh5ZjR1YVZCbGc0T29mR1lCTkRDdEJYNGljQ2FkU3l4Y3hTcTlyTlV1bnJ2aWNRLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEyNzoiaHR0cDovL3d4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9QaWFqeFNxQlJhRUoyMzZLQ2ljb2VQaWJ0TWgzYmhveFZzYld5VEtocXVGRHh5ZjR1YVZCbGc0T29mR1lCTkRDdEJYNGljQ2FkU3l4Y3hTcTlyTlV1bnJ2aWNRLzEzMiI7fQ==\";newstoreid|i:0;prom_cps|a:6:{s:1:\"i\";s:1:\"6\";s:1:\"c\";s:5:\"entry\";s:1:\"m\";s:11:\"ewei_shopv2\";s:2:\"do\";s:6:\"mobile\";s:1:\"r\";s:12:\"goods.detail\";s:2:\"id\";s:3:\"202\";}',1504569471),('46c28c390794918a20108954fe04c1d2',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"tYFf\";i:1504565251;}dest_url|s:139:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26from%3Dsinglemessage%26isappinstalled%3D0\";',1504568851),('76574ab16b4acf73e093634859f8f25d',6,'117.185.27.113','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"MDzC\";i:1504565251;}',1504568851),('812984e750225d76fa3d76bd65ea62a4',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"XMLE\";i:1504565253;}',1504568853),('44db7067fc1a25d99e9ab83e4f71de99',6,'140.207.185.112','acid|s:1:\"6\";uniacid|i:6;token|a:3:{s:4:\"We0x\";i:1504565256;s:4:\"PMTM\";i:1504565260;s:4:\"vPhT\";i:1504565265;}newstoreid|i:0;',1504568865),('a3ea39dbad0bf5f5f9192d56f934b19d',6,'101.226.33.240','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"w74b\";i:1504565266;}dest_url|s:139:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26from%3Dsinglemessage%26isappinstalled%3D0\";',1504568866),('553fba48f213ec04e8ab1a586b16a6f9',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"ICGG\";i:1504565274;}dest_url|s:108:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember\";',1504568874),('6702fd0f90ccdc98c5ff616068dfc870',6,'101.226.33.201','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"TS17\";i:1504565287;}dest_url|s:108:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dmember\";',1504568887),('e59c542593353253e53aad5cdcb513e0',6,'117.185.27.114','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"dl8A\";i:1504565856;}dest_url|s:125:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods.detail%26id%3D202\";',1504569456),('fa2ca6caaedc8809cff72817eea96646',6,'218.6.78.20','acid|s:1:\"6\";uniacid|i:6;token|a:6:{s:4:\"FnmB\";i:1504585493;s:4:\"EboN\";i:1504585497;s:4:\"Tq1q\";i:1504585509;s:4:\"ye2i\";i:1504585510;s:4:\"Ysjf\";i:1504585512;s:4:\"nfLU\";i:1504585526;}dest_url|s:73:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26eid%3D1\";oauth_openid|s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";uid|s:1:\"1\";userinfo|s:832:\"YToxNDp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib1pvNGh3OFd0NTY1WUxhbW4yVEpxR0V4UWlyQSI7czo4OiJuaWNrbmFtZSI7czo2OiLooZflopkiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuWOpumXqCI7czo4OiJwcm92aW5jZSI7czo2OiLnpo/lu7oiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTI3OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL0hJbVRyOVk1YkpYT1E0TWVwdmtIMzBYR2lhODZLTFdDdU1oN3RJZW9QMUVGZUNVRmxIQW5GbmRQZUxrZzlnTmtUQVA1cExjdlJhbTBUVHhnb2Jyc1FKd2xURG5MY0NEd00vMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTA0MjcxNTc5O3M6NjoicmVtYXJrIjtzOjA6IiI7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI3OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL0hJbVRyOVk1YkpYT1E0TWVwdmtIMzBYR2lhODZLTFdDdU1oN3RJZW9QMUVGZUNVRmxIQW5GbmRQZUxrZzlnTmtUQVA1cExjdlJhbTBUVHhnb2Jyc1FKd2xURG5MY0NEd00vMTMyIjt9\";newstoreid|i:0;',1504589126),('4aba0fb0fef59bd6f858fac77920efe9',6,'117.185.27.115','acid|s:1:\"6\";uniacid|i:6;token|a:1:{s:4:\"iMnV\";i:1504616821;}dest_url|s:125:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26m%3Dewei_shopv2%26do%3Dmobile%26r%3Dgoods.detail%26id%3D206\";',1504620421),('a9d21ef7d3ec2bcec17ae4e9be160037',6,'120.41.220.107','acid|s:1:\"6\";uniacid|i:6;token|a:6:{s:4:\"P7Vf\";i:1504617613;s:4:\"Z2p0\";i:1504617613;s:4:\"lhkA\";i:1504617617;s:4:\"l88A\";i:1504617623;s:4:\"yoG6\";i:1504617729;s:4:\"rBt7\";i:1504617730;}dest_url|s:73:\"http%3A%2F%2Fwx.adjyc.com%2Fapp%2Findex.php%3Fi%3D6%26c%3Dentry%26eid%3D1\";oauth_openid|s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";oauth_acid|s:1:\"6\";openid|s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";uid|s:1:\"1\";userinfo|s:832:\"YToxNDp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib1pvNGh3OFd0NTY1WUxhbW4yVEpxR0V4UWlyQSI7czo4OiJuaWNrbmFtZSI7czo2OiLooZflopkiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuWOpumXqCI7czo4OiJwcm92aW5jZSI7czo2OiLnpo/lu7oiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTI3OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL0hJbVRyOVk1YkpYT1E0TWVwdmtIMzBYR2lhODZLTFdDdU1oN3RJZW9QMUVGZUNVRmxIQW5GbmRQZUxrZzlnTmtUQVA1cExjdlJhbTBUVHhnb2Jyc1FKd2xURG5MY0NEd00vMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTA0MjcxNTc5O3M6NjoicmVtYXJrIjtzOjA6IiI7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI3OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL0hJbVRyOVk1YkpYT1E0TWVwdmtIMzBYR2lhODZLTFdDdU1oN3RJZW9QMUVGZUNVRmxIQW5GbmRQZUxrZzlnTmtUQVA1cExjdlJhbTBUVHhnb2Jyc1FKd2xURG5MY0NEd00vMTMyIjt9\";newstoreid|i:0;',1504621330),('fa4842e30eafa9c168ba30a4eb69c5f8',6,'120.41.220.107','acid|s:1:\"6\";uniacid|i:6;token|a:6:{s:4:\"zSoU\";i:1504618396;s:4:\"diJ0\";i:1504618398;s:4:\"dp3k\";i:1504618399;s:4:\"AxpB\";i:1504618400;s:4:\"gSZ8\";i:1504618400;s:4:\"yo3T\";i:1504618401;}newstoreid|i:0;',1504622001);
/*!40000 ALTER TABLE `ims_core_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_core_settings`
--

DROP TABLE IF EXISTS `ims_core_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_core_settings` (
  `key` varchar(200) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_core_settings`
--

LOCK TABLES `ims_core_settings` WRITE;
/*!40000 ALTER TABLE `ims_core_settings` DISABLE KEYS */;
INSERT INTO `ims_core_settings` VALUES ('copyright','a:28:{s:6:\"status\";s:1:\"0\";s:10:\"verifycode\";s:1:\"0\";s:6:\"reason\";s:0:\"\";s:8:\"sitename\";s:9:\"融惠联\";s:3:\"url\";s:7:\"http://\";s:8:\"statcode\";s:0:\"\";s:10:\"footerleft\";s:26:\"融惠联版权所有 2017\";s:11:\"footerright\";s:21:\"融惠联版权所有\";s:4:\"icon\";s:0:\"\";s:6:\"flogo1\";s:48:\"images/global/f22kf6228kd8ztKXk6826Mmul66d8F.png\";s:6:\"flogo2\";s:48:\"images/global/f22kf6228kd8ztKXk6826Mmul66d8F.png\";s:6:\"slides\";s:2:\"N;\";s:6:\"notice\";s:9:\"融惠联\";s:5:\"blogo\";s:48:\"images/global/f22kf6228kd8ztKXk6826Mmul66d8F.png\";s:6:\"qrcode\";s:48:\"images/global/mz1w4jmlQlom6IWl0O1a6pf00jo8cE.jpg\";s:8:\"baidumap\";a:2:{s:3:\"lng\";s:0:\"\";s:3:\"lat\";s:0:\"\";}s:7:\"company\";s:9:\"融惠联\";s:4:\"skin\";s:7:\"default\";s:14:\"companyprofile\";s:0:\"\";s:7:\"address\";s:15:\"融惠联地址\";s:6:\"person\";s:3:\"jie\";s:5:\"phone\";s:11:\"18959269002\";s:2:\"qq\";s:10:\"1569501393\";s:5:\"email\";s:17:\"1569501393@qq.com\";s:8:\"keywords\";s:9:\"融惠联\";s:11:\"description\";s:9:\"融惠联\";s:12:\"showhomepage\";i:0;s:13:\"leftmenufixed\";i:0;}'),('authmode','i:1;'),('close','a:2:{s:6:\"status\";s:1:\"0\";s:6:\"reason\";s:0:\"\";}'),('register','a:4:{s:4:\"open\";i:1;s:6:\"verify\";i:0;s:4:\"code\";i:1;s:7:\"groupid\";i:1;}'),('site','a:5:{s:3:\"key\";s:6:\"888888\";s:5:\"token\";s:16:\"shop33453630.taobao.com\";s:3:\"url\";s:24:\"http://shop33453630.taobao.com\";s:7:\"version\";s:5:\"1.4.0\";s:15:\"profile_perfect\";i:1;}'),('module_ban','a:0:{}'),('module_upgrade','a:0:{}'),('basic','a:1:{s:8:\"template\";s:10:\"affordable\";}'),('platform','a:5:{s:5:\"token\";s:32:\"Q3gAV93Pe9t11lVi30eBgfAIrLK39r03\";s:14:\"encodingaeskey\";s:43:\"kf4TaD48eG4CSE38cUtA4Tc4sSdacE4cdADGGJs0SaF\";s:9:\"appsecret\";s:0:\"\";s:5:\"appid\";s:0:\"\";s:9:\"authstate\";i:1;}'),('cloudip','a:0:{}');
/*!40000 ALTER TABLE `ims_core_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_core_settings_皮肤设置`
--

DROP TABLE IF EXISTS `ims_core_settings_皮肤设置`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_core_settings_皮肤设置` (
  `key` varchar(200) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_core_settings_皮肤设置`
--

LOCK TABLES `ims_core_settings_皮肤设置` WRITE;
/*!40000 ALTER TABLE `ims_core_settings_皮肤设置` DISABLE KEYS */;
INSERT INTO `ims_core_settings_皮肤设置` VALUES ('copyright','a:28:{s:6:\"status\";s:1:\"0\";s:10:\"verifycode\";s:1:\"1\";s:6:\"reason\";s:0:\"\";s:8:\"sitename\";s:0:\"\";s:3:\"url\";s:7:\"http://\";s:8:\"statcode\";s:0:\"\";s:10:\"footerleft\";s:0:\"\";s:11:\"footerright\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"flogo1\";s:0:\"\";s:6:\"flogo2\";s:0:\"\";s:6:\"slides\";s:2:\"N;\";s:6:\"notice\";s:0:\"\";s:5:\"blogo\";s:0:\"\";s:6:\"qrcode\";s:0:\"\";s:8:\"baidumap\";a:2:{s:3:\"lng\";s:0:\"\";s:3:\"lat\";s:0:\"\";}s:7:\"company\";s:0:\"\";s:4:\"skin\";s:7:\"default\";s:14:\"companyprofile\";s:0:\"\";s:7:\"address\";s:0:\"\";s:6:\"person\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:2:\"qq\";s:0:\"\";s:5:\"email\";s:0:\"\";s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";s:12:\"showhomepage\";i:0;s:13:\"leftmenufixed\";i:0;}'),('authmode','i:1;'),('close','a:2:{s:6:\"status\";s:1:\"0\";s:6:\"reason\";s:0:\"\";}'),('register','a:4:{s:4:\"open\";i:1;s:6:\"verify\";i:0;s:4:\"code\";i:1;s:7:\"groupid\";i:1;}'),('site','a:5:{s:3:\"key\";s:6:\"888888\";s:5:\"token\";s:16:\"shop33453630.taobao.com\";s:3:\"url\";s:24:\"http://shop33453630.taobao.com\";s:7:\"version\";s:5:\"1.4.0\";s:15:\"profile_perfect\";i:1;}'),('module_ban','a:0:{}'),('module_upgrade','a:0:{}'),('module_receive_ban','a:1:{s:6:\"bm_top\";s:6:\"bm_top\";}'),('basic','a:1:{s:8:\"template\";s:10:\"affordable\";}');
/*!40000 ALTER TABLE `ims_core_settings_皮肤设置` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_core_settings_copy`
--

DROP TABLE IF EXISTS `ims_core_settings_copy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_core_settings_copy` (
  `key` varchar(200) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_core_settings_copy`
--

LOCK TABLES `ims_core_settings_copy` WRITE;
/*!40000 ALTER TABLE `ims_core_settings_copy` DISABLE KEYS */;
INSERT INTO `ims_core_settings_copy` VALUES ('copyright','a:28:{s:6:\"status\";s:1:\"0\";s:10:\"verifycode\";s:1:\"1\";s:6:\"reason\";s:0:\"\";s:8:\"sitename\";s:0:\"\";s:3:\"url\";s:7:\"http://\";s:8:\"statcode\";s:0:\"\";s:10:\"footerleft\";s:0:\"\";s:11:\"footerright\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"flogo1\";s:0:\"\";s:6:\"flogo2\";s:0:\"\";s:6:\"slides\";s:2:\"N;\";s:6:\"notice\";s:0:\"\";s:5:\"blogo\";s:0:\"\";s:6:\"qrcode\";s:0:\"\";s:8:\"baidumap\";a:2:{s:3:\"lng\";s:0:\"\";s:3:\"lat\";s:0:\"\";}s:7:\"company\";s:0:\"\";s:4:\"skin\";s:7:\"default\";s:14:\"companyprofile\";s:0:\"\";s:7:\"address\";s:0:\"\";s:6:\"person\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:2:\"qq\";s:0:\"\";s:5:\"email\";s:0:\"\";s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";s:12:\"showhomepage\";i:0;s:13:\"leftmenufixed\";i:0;}'),('authmode','i:1;'),('close','a:2:{s:6:\"status\";s:1:\"0\";s:6:\"reason\";s:0:\"\";}'),('register','a:4:{s:4:\"open\";i:1;s:6:\"verify\";i:0;s:4:\"code\";i:1;s:7:\"groupid\";i:1;}'),('site','a:5:{s:3:\"key\";s:6:\"888888\";s:5:\"token\";s:16:\"shop33453630.taobao.com\";s:3:\"url\";s:24:\"http://shop33453630.taobao.com\";s:7:\"version\";s:5:\"1.4.0\";s:15:\"profile_perfect\";i:1;}'),('module_ban','a:0:{}'),('module_upgrade','a:0:{}'),('module_receive_ban','a:1:{s:6:\"bm_top\";s:6:\"bm_top\";}'),('basic','a:1:{s:8:\"template\";s:8:\"hcwechat\";}');
/*!40000 ALTER TABLE `ims_core_settings_copy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_coupon`
--

DROP TABLE IF EXISTS `ims_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_coupon` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL DEFAULT '0',
  `acid` int(10) unsigned NOT NULL DEFAULT '0',
  `card_id` varchar(50) NOT NULL,
  `type` varchar(15) NOT NULL COMMENT '卡券类型',
  `logo_url` varchar(150) NOT NULL,
  `code_type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT 'code类型（二维码/条形码/code码）',
  `brand_name` varchar(15) NOT NULL COMMENT '商家名称',
  `title` varchar(15) NOT NULL,
  `sub_title` varchar(20) NOT NULL,
  `color` varchar(15) NOT NULL,
  `notice` varchar(15) NOT NULL COMMENT '使用说明',
  `description` varchar(1000) NOT NULL,
  `date_info` varchar(200) NOT NULL COMMENT '使用期限',
  `quantity` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '总库存',
  `use_custom_code` tinyint(3) NOT NULL DEFAULT '0',
  `bind_openid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `can_share` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '是否可分享',
  `can_give_friend` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '是否可转赠给朋友',
  `get_limit` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '每人领取限制',
  `service_phone` varchar(20) NOT NULL,
  `extra` varchar(1000) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1:审核中,2:未通过,3:已通过,4:卡券被商户删除,5:未知',
  `is_display` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '是否上架',
  `is_selfconsume` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否开启自助核销',
  `promotion_url_name` varchar(10) NOT NULL,
  `promotion_url` varchar(100) NOT NULL,
  `promotion_url_sub_title` varchar(10) NOT NULL,
  `source` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '来源，1是系统，2是微信',
  `dosage` int(10) unsigned DEFAULT '0' COMMENT '已领取数量',
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`,`acid`),
  KEY `card_id` (`card_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_coupon`
--

LOCK TABLES `ims_coupon` WRITE;
/*!40000 ALTER TABLE `ims_coupon` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_coupon_activity`
--

DROP TABLE IF EXISTS `ims_coupon_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_coupon_activity` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) NOT NULL,
  `msg_id` int(10) NOT NULL DEFAULT '0',
  `status` int(10) NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL DEFAULT '',
  `type` int(3) NOT NULL DEFAULT '0' COMMENT '1 发送系统卡券 2发送微信卡券',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `coupons` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '‘’',
  `members` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_coupon_activity`
--

LOCK TABLES `ims_coupon_activity` WRITE;
/*!40000 ALTER TABLE `ims_coupon_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_coupon_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_coupon_groups`
--

DROP TABLE IF EXISTS `ims_coupon_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_coupon_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) NOT NULL,
  `couponid` varchar(255) NOT NULL DEFAULT '',
  `groupid` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_coupon_groups`
--

LOCK TABLES `ims_coupon_groups` WRITE;
/*!40000 ALTER TABLE `ims_coupon_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_coupon_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_coupon_location`
--

DROP TABLE IF EXISTS `ims_coupon_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_coupon_location` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `sid` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `business_name` varchar(50) NOT NULL,
  `branch_name` varchar(50) NOT NULL,
  `category` varchar(255) NOT NULL,
  `province` varchar(15) NOT NULL,
  `city` varchar(15) NOT NULL,
  `district` varchar(15) NOT NULL,
  `address` varchar(50) NOT NULL,
  `longitude` varchar(15) NOT NULL,
  `latitude` varchar(15) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `photo_list` varchar(10000) NOT NULL,
  `avg_price` int(10) unsigned NOT NULL,
  `open_time` varchar(50) NOT NULL,
  `recommend` varchar(255) NOT NULL,
  `special` varchar(255) NOT NULL,
  `introduction` varchar(255) NOT NULL,
  `offset_type` tinyint(3) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `message` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`,`acid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_coupon_location`
--

LOCK TABLES `ims_coupon_location` WRITE;
/*!40000 ALTER TABLE `ims_coupon_location` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_coupon_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_coupon_modules`
--

DROP TABLE IF EXISTS `ims_coupon_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_coupon_modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `couponid` int(10) unsigned NOT NULL DEFAULT '0',
  `module` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cid` (`couponid`),
  KEY `uniacid` (`uniacid`,`acid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_coupon_modules`
--

LOCK TABLES `ims_coupon_modules` WRITE;
/*!40000 ALTER TABLE `ims_coupon_modules` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_coupon_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_coupon_record`
--

DROP TABLE IF EXISTS `ims_coupon_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_coupon_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `card_id` varchar(50) NOT NULL,
  `openid` varchar(50) NOT NULL,
  `friend_openid` varchar(50) NOT NULL,
  `givebyfriend` tinyint(3) unsigned NOT NULL,
  `code` varchar(50) NOT NULL,
  `hash` varchar(32) NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `usetime` int(10) unsigned NOT NULL,
  `status` tinyint(3) NOT NULL,
  `clerk_name` varchar(15) NOT NULL,
  `clerk_id` int(10) unsigned NOT NULL,
  `store_id` int(10) unsigned NOT NULL,
  `clerk_type` tinyint(3) unsigned NOT NULL,
  `couponid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `grantmodule` varchar(255) NOT NULL,
  `remark` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`,`acid`),
  KEY `card_id` (`card_id`),
  KEY `hash` (`hash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_coupon_record`
--

LOCK TABLES `ims_coupon_record` WRITE;
/*!40000 ALTER TABLE `ims_coupon_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_coupon_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_coupon_store`
--

DROP TABLE IF EXISTS `ims_coupon_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_coupon_store` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) NOT NULL,
  `couponid` varchar(255) NOT NULL DEFAULT '',
  `storeid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `couponid` (`couponid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_coupon_store`
--

LOCK TABLES `ims_coupon_store` WRITE;
/*!40000 ALTER TABLE `ims_coupon_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_coupon_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_cover_reply`
--

DROP TABLE IF EXISTS `ims_cover_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_cover_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `multiid` int(10) unsigned NOT NULL,
  `rid` int(10) unsigned NOT NULL,
  `module` varchar(30) NOT NULL,
  `do` varchar(30) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_cover_reply`
--

LOCK TABLES `ims_cover_reply` WRITE;
/*!40000 ALTER TABLE `ims_cover_reply` DISABLE KEYS */;
INSERT INTO `ims_cover_reply` VALUES (1,1,0,7,'mc','','进入个人中心','','','./index.php?c=mc&a=home&i=1'),(2,1,1,8,'site','','进入首页','','','./index.php?c=home&i=1&t=1');
/*!40000 ALTER TABLE `ims_cover_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_custom_reply`
--

DROP TABLE IF EXISTS `ims_custom_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_custom_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `start1` int(10) NOT NULL,
  `end1` int(10) NOT NULL,
  `start2` int(10) NOT NULL,
  `end2` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_custom_reply`
--

LOCK TABLES `ims_custom_reply` WRITE;
/*!40000 ALTER TABLE `ims_custom_reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_custom_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_message_mass_sign`
--

DROP TABLE IF EXISTS `ims_ewei_message_mass_sign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_message_mass_sign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(50) DEFAULT NULL,
  `nickname` varchar(50) DEFAULT NULL,
  `taskid` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `log` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_message_mass_sign`
--

LOCK TABLES `ims_ewei_message_mass_sign` WRITE;
/*!40000 ALTER TABLE `ims_ewei_message_mass_sign` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_message_mass_sign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_message_mass_task`
--

DROP TABLE IF EXISTS `ims_ewei_message_mass_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_message_mass_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `status` tinyint(1) DEFAULT '0',
  `processnum` int(11) DEFAULT '1',
  `sendnum` int(11) DEFAULT '0',
  `messagetype` tinyint(1) DEFAULT '0',
  `templateid` int(11) DEFAULT '0',
  `resptitle` varchar(255) DEFAULT NULL,
  `respthumb` varchar(255) DEFAULT NULL,
  `respdesc` varchar(255) DEFAULT NULL,
  `respurl` varchar(255) DEFAULT NULL,
  `sendlimittype` tinyint(1) DEFAULT '0',
  `send_openid` text,
  `send_level` int(11) DEFAULT NULL,
  `send_group` int(11) DEFAULT NULL,
  `send_agentlevel` int(11) DEFAULT NULL,
  `customertype` tinyint(1) DEFAULT '0',
  `resdesc2` varchar(255) DEFAULT '',
  `pagecount` int(11) DEFAULT '0',
  `successnum` int(11) DEFAULT '0',
  `failnum` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_message_mass_task`
--

LOCK TABLES `ims_ewei_message_mass_task` WRITE;
/*!40000 ALTER TABLE `ims_ewei_message_mass_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_message_mass_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_message_mass_template`
--

DROP TABLE IF EXISTS `ims_ewei_message_mass_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_message_mass_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `template_id` varchar(255) DEFAULT '',
  `first` text NOT NULL,
  `firstcolor` varchar(255) DEFAULT '',
  `data` text NOT NULL,
  `remark` text NOT NULL,
  `remarkcolor` varchar(255) DEFAULT '',
  `url` varchar(255) NOT NULL,
  `createtime` int(11) DEFAULT '0',
  `sendtimes` int(11) DEFAULT '0',
  `sendcount` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_message_mass_template`
--

LOCK TABLES `ims_ewei_message_mass_template` WRITE;
/*!40000 ALTER TABLE `ims_ewei_message_mass_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_message_mass_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_abonus_bill`
--

DROP TABLE IF EXISTS `ims_ewei_shop_abonus_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_abonus_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `billno` varchar(100) DEFAULT '',
  `paytype` int(11) DEFAULT '0',
  `year` int(11) DEFAULT '0',
  `month` int(11) DEFAULT '0',
  `week` int(11) DEFAULT '0',
  `ordercount` int(11) DEFAULT '0',
  `ordermoney` decimal(10,2) DEFAULT '0.00',
  `paytime` int(11) DEFAULT '0',
  `aagentcount1` int(11) DEFAULT '0',
  `aagentcount2` int(11) DEFAULT '0',
  `aagentcount3` int(11) DEFAULT '0',
  `bonusmoney1` decimal(10,2) DEFAULT '0.00',
  `bonusmoney_send1` decimal(10,2) DEFAULT '0.00',
  `bonusmoney_pay1` decimal(10,2) DEFAULT '0.00',
  `bonusmoney2` decimal(10,2) DEFAULT '0.00',
  `bonusmoney_send2` decimal(10,2) DEFAULT '0.00',
  `bonusmoney_pay2` decimal(10,2) DEFAULT '0.00',
  `bonusmoney3` decimal(10,2) DEFAULT '0.00',
  `bonusmoney_send3` decimal(10,2) DEFAULT '0.00',
  `bonusmoney_pay3` decimal(10,2) DEFAULT '0.00',
  `createtime` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  `starttime` int(11) DEFAULT '0',
  `endtime` int(11) DEFAULT '0',
  `confirmtime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_paytype` (`paytype`) USING BTREE,
  KEY `idx_createtime` (`createtime`) USING BTREE,
  KEY `idx_paytime` (`paytime`) USING BTREE,
  KEY `idx_status` (`status`) USING BTREE,
  KEY `idx_month` (`month`) USING BTREE,
  KEY `idx_week` (`week`) USING BTREE,
  KEY `idx_year` (`year`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_abonus_bill`
--

LOCK TABLES `ims_ewei_shop_abonus_bill` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_abonus_bill` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_abonus_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_abonus_billo`
--

DROP TABLE IF EXISTS `ims_ewei_shop_abonus_billo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_abonus_billo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `billid` int(11) DEFAULT '0',
  `orderid` int(11) DEFAULT '0',
  `ordermoney` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `idx_billid` (`billid`) USING BTREE,
  KEY `idx_uniacid` (`uniacid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_abonus_billo`
--

LOCK TABLES `ims_ewei_shop_abonus_billo` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_abonus_billo` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_abonus_billo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_abonus_billp`
--

DROP TABLE IF EXISTS `ims_ewei_shop_abonus_billp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_abonus_billp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `billid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `payno` varchar(255) DEFAULT '',
  `paytype` tinyint(3) DEFAULT '0',
  `bonus1` decimal(10,4) DEFAULT '0.0000',
  `bonus2` decimal(10,4) DEFAULT '0.0000',
  `bonus3` decimal(10,4) DEFAULT '0.0000',
  `money1` decimal(10,2) DEFAULT '0.00',
  `realmoney1` decimal(10,2) DEFAULT '0.00',
  `paymoney1` decimal(10,2) DEFAULT '0.00',
  `money2` decimal(10,2) DEFAULT '0.00',
  `realmoney2` decimal(10,2) DEFAULT '0.00',
  `paymoney2` decimal(10,2) DEFAULT '0.00',
  `money3` decimal(10,2) DEFAULT '0.00',
  `realmoney3` decimal(10,2) DEFAULT '0.00',
  `paymoney3` decimal(10,2) DEFAULT '0.00',
  `chargemoney1` decimal(10,2) DEFAULT '0.00',
  `chargemoney2` decimal(10,2) DEFAULT '0.00',
  `chargemoney3` decimal(10,2) DEFAULT '0.00',
  `charge` decimal(10,2) DEFAULT '0.00',
  `status` tinyint(3) DEFAULT '0',
  `reason` varchar(255) DEFAULT '',
  `paytime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_billid` (`billid`) USING BTREE,
  KEY `idx_uniacid` (`uniacid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_abonus_billp`
--

LOCK TABLES `ims_ewei_shop_abonus_billp` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_abonus_billp` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_abonus_billp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_abonus_level`
--

DROP TABLE IF EXISTS `ims_ewei_shop_abonus_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_abonus_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `levelname` varchar(50) DEFAULT '',
  `bonus1` decimal(10,4) DEFAULT '0.0000',
  `bonus2` decimal(10,4) DEFAULT '0.0000',
  `bonus3` decimal(10,4) DEFAULT '0.0000',
  `ordermoney` decimal(10,2) DEFAULT '0.00',
  `ordercount` int(11) DEFAULT '0',
  `bonusmoney` decimal(10,2) DEFAULT '0.00',
  `downcount` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_abonus_level`
--

LOCK TABLES `ims_ewei_shop_abonus_level` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_abonus_level` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_abonus_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_adv`
--

DROP TABLE IF EXISTS `ims_ewei_shop_adv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_adv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `advname` varchar(50) DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `enabled` int(11) DEFAULT '0',
  `shopid` int(11) DEFAULT '0',
  `iswxapp` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_enabled` (`enabled`),
  KEY `idx_displayorder` (`displayorder`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_adv`
--

LOCK TABLES `ims_ewei_shop_adv` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_adv` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_adv` VALUES (9,6,'*幻灯片1','','images/6/2017/09/Sj96Wi726WwH210Itzk6xx1Y2uxht6.jpg',0,1,0,0),(10,6,'*幻灯片2','','images/6/2017/09/nnNjMAgGqNgs3g800ZnDY40AM8QSam.jpg',0,1,0,0),(11,6,'*幻灯片3','','images/6/2017/09/a9Jw7fAhmwzvF7t98P70W11VAaxXZf.jpg',0,1,0,0),(12,6,'幻灯片4','','images/6/2017/09/KM997qmpN8M9N078DHiM88mhp90q8H.jpg',0,1,0,0),(13,6,'幻灯片5','','images/6/2017/09/Xj5aP3Zk7r3J3p3Vt33Yt8K86R0KIu.jpg',0,1,0,0);
/*!40000 ALTER TABLE `ims_ewei_shop_adv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_area_config`
--

DROP TABLE IF EXISTS `ims_ewei_shop_area_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_area_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `new_area` tinyint(3) NOT NULL DEFAULT '0',
  `address_street` tinyint(3) NOT NULL DEFAULT '0',
  `createtime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_area_config`
--

LOCK TABLES `ims_ewei_shop_area_config` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_area_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_area_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_article`
--

DROP TABLE IF EXISTS `ims_ewei_shop_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_title` varchar(255) NOT NULL DEFAULT '',
  `resp_desc` text NOT NULL,
  `resp_img` text NOT NULL,
  `article_content` longtext,
  `article_category` int(11) NOT NULL DEFAULT '0',
  `article_date_v` varchar(20) NOT NULL DEFAULT '',
  `article_date` varchar(20) NOT NULL DEFAULT '',
  `article_mp` varchar(50) NOT NULL DEFAULT '',
  `article_author` varchar(20) NOT NULL DEFAULT '',
  `article_readnum_v` int(11) NOT NULL DEFAULT '0',
  `article_readnum` int(11) NOT NULL DEFAULT '0',
  `article_likenum_v` int(11) NOT NULL DEFAULT '0',
  `article_likenum` int(11) NOT NULL DEFAULT '0',
  `article_linkurl` varchar(300) NOT NULL DEFAULT '',
  `article_rule_daynum` int(11) NOT NULL DEFAULT '0',
  `article_rule_allnum` int(11) NOT NULL DEFAULT '0',
  `article_rule_credit` int(11) NOT NULL DEFAULT '0',
  `article_rule_money` decimal(10,2) NOT NULL DEFAULT '0.00',
  `page_set_option_nocopy` int(1) NOT NULL DEFAULT '0',
  `page_set_option_noshare_tl` int(1) NOT NULL DEFAULT '0',
  `page_set_option_noshare_msg` int(1) NOT NULL DEFAULT '0',
  `article_keyword` varchar(255) NOT NULL DEFAULT '',
  `article_report` int(1) NOT NULL DEFAULT '0',
  `product_advs_type` int(1) NOT NULL DEFAULT '0',
  `product_advs_title` varchar(255) NOT NULL DEFAULT '',
  `product_advs_more` varchar(255) NOT NULL DEFAULT '',
  `product_advs_link` varchar(255) NOT NULL DEFAULT '',
  `product_advs` text NOT NULL,
  `article_state` int(1) NOT NULL DEFAULT '0',
  `network_attachment` varchar(255) DEFAULT '',
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `article_rule_credittotal` int(11) DEFAULT '0',
  `article_rule_moneytotal` decimal(10,2) DEFAULT '0.00',
  `article_rule_credit2` int(11) NOT NULL DEFAULT '0',
  `article_rule_money2` decimal(10,2) NOT NULL DEFAULT '0.00',
  `article_rule_creditm` int(11) NOT NULL DEFAULT '0',
  `article_rule_moneym` decimal(10,2) NOT NULL DEFAULT '0.00',
  `article_rule_creditm2` int(11) NOT NULL DEFAULT '0',
  `article_rule_moneym2` decimal(10,2) NOT NULL DEFAULT '0.00',
  `article_readtime` int(11) DEFAULT '0',
  `article_areas` varchar(255) DEFAULT '',
  `article_endtime` int(11) DEFAULT '0',
  `article_hasendtime` tinyint(3) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `article_keyword2` varchar(255) NOT NULL DEFAULT '',
  `article_advance` int(11) DEFAULT '0',
  `article_virtualadd` tinyint(3) DEFAULT '0',
  `article_visit` tinyint(3) DEFAULT '0',
  `article_visit_level` text,
  `article_visit_tip` varchar(500) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_article_title` (`article_title`),
  KEY `idx_article_content` (`article_content`(10)),
  KEY `idx_article_keyword` (`article_keyword`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='营销文章';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_article`
--

LOCK TABLES `ims_ewei_shop_article` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_article_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_article_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_article_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL DEFAULT '',
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `displayorder` int(11) NOT NULL DEFAULT '0',
  `isshow` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_category_name` (`category_name`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='营销表单分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_article_category`
--

LOCK TABLES `ims_ewei_shop_article_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_article_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_article_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_article_log`
--

DROP TABLE IF EXISTS `ims_ewei_shop_article_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_article_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aid` int(11) NOT NULL DEFAULT '0',
  `read` int(11) NOT NULL DEFAULT '0',
  `like` int(11) NOT NULL DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `uniacid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_aid` (`aid`),
  KEY `idx_openid` (`openid`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=621 DEFAULT CHARSET=utf8 COMMENT='点赞/阅读记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_article_log`
--

LOCK TABLES `ims_ewei_shop_article_log` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_article_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_article_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_article_report`
--

DROP TABLE IF EXISTS `ims_ewei_shop_article_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_article_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) NOT NULL DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `aid` int(11) DEFAULT '0',
  `cate` varchar(255) NOT NULL DEFAULT '',
  `cons` varchar(255) NOT NULL DEFAULT '',
  `uniacid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户举报记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_article_report`
--

LOCK TABLES `ims_ewei_shop_article_report` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_article_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_article_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_article_share`
--

DROP TABLE IF EXISTS `ims_ewei_shop_article_share`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_article_share` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aid` int(11) NOT NULL DEFAULT '0',
  `share_user` int(11) NOT NULL DEFAULT '0',
  `click_user` int(11) NOT NULL DEFAULT '0',
  `click_date` varchar(20) NOT NULL DEFAULT '',
  `add_credit` int(11) NOT NULL DEFAULT '0',
  `add_money` decimal(10,2) NOT NULL DEFAULT '0.00',
  `uniacid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_aid` (`aid`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=63 DEFAULT CHARSET=utf8 COMMENT='用户分享数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_article_share`
--

LOCK TABLES `ims_ewei_shop_article_share` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_article_share` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_article_share` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_article_sys`
--

DROP TABLE IF EXISTS `ims_ewei_shop_article_sys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_article_sys` (
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `article_message` varchar(255) NOT NULL DEFAULT '',
  `article_title` varchar(255) NOT NULL DEFAULT '',
  `article_image` varchar(300) NOT NULL DEFAULT '',
  `article_shownum` int(11) NOT NULL DEFAULT '0',
  `article_keyword` varchar(255) NOT NULL DEFAULT '',
  `article_temp` int(11) NOT NULL DEFAULT '0',
  `article_source` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uniacid`),
  KEY `idx_article_message` (`article_message`),
  KEY `idx_article_keyword` (`article_keyword`),
  KEY `idx_article_title` (`article_title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文章设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_article_sys`
--

LOCK TABLES `ims_ewei_shop_article_sys` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_article_sys` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_article_sys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_author_bill`
--

DROP TABLE IF EXISTS `ims_ewei_shop_author_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_author_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `billno` varchar(100) DEFAULT '',
  `paytype` int(11) DEFAULT '0',
  `year` int(11) DEFAULT '0',
  `month` int(11) DEFAULT '0',
  `week` int(11) DEFAULT '0',
  `ordercount` int(11) DEFAULT '0',
  `ordermoney` decimal(10,2) DEFAULT '0.00',
  `bonusordermoney` decimal(10,2) DEFAULT '0.00',
  `bonusrate` decimal(10,2) DEFAULT '0.00',
  `bonusmoney` decimal(10,2) DEFAULT '0.00',
  `bonusmoney_send` decimal(10,2) DEFAULT '0.00',
  `bonusmoney_pay` decimal(10,2) DEFAULT '0.00',
  `paytime` int(11) DEFAULT '0',
  `partnercount` int(11) DEFAULT '0',
  `createtime` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  `starttime` int(11) DEFAULT '0',
  `endtime` int(11) DEFAULT '0',
  `confirmtime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_paytype` (`paytype`) USING BTREE,
  KEY `idx_createtime` (`createtime`) USING BTREE,
  KEY `idx_paytime` (`paytime`) USING BTREE,
  KEY `idx_status` (`status`) USING BTREE,
  KEY `idx_month` (`month`) USING BTREE,
  KEY `idx_week` (`week`) USING BTREE,
  KEY `idx_year` (`year`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_author_bill`
--

LOCK TABLES `ims_ewei_shop_author_bill` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_author_bill` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_author_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_author_billo`
--

DROP TABLE IF EXISTS `ims_ewei_shop_author_billo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_author_billo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `billid` int(11) DEFAULT '0',
  `authorid` int(11) DEFAULT NULL,
  `orderid` text,
  `ordermoney` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `idx_billid` (`billid`) USING BTREE,
  KEY `idx_uniacid` (`uniacid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_author_billo`
--

LOCK TABLES `ims_ewei_shop_author_billo` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_author_billo` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_author_billo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_author_billp`
--

DROP TABLE IF EXISTS `ims_ewei_shop_author_billp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_author_billp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `billid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `payno` varchar(255) DEFAULT '',
  `paytype` tinyint(3) DEFAULT '0',
  `bonus` decimal(10,2) DEFAULT '0.00',
  `money` decimal(10,2) DEFAULT '0.00',
  `realmoney` decimal(10,2) DEFAULT '0.00',
  `paymoney` decimal(10,2) DEFAULT '0.00',
  `charge` decimal(10,2) DEFAULT '0.00',
  `chargemoney` decimal(10,2) DEFAULT '0.00',
  `status` tinyint(3) DEFAULT '0',
  `reason` varchar(255) DEFAULT '',
  `paytime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_billid` (`billid`) USING BTREE,
  KEY `idx_uniacid` (`uniacid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_author_billp`
--

LOCK TABLES `ims_ewei_shop_author_billp` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_author_billp` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_author_billp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_author_level`
--

DROP TABLE IF EXISTS `ims_ewei_shop_author_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_author_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `levelname` varchar(50) DEFAULT '',
  `bonus` decimal(10,4) DEFAULT '0.0000',
  `ordermoney` decimal(10,2) DEFAULT '0.00',
  `ordercount` int(11) DEFAULT '0',
  `commissionmoney` decimal(10,2) DEFAULT '0.00',
  `bonusmoney` decimal(10,2) DEFAULT '0.00',
  `downcount` int(11) DEFAULT '0',
  `bonus_fg` varchar(500) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_author_level`
--

LOCK TABLES `ims_ewei_shop_author_level` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_author_level` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_author_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_author_team`
--

DROP TABLE IF EXISTS `ims_ewei_shop_author_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_author_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `teamno` varchar(50) DEFAULT '',
  `year` int(11) DEFAULT '0',
  `month` int(11) DEFAULT '0',
  `team_count` int(11) DEFAULT '0',
  `team_ids` longtext,
  `status` tinyint(1) DEFAULT '0',
  `createtime` int(11) DEFAULT '0',
  `paytime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`) USING BTREE,
  KEY `teamno` (`teamno`) USING BTREE,
  KEY `year` (`year`) USING BTREE,
  KEY `month` (`month`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `createtime` (`createtime`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_author_team`
--

LOCK TABLES `ims_ewei_shop_author_team` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_author_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_author_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_author_team_pay`
--

DROP TABLE IF EXISTS `ims_ewei_shop_author_team_pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_author_team_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `teamid` int(11) DEFAULT '0',
  `mid` int(11) DEFAULT '0',
  `payno` varchar(255) DEFAULT '',
  `money` decimal(10,2) DEFAULT '0.00',
  `paymoney` decimal(10,2) DEFAULT '0.00',
  `paytime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_teamid` (`teamid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_author_team_pay`
--

LOCK TABLES `ims_ewei_shop_author_team_pay` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_author_team_pay` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_author_team_pay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_banner`
--

DROP TABLE IF EXISTS `ims_ewei_shop_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `bannername` varchar(50) DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `enabled` int(11) DEFAULT '0',
  `shopid` int(11) DEFAULT '0',
  `iswxapp` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_enabled` (`enabled`),
  KEY `idx_displayorder` (`displayorder`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_banner`
--

LOCK TABLES `ims_ewei_shop_banner` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_banner` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_banner` VALUES (4,6,'广告1','','images/6/2017/09/Z2LrZwPT1zXtGx2MTwlAZWWp16PRP2.jpg',0,1,0,0),(5,6,'广告2','','images/6/2017/09/Yg0WRKtCTwUUBHhpHx00KWPCw11ru4.jpg',0,0,0,0),(6,6,'广告3','','images/6/2017/09/I46GWeh8e76m5mQz4Tw7QezV6htT4g.jpg',0,0,0,0);
/*!40000 ALTER TABLE `ims_ewei_shop_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_bargain_account`
--

DROP TABLE IF EXISTS `ims_ewei_shop_bargain_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_bargain_account` (
  `id` int(11) NOT NULL,
  `mall_name` varchar(255) DEFAULT NULL,
  `banner` varchar(255) DEFAULT NULL,
  `mall_title` varchar(255) DEFAULT NULL,
  `mall_content` varchar(255) DEFAULT NULL,
  `mall_logo` varchar(255) DEFAULT NULL,
  `message` int(11) DEFAULT '0',
  `partin` int(11) DEFAULT '0',
  `rule` text,
  `end_message` int(11) DEFAULT '0',
  `follow_swi` tinyint(1) NOT NULL DEFAULT '0',
  `sharestyle` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_bargain_account`
--

LOCK TABLES `ims_ewei_shop_bargain_account` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_bargain_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_bargain_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_bargain_actor`
--

DROP TABLE IF EXISTS `ims_ewei_shop_bargain_actor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_bargain_actor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `now_price` decimal(9,2) NOT NULL,
  `created_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `bargain_times` int(10) NOT NULL,
  `openid` varchar(50) NOT NULL DEFAULT '',
  `nickname` varchar(20) NOT NULL,
  `head_image` varchar(200) NOT NULL,
  `bargain_price` decimal(9,2) NOT NULL,
  `status` tinyint(2) NOT NULL,
  `account_id` int(11) NOT NULL,
  `initiate` tinyint(4) NOT NULL DEFAULT '0',
  `order` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_bargain_actor`
--

LOCK TABLES `ims_ewei_shop_bargain_actor` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_bargain_actor` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_bargain_actor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_bargain_goods`
--

DROP TABLE IF EXISTS `ims_ewei_shop_bargain_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_bargain_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `goods_id` varchar(20) NOT NULL,
  `end_price` decimal(10,2) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `status` tinyint(2) NOT NULL,
  `type` tinyint(2) NOT NULL,
  `user_set` text,
  `rule` text,
  `act_times` int(11) NOT NULL,
  `mode` tinyint(4) NOT NULL,
  `total_time` int(11) NOT NULL,
  `each_time` int(11) NOT NULL,
  `time_limit` int(11) NOT NULL,
  `probability` text NOT NULL,
  `custom` varchar(255) DEFAULT NULL,
  `maximum` int(11) DEFAULT NULL,
  `initiate` tinyint(4) NOT NULL DEFAULT '0',
  `myself` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `goods_id` (`goods_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_bargain_goods`
--

LOCK TABLES `ims_ewei_shop_bargain_goods` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_bargain_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_bargain_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_bargain_record`
--

DROP TABLE IF EXISTS `ims_ewei_shop_bargain_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_bargain_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `actor_id` int(11) NOT NULL,
  `bargain_price` decimal(9,2) NOT NULL,
  `openid` varchar(50) NOT NULL DEFAULT '',
  `nickname` varchar(20) NOT NULL,
  `head_image` varchar(200) NOT NULL,
  `bargain_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_bargain_record`
--

LOCK TABLES `ims_ewei_shop_bargain_record` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_bargain_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_bargain_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_carrier`
--

DROP TABLE IF EXISTS `ims_ewei_shop_carrier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_carrier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `realname` varchar(50) DEFAULT '',
  `mobile` varchar(50) DEFAULT '',
  `address` varchar(255) DEFAULT '',
  `deleted` tinyint(1) DEFAULT '0',
  `createtime` int(11) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_deleted` (`deleted`),
  KEY `idx_createtime` (`createtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_carrier`
--

LOCK TABLES `ims_ewei_shop_carrier` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_carrier` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_carrier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_cashier_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_cashier_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_cashier_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `catename` varchar(255) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  `status` tinyint(1) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_cashier_category`
--

LOCK TABLES `ims_ewei_shop_cashier_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_cashier_clearing`
--

DROP TABLE IF EXISTS `ims_ewei_shop_cashier_clearing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_cashier_clearing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `cashierid` int(11) DEFAULT '0',
  `clearno` varchar(64) DEFAULT '',
  `status` tinyint(3) DEFAULT '0',
  `money` decimal(10,2) DEFAULT '0.00',
  `realmoney` decimal(10,2) DEFAULT '0.00',
  `remark` varchar(500) DEFAULT '',
  `orderids` text,
  `createtime` int(11) DEFAULT '0',
  `paytime` int(11) DEFAULT '0',
  `deleted` tinyint(3) DEFAULT '0',
  `paytype` tinyint(1) DEFAULT '0',
  `payinfo` varchar(1000) DEFAULT '',
  `charge` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`) USING BTREE,
  KEY `storeid` (`cashierid`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `createtime` (`createtime`) USING BTREE,
  KEY `deleted` (`deleted`) USING BTREE,
  KEY `clearno` (`clearno`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_cashier_clearing`
--

LOCK TABLES `ims_ewei_shop_cashier_clearing` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_clearing` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_clearing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_cashier_goods`
--

DROP TABLE IF EXISTS `ims_ewei_shop_cashier_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_cashier_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `cashierid` int(11) DEFAULT '0',
  `createtime` int(10) unsigned DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `categoryid` tinyint(1) DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `total` int(11) DEFAULT '0',
  `status` tinyint(1) DEFAULT '0',
  `goodssn` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`) USING BTREE,
  KEY `cashierid` (`cashierid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_cashier_goods`
--

LOCK TABLES `ims_ewei_shop_cashier_goods` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_cashier_goods_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_cashier_goods_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_cashier_goods_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `cashierid` int(11) DEFAULT '0',
  `catename` varchar(255) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  `status` tinyint(1) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_cashierid` (`cashierid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_cashier_goods_category`
--

LOCK TABLES `ims_ewei_shop_cashier_goods_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_goods_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_goods_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_cashier_operator`
--

DROP TABLE IF EXISTS `ims_ewei_shop_cashier_operator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_cashier_operator` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `cashierid` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `manageopenid` varchar(50) DEFAULT '',
  `username` varchar(255) DEFAULT '',
  `password` varchar(50) DEFAULT '',
  `salt` varchar(8) DEFAULT '',
  `perm` text,
  `createtime` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`) USING BTREE,
  KEY `cashierid` (`cashierid`) USING BTREE,
  KEY `manageopenid` (`manageopenid`) USING BTREE,
  KEY `username` (`username`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_cashier_operator`
--

LOCK TABLES `ims_ewei_shop_cashier_operator` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_operator` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_operator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_cashier_order`
--

DROP TABLE IF EXISTS `ims_ewei_shop_cashier_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_cashier_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `ordersn` varchar(255) DEFAULT '',
  `price` decimal(10,2) DEFAULT '0.00',
  `openid` varchar(50) DEFAULT '',
  `payopenid` varchar(50) DEFAULT '',
  `createtime` int(10) unsigned DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `paytime` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_cashier_order`
--

LOCK TABLES `ims_ewei_shop_cashier_order` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_cashier_pay_log`
--

DROP TABLE IF EXISTS `ims_ewei_shop_cashier_pay_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_cashier_pay_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `cashierid` int(11) DEFAULT '0',
  `operatorid` int(11) DEFAULT '0',
  `openid` varchar(50) DEFAULT '',
  `paytype` tinyint(3) DEFAULT NULL,
  `logno` varchar(255) DEFAULT '',
  `title` varchar(255) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `money` decimal(10,2) DEFAULT '0.00',
  `paytime` int(11) DEFAULT '0',
  `is_applypay` tinyint(1) DEFAULT '0',
  `randommoney` decimal(10,2) DEFAULT '0.00',
  `enough` decimal(10,2) DEFAULT '0.00',
  `mobile` varchar(20) DEFAULT '',
  `deduction` decimal(10,2) DEFAULT '0.00',
  `discountmoney` decimal(10,2) DEFAULT '0.00',
  `discount` decimal(5,2) DEFAULT '0.00',
  `isgoods` tinyint(1) DEFAULT '0',
  `orderid` int(11) DEFAULT '0',
  `orderprice` decimal(10,2) DEFAULT '0.00',
  `goodsprice` decimal(10,2) DEFAULT '0.00',
  `couponpay` decimal(10,2) DEFAULT '0.00',
  `payopenid` varchar(50) DEFAULT '',
  `nosalemoney` decimal(10,2) DEFAULT '0.00',
  `coupon` int(11) DEFAULT '0',
  `usecoupon` int(11) DEFAULT '0',
  `usecouponprice` decimal(10,2) DEFAULT '0.00',
  `present_credit1` int(11) DEFAULT '0',
  `refundsn` varchar(50) DEFAULT '',
  `refunduser` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_type` (`paytype`) USING BTREE,
  KEY `idx_createtime` (`createtime`) USING BTREE,
  KEY `idx_status` (`status`) USING BTREE,
  KEY `idx_storeid` (`cashierid`) USING BTREE,
  KEY `idx_logno` (`logno`) USING BTREE,
  KEY `is_applypay` (`is_applypay`) USING BTREE,
  KEY `orderid` (`orderid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_cashier_pay_log`
--

LOCK TABLES `ims_ewei_shop_cashier_pay_log` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_pay_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_pay_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_cashier_pay_log_goods`
--

DROP TABLE IF EXISTS `ims_ewei_shop_cashier_pay_log_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_cashier_pay_log_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cashierid` int(11) DEFAULT '0',
  `logid` int(11) DEFAULT '0',
  `goodsid` int(11) DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `total` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `logid` (`logid`) USING BTREE,
  KEY `goodsid` (`goodsid`) USING BTREE,
  KEY `cashierid` (`cashierid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_cashier_pay_log_goods`
--

LOCK TABLES `ims_ewei_shop_cashier_pay_log_goods` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_pay_log_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_pay_log_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_cashier_qrcode`
--

DROP TABLE IF EXISTS `ims_ewei_shop_cashier_qrcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_cashier_qrcode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `cashierid` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `goodstitle` varchar(255) DEFAULT '',
  `money` decimal(10,2) DEFAULT '0.00',
  `createtime` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`) USING BTREE,
  KEY `cashierid` (`cashierid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_cashier_qrcode`
--

LOCK TABLES `ims_ewei_shop_cashier_qrcode` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_qrcode` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_qrcode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_cashier_user`
--

DROP TABLE IF EXISTS `ims_ewei_shop_cashier_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_cashier_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `storeid` int(11) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  `setmeal` tinyint(3) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `logo` varchar(255) DEFAULT '',
  `manageopenid` varchar(50) DEFAULT '',
  `isopen_commission` tinyint(1) DEFAULT '0',
  `name` varchar(50) DEFAULT '',
  `mobile` varchar(50) DEFAULT '',
  `categoryid` int(11) DEFAULT '0',
  `wechat_status` tinyint(1) DEFAULT '0',
  `wechatpay` text,
  `alipay_status` tinyint(1) DEFAULT '0',
  `alipay` text,
  `withdraw` decimal(10,2) DEFAULT '0.00',
  `openid` varchar(50) DEFAULT '',
  `diyformfields` text,
  `diyformdata` text,
  `createtime` int(11) DEFAULT '0',
  `username` varchar(255) DEFAULT '',
  `password` varchar(32) DEFAULT '',
  `salt` char(8) DEFAULT '',
  `lifetimestart` int(10) unsigned DEFAULT '0',
  `lifetimeend` int(10) unsigned DEFAULT '0',
  `status` tinyint(1) DEFAULT '0',
  `set` longtext,
  `deleted` tinyint(1) DEFAULT '0',
  `can_withdraw` tinyint(1) DEFAULT '0',
  `show_paytype` tinyint(1) DEFAULT '0',
  `couponid` varchar(255) DEFAULT '',
  `management` varchar(1000) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`) USING BTREE,
  KEY `openid` (`manageopenid`) USING BTREE,
  KEY `username` (`username`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_cashier_user`
--

LOCK TABLES `ims_ewei_shop_cashier_user` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_cashier_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `parentid` int(11) DEFAULT '0',
  `isrecommand` int(10) DEFAULT '0',
  `description` varchar(500) DEFAULT NULL,
  `displayorder` tinyint(3) unsigned DEFAULT '0',
  `enabled` tinyint(1) DEFAULT '1',
  `ishome` tinyint(3) DEFAULT '0',
  `advimg` varchar(255) DEFAULT '',
  `advurl` varchar(500) DEFAULT '',
  `level` tinyint(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_displayorder` (`displayorder`),
  KEY `idx_enabled` (`enabled`),
  KEY `idx_parentid` (`parentid`),
  KEY `idx_isrecommand` (`isrecommand`),
  KEY `idx_ishome` (`ishome`)
) ENGINE=MyISAM AUTO_INCREMENT=1187 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_category`
--

LOCK TABLES `ims_ewei_shop_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_category` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_category` VALUES (1174,6,'手机','',0,0,'手机',0,1,0,'images/6/2017/09/qJjG2YfkZJD5KKa6TGg3n3jW32j2J2.jpg','',1),(1175,6,'红酒','',0,0,'红酒',0,1,0,'','',1),(1176,6,'首饰','',0,0,'首饰',0,1,0,'','',1),(1177,6,'华为','',1174,1,'',0,1,1,'','',2),(1178,6,'小米','',1174,0,'',0,1,0,'','',2),(1179,6,'苹果','',1174,0,'',0,1,0,'','',2),(1180,6,'Mate系列','',1177,0,'',0,1,0,'','',3),(1181,6,'P系列','',1177,0,'',0,1,0,'','',3),(1182,6,'G系列','',1177,0,'',0,1,0,'','',3),(1183,6,'美妆个护','',0,0,'美妆个护',0,1,0,'','',1),(1184,6,'护肤套装','',1183,1,'护肤套装',0,1,1,'','',2),(1185,6,'精华/原液','',1183,1,'精华/原液',0,1,1,'','',2),(1186,6,'乳液/面霜','',1183,1,'乳液/面霜',0,1,1,'','',2);
/*!40000 ALTER TABLE `ims_ewei_shop_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_commission_apply`
--

DROP TABLE IF EXISTS `ims_ewei_shop_commission_apply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_commission_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `applyno` varchar(255) DEFAULT '',
  `mid` int(11) DEFAULT '0',
  `type` tinyint(3) DEFAULT '0',
  `orderids` longtext,
  `commission` decimal(10,2) DEFAULT '0.00',
  `commission_pay` decimal(10,2) DEFAULT '0.00',
  `content` text,
  `status` tinyint(3) DEFAULT '0',
  `applytime` int(11) DEFAULT '0',
  `checktime` int(11) DEFAULT '0',
  `paytime` int(11) DEFAULT '0',
  `invalidtime` int(11) DEFAULT '0',
  `refusetime` int(11) DEFAULT '0',
  `realmoney` decimal(10,2) DEFAULT '0.00',
  `charge` decimal(10,2) DEFAULT '0.00',
  `deductionmoney` decimal(10,2) DEFAULT '0.00',
  `beginmoney` decimal(10,2) DEFAULT '0.00',
  `endmoney` decimal(10,2) DEFAULT '0.00',
  `alipay` varchar(50) NOT NULL DEFAULT '',
  `bankname` varchar(50) NOT NULL DEFAULT '',
  `bankcard` varchar(50) NOT NULL DEFAULT '',
  `realname` varchar(50) NOT NULL DEFAULT '',
  `repurchase` decimal(10,2) DEFAULT '0.00',
  `alipay1` varchar(50) NOT NULL DEFAULT '',
  `bankname1` varchar(50) NOT NULL DEFAULT '',
  `bankcard1` varchar(50) NOT NULL DEFAULT '',
  `sendmoney` decimal(10,2) DEFAULT '0.00',
  `senddata` text,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_mid` (`mid`),
  KEY `idx_checktime` (`checktime`),
  KEY `idx_paytime` (`paytime`),
  KEY `idx_applytime` (`applytime`),
  KEY `idx_status` (`status`),
  KEY `idx_invalidtime` (`invalidtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_commission_apply`
--

LOCK TABLES `ims_ewei_shop_commission_apply` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_commission_apply` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_commission_apply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_commission_bank`
--

DROP TABLE IF EXISTS `ims_ewei_shop_commission_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_commission_bank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `bankname` varchar(255) NOT NULL DEFAULT '',
  `content` varchar(255) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `displayorder` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_commission_bank`
--

LOCK TABLES `ims_ewei_shop_commission_bank` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_commission_bank` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_commission_bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_commission_clickcount`
--

DROP TABLE IF EXISTS `ims_ewei_shop_commission_clickcount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_commission_clickcount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `from_openid` varchar(255) DEFAULT '',
  `clicktime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_openid` (`openid`),
  KEY `idx_from_openid` (`from_openid`)
) ENGINE=MyISAM AUTO_INCREMENT=301 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_commission_clickcount`
--

LOCK TABLES `ims_ewei_shop_commission_clickcount` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_commission_clickcount` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_commission_clickcount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_commission_level`
--

DROP TABLE IF EXISTS `ims_ewei_shop_commission_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_commission_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `levelname` varchar(50) DEFAULT '',
  `commission1` decimal(10,2) DEFAULT '0.00',
  `commission2` decimal(10,2) DEFAULT '0.00',
  `commission3` decimal(10,2) DEFAULT '0.00',
  `commissionmoney` decimal(10,2) DEFAULT '0.00',
  `ordermoney` decimal(10,2) DEFAULT '0.00',
  `downcount` varchar(255) DEFAULT '',
  `ordercount` int(11) DEFAULT '0',
  `withdraw` decimal(10,2) DEFAULT '0.00',
  `repurchase` decimal(10,2) DEFAULT '0.00',
  `goodsids` varchar(1000) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_commission_level`
--

LOCK TABLES `ims_ewei_shop_commission_level` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_commission_level` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_commission_level` VALUES (3,6,'一级分销','0.00','0.00','0.00','0.00','9999.00','0',0,'0.00','0.00',''),(4,6,'二级分销','0.00','0.00','0.00','0.00','999.00','0',0,'0.00','0.00',''),(5,6,'三级分销','0.00','0.00','0.00','0.00','99.00','0',0,'0.00','0.00','');
/*!40000 ALTER TABLE `ims_ewei_shop_commission_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_commission_log`
--

DROP TABLE IF EXISTS `ims_ewei_shop_commission_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_commission_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `applyid` int(11) DEFAULT '0',
  `mid` int(11) DEFAULT '0',
  `commission` decimal(10,2) DEFAULT '0.00',
  `createtime` int(11) DEFAULT '0',
  `commission_pay` decimal(10,2) DEFAULT '0.00',
  `realmoney` decimal(10,2) DEFAULT '0.00',
  `charge` decimal(10,2) DEFAULT '0.00',
  `deductionmoney` decimal(10,2) DEFAULT '0.00',
  `type` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_applyid` (`applyid`),
  KEY `idx_mid` (`mid`),
  KEY `idx_createtime` (`createtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_commission_log`
--

LOCK TABLES `ims_ewei_shop_commission_log` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_commission_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_commission_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_commission_rank`
--

DROP TABLE IF EXISTS `ims_ewei_shop_commission_rank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_commission_rank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '0',
  `num` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_commission_rank`
--

LOCK TABLES `ims_ewei_shop_commission_rank` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_commission_rank` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_commission_rank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_commission_repurchase`
--

DROP TABLE IF EXISTS `ims_ewei_shop_commission_repurchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_commission_repurchase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(50) DEFAULT '',
  `year` int(4) DEFAULT '0',
  `month` tinyint(2) DEFAULT '0',
  `repurchase` decimal(10,2) DEFAULT '0.00',
  `applyid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `applyid` (`applyid`),
  KEY `openid` (`openid`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_commission_repurchase`
--

LOCK TABLES `ims_ewei_shop_commission_repurchase` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_commission_repurchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_commission_repurchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_commission_shop`
--

DROP TABLE IF EXISTS `ims_ewei_shop_commission_shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_commission_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `mid` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT '',
  `logo` varchar(255) DEFAULT '',
  `img` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT '',
  `selectgoods` tinyint(3) DEFAULT '0',
  `selectcategory` tinyint(3) DEFAULT '0',
  `goodsids` text,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_mid` (`mid`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_commission_shop`
--

LOCK TABLES `ims_ewei_shop_commission_shop` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_commission_shop` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_commission_shop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_coupon`
--

DROP TABLE IF EXISTS `ims_ewei_shop_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `catid` int(11) DEFAULT '0',
  `couponname` varchar(255) DEFAULT '',
  `gettype` tinyint(3) DEFAULT '0',
  `getmax` int(11) DEFAULT '0',
  `usetype` tinyint(3) DEFAULT '0',
  `returntype` tinyint(3) DEFAULT '0',
  `bgcolor` varchar(255) DEFAULT '',
  `enough` decimal(10,2) DEFAULT '0.00',
  `timelimit` tinyint(3) DEFAULT '0',
  `coupontype` tinyint(3) DEFAULT '0',
  `timedays` int(11) DEFAULT '0',
  `timestart` int(11) DEFAULT '0',
  `timeend` int(11) DEFAULT '0',
  `discount` decimal(10,2) DEFAULT '0.00',
  `deduct` decimal(10,2) DEFAULT '0.00',
  `backtype` tinyint(3) DEFAULT '0',
  `backmoney` varchar(50) DEFAULT '',
  `backcredit` varchar(50) DEFAULT '',
  `backredpack` varchar(50) DEFAULT '',
  `backwhen` tinyint(3) DEFAULT '0',
  `thumb` varchar(255) DEFAULT '',
  `desc` text,
  `createtime` int(11) DEFAULT '0',
  `total` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  `money` decimal(10,2) DEFAULT '0.00',
  `respdesc` text,
  `respthumb` varchar(255) DEFAULT '',
  `resptitle` varchar(255) DEFAULT '',
  `respurl` varchar(255) DEFAULT '',
  `credit` int(11) DEFAULT '0',
  `usecredit2` tinyint(3) DEFAULT '0',
  `remark` varchar(1000) DEFAULT '',
  `descnoset` tinyint(3) DEFAULT '0',
  `pwdkey` varchar(255) DEFAULT '',
  `pwdsuc` text,
  `pwdfail` text,
  `pwdurl` varchar(255) DEFAULT '',
  `pwdask` text,
  `pwdstatus` tinyint(3) DEFAULT '0',
  `pwdtimes` int(11) DEFAULT '0',
  `pwdfull` text,
  `pwdwords` text,
  `pwdopen` tinyint(3) DEFAULT '0',
  `pwdown` text,
  `pwdexit` varchar(255) DEFAULT '',
  `pwdexitstr` text,
  `displayorder` int(11) DEFAULT '0',
  `pwdkey2` varchar(255) DEFAULT '',
  `merchid` int(11) DEFAULT '0',
  `limitgoodtype` tinyint(1) DEFAULT '0',
  `limitgoodcatetype` tinyint(1) DEFAULT '0',
  `limitgoodcateids` varchar(500) DEFAULT '',
  `limitgoodids` varchar(500) DEFAULT '',
  `islimitlevel` tinyint(1) DEFAULT '0',
  `limitmemberlevels` varchar(500) DEFAULT '',
  `limitagentlevels` varchar(500) DEFAULT '',
  `limitpartnerlevels` varchar(500) DEFAULT '',
  `limitaagentlevels` varchar(500) DEFAULT '',
  `tagtitle` varchar(20) DEFAULT '',
  `settitlecolor` tinyint(1) DEFAULT '0',
  `titlecolor` varchar(10) DEFAULT '',
  `limitdiscounttype` tinyint(1) DEFAULT '1',
  `quickget` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_coupontype` (`coupontype`),
  KEY `idx_timestart` (`timestart`),
  KEY `idx_timeend` (`timeend`),
  KEY `idx_timelimit` (`timelimit`),
  KEY `idx_status` (`status`),
  KEY `idx_givetype` (`backtype`),
  KEY `idx_catid` (`catid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_coupon`
--

LOCK TABLES `ims_ewei_shop_coupon` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_coupon_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_coupon_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_coupon_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_displayorder` (`displayorder`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_coupon_category`
--

LOCK TABLES `ims_ewei_shop_coupon_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_coupon_data`
--

DROP TABLE IF EXISTS `ims_ewei_shop_coupon_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_coupon_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `couponid` int(11) DEFAULT '0',
  `gettype` tinyint(3) DEFAULT '0',
  `used` int(11) DEFAULT '0',
  `usetime` int(11) DEFAULT '0',
  `gettime` int(11) DEFAULT '0',
  `senduid` int(11) DEFAULT '0',
  `ordersn` varchar(255) DEFAULT '',
  `back` tinyint(3) DEFAULT '0',
  `backtime` int(11) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  `isnew` tinyint(1) DEFAULT '1',
  `nocount` tinyint(1) DEFAULT '1',
  `shareident` varchar(50) DEFAULT NULL,
  `textkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_couponid` (`couponid`),
  KEY `idx_gettype` (`gettype`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_coupon_data`
--

LOCK TABLES `ims_ewei_shop_coupon_data` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_coupon_goodsendtask`
--

DROP TABLE IF EXISTS `ims_ewei_shop_coupon_goodsendtask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_coupon_goodsendtask` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT NULL,
  `goodsid` int(11) DEFAULT '0',
  `couponid` int(11) DEFAULT '0',
  `starttime` int(11) DEFAULT '0',
  `endtime` int(11) DEFAULT '0',
  `sendnum` int(11) DEFAULT '1',
  `num` int(11) DEFAULT '0',
  `sendpoint` tinyint(1) DEFAULT '0',
  `status` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_coupon_goodsendtask`
--

LOCK TABLES `ims_ewei_shop_coupon_goodsendtask` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_goodsendtask` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_goodsendtask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_coupon_guess`
--

DROP TABLE IF EXISTS `ims_ewei_shop_coupon_guess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_coupon_guess` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `couponid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `times` int(11) DEFAULT '0',
  `pwdkey` varchar(255) DEFAULT '',
  `ok` tinyint(3) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_couponid` (`couponid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_coupon_guess`
--

LOCK TABLES `ims_ewei_shop_coupon_guess` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_guess` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_guess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_coupon_log`
--

DROP TABLE IF EXISTS `ims_ewei_shop_coupon_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_coupon_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `logno` varchar(255) DEFAULT '',
  `openid` varchar(255) DEFAULT '',
  `couponid` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `paystatus` tinyint(3) DEFAULT '0',
  `creditstatus` tinyint(3) DEFAULT '0',
  `createtime` int(11) DEFAULT '0',
  `paytype` tinyint(3) DEFAULT '0',
  `getfrom` tinyint(3) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_couponid` (`couponid`),
  KEY `idx_status` (`status`),
  KEY `idx_paystatus` (`paystatus`),
  KEY `idx_createtime` (`createtime`),
  KEY `idx_getfrom` (`getfrom`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_coupon_log`
--

LOCK TABLES `ims_ewei_shop_coupon_log` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_coupon_sendshow`
--

DROP TABLE IF EXISTS `ims_ewei_shop_coupon_sendshow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_coupon_sendshow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `showkey` varchar(20) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `openid` varchar(255) NOT NULL,
  `coupondataid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_coupon_sendshow`
--

LOCK TABLES `ims_ewei_shop_coupon_sendshow` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_sendshow` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_sendshow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_coupon_sendtasks`
--

DROP TABLE IF EXISTS `ims_ewei_shop_coupon_sendtasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_coupon_sendtasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT NULL,
  `enough` decimal(10,2) DEFAULT '0.00',
  `couponid` int(11) DEFAULT '0',
  `starttime` int(11) DEFAULT '0',
  `endtime` int(11) DEFAULT '0',
  `sendnum` int(11) DEFAULT '1',
  `num` int(11) DEFAULT '0',
  `sendpoint` tinyint(1) DEFAULT '0',
  `status` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_coupon_sendtasks`
--

LOCK TABLES `ims_ewei_shop_coupon_sendtasks` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_sendtasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_sendtasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_coupon_taskdata`
--

DROP TABLE IF EXISTS `ims_ewei_shop_coupon_taskdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_coupon_taskdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT NULL,
  `openid` varchar(50) DEFAULT NULL,
  `taskid` int(11) DEFAULT '0',
  `couponid` int(11) DEFAULT '0',
  `sendnum` int(11) DEFAULT '0',
  `tasktype` tinyint(1) DEFAULT '0',
  `orderid` int(11) DEFAULT '0',
  `parentorderid` int(11) DEFAULT '0',
  `createtime` int(11) DEFAULT '0',
  `status` tinyint(1) DEFAULT '0',
  `sendpoint` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_coupon_taskdata`
--

LOCK TABLES `ims_ewei_shop_coupon_taskdata` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_taskdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_taskdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_coupon_usesendtasks`
--

DROP TABLE IF EXISTS `ims_ewei_shop_coupon_usesendtasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_coupon_usesendtasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT NULL,
  `usecouponid` int(11) DEFAULT '0',
  `couponid` int(11) DEFAULT '0',
  `starttime` int(11) DEFAULT '0',
  `endtime` int(11) DEFAULT '0',
  `sendnum` int(11) DEFAULT '1',
  `num` int(11) DEFAULT '0',
  `status` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_coupon_usesendtasks`
--

LOCK TABLES `ims_ewei_shop_coupon_usesendtasks` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_usesendtasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_coupon_usesendtasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_creditshop_adv`
--

DROP TABLE IF EXISTS `ims_ewei_shop_creditshop_adv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_creditshop_adv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `advname` varchar(50) DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `enabled` int(11) DEFAULT '0',
  `merchid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_enabled` (`enabled`),
  KEY `idx_displayorder` (`displayorder`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_creditshop_adv`
--

LOCK TABLES `ims_ewei_shop_creditshop_adv` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_adv` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_adv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_creditshop_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_creditshop_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_creditshop_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `displayorder` tinyint(3) unsigned DEFAULT '0',
  `enabled` tinyint(1) DEFAULT '1',
  `advimg` varchar(255) DEFAULT '',
  `advurl` varchar(500) DEFAULT '',
  `isrecommand` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_displayorder` (`displayorder`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_creditshop_category`
--

LOCK TABLES `ims_ewei_shop_creditshop_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_creditshop_comment`
--

DROP TABLE IF EXISTS `ims_ewei_shop_creditshop_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_creditshop_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `logid` int(11) NOT NULL DEFAULT '0',
  `logno` varchar(50) NOT NULL DEFAULT '',
  `goodsid` int(11) NOT NULL DEFAULT '0',
  `openid` varchar(50) DEFAULT NULL,
  `nickname` varchar(50) DEFAULT NULL,
  `headimg` varchar(255) DEFAULT NULL,
  `level` tinyint(3) NOT NULL DEFAULT '0',
  `content` varchar(255) DEFAULT NULL,
  `images` text,
  `time` int(11) NOT NULL DEFAULT '0',
  `reply_content` varchar(255) DEFAULT NULL,
  `reply_images` text,
  `reply_time` int(11) NOT NULL DEFAULT '0',
  `append_content` varchar(255) DEFAULT NULL,
  `append_images` text,
  `append_time` int(11) NOT NULL DEFAULT '0',
  `append_reply_content` varchar(255) DEFAULT NULL,
  `append_reply_images` text,
  `append_reply_time` int(11) NOT NULL DEFAULT '0',
  `istop` tinyint(3) NOT NULL DEFAULT '0',
  `checked` tinyint(3) NOT NULL DEFAULT '0',
  `append_checked` tinyint(3) NOT NULL DEFAULT '0',
  `virtual` tinyint(3) NOT NULL DEFAULT '0',
  `deleted` tinyint(3) NOT NULL DEFAULT '0',
  `merchid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_creditshop_comment`
--

LOCK TABLES `ims_ewei_shop_creditshop_comment` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_creditshop_goods`
--

DROP TABLE IF EXISTS `ims_ewei_shop_creditshop_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_creditshop_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `cate` int(11) DEFAULT '0',
  `thumb` varchar(255) DEFAULT '',
  `price` decimal(10,2) DEFAULT '0.00',
  `type` tinyint(3) DEFAULT '0',
  `credit` int(11) DEFAULT '0',
  `money` decimal(10,2) DEFAULT '0.00',
  `total` int(11) DEFAULT '0',
  `totalday` int(11) DEFAULT '0',
  `chance` int(11) DEFAULT '0',
  `chanceday` int(11) DEFAULT '0',
  `detail` text,
  `rate1` int(11) DEFAULT '0',
  `rate2` int(11) DEFAULT '0',
  `endtime` int(11) DEFAULT '0',
  `joins` int(11) DEFAULT '0',
  `views` int(11) DEFAULT '0',
  `createtime` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  `deleted` tinyint(3) DEFAULT '0',
  `showlevels` text,
  `buylevels` text,
  `showgroups` text,
  `buygroups` text,
  `vip` tinyint(3) DEFAULT '0',
  `istop` tinyint(3) DEFAULT '0',
  `isrecommand` tinyint(3) DEFAULT '0',
  `istime` tinyint(3) DEFAULT '0',
  `timestart` int(11) DEFAULT '0',
  `timeend` int(11) DEFAULT '0',
  `share_title` varchar(255) DEFAULT '',
  `share_icon` varchar(255) DEFAULT '',
  `share_desc` varchar(500) DEFAULT '',
  `followneed` tinyint(3) DEFAULT '0',
  `followtext` varchar(255) DEFAULT '',
  `subtitle` varchar(255) DEFAULT '',
  `subdetail` text,
  `noticedetail` text,
  `usedetail` varchar(255) DEFAULT '',
  `goodsdetail` text,
  `isendtime` tinyint(3) DEFAULT '0',
  `usecredit2` tinyint(3) DEFAULT '0',
  `area` varchar(255) DEFAULT '',
  `dispatch` decimal(10,2) DEFAULT '0.00',
  `storeids` text,
  `noticeopenid` varchar(255) DEFAULT '',
  `noticetype` tinyint(3) DEFAULT '0',
  `isverify` tinyint(3) DEFAULT '0',
  `goodstype` tinyint(3) DEFAULT '0',
  `couponid` int(11) DEFAULT '0',
  `goodsid` int(11) DEFAULT '0',
  `merchid` int(11) NOT NULL DEFAULT '0',
  `productprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `mincredit` decimal(10,2) NOT NULL DEFAULT '0.00',
  `minmoney` decimal(10,2) NOT NULL DEFAULT '0.00',
  `maxcredit` decimal(10,2) NOT NULL DEFAULT '0.00',
  `maxmoney` decimal(10,2) NOT NULL DEFAULT '0.00',
  `dispatchtype` tinyint(3) NOT NULL DEFAULT '0',
  `dispatchid` int(11) NOT NULL DEFAULT '0',
  `verifytype` tinyint(3) NOT NULL DEFAULT '0',
  `verifynum` int(11) NOT NULL DEFAULT '0',
  `grant1` decimal(10,2) NOT NULL DEFAULT '0.00',
  `grant2` decimal(10,2) NOT NULL DEFAULT '0.00',
  `goodssn` varchar(255) NOT NULL,
  `productsn` varchar(255) NOT NULL,
  `weight` int(11) NOT NULL,
  `showtotal` tinyint(3) NOT NULL,
  `totalcnf` tinyint(3) NOT NULL DEFAULT '0',
  `usetime` int(11) NOT NULL DEFAULT '0',
  `hasoption` tinyint(3) NOT NULL DEFAULT '0',
  `noticedetailshow` tinyint(3) NOT NULL DEFAULT '0',
  `detailshow` tinyint(3) NOT NULL DEFAULT '0',
  `packetmoney` decimal(10,2) NOT NULL DEFAULT '0.00',
  `surplusmoney` decimal(10,2) NOT NULL DEFAULT '0.00',
  `packetlimit` decimal(10,2) NOT NULL DEFAULT '0.00',
  `packettype` tinyint(3) NOT NULL DEFAULT '0',
  `minpacketmoney` decimal(10,2) NOT NULL DEFAULT '0.00',
  `packettotal` int(11) NOT NULL DEFAULT '0',
  `packetsurplus` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_type` (`type`),
  KEY `idx_endtime` (`endtime`),
  KEY `idx_createtime` (`createtime`),
  KEY `idx_status` (`status`),
  KEY `idx_displayorder` (`displayorder`),
  KEY `idx_deleted` (`deleted`),
  KEY `idx_istop` (`istop`),
  KEY `idx_isrecommand` (`isrecommand`),
  KEY `idx_istime` (`istime`),
  KEY `idx_timestart` (`timestart`),
  KEY `idx_timeend` (`timeend`),
  KEY `idx_goodstype` (`goodstype`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_creditshop_goods`
--

LOCK TABLES `ims_ewei_shop_creditshop_goods` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_creditshop_log`
--

DROP TABLE IF EXISTS `ims_ewei_shop_creditshop_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_creditshop_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `logno` varchar(255) DEFAULT '',
  `eno` varchar(255) DEFAULT '',
  `openid` varchar(255) DEFAULT '',
  `goodsid` int(11) DEFAULT '0',
  `createtime` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  `paystatus` tinyint(3) DEFAULT '0',
  `paytype` tinyint(3) DEFAULT '-1',
  `dispatchstatus` tinyint(3) DEFAULT '0',
  `creditpay` tinyint(3) DEFAULT '0',
  `addressid` int(11) DEFAULT '0',
  `dispatchno` varchar(255) DEFAULT '',
  `usetime` int(11) DEFAULT '0',
  `express` varchar(255) DEFAULT '',
  `expresssn` varchar(255) DEFAULT '',
  `expresscom` varchar(255) DEFAULT '',
  `verifyopenid` varchar(255) DEFAULT '',
  `storeid` int(11) DEFAULT '0',
  `realname` varchar(255) DEFAULT '',
  `mobile` varchar(255) DEFAULT '',
  `couponid` int(11) DEFAULT '0',
  `dupdate1` tinyint(3) DEFAULT '0',
  `transid` varchar(255) DEFAULT '',
  `dispatchtransid` varchar(255) DEFAULT '',
  `address` text,
  `optionid` int(11) NOT NULL DEFAULT '0',
  `time_send` int(11) NOT NULL DEFAULT '0',
  `time_finish` int(11) NOT NULL DEFAULT '0',
  `iscomment` tinyint(3) NOT NULL DEFAULT '0',
  `dispatchtime` int(11) NOT NULL DEFAULT '0',
  `verifynum` int(11) NOT NULL DEFAULT '1',
  `verifytime` int(11) NOT NULL DEFAULT '0',
  `merchid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_creditshop_log`
--

LOCK TABLES `ims_ewei_shop_creditshop_log` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_creditshop_option`
--

DROP TABLE IF EXISTS `ims_ewei_shop_creditshop_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_creditshop_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `goodsid` int(10) DEFAULT '0',
  `title` varchar(50) DEFAULT '',
  `thumb` varchar(60) DEFAULT '',
  `credit` int(10) NOT NULL DEFAULT '0',
  `money` decimal(10,2) DEFAULT '0.00',
  `total` int(11) DEFAULT '0',
  `weight` decimal(10,2) DEFAULT '0.00',
  `displayorder` int(11) DEFAULT '0',
  `specs` text,
  `skuId` varchar(255) DEFAULT '',
  `goodssn` varchar(255) DEFAULT '',
  `productsn` varchar(255) DEFAULT '',
  `virtual` int(11) DEFAULT '0',
  `exchange_stock` int(11) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_creditshop_option`
--

LOCK TABLES `ims_ewei_shop_creditshop_option` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_creditshop_spec`
--

DROP TABLE IF EXISTS `ims_ewei_shop_creditshop_spec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_creditshop_spec` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `goodsid` int(11) DEFAULT '0',
  `title` varchar(50) DEFAULT '',
  `description` varchar(1000) DEFAULT '',
  `displaytype` tinyint(3) DEFAULT '0',
  `content` text,
  `displayorder` int(11) DEFAULT '0',
  `propId` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_creditshop_spec`
--

LOCK TABLES `ims_ewei_shop_creditshop_spec` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_spec` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_spec` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_creditshop_spec_item`
--

DROP TABLE IF EXISTS `ims_ewei_shop_creditshop_spec_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_creditshop_spec_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `specid` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `show` int(11) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `valueId` varchar(255) DEFAULT '',
  `virtual` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_creditshop_spec_item`
--

LOCK TABLES `ims_ewei_shop_creditshop_spec_item` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_spec_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_spec_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_creditshop_verify`
--

DROP TABLE IF EXISTS `ims_ewei_shop_creditshop_verify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_creditshop_verify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(45) DEFAULT '0',
  `logid` int(11) DEFAULT '0',
  `verifycode` varchar(45) DEFAULT NULL,
  `storeid` int(11) DEFAULT '0',
  `verifier` varchar(45) DEFAULT '0',
  `isverify` tinyint(3) DEFAULT '0',
  `verifytime` int(11) DEFAULT '0',
  `merchid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_creditshop_verify`
--

LOCK TABLES `ims_ewei_shop_creditshop_verify` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_verify` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_creditshop_verify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_customer`
--

DROP TABLE IF EXISTS `ims_ewei_shop_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `kf_id` varchar(255) DEFAULT NULL,
  `kf_account` varchar(255) DEFAULT '',
  `kf_nick` varchar(255) DEFAULT '',
  `kf_pwd` varchar(255) DEFAULT '',
  `kf_headimgurl` varchar(255) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_createtime` (`createtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_customer`
--

LOCK TABLES `ims_ewei_shop_customer` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_customer_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_customer_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_customer_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_customer_category`
--

LOCK TABLES `ims_ewei_shop_customer_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_customer_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_customer_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_customer_guestbook`
--

DROP TABLE IF EXISTS `ims_ewei_shop_customer_guestbook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_customer_guestbook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `realname` varchar(11) DEFAULT '',
  `mobile` varchar(255) DEFAULT '',
  `weixin` varchar(255) DEFAULT '',
  `images` text,
  `content` text,
  `remark` text,
  `status` tinyint(3) DEFAULT '0',
  `createtime` int(11) DEFAULT '0',
  `deleted` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_customer_guestbook`
--

LOCK TABLES `ims_ewei_shop_customer_guestbook` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_customer_guestbook` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_customer_guestbook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_customer_robot`
--

DROP TABLE IF EXISTS `ims_ewei_shop_customer_robot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_customer_robot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `cate` int(11) DEFAULT '0',
  `keywords` varchar(500) DEFAULT '',
  `title` varchar(255) DEFAULT '',
  `content` longtext,
  `url` varchar(255) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_cate` (`cate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_customer_robot`
--

LOCK TABLES `ims_ewei_shop_customer_robot` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_customer_robot` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_customer_robot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_designer`
--

DROP TABLE IF EXISTS `ims_ewei_shop_designer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_designer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `pagename` varchar(255) NOT NULL DEFAULT '',
  `pagetype` tinyint(3) NOT NULL DEFAULT '0',
  `pageinfo` text NOT NULL,
  `createtime` varchar(255) NOT NULL DEFAULT '',
  `keyword` varchar(255) DEFAULT '',
  `savetime` varchar(255) NOT NULL DEFAULT '',
  `setdefault` tinyint(3) NOT NULL DEFAULT '0',
  `datas` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_pagetype` (`pagetype`),
  KEY `idx_keyword` (`keyword`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_designer`
--

LOCK TABLES `ims_ewei_shop_designer` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_designer` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_designer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_designer_menu`
--

DROP TABLE IF EXISTS `ims_ewei_shop_designer_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_designer_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `menuname` varchar(255) DEFAULT '',
  `isdefault` tinyint(3) DEFAULT '0',
  `createtime` int(11) DEFAULT '0',
  `menus` text,
  `params` text,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_isdefault` (`isdefault`),
  KEY `idx_createtime` (`createtime`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_designer_menu`
--

LOCK TABLES `ims_ewei_shop_designer_menu` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_designer_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_designer_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_dispatch`
--

DROP TABLE IF EXISTS `ims_ewei_shop_dispatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_dispatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `dispatchname` varchar(50) DEFAULT '',
  `dispatchtype` int(11) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `firstprice` decimal(10,2) DEFAULT '0.00',
  `secondprice` decimal(10,2) DEFAULT '0.00',
  `firstweight` int(11) DEFAULT '0',
  `secondweight` int(11) DEFAULT '0',
  `express` varchar(250) DEFAULT '',
  `areas` longtext,
  `carriers` text,
  `enabled` int(11) DEFAULT '0',
  `calculatetype` tinyint(1) DEFAULT '0',
  `firstnum` int(11) DEFAULT '0',
  `secondnum` int(11) DEFAULT '0',
  `firstnumprice` decimal(10,2) DEFAULT '0.00',
  `secondnumprice` decimal(10,2) DEFAULT '0.00',
  `isdefault` tinyint(1) DEFAULT '0',
  `shopid` int(11) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  `nodispatchareas` text,
  `nodispatchareas_code` longtext,
  `isdispatcharea` tinyint(3) NOT NULL DEFAULT '0',
  `freeprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_displayorder` (`displayorder`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_dispatch`
--

LOCK TABLES `ims_ewei_shop_dispatch` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_dispatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_dispatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_diyform_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_diyform_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_diyform_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_diyform_category`
--

LOCK TABLES `ims_ewei_shop_diyform_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_diyform_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_diyform_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_diyform_data`
--

DROP TABLE IF EXISTS `ims_ewei_shop_diyform_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_diyform_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `typeid` int(11) NOT NULL DEFAULT '0',
  `cid` int(11) DEFAULT '0',
  `diyformfields` text,
  `fields` text NOT NULL,
  `openid` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(2) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_typeid` (`typeid`),
  KEY `idx_cid` (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_diyform_data`
--

LOCK TABLES `ims_ewei_shop_diyform_data` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_diyform_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_diyform_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_diyform_temp`
--

DROP TABLE IF EXISTS `ims_ewei_shop_diyform_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_diyform_temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `typeid` int(11) DEFAULT '0',
  `cid` int(11) NOT NULL DEFAULT '0',
  `diyformfields` text,
  `fields` text NOT NULL,
  `openid` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(1) DEFAULT '0',
  `diyformid` int(11) DEFAULT '0',
  `diyformdata` text,
  `carrier_realname` varchar(255) DEFAULT '',
  `carrier_mobile` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_cid` (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_diyform_temp`
--

LOCK TABLES `ims_ewei_shop_diyform_temp` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_diyform_temp` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_diyform_temp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_diyform_type`
--

DROP TABLE IF EXISTS `ims_ewei_shop_diyform_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_diyform_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `cate` int(11) DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `fields` text NOT NULL,
  `usedata` int(11) NOT NULL DEFAULT '0',
  `alldata` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) DEFAULT '1',
  `savedata` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_cate` (`cate`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_diyform_type`
--

LOCK TABLES `ims_ewei_shop_diyform_type` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_diyform_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_diyform_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_diypage`
--

DROP TABLE IF EXISTS `ims_ewei_shop_diypage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_diypage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `data` longtext NOT NULL,
  `createtime` int(11) NOT NULL DEFAULT '0',
  `lastedittime` int(11) NOT NULL DEFAULT '0',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `diymenu` int(11) NOT NULL DEFAULT '0',
  `merch` int(11) NOT NULL DEFAULT '0',
  `diyadv` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_type` (`type`),
  KEY `idx_keyword` (`keyword`),
  KEY `idx_lastedittime` (`lastedittime`),
  KEY `idx_createtime` (`createtime`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_diypage`
--

LOCK TABLES `ims_ewei_shop_diypage` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_diypage` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_diypage` VALUES (19,6,2,'我的首页','eyJwYWdlIjp7InR5cGUiOiIyIiwidGl0bGUiOiJcdTk5OTZcdTk4NzUiLCJuYW1lIjoiXHU2MjExXHU3Njg0XHU5OTk2XHU5ODc1IiwiZGVzYyI6Ilx1OTk5Nlx1OTg3NSIsImljb24iOiIiLCJrZXl3b3JkIjoiXHU5OTk2XHU5ODc1IiwiYmFja2dyb3VuZCI6IiNmYWZhZmEiLCJkaXltZW51IjoiLTEiLCJkaXlsYXllciI6IjAiLCJkaXlnb3RvcCI6IjAiLCJmb2xsb3diYXIiOiIwIiwidmlzaXQiOiIwIiwidmlzaXRsZXZlbCI6eyJtZW1iZXIiOiIiLCJjb21taXNzaW9uIjoiIn0sIm5vdmlzaXQiOnsidGl0bGUiOiIiLCJsaW5rIjoiIn19LCJpdGVtcyI6eyJNMTUwNDYxODE2NzM1MSI6eyJpc3RvcCI6IjEiLCJtYXgiOiIxIiwicGFyYW1zIjp7ImxlZnRuYXYiOiIxIiwicmlnaHRuYXYiOiIxIiwibGVmdG5hdmljb24iOiJpY29uLXNob3AiLCJyaWdodG5hdmljb24iOiJpY29uLWNhcnQiLCJzZWFyY2hzdHlsZSI6InJvdW5kIiwicGxhY2Vob2xkZXIiOiJcdThmOTNcdTUxNjVcdTUxNzNcdTk1MmVcdTViNTdcdThmZGJcdTg4NGNcdTY0MWNcdTdkMjIifSwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiMwMDAwMDAiLCJvcGFjaXR5IjoiMC44Iiwib3BhY2l0eWlucHV0IjoiMC44IiwibGVmdG5hdmNvbG9yIjoiI2ZmZmZmZiIsInJpZ2h0bmF2Y29sb3IiOiIjZmZmZmZmIiwic2VhcmNoYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJzZWFyY2h0ZXh0Y29sb3IiOiIjNjY2NjY2In0sImlkIjoiZml4ZWRzZWFyY2gifSwiTTE1MDQ2MTgxMTkwMzAiOnsicGFyYW1zIjp7Imljb251cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvaG90ZG90LmpwZyIsIm5vdGljZWRhdGEiOiIwIiwic3BlZWQiOiI0Iiwibm90aWNlbnVtIjoiNSJ9LCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsImljb25jb2xvciI6IiNmZDU0NTQiLCJjb2xvciI6IiM2NjY2NjYiLCJib3JkZXJjb2xvciI6IiNlMmUyZTIifSwiZGF0YSI6eyJDMTUwNDYxODExOTAzMCI6eyJ0aXRsZSI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1N2IyY1x1NGUwMFx1Njc2MVx1ODFlYVx1NWI5YVx1NGU0OVx1NTE2Y1x1NTQ0YVx1NzY4NFx1NjgwN1x1OTg5OCIsImxpbmt1cmwiOiIifSwiQzE1MDQ2MTgxMTkwMzEiOnsidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTdiMmNcdTRlOGNcdTY3NjFcdTgxZWFcdTViOWFcdTRlNDlcdTUxNmNcdTU0NGFcdTc2ODRcdTY4MDdcdTk4OTgiLCJsaW5rdXJsIjoiIn19LCJpZCI6Im5vdGljZSJ9LCJNMTUwNDYxODE3Njk2OCI6eyJwYXJhbXMiOnsiZ29vZHN0eXBlIjoiMCIsInNob3d0aXRsZSI6IjEiLCJzaG93cHJpY2UiOiIxIiwic2hvd3RhZyI6IjAiLCJnb29kc2RhdGEiOiIwIiwiY2F0ZWlkIjoiIiwiY2F0ZW5hbWUiOiIiLCJncm91cGlkIjoiIiwiZ3JvdXBuYW1lIjoiIiwiZ29vZHNzb3J0IjoiMCIsImdvb2RzbnVtIjoiNiIsInNob3dpY29uIjoiMSIsImljb25wb3NpdGlvbiI6ImxlZnQgdG9wIiwicHJvZHVjdHByaWNlIjoiMSIsInNob3dwcm9kdWN0cHJpY2UiOiIwIiwic2hvd3NhbGVzIjoiMCIsInByb2R1Y3RwcmljZXRleHQiOiJcdTUzOWZcdTRlZjciLCJzYWxlc3RleHQiOiJcdTk1MDBcdTkxY2YiLCJwcm9kdWN0cHJpY2VsaW5lIjoiMCJ9LCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2ZhZmFmYSIsImxpc3RzdHlsZSI6ImJsb2NrIiwiYnV5c3R5bGUiOiJidXlidG4tMSIsImdvb2RzaWNvbiI6InJlY29tbWFuZCIsInByaWNlY29sb3IiOiIjZWQyODIyIiwicHJvZHVjdHByaWNlY29sb3IiOiIjNzc3Nzc3IiwiaWNvbnBhZGRpbmd0b3AiOiIwIiwiaWNvbnBhZGRpbmdsZWZ0IjoiMCIsImJ1eWJ0bmNvbG9yIjoiI2ZlNTQ1NSIsImljb256b29tIjoiMTAwIiwidGl0bGVjb2xvciI6IiMyNjI2MjYiLCJ0YWdiYWNrZ3JvdW5kIjoiI2ZlNTQ1NSIsInNhbGVzY29sb3IiOiIjNzc3Nzc3In0sImRhdGEiOnsiQzE1MDQ2MTgxNzY5NjgiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMS5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIiLCJiYXJnYWluIjoiMCIsImNyZWRpdCI6IjAiLCJjdHlwZSI6IjEifSwiQzE1MDQ2MTgxNzY5NjkiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMi5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIiLCJiYXJnYWluIjoiMCIsImNyZWRpdCI6IjAiLCJjdHlwZSI6IjEifSwiQzE1MDQ2MTgxNzY5NzAiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMy5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIiLCJiYXJnYWluIjoiMCIsImNyZWRpdCI6IjAiLCJjdHlwZSI6IjAifSwiQzE1MDQ2MTgxNzY5NzEiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtNC5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIiLCJiYXJnYWluIjoiMCIsImNyZWRpdCI6IjAiLCJjdHlwZSI6IjAifX0sImlkIjoiZ29vZHMifSwiTTE1MDQ2MTgxODI4MTkiOnsicGFyYW1zIjp7Im1lcmNoZGF0YSI6IjAiLCJtZXJjaG51bSI6IjYiLCJtZXJjaHNvcnQiOiIiLCJjYXRlbmFtZSI6IiIsImNhdGVpZCI6IiIsImdyb3VwbmFtZSI6IiIsImdyb3VwaWQiOiIiLCJvcGVubG9jYXRpb24iOiIwIn0sInN0eWxlIjp7ImJhY2tncm91bmQiOiIjZmZmZmZmIiwidGl0bGVjb2xvciI6IiMzMzMzMzMiLCJ0ZXh0Y29sb3IiOiIjNjY2NjY2IiwicmFuZ2Vjb2xvciI6IiMwMDgwMDAiLCJsb2NhdGlvbmNvbG9yIjoiI2ZmOTkwMCIsIm1hcmdpbnRvcCI6IjEwIn0sImRhdGEiOnsiQzE1MDQ2MTgxODI4MTkiOnsibmFtZSI6Ilx1NTU0Nlx1NjIzN1x1NTQwZFx1NzlmMEEiLCJkZXNjIjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU1NTQ2XHU2MjM3QVx1NzY4NFx1NGVjYlx1N2VjZCIsInRodW1iIjoiIiwibWVyY2hpZCI6IiJ9LCJDMTUwNDYxODE4MjgyMCI6eyJuYW1lIjoiXHU1NTQ2XHU2MjM3XHU1NDBkXHU3OWYwQiIsImRlc2MiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTYyMzdCXHU3Njg0XHU0ZWNiXHU3ZWNkIiwidGh1bWIiOiIiLCJtZXJjaGlkIjoiIn0sIkMxNTA0NjE4MTgyODIxIjp7Im5hbWUiOiJcdTU1NDZcdTYyMzdcdTU0MGRcdTc5ZjBDIiwiZGVzYyI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1NTU0Nlx1NjIzN0NcdTc2ODRcdTRlY2JcdTdlY2QiLCJ0aHVtYiI6IiIsIm1lcmNoaWQiOiIifX0sImlkIjoibWVyY2hncm91cCJ9LCJNMTUwNDYxODE4ODMyNyI6eyJtYXgiOiIyIiwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJjb2xvciI6IiM2NjY2NjYiLCJhY3RpdmViYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsImFjdGl2ZWNvbG9yIjoiI2VmNGY0ZiIsInNjcm9sbG51bSI6IjMifSwiZGF0YSI6eyJDMTUwNDYxODE4ODMyNyI6eyJ0ZXh0IjoiXHU5MDA5XHU5ODc5XHU1MzYxXHU2NTg3XHU1YjU3IiwibGlua3VybCI6IiJ9LCJDMTUwNDYxODE4ODMyOCI6eyJ0ZXh0IjoiXHU5MDA5XHU5ODc5XHU1MzYxXHU2NTg3XHU1YjU3IiwibGlua3VybCI6IiJ9fSwiaWQiOiJ0YWJiYXIifSwiTTE1MDQ2MTgxOTE0NzAiOnsic3R5bGUiOnsibWFyZ2ludG9wIjoiMTAiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsImljb25jb2xvciI6IiM5OTk5OTkiLCJ0ZXh0Y29sb3IiOiIjMzMzMzMzIiwicmVtYXJrY29sb3IiOiIjODg4ODg4In0sImRhdGEiOnsiQzE1MDQ2MTgxOTE0NzAiOnsidGV4dCI6Ilx1NjU4N1x1NWI1NzEiLCJsaW5rdXJsIjoiIiwiaWNvbmNsYXNzIjoiaWNvbi1ob21lIiwicmVtYXJrIjoiXHU2N2U1XHU3NzBiIiwiZG90bnVtIjoiIn0sIkMxNTA0NjE4MTkxNDcxIjp7InRleHQiOiJcdTY1ODdcdTViNTcyIiwibGlua3VybCI6IiIsImljb25jbGFzcyI6Imljb24taG9tZSIsInJlbWFyayI6Ilx1NjdlNVx1NzcwYiIsImRvdG51bSI6IiJ9LCJDMTUwNDYxODE5MTQ3MiI6eyJ0ZXh0IjoiXHU2NTg3XHU1YjU3MyIsImxpbmt1cmwiOiIiLCJpY29uY2xhc3MiOiJpY29uLWhvbWUiLCJyZW1hcmsiOiJcdTY3ZTVcdTc3MGIiLCJkb3RudW0iOiIifX0sImlkIjoibGlzdG1lbnUifSwiTTE1MDQ2MTgxOTM0NTAiOnsicGFyYW1zIjp7ImNvbnRlbnQiOiIifSwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJwYWRkaW5nIjoiMCJ9LCJpZCI6InJpY2h0ZXh0In0sIk0xNTA0NjE4MTk2MzExIjp7InBhcmFtcyI6eyJ0aXRsZSI6IiIsImljb24iOiIifSwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJjb2xvciI6IiM2NjY2NjYiLCJ0ZXh0YWxpZ24iOiJsZWZ0IiwiZm9udHNpemUiOiIxMiIsInBhZGRpbmd0b3AiOiI1IiwicGFkZGluZ2xlZnQiOiI1In0sImlkIjoidGl0bGUifSwiTTE1MDQ2MTgxOTc5NTkiOnsic3R5bGUiOnsiaGVpZ2h0IjoiMiIsImJhY2tncm91bmQiOiIjZmZmZmZmIiwiYm9yZGVyIjoiIzAwMDAwMCIsInBhZGRpbmciOiIxMCIsImxpbmVzdHlsZSI6InNvbGlkIn0sImlkIjoibGluZSJ9LCJNMTUwNDYxODIwMTg5MCI6eyJzdHlsZSI6eyJoZWlnaHQiOiIyMCIsImJhY2tncm91bmQiOiIjZmZmZmZmIn0sImlkIjoiYmxhbmsifSwiTTE1MDQ2MTgyMDM5MjciOnsic3R5bGUiOnsibmF2c3R5bGUiOiIiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsInJvd251bSI6IjQiLCJzaG93dHlwZSI6IjAiLCJwYWdlbnVtIjoiOCIsInNob3dkb3QiOiIxIn0sImRhdGEiOnsiQzE1MDQ2MTgyMDM5MjciOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2ljb24tMS5wbmciLCJsaW5rdXJsIjoiIiwidGV4dCI6Ilx1NjMwOVx1OTRhZVx1NjU4N1x1NWI1NzEiLCJjb2xvciI6IiM2NjY2NjYifSwiQzE1MDQ2MTgyMDM5MjgiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2ljb24tMi5wbmciLCJsaW5rdXJsIjoiIiwidGV4dCI6Ilx1NjMwOVx1OTRhZVx1NjU4N1x1NWI1NzIiLCJjb2xvciI6IiM2NjY2NjYifSwiQzE1MDQ2MTgyMDM5MjkiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2ljb24tMy5wbmciLCJsaW5rdXJsIjoiIiwidGV4dCI6Ilx1NjMwOVx1OTRhZVx1NjU4N1x1NWI1NzMiLCJjb2xvciI6IiM2NjY2NjYifSwiQzE1MDQ2MTgyMDM5MzAiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2ljb24tNC5wbmciLCJsaW5rdXJsIjoiIiwidGV4dCI6Ilx1NjMwOVx1OTRhZVx1NjU4N1x1NWI1NzQiLCJjb2xvciI6IiM2NjY2NjYifX0sImlkIjoibWVudSJ9LCJNMTUwNDYxODIwNjYzMyI6eyJzdHlsZSI6eyJtYXJnaW50b3AiOiIxMCIsImJhY2tncm91bmQiOiIjZmZmZmZmIn0sImRhdGEiOnsiQzE1MDQ2MTgyMDY2MzMiOnsidGV4dCI6Ilx1NjIxMVx1NzY4NFx1NzllZlx1NTIwNiIsImljb25jbGFzcyI6IiIsInRleHRjb2xvciI6IiM2NjY2NjYiLCJpY29uY29sb3IiOiIjNjY2NjY2IiwibGlua3VybCI6IiJ9LCJDMTUwNDYxODIwNjYzNCI6eyJ0ZXh0IjoiXHU1MTUxXHU2MzYyXHU4YmIwXHU1ZjU1IiwiaWNvbmNsYXNzIjoiIiwidGV4dGNvbG9yIjoiIzY2NjY2NiIsImljb25jb2xvciI6IiM2NjY2NjYiLCJsaW5rdXJsIjoiIn19LCJpZCI6Im1lbnUyIn0sIk0xNTA0NjE4MjA4NDcyIjp7InN0eWxlIjp7InBhZGRpbmd0b3AiOiIwIiwicGFkZGluZ2xlZnQiOiIwIn0sImRhdGEiOnsiQzE1MDQ2MTgyMDg0NzMiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0xLmpwZyIsImxpbmt1cmwiOiIifSwiQzE1MDQ2MTgyMDg0NzQiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0yLmpwZyIsImxpbmt1cmwiOiIifX0sImlkIjoicGljdHVyZSJ9LCJNMTUwNDYxODIxMTE4OSI6eyJzdHlsZSI6eyJkb3RzdHlsZSI6InJlY3RhbmdsZSIsImRvdGFsaWduIjoibGVmdCIsImJhY2tncm91bmQiOiIjZmZmZmZmIiwibGVmdHJpZ2h0IjoiNSIsImJvdHRvbSI6IjUiLCJvcGFjaXR5IjoiMC44In0sImRhdGEiOnsiQzE1MDQ2MTgyMTExODkiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0xLmpwZyIsImxpbmt1cmwiOiIifSwiQzE1MDQ2MTgyMTExOTAiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0yLmpwZyIsImxpbmt1cmwiOiIifX0sImlkIjoiYmFubmVyIn0sIk0xNTA0NjE4MjE0MTkwIjp7InBhcmFtcyI6eyJyb3ciOiIxIiwic2hvd3R5cGUiOiIwIiwicGFnZW51bSI6IjIifSwic3R5bGUiOnsicGFkZGluZ3RvcCI6IjAiLCJwYWRkaW5nbGVmdCI6IjAiLCJzaG93ZG90IjoiMCIsInNob3didG4iOiIwIn0sImRhdGEiOnsiQzE1MDQ2MTgyMTQxOTAiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0xLmpwZyIsImxpbmt1cmwiOiIifSwiQzE1MDQ2MTgyMTQxOTEiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0yLmpwZyIsImxpbmt1cmwiOiIifSwiQzE1MDQ2MTgyMTQxOTIiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0xLmpwZyIsImxpbmt1cmwiOiIifSwiQzE1MDQ2MTgyMTQxOTMiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0yLmpwZyIsImxpbmt1cmwiOiIifX0sImlkIjoicGljdHVyZXcifSwiTTE1MDQ2MTgyMTc3MzciOnsicGFyYW1zIjp7ImhpZGV0ZXh0IjoiMCIsInNob3d0eXBlIjoiMCIsInJvd251bSI6IjMiLCJzaG93YnRuIjoiMCJ9LCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsInBhZGRpbmd0b3AiOiIzIiwicGFkZGluZ2xlZnQiOiI1IiwidGl0bGVhbGlnbiI6ImxlZnQiLCJ0ZXh0YWxpZ24iOiJsZWZ0IiwidGl0bGVjb2xvciI6IiNmZmZmZmYiLCJ0ZXh0Y29sb3IiOiIjNjY2NjY2In0sImRhdGEiOnsiQzE1MDQ2MTgyMTc3MzciOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL21vdmllLXBvc3Rlci5qcGciLCJsaW5rdXJsIjoiIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTRlMGFcdTY4MDdcdTk4OTgiLCJ0ZXh0IjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU0ZTBiXHU2ODA3XHU5ODk4In0sIkMxNTA0NjE4MjE3NzM5Ijp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvaW1hZ2VzXC9kZWZhdWx0XC9tb3ZpZS1wb3N0ZXIuanBnIiwibGlua3VybCI6IiIsInRpdGxlIjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU0ZTBhXHU2ODA3XHU5ODk4IiwidGV4dCI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1NGUwYlx1NjgwN1x1OTg5OCJ9LCJDMTUwNDYxODIxNzc0MCI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvbW92aWUtcG9zdGVyLmpwZyIsImxpbmt1cmwiOiIiLCJ0aXRsZSI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1NGUwYVx1NjgwN1x1OTg5OCIsInRleHQiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTRlMGJcdTY4MDdcdTk4OTgifX0sImlkIjoicGljdHVyZXMifSwiTTE1MDQ2MTgyMjAxMDQiOnsicGFyYW1zIjp7InJvd251bSI6IjQiLCJib3JkZXIiOiIxIiwiYm9yZGVydG9wIjoiMSIsImJvcmRlcmJvdHRvbSI6IjEifSwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJib3JkZXJjb2xvciI6IiNlYmViZWIiLCJ0ZXh0Y29sb3IiOiIjN2E3YTdhIiwiaWNvbmNvbG9yIjoiI2FhYWFhYSIsImRvdGNvbG9yIjoiI2ZmMDAxMSJ9LCJkYXRhIjp7IkMxNTA0NjE4MjIwMTA0Ijp7Imljb25jbGFzcyI6Imljb24tY2FyZCIsInRleHQiOiJcdTVmODVcdTRlZDhcdTZiM2UiLCJsaW5rdXJsIjoiIiwiZG90bnVtIjoiMCJ9LCJDMTUwNDYxODIyMDEwNSI6eyJpY29uY2xhc3MiOiJpY29uLWJveCIsInRleHQiOiJcdTVmODVcdTUzZDFcdThkMjciLCJsaW5rdXJsIjoiIiwiZG90bnVtIjoiMCJ9LCJDMTUwNDYxODIyMDEwNiI6eyJpY29uY2xhc3MiOiJpY29uLWRlbGl2ZXIiLCJ0ZXh0IjoiXHU1Zjg1XHU2NTM2XHU4ZDI3IiwibGlua3VybCI6IiIsImRvdG51bSI6IjAifSwiQzE1MDQ2MTgyMjAxMDciOnsiaWNvbmNsYXNzIjoiaWNvbi1lbGVjdHJpY2FsIiwidGV4dCI6Ilx1OTAwMFx1NjM2Mlx1OGQyNyIsImxpbmt1cmwiOiIiLCJkb3RudW0iOiIwIn19LCJpZCI6Imljb25ncm91cCJ9LCJNMTUwNDYxODIyMjI3OCI6eyJwYXJhbXMiOnsidGl0bGUiOiJcdTY3MmFcdTViOWFcdTRlNDlcdTk3ZjNcdTk4OTFcdTRmZTFcdTYwNmYiLCJzdWJ0aXRsZSI6Ilx1NTI2Zlx1NjgwN1x1OTg5OCIsInBsYXllcnN0eWxlIjoiMCIsImF1dG9wbGF5IjoiMCIsImxvb3BwbGF5IjoiMCIsInBhdXNlc3RvcCI6IjAiLCJoZWFkYWxpZ24iOiJsZWZ0IiwiaGVhZHR5cGUiOiIiLCJoZWFkdXJsIjoiIn0sInN0eWxlIjp7ImJhY2tncm91bmQiOiIjZjFmMWYxIiwiYm9yZGVyY29sb3IiOiIjZWRlZGVkIiwidGV4dGNvbG9yIjoiIzMzMzMzMyIsInN1YnRpdGxlY29sb3IiOiIjNjY2NjY2IiwidGltZWNvbG9yIjoiIzY2NjY2NiIsInBhZGRpbmd0b3AiOiIyMCIsInBhZGRpbmdsZWZ0IjoiMjAiLCJ3aWR0aCI6IjgwIn0sImlkIjoiYXVkaW8ifSwiTTE1MDQ2MTgyMjMyMjIiOnsicGFyYW1zIjp7ImNvdXBvbnN0eWxlIjoiMyJ9LCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsIm1hcmdpbnRvcCI6IjEwIiwibWFyZ2lubGVmdCI6IjUifSwiZGF0YSI6eyJDMTUwNDYxODIyMzIyMiI6eyJuYW1lIjoiXHU0ZjE4XHU2MGUwXHU1MjM4XHU1NDBkXHU3OWYwIiwiZGVzYyI6Ilx1NmVlMTEwMFx1NTE0M1x1NTNlZlx1NzUyOCIsInByaWNlIjoiXHVmZmU1ODkuOTAiLCJjb3Vwb25pZCI6IiIsImJhY2tncm91bmQiOiIjZmZlYWVjIiwiYm9yZGVyY29sb3IiOiIjZmY5M2IyIiwidGV4dGNvbG9yIjoiI2ZhNTI2MiJ9LCJDMTUwNDYxODIyMzIyMyI6eyJuYW1lIjoiXHU0ZjE4XHU2MGUwXHU1MjM4XHU1NDBkXHU3OWYwIiwiZGVzYyI6Ilx1NmVlMTEwMFx1NTE0M1x1NTNlZlx1NzUyOCIsInByaWNlIjoiXHVmZmU1ODkuOTAiLCJjb3Vwb25pZCI6IiIsImJhY2tncm91bmQiOiIjZjNmZmVmIiwiYm9yZGVyY29sb3IiOiIjOThlMjdmIiwidGV4dGNvbG9yIjoiIzdhY2Y4ZCJ9LCJDMTUwNDYxODIyMzIyNCI6eyJuYW1lIjoiXHU0ZjE4XHU2MGUwXHU1MjM4XHU1NDBkXHU3OWYwIiwiZGVzYyI6Ilx1NmVlMTEwMFx1NTE0M1x1NTNlZlx1NzUyOCIsInByaWNlIjoiXHVmZmU1ODkuOTAiLCJjb3Vwb25pZCI6IiIsImJhY2tncm91bmQiOiIjZmZlYWUzIiwiYm9yZGVyY29sb3IiOiIjZmZhNDkyIiwidGV4dGNvbG9yIjoiI2ZmOTY2NCJ9fSwiaWQiOiJjb3Vwb24ifSwiTTE1MDQ2MTgxMjY1NjUiOnsicGFyYW1zIjp7InBsYWNlaG9sZGVyIjoiXHU4YmY3XHU4ZjkzXHU1MTY1XHU1MTczXHU5NTJlXHU1YjU3XHU4ZmRiXHU4ODRjXHU2NDFjXHU3ZDIyIn0sInN0eWxlIjp7ImlucHV0YmFja2dyb3VuZCI6IiNmZmZmZmYiLCJiYWNrZ3JvdW5kIjoiI2YxZjFmMiIsImljb25jb2xvciI6IiNiNGI0YjQiLCJjb2xvciI6IiM5OTk5OTkiLCJwYWRkaW5ndG9wIjoiMTAiLCJwYWRkaW5nbGVmdCI6IjEwIiwidGV4dGFsaWduIjoibGVmdCIsInNlYXJjaHN0eWxlIjoiIn0sImlkIjoic2VhcmNoIn19fQ==',1504618368,1504618368,'首页',-1,0,0);
/*!40000 ALTER TABLE `ims_ewei_shop_diypage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_diypage_menu`
--

DROP TABLE IF EXISTS `ims_ewei_shop_diypage_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_diypage_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  `createtime` int(11) NOT NULL DEFAULT '0',
  `lastedittime` int(11) NOT NULL DEFAULT '0',
  `merch` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_createtime` (`createtime`),
  KEY `idx_lastedittime` (`lastedittime`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_diypage_menu`
--

LOCK TABLES `ims_ewei_shop_diypage_menu` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_diypage_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_diypage_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_diypage_plu`
--

DROP TABLE IF EXISTS `ims_ewei_shop_diypage_plu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_diypage_plu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  `createtime` int(11) NOT NULL DEFAULT '0',
  `lastedittime` int(11) NOT NULL DEFAULT '0',
  `merch` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_createtime` (`createtime`) USING BTREE,
  KEY `idx_lastedittime` (`lastedittime`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_diypage_plu`
--

LOCK TABLES `ims_ewei_shop_diypage_plu` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_diypage_plu` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_diypage_plu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_diypage_template`
--

DROP TABLE IF EXISTS `ims_ewei_shop_diypage_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_diypage_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `type` tinyint(3) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `data` longtext NOT NULL,
  `preview` varchar(255) NOT NULL DEFAULT '',
  `tplid` int(11) DEFAULT '0',
  `cate` int(11) DEFAULT '0',
  `deleted` tinyint(3) DEFAULT '0',
  `merch` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_type` (`type`),
  KEY `idx_cate` (`cate`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_diypage_template`
--

LOCK TABLES `ims_ewei_shop_diypage_template` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_diypage_template` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_diypage_template` VALUES (1,0,2,'系统模板01','eyJwYWdlIjp7InR5cGUiOiIyIiwidGl0bGUiOiJcdTMwMTBcdTZhMjFcdTY3N2ZcdTMwMTFcdTdjZmJcdTdlZGZcdTZhMjFcdTY3N2YwMSIsIm5hbWUiOiJcdTMwMTBcdTZhMjFcdTY3N2ZcdTMwMTFcdTdjZmJcdTdlZGZcdTZhMjFcdTY3N2YwMSIsImRlc2MiOiIiLCJpY29uIjoiIiwia2V5d29yZCI6IiIsImJhY2tncm91bmQiOiIjZmFmYWZhIiwiZGl5bWVudSI6Ii0xIn0sIml0ZW1zIjp7Ik0xNDY1ODAyOTg0ODg1Ijp7InN0eWxlIjp7ImRvdHN0eWxlIjoicm91bmQiLCJkb3RhbGlnbiI6ImNlbnRlciIsImJhY2tncm91bmQiOiIjZmZmZmZmIiwibGVmdHJpZ2h0IjoiNSIsImJvdHRvbSI6IjEwIiwib3BhY2l0eSI6IjAuOCJ9LCJkYXRhIjp7IkMxNDY1ODAyOTg0ODg1Ijp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQxXC9iYW5uZXJfMS5qcGciLCJsaW5rdXJsIjoiIn0sIkMxNDY1ODAyOTg0ODg2Ijp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQxXC9iYW5uZXJfMi5qcGciLCJsaW5rdXJsIjoiIn0sIk0xNDY1ODAzMDE0ODM3Ijp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQxXC9iYW5uZXJfMy5qcGciLCJsaW5rdXJsIjoiIn19LCJpZCI6ImJhbm5lciJ9LCJNMTQ2NTgwMzY5MjkzMiI6eyJzdHlsZSI6eyJoZWlnaHQiOiIxMCIsImJhY2tncm91bmQiOiIjZmZmZmZmIn0sImlkIjoiYmxhbmsifSwiTTE0NjU4MDMzMTk4NTMiOnsic3R5bGUiOnsibmF2c3R5bGUiOiIiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsInJvd251bSI6IjUifSwiZGF0YSI6eyJDMTQ2NTgwMzMxOTg1MyI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0MVwvbWVudV8xLnBuZyIsImxpbmt1cmwiOiIiLCJ0ZXh0IjoiXHU2NWIwXHU1NGMxIiwiY29sb3IiOiIjNjY2NjY2In0sIkMxNDY1ODAzMzE5ODU0Ijp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQxXC9tZW51XzIucG5nIiwibGlua3VybCI6IiIsInRleHQiOiJcdTcwZWRcdTUzNTYiLCJjb2xvciI6IiM2NjY2NjYifSwiQzE0NjU4MDMzMTk4NTUiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDFcL21lbnVfMy5wbmciLCJsaW5rdXJsIjoiIiwidGV4dCI6Ilx1NGZjM1x1OTUwMCIsImNvbG9yIjoiIzY2NjY2NiJ9LCJDMTQ2NTgwMzMxOTg1NiI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0MVwvbWVudV80LnBuZyIsImxpbmt1cmwiOiIiLCJ0ZXh0IjoiXHU4YmEyXHU1MzU1IiwiY29sb3IiOiIjNjY2NjY2In0sIk0xNDY1ODAzMzQ3MDQ1Ijp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQxXC9tZW51XzUucG5nIiwibGlua3VybCI6IiIsInRleHQiOiJcdTdiN2VcdTUyMzAiLCJjb2xvciI6IiM2NjY2NjYifX0sImlkIjoibWVudSJ9LCJNMTQ2NTgwMzM1OTEwMCI6eyJzdHlsZSI6eyJuYXZzdHlsZSI6IiIsImJhY2tncm91bmQiOiIjZmZmZmZmIiwicm93bnVtIjoiNSJ9LCJkYXRhIjp7IkMxNDY1ODAzMzU5MTAwIjp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQxXC9tZW51XzYucG5nIiwibGlua3VybCI6IiIsInRleHQiOiJcdTRlMGFcdTg4NjMiLCJjb2xvciI6IiM2NjY2NjYifSwiQzE0NjU4MDMzNTkxMDEiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDFcL21lbnVfNy5wbmciLCJsaW5rdXJsIjoiIiwidGV4dCI6Ilx1NGUwYlx1ODg2MyIsImNvbG9yIjoiIzY2NjY2NiJ9LCJDMTQ2NTgwMzM1OTEwMiI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0MVwvbWVudV84LnBuZyIsImxpbmt1cmwiOiIiLCJ0ZXh0IjoiXHU5NzhiXHU1YjUwIiwiY29sb3IiOiIjNjY2NjY2In0sIkMxNDY1ODAzMzU5MTAzIjp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQxXC9tZW51XzkucG5nIiwibGlua3VybCI6IiIsInRleHQiOiJcdTUxODVcdTg4NjMiLCJjb2xvciI6IiM2NjY2NjYifSwiTTE0NjU4MDM0NTA4MjciOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDFcL21lbnVfMTAucG5nIiwibGlua3VybCI6IiIsInRleHQiOiJcdTUxNjhcdTkwZTgiLCJjb2xvciI6IiM2NjY2NjYifX0sImlkIjoibWVudSJ9LCJNMTQ2NTgwMzcwMDEzMiI6eyJzdHlsZSI6eyJoZWlnaHQiOiIxMCIsImJhY2tncm91bmQiOiIjZmZmZmZmIn0sImlkIjoiYmxhbmsifSwiTTE0NjU4MDM2MjE5ODAiOnsicGFyYW1zIjp7Imljb251cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2Mlwvc3RhdGljXC9pbWFnZXNcL2hvdGRvdC5qcGciLCJub3RpY2VkYXRhIjoiMSIsInNwZWVkIjoiNCIsIm5vdGljZW51bSI6IjUifSwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJpY29uY29sb3IiOiIjZmQ1NDU0IiwiY29sb3IiOiIjNjY2NjY2In0sImRhdGEiOnsiQzE0NjU4MDM2MjE5ODAiOnsidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTdiMmNcdTRlMDBcdTY3NjFcdTgxZWFcdTViOWFcdTRlNDlcdTUxNmNcdTU0NGFcdTc2ODRcdTY4MDdcdTk4OTgiLCJsaW5rdXJsIjoiaHR0cDpcL1wvd3d3LmJhaWR1LmNvbSJ9LCJDMTQ2NTgwMzYyMTk4MSI6eyJ0aXRsZSI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1N2IyY1x1NGU4Y1x1Njc2MVx1ODFlYVx1NWI5YVx1NGU0OVx1NTE2Y1x1NTQ0YVx1NzY4NFx1NjgwN1x1OTg5OCIsImxpbmt1cmwiOiJodHRwOlwvXC93d3cuYmFpZHUuY29tIn19LCJpZCI6Im5vdGljZSJ9LCJNMTQ2NTgwMzkzMjQ2MCI6eyJwYXJhbXMiOnsicm93IjoiMiJ9LCJkYXRhIjp7IkMxNDY1ODAzOTMyNDYwIjp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQxXC9waWN0dXJld18xLmpwZyIsImxpbmt1cmwiOiIifSwiQzE0NjU4MDM5MzI0NjMiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDFcL3BpY3R1cmV3XzIuanBnIiwibGlua3VybCI6IiJ9fSwiaWQiOiJwaWN0dXJldyIsInN0eWxlIjp7InBhZGRpbmd0b3AiOiIxNiIsInBhZGRpbmdsZWZ0IjoiNCJ9fSwiTTE0NjU4MDQwMjU1MDgiOnsicGFyYW1zIjp7InRpdGxlIjoiXHU2NWIwXHU1NGMxXHU0ZTBhXHU1ZTAyIiwiaWNvbiI6Imljb24tbmV3In0sInN0eWxlIjp7ImJhY2tncm91bmQiOiIjZmZmZmZmIiwiY29sb3IiOiIjZjA2MjkyIiwidGV4dGFsaWduIjoiY2VudGVyIiwiZm9udHNpemUiOiIxOCIsInBhZGRpbmd0b3AiOiI1IiwicGFkZGluZ2xlZnQiOiI1In0sImlkIjoidGl0bGUifSwiTTE0NjU4MTMzNjgwODUiOnsicGFyYW1zIjp7InNob3d0aXRsZSI6IjEiLCJzaG93cHJpY2UiOiIxIiwiZ29vZHNkYXRhIjoiMCIsImNhdGVpZCI6IiIsImNhdGVuYW1lIjoiIiwiZ3JvdXBpZCI6IiIsImdyb3VwbmFtZSI6IiIsImdvb2Rzc29ydCI6IjAiLCJnb29kc251bSI6IjYiLCJzaG93aWNvbiI6IjAiLCJpY29ucG9zaXRpb24iOiJsZWZ0IHRvcCJ9LCJzdHlsZSI6eyJsaXN0c3R5bGUiOiJibG9jayIsImJ1eXN0eWxlIjoiYnV5YnRuLTEiLCJnb29kc2ljb24iOiJyZWNvbW1hbmQiLCJwcmljZWNvbG9yIjoiI2VkMjgyMiIsImljb25wYWRkaW5ndG9wIjoiMCIsImljb25wYWRkaW5nbGVmdCI6IjAiLCJidXlidG5jb2xvciI6IiNmZTU0NTUiLCJpY29uem9vbSI6IjEwMCIsInRpdGxlY29sb3IiOiIjMjYyNjI2In0sImRhdGEiOnsiQzE0NjU4MTMzNjgwODUiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMS5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIifSwiQzE0NjU4MTMzNjgwODYiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMi5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIifSwiQzE0NjU4MTMzNjgwODciOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMy5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIifSwiQzE0NjU4MTMzNjgwODgiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtNC5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIifX0sImlkIjoiZ29vZHMifSwiTTE0NjU4MDU4MjEwNjciOnsicGFyYW1zIjp7InRpdGxlIjoiXHU3MGVkXHU1MzU2XHU1NTQ2XHU1NGMxIiwiaWNvbiI6Imljb24taG90In0sInN0eWxlIjp7ImJhY2tncm91bmQiOiIjZmZmZmZmIiwiY29sb3IiOiIjZmFjMDQyIiwidGV4dGFsaWduIjoiY2VudGVyIiwiZm9udHNpemUiOiIxOCIsInBhZGRpbmd0b3AiOiI1IiwicGFkZGluZ2xlZnQiOiI1In0sImlkIjoidGl0bGUifSwiTTE0NjU4MTMzNzY4OTIiOnsicGFyYW1zIjp7InNob3d0aXRsZSI6IjEiLCJzaG93cHJpY2UiOiIxIiwiZ29vZHNkYXRhIjoiMCIsImNhdGVpZCI6IiIsImNhdGVuYW1lIjoiIiwiZ3JvdXBpZCI6IiIsImdyb3VwbmFtZSI6IiIsImdvb2Rzc29ydCI6IjAiLCJnb29kc251bSI6IjYiLCJzaG93aWNvbiI6IjEiLCJpY29ucG9zaXRpb24iOiJsZWZ0IHRvcCJ9LCJzdHlsZSI6eyJsaXN0c3R5bGUiOiJibG9jayIsImJ1eXN0eWxlIjoiYnV5YnRuLTEiLCJnb29kc2ljb24iOiJyZWNvbW1hbmQiLCJwcmljZWNvbG9yIjoiI2VkMjgyMiIsImljb25wYWRkaW5ndG9wIjoiMCIsImljb25wYWRkaW5nbGVmdCI6IjAiLCJidXlidG5jb2xvciI6IiNmZTU0NTUiLCJpY29uem9vbSI6IjEwMCIsInRpdGxlY29sb3IiOiIjMjYyNjI2In0sImRhdGEiOnsiQzE0NjU4MTMzNzY4OTIiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMS5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIifSwiQzE0NjU4MTMzNzY4OTMiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMi5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIifSwiQzE0NjU4MTMzNzY4OTQiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMy5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIifSwiQzE0NjU4MTMzNzY4OTUiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtNC5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIifX0sImlkIjoiZ29vZHMifX19','../addons/ewei_shopv2/plugin/diypage/static/template/default1/preview.jpg',1,0,0,0),(2,0,1,'系统模板02','eyJwYWdlIjp7InR5cGUiOiIxIiwidGl0bGUiOiJcdTMwMTBcdTZhMjFcdTY3N2ZcdTMwMTFcdTdjZmJcdTdlZGZcdTZhMjFcdTY3N2YwMiIsIm5hbWUiOiJcdTMwMTBcdTZhMjFcdTY3N2ZcdTMwMTFcdTdjZmJcdTdlZGZcdTZhMjFcdTY3N2YwMiIsImRlc2MiOiIiLCJpY29uIjoiIiwia2V5d29yZCI6IiIsImJhY2tncm91bmQiOiIjZmFmYWZhIiwiZGl5bWVudSI6Ii0xIn0sIml0ZW1zIjp7Ik0xNDY1ODA4NTU2MDAxIjp7InN0eWxlIjp7ImRvdHN0eWxlIjoicm91bmQiLCJkb3RhbGlnbiI6InJpZ2h0IiwiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJsZWZ0cmlnaHQiOiIxMCIsImJvdHRvbSI6IjEwIiwib3BhY2l0eSI6IjAuOCJ9LCJkYXRhIjp7IkMxNDY1ODA4NTU2MDAxIjp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQyXC9iYW5uZXJfMS5qcGciLCJsaW5rdXJsIjoiIn0sIkMxNDY1ODA4NTU2MDAyIjp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQyXC9iYW5uZXJfMi5qcGciLCJsaW5rdXJsIjoiIn0sIk0xNDY1ODA4NTc1MTIyIjp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQyXC9iYW5uZXJfMy5qcGciLCJsaW5rdXJsIjoiIn19LCJpZCI6ImJhbm5lciJ9LCJNMTQ2NTgwODcwNTA2NCI6eyJzdHlsZSI6eyJoZWlnaHQiOiIyMCIsImJhY2tncm91bmQiOiIjZmZmZmZmIn0sImlkIjoiYmxhbmsifSwiTTE0NjU4MDg2NzMwNDAiOnsicGFyYW1zIjp7InJvdyI6IjIifSwiZGF0YSI6eyJDMTQ2NTgwODY3MzA0MCI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0MlwvcGljdHVyZXdfMS5qcGciLCJsaW5rdXJsIjoiIn0sIkMxNDY1ODA4NjczMDQxIjp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQyXC9waWN0dXJld18yLmpwZyIsImxpbmt1cmwiOiIifX0sImlkIjoicGljdHVyZXciLCJzdHlsZSI6eyJwYWRkaW5ndG9wIjoiMCIsInBhZGRpbmdsZWZ0IjoiMCJ9fSwiTTE0NjU4MDg3MDkyODAiOnsic3R5bGUiOnsiaGVpZ2h0IjoiMjAiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiJ9LCJpZCI6ImJsYW5rIn0sIk0xNDY1ODA4NzY2NTY3Ijp7InBhcmFtcyI6eyJyb3ciOiIyIn0sImRhdGEiOnsiQzE0NjU4MDg3NjY1NzAiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDJcL3BpY3R1cmV3XzMuanBnIiwibGlua3VybCI6IiJ9LCJDMTQ2NTgwODc2NjU3MSI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0MlwvcGljdHVyZXdfNC5qcGciLCJsaW5rdXJsIjoiIn19LCJpZCI6InBpY3R1cmV3Iiwic3R5bGUiOnsicGFkZGluZ3RvcCI6IjAiLCJwYWRkaW5nbGVmdCI6IjAifX0sIk0xNDY1ODA4NzkxMDcyIjp7InN0eWxlIjp7ImhlaWdodCI6IjIwIiwiYmFja2dyb3VuZCI6IiNmZmZmZmYifSwiaWQiOiJibGFuayJ9LCJNMTQ2NTgwODg3MDY4MCI6eyJkYXRhIjp7IkMxNDY1ODA4ODcwNjgwIjp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQyXC9iYW5uZXJfMy5qcGciLCJsaW5rdXJsIjoiIn19LCJpZCI6InBpY3R1cmUiLCJzdHlsZSI6eyJwYWRkaW5ndG9wIjoiMCIsInBhZGRpbmdsZWZ0IjoiMCJ9fSwiTTE0NjU4MDkwMTA0MTUiOnsic3R5bGUiOnsiaGVpZ2h0IjoiMjAiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiJ9LCJpZCI6ImJsYW5rIn0sIk0xNDY1ODA4OTgxNTk5Ijp7InBhcmFtcyI6eyJyb3ciOiIyIn0sImRhdGEiOnsiQzE0NjU4MDg5ODE1OTkiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDJcL3BpY3R1cmV3XzUuanBnIiwibGlua3VybCI6IiJ9LCJDMTQ2NTgwODk4MTYwMCI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0MlwvcGljdHVyZXdfNi5qcGciLCJsaW5rdXJsIjoiIn19LCJpZCI6InBpY3R1cmV3Iiwic3R5bGUiOnsicGFkZGluZ3RvcCI6IjAiLCJwYWRkaW5nbGVmdCI6IjAifX0sIk0xNDY1ODg5MzczNTY3Ijp7InBhcmFtcyI6eyJzaG93dGl0bGUiOiIxIiwic2hvd3ByaWNlIjoiMSIsImdvb2RzZGF0YSI6IjAiLCJjYXRlaWQiOiIiLCJjYXRlbmFtZSI6IiIsImdyb3VwaWQiOiIiLCJncm91cG5hbWUiOiIiLCJnb29kc3NvcnQiOiIwIiwiZ29vZHNudW0iOiI2Iiwic2hvd2ljb24iOiIxIiwiaWNvbnBvc2l0aW9uIjoibGVmdCB0b3AifSwic3R5bGUiOnsibGlzdHN0eWxlIjoiYmxvY2siLCJidXlzdHlsZSI6ImJ1eWJ0bi0xIiwiZ29vZHNpY29uIjoicmVjb21tYW5kIiwicHJpY2Vjb2xvciI6IiNlZDI4MjIiLCJpY29ucGFkZGluZ3RvcCI6IjAiLCJpY29ucGFkZGluZ2xlZnQiOiIwIiwiYnV5YnRuY29sb3IiOiIjZmU1NDU1IiwiaWNvbnpvb20iOiIxMDAiLCJ0aXRsZWNvbG9yIjoiIzI2MjYyNiJ9LCJkYXRhIjp7IkMxNDY1ODg5MzczNTY3Ijp7InRodW1iIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2dvb2RzLTEuanBnIiwicHJpY2UiOiIyMC4wMCIsInRpdGxlIjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU1NTQ2XHU1NGMxXHU2ODA3XHU5ODk4IiwiZ2lkIjoiIn0sIkMxNDY1ODg5MzczNTY4Ijp7InRodW1iIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2dvb2RzLTIuanBnIiwicHJpY2UiOiIyMC4wMCIsInRpdGxlIjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU1NTQ2XHU1NGMxXHU2ODA3XHU5ODk4IiwiZ2lkIjoiIn0sIkMxNDY1ODg5MzczNTY5Ijp7InRodW1iIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2dvb2RzLTMuanBnIiwicHJpY2UiOiIyMC4wMCIsInRpdGxlIjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU1NTQ2XHU1NGMxXHU2ODA3XHU5ODk4IiwiZ2lkIjoiIn0sIkMxNDY1ODg5MzczNTcwIjp7InRodW1iIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2dvb2RzLTQuanBnIiwicHJpY2UiOiIyMC4wMCIsInRpdGxlIjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU1NTQ2XHU1NGMxXHU2ODA3XHU5ODk4IiwiZ2lkIjoiIn19LCJpZCI6Imdvb2RzIn0sIk0xNDY1ODg5Mzc3NDIzIjp7InBhcmFtcyI6eyJjb250ZW50IjoiUEhBZ2MzUjViR1U5SW5SbGVIUXRZV3hwWjI0NklHTmxiblJsY2pzaVB1V2J2dWVKaCthZHBlYTZrT1M2anVlOWtlZTduTys4ak9lSmlPYWRnK1c5a3VXT24rUzluT2lBaGVhSmdPYWNpVHd2Y0Q0PSJ9LCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsInBhZGRpbmciOiIyMCJ9LCJpZCI6InJpY2h0ZXh0In19fQ==','../addons/ewei_shopv2/plugin/diypage/static/template/default2/preview.jpg',2,0,0,0),(3,0,2,'系统模板03','eyJwYWdlIjp7InR5cGUiOiIyIiwidGl0bGUiOiJcdTMwMTBcdTZhMjFcdTY3N2ZcdTMwMTFcdTdjZmJcdTdlZGZcdTZhMjFcdTY3N2YwMyIsIm5hbWUiOiJcdTMwMTBcdTZhMjFcdTY3N2ZcdTMwMTFcdTdjZmJcdTdlZGZcdTZhMjFcdTY3N2YwMyIsImRlc2MiOiIiLCJpY29uIjoiIiwia2V5d29yZCI6IiIsImJhY2tncm91bmQiOiIjZmFmYWZhIiwiZGl5bWVudSI6Ii0xIn0sIml0ZW1zIjp7Ik0xNDY1ODA5MjQyOTc2Ijp7InN0eWxlIjp7ImRvdHN0eWxlIjoicm91bmQiLCJkb3RhbGlnbiI6ImxlZnQiLCJiYWNrZ3JvdW5kIjoiIzM0YmVkYyIsImxlZnRyaWdodCI6IjEwIiwiYm90dG9tIjoiMTAiLCJvcGFjaXR5IjoiMC43In0sImRhdGEiOnsiQzE0NjU4MDkyNDI5NzYiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDNcL2Jhbm5lcl8xLmpwZyIsImxpbmt1cmwiOiIifSwiQzE0NjU4MDkyNDI5NzciOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDNcL2Jhbm5lcl8yLmpwZyIsImxpbmt1cmwiOiIifSwiTTE0NjU4MDkyNjU5OTIiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDNcL2Jhbm5lcl8zLmpwZyIsImxpbmt1cmwiOiIifX0sImlkIjoiYmFubmVyIn0sIk0xNDY1ODA5NTQxNTM1Ijp7InBhcmFtcyI6eyJyb3ciOiIxIn0sImRhdGEiOnsiQzE0NjU4MDk1NDE1MzUiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDNcL3BpY3R1cmV3XzEuanBnIiwibGlua3VybCI6IiJ9LCJDMTQ2NTgwOTU0MTUzNiI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0M1wvcGljdHVyZXdfMi5qcGciLCJsaW5rdXJsIjoiIn0sIkMxNDY1ODA5NTQxNTM3Ijp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQzXC9waWN0dXJld18zLmpwZyIsImxpbmt1cmwiOiIifX0sImlkIjoicGljdHVyZXciLCJzdHlsZSI6eyJwYWRkaW5ndG9wIjoiNSIsInBhZGRpbmdsZWZ0IjoiNSIsImJhY2tncm91bmQiOiIjZmFmYWZhIn19LCJNMTQ2NTgwOTc2MzQxNSI6eyJzdHlsZSI6eyJoZWlnaHQiOiI1IiwiYmFja2dyb3VuZCI6IiNmYWZhZmEifSwiaWQiOiJibGFuayJ9LCJNMTQ2NTgwOTcwOTA0MCI6eyJwYXJhbXMiOnsidGl0bGUiOiJcdTY1YjBcdTU0YzFcdTRlMGFcdTVlMDIiLCJpY29uIjoiaWNvbi1uZXcifSwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiMyOGMxOTIiLCJjb2xvciI6IiNmZmZmZmYiLCJ0ZXh0YWxpZ24iOiJsZWZ0IiwiZm9udHNpemUiOiIxOCIsInBhZGRpbmd0b3AiOiI1IiwicGFkZGluZ2xlZnQiOiI1In0sImlkIjoidGl0bGUifSwiTTE0NjU4MDk3OTEyMzEiOnsicGFyYW1zIjp7InNob3d0aXRsZSI6IjEiLCJzaG93cHJpY2UiOiIxIiwiZ29vZHNkYXRhIjoiMCIsImNhdGVpZCI6IiIsImNhdGVuYW1lIjoiIiwiZ3JvdXBpZCI6IiIsImdyb3VwbmFtZSI6IiIsImdvb2Rzc29ydCI6IjAiLCJnb29kc251bSI6IjYiLCJzaG93aWNvbiI6IjAiLCJpY29ucG9zaXRpb24iOiJsZWZ0IHRvcCJ9LCJzdHlsZSI6eyJsaXN0c3R5bGUiOiJibG9jayIsImJ1eXN0eWxlIjoiYnV5YnRuLTMiLCJnb29kc2ljb24iOiJyZWNvbW1hbmQiLCJwcmljZWNvbG9yIjoiIzI4YzE5MiIsImljb25wYWRkaW5ndG9wIjoiMCIsImljb25wYWRkaW5nbGVmdCI6IjAiLCJidXlidG5jb2xvciI6IiMyOGMxOGYiLCJpY29uem9vbSI6IjEwMCIsInRpdGxlY29sb3IiOiIjMjhjMTkyIn0sImRhdGEiOnsiQzE0NjU4MDk3OTEyMzEiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMS5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIifSwiQzE0NjU4MDk3OTEyMzIiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMi5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIifSwiQzE0NjU4MDk3OTEyMzMiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMy5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIifSwiQzE0NjU4MDk3OTEyMzQiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtNC5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIifX0sImlkIjoiZ29vZHMifSwiTTE0NjU4MDk5NTA4NDciOnsicGFyYW1zIjp7InRpdGxlIjoiXHU2MzhjXHU2N2RjXHU2M2E4XHU4MzUwIiwiaWNvbiI6Imljb24tYXBwcmVjaWF0ZSJ9LCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2ZmYmQzMyIsImNvbG9yIjoiI2ZmZmZmZiIsInRleHRhbGlnbiI6InJpZ2h0IiwiZm9udHNpemUiOiIxOCIsInBhZGRpbmd0b3AiOiI1IiwicGFkZGluZ2xlZnQiOiI1In0sImlkIjoidGl0bGUifSwiTTE0NjU4MDk5NDMyMzEiOnsicGFyYW1zIjp7InNob3d0aXRsZSI6IjEiLCJzaG93cHJpY2UiOiIxIiwiZ29vZHNkYXRhIjoiMCIsImNhdGVpZCI6IiIsImNhdGVuYW1lIjoiIiwiZ3JvdXBpZCI6IiIsImdyb3VwbmFtZSI6IiIsImdvb2Rzc29ydCI6IjAiLCJnb29kc251bSI6IjYiLCJzaG93aWNvbiI6IjEiLCJpY29ucG9zaXRpb24iOiJsZWZ0IHRvcCJ9LCJzdHlsZSI6eyJsaXN0c3R5bGUiOiJibG9jayIsImJ1eXN0eWxlIjoiYnV5YnRuLTEiLCJnb29kc2ljb24iOiJyZWNvbW1hbmQiLCJwcmljZWNvbG9yIjoiI2VkMjgyMiIsImljb25wYWRkaW5ndG9wIjoiMCIsImljb25wYWRkaW5nbGVmdCI6IjAiLCJidXlidG5jb2xvciI6IiNmZTU0NTUiLCJpY29uem9vbSI6IjEwMCIsInRpdGxlY29sb3IiOiIjMjYyNjI2In0sImRhdGEiOnsiQzE0NjU4MDk5NDMyMzEiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMS5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIifSwiQzE0NjU4MDk5NDMyMzIiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMi5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIifSwiQzE0NjU4MDk5NDMyMzMiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMy5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIifSwiQzE0NjU4MDk5NDMyMzQiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtNC5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIifX0sImlkIjoiZ29vZHMifSwiTTE0NjU4MTAwNTk2OTQiOnsicGFyYW1zIjp7ImNvbnRlbnQiOiJQSEFnYzNSNWJHVTlJblJsZUhRdFlXeHBaMjQ2SUdObGJuUmxjanNpUGp4aWNpOCtQQzl3UGp4d0lITjBlV3hsUFNKMFpYaDBMV0ZzYVdkdU9pQmpaVzUwWlhJN0lqN25pWWptbllQbWlZRG1uSWtvWXlsWVdPV1ZodVdmamp3dmNENDhjRDRtYm1KemNEczhZbkl2UGp3dmNEND0ifSwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZmZmZmYifSwiaWQiOiJyaWNodGV4dCJ9fX0=','../addons/ewei_shopv2/plugin/diypage/static/template/default3/preview.jpg',3,0,0,0),(4,0,1,'系统模板04','eyJwYWdlIjp7InR5cGUiOiIxIiwidGl0bGUiOiJcdTMwMTBcdTZhMjFcdTY3N2ZcdTMwMTFcdTdjZmJcdTdlZGZcdTZhMjFcdTY3N2YwNCIsIm5hbWUiOiJcdTMwMTBcdTZhMjFcdTY3N2ZcdTMwMTFcdTdjZmJcdTdlZGZcdTZhMjFcdTY3N2YwNCIsImRlc2MiOiIiLCJpY29uIjoiIiwia2V5d29yZCI6IiIsImJhY2tncm91bmQiOiIjZmFmYWZhIiwiZGl5bWVudSI6Ii0xIn0sIml0ZW1zIjp7Ik0xNDY1ODEwMzUyODk0Ijp7ImRhdGEiOnsiQzE0NjU4MTAzNTI4OTQiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDRcL3BpY3R1cmVfMS5wbmciLCJsaW5rdXJsIjoiIn0sIkMxNDY1ODEwMzUyODk1Ijp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQ0XC9waWN0dXJlXzIucG5nIiwibGlua3VybCI6IiJ9LCJNMTQ2NTgxMDM3MDM5OSI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0NFwvcGljdHVyZV8zLnBuZyIsImxpbmt1cmwiOiIifSwiTTE0NjU4MTAzNzE3MDEiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDRcL3BpY3R1cmVfNC5wbmciLCJsaW5rdXJsIjoiIn0sIk0xNDY1ODEwMzcyNzkxIjp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQ0XC9waWN0dXJlXzUucG5nIiwibGlua3VybCI6IiJ9fSwiaWQiOiJwaWN0dXJlIiwic3R5bGUiOnsicGFkZGluZ3RvcCI6IjAiLCJwYWRkaW5nbGVmdCI6IjAifX0sIk0xNDY1ODg5OTQ0NzY5Ijp7InBhcmFtcyI6eyJjb250ZW50IjoiUEhBZ2MzUjViR1U5SW5SbGVIUXRZV3hwWjI0NklHTmxiblJsY2pzaVB1V2J2dWVKaCthZHBlYTZrT1M2anVlOWtlZTduTys4ak9lSmlPYWRnK1c5a3VXT24rUzluT2lBaGVhSmdPYWNpVHd2Y0Q0PSJ9LCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsInBhZGRpbmciOiIyMCJ9LCJpZCI6InJpY2h0ZXh0In19fQ==','../addons/ewei_shopv2/plugin/diypage/static/template/default4/preview.jpg',4,0,0,0),(5,0,2,'系统模板05','eyJwYWdlIjp7InR5cGUiOiIyIiwidGl0bGUiOiJcdTMwMTBcdTZhMjFcdTY3N2ZcdTMwMTFcdTdjZmJcdTdlZGZcdTZhMjFcdTY3N2YwNSIsIm5hbWUiOiJcdTMwMTBcdTZhMjFcdTY3N2ZcdTMwMTFcdTdjZmJcdTdlZGZcdTZhMjFcdTY3N2YwNSIsImRlc2MiOiIiLCJpY29uIjoiIiwia2V5d29yZCI6InQ1IiwiYmFja2dyb3VuZCI6IiNmYWZhZmEiLCJkaXltZW51IjoiLTEifSwiaXRlbXMiOnsiTTE0NjU4MTA3NTE4MDciOnsic3R5bGUiOnsiZG90c3R5bGUiOiJyb3VuZCIsImRvdGFsaWduIjoibGVmdCIsImJhY2tncm91bmQiOiIjZmZmZmZmIiwibGVmdHJpZ2h0IjoiMTAiLCJib3R0b20iOiIxMCIsIm9wYWNpdHkiOiIwLjcifSwiZGF0YSI6eyJDMTQ2NTgxMDc1MTgwNyI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0NVwvYmFubmVyXzEuanBnIiwibGlua3VybCI6IiJ9LCJDMTQ2NTgxMDc1MTgwOCI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0NVwvYmFubmVyXzIuanBnIiwibGlua3VybCI6IiJ9LCJNMTQ2NTgxMDc2NjQ4NiI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0NVwvYmFubmVyXzMuanBnIiwibGlua3VybCI6IiJ9fSwiaWQiOiJiYW5uZXIifSwiTTE0NjU4MTA5NzA0OTQiOnsic3R5bGUiOnsibmF2c3R5bGUiOiIiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsInJvd251bSI6IjQifSwiZGF0YSI6eyJDMTQ2NTgxMDk3MDQ5NCI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0NVwvbWVudV8xLnBuZyIsImxpbmt1cmwiOiIiLCJ0ZXh0IjoiSE9NRSIsImNvbG9yIjoiIzY2NjY2NiJ9LCJDMTQ2NTgxMDk3MDQ5NSI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0NVwvbWVudV8yLnBuZyIsImxpbmt1cmwiOiIiLCJ0ZXh0IjoiTkVXIiwiY29sb3IiOiIjNjY2NjY2In0sIkMxNDY1ODEwOTcwNDk2Ijp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQ1XC9tZW51XzMucG5nIiwibGlua3VybCI6IiIsInRleHQiOiJIT1QiLCJjb2xvciI6IiM2NjY2NjYifSwiQzE0NjU4MTA5NzA0OTciOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDVcL21lbnVfNC5wbmciLCJsaW5rdXJsIjoiIiwidGV4dCI6IkxJU1QiLCJjb2xvciI6IiM2NjY2NjYifX0sImlkIjoibWVudSJ9LCJNMTQ2NTgxMTA5OTI0MCI6eyJwYXJhbXMiOnsicm93IjoiMyJ9LCJkYXRhIjp7IkMxNDY1ODExMDk5MjQwIjp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQ1XC9waWN0dXJld18xLmpwZyIsImxpbmt1cmwiOiIifSwiQzE0NjU4MTEwOTkyNDEiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDVcL3BpY3R1cmV3XzQuanBnIiwibGlua3VybCI6IiJ9LCJDMTQ2NTgxMTA5OTI0MyI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0NVwvcGljdHVyZXdfMS5qcGciLCJsaW5rdXJsIjoiIn19LCJpZCI6InBpY3R1cmV3Iiwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJwYWRkaW5ndG9wIjoiNSIsInBhZGRpbmdsZWZ0IjoiNSJ9fSwiTTE0NjU4MTIzOTAxNzQiOnsicGFyYW1zIjp7InJvdyI6IjIifSwiZGF0YSI6eyJDMTQ2NTgxMjM5MDE3NSI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0NVwvcGljdHVyZXdfMy5qcGciLCJsaW5rdXJsIjoiIn0sIkMxNDY1ODEyMzkwMTc2Ijp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQ1XC9waWN0dXJld18zLmpwZyIsImxpbmt1cmwiOiIifX0sImlkIjoicGljdHVyZXciLCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsInBhZGRpbmd0b3AiOiIwIiwicGFkZGluZ2xlZnQiOiI1In19LCJNMTQ2NTg3MjQ4NTQ4NiI6eyJzdHlsZSI6eyJoZWlnaHQiOiIxMCIsImJhY2tncm91bmQiOiIjZmFmYWZhIn0sImlkIjoiYmxhbmsifSwiTTE0NjU4MTExNzQ5NTgiOnsiZGF0YSI6eyJDMTQ2NTgxMTE3NDk1OSI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0NVwvcGljdHVyZV8xLmpwZyIsImxpbmt1cmwiOiIifX0sImlkIjoicGljdHVyZSIsInN0eWxlIjp7InBhZGRpbmd0b3AiOiIwIiwicGFkZGluZ2xlZnQiOiIwIn19LCJNMTQ2NTgxMjQxMTM4MSI6eyJwYXJhbXMiOnsic2hvd3RpdGxlIjoiMSIsInNob3dwcmljZSI6IjEiLCJnb29kc2RhdGEiOiIwIiwiY2F0ZWlkIjoiIiwiY2F0ZW5hbWUiOiIiLCJncm91cGlkIjoiIiwiZ3JvdXBuYW1lIjoiIiwiZ29vZHNzb3J0IjoiMCIsImdvb2RzbnVtIjoiNiIsInNob3dpY29uIjoiMSIsImljb25wb3NpdGlvbiI6ImxlZnQgdG9wIn0sInN0eWxlIjp7Imxpc3RzdHlsZSI6ImJsb2NrIiwiYnV5c3R5bGUiOiJidXlidG4tMSIsImdvb2RzaWNvbiI6InJlY29tbWFuZCIsInByaWNlY29sb3IiOiIjZWQyODIyIiwiaWNvbnBhZGRpbmd0b3AiOiIwIiwiaWNvbnBhZGRpbmdsZWZ0IjoiMCIsImJ1eWJ0bmNvbG9yIjoiI2ZlNTQ1NSIsImljb256b29tIjoiMTAwIiwidGl0bGVjb2xvciI6IiMyNjI2MjYifSwiZGF0YSI6eyJDMTQ2NTgxMjQxMTM4MSI6eyJ0aHVtYiI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvaW1hZ2VzXC9kZWZhdWx0XC9nb29kcy0xLmpwZyIsInByaWNlIjoiMjAuMDAiLCJ0aXRsZSI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1NTU0Nlx1NTRjMVx1NjgwN1x1OTg5OCIsImdpZCI6IiJ9LCJDMTQ2NTgxMjQxMTM4MiI6eyJ0aHVtYiI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvaW1hZ2VzXC9kZWZhdWx0XC9nb29kcy0yLmpwZyIsInByaWNlIjoiMjAuMDAiLCJ0aXRsZSI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1NTU0Nlx1NTRjMVx1NjgwN1x1OTg5OCIsImdpZCI6IiJ9LCJDMTQ2NTgxMjQxMTM4MyI6eyJ0aHVtYiI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvaW1hZ2VzXC9kZWZhdWx0XC9nb29kcy0zLmpwZyIsInByaWNlIjoiMjAuMDAiLCJ0aXRsZSI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1NTU0Nlx1NTRjMVx1NjgwN1x1OTg5OCIsImdpZCI6IiJ9LCJDMTQ2NTgxMjQxMTM4NCI6eyJ0aHVtYiI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvaW1hZ2VzXC9kZWZhdWx0XC9nb29kcy00LmpwZyIsInByaWNlIjoiMjAuMDAiLCJ0aXRsZSI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1NTU0Nlx1NTRjMVx1NjgwN1x1OTg5OCIsImdpZCI6IiJ9fSwiaWQiOiJnb29kcyJ9LCJNMTQ2NTgxMjQ2Njg5MyI6eyJwYXJhbXMiOnsiY29udGVudCI6IlBIQWdjM1I1YkdVOUluUmxlSFF0WVd4cFoyNDZJR05sYm5SbGNqc2lQanhpY2k4K1BDOXdQanh3SUhOMGVXeGxQU0owWlhoMExXRnNhV2R1T2lCalpXNTBaWEk3SWo3a3U2WGt1SXJsbTc3bmlZZmxuWWZtbmFYbXVwRGt1bzdudlpIbnU1enZ2SXpuaVlqbW5ZUGx2WkxsanBcL2t2WnpvZ0lYbWlZRG1uSW5qZ0lJOEwzQStQSEErUEdKeUx6NDhMM0ErIn0sInN0eWxlIjp7ImJhY2tncm91bmQiOiIjZmZmZmZmIn0sImlkIjoicmljaHRleHQifX19','../addons/ewei_shopv2/plugin/diypage/static/template/default5/preview.jpg',5,0,0,0),(6,0,1,'系统模板06','eyJwYWdlIjp7InR5cGUiOiIxIiwidGl0bGUiOiJcdTMwMTBcdTZhMjFcdTY3N2ZcdTMwMTFcdTdjZmJcdTdlZGZcdTZhMjFcdTY3N2YwNiIsIm5hbWUiOiJcdTMwMTBcdTZhMjFcdTY3N2ZcdTMwMTFcdTdjZmJcdTdlZGZcdTZhMjFcdTY3N2YwNiIsImRlc2MiOiIiLCJpY29uIjoiIiwia2V5d29yZCI6IiIsImJhY2tncm91bmQiOiIjZmFmYWZhIiwiZGl5bWVudSI6Ii0xIn0sIml0ZW1zIjp7Ik0xNDY1ODEyNjAyOTMzIjp7ImRhdGEiOnsiQzE0NjU4MTI2MDI5MzMiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDZcL3BpY3R1cmVfMS5qcGciLCJsaW5rdXJsIjoiIn0sIkMxNDY1ODEyNjAyOTM0Ijp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQ2XC9waWN0dXJlXzIuanBnIiwibGlua3VybCI6IiJ9LCJNMTQ2NTgxMjYwNDQ5NCI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0NlwvcGljdHVyZV8zLmpwZyIsImxpbmt1cmwiOiIifSwiTTE0NjU4MTI2MDUyNDUiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDZcL3BpY3R1cmVfNC5qcGciLCJsaW5rdXJsIjoiIn0sIk0xNDY1ODEyNjA1OTgwIjp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQ2XC9waWN0dXJlXzUuanBnIiwibGlua3VybCI6IiJ9LCJNMTQ2NTgxMjYwNzA0NSI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0NlwvcGljdHVyZV82LmpwZyIsImxpbmt1cmwiOiIifX0sImlkIjoicGljdHVyZSIsInN0eWxlIjp7InBhZGRpbmd0b3AiOiIwIiwicGFkZGluZ2xlZnQiOiIwIn19LCJNMTQ2NTg5MDE4NDY1MCI6eyJwYXJhbXMiOnsiY29udGVudCI6IlBIQWdjM1I1YkdVOUluUmxlSFF0WVd4cFoyNDZJR05sYm5SbGNqc2lQdVdidnVlSmgrYWRwZWE2a09TNmp1ZTlrZWU3bk8rOGpPZUppT2FkZytXOWt1V09uK1M5bk9pQWhlYUpnT2FjaVR3dmNEND0ifSwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJwYWRkaW5nIjoiMjAifSwiaWQiOiJyaWNodGV4dCJ9fX0=','../addons/ewei_shopv2/plugin/diypage/static/template/default6/preview.jpg',6,0,0,0),(7,0,2,'系统模板07','eyJwYWdlIjp7InR5cGUiOiIyIiwidGl0bGUiOiJcdTMwMTBcdTZhMjFcdTY3N2ZcdTMwMTFcdTdjZmJcdTdlZGZcdTZhMjFcdTY3N2YwNyIsIm5hbWUiOiJcdTMwMTBcdTZhMjFcdTY3N2ZcdTMwMTFcdTdjZmJcdTdlZGZcdTZhMjFcdTY3N2YwNyIsImRlc2MiOiIiLCJpY29uIjoiIiwia2V5d29yZCI6IiIsImJhY2tncm91bmQiOiIjZmFmYWZhIiwiZGl5bWVudSI6Ii0xIn0sIml0ZW1zIjp7Ik0xNDY1ODEyNjkxMzg5Ijp7ImRhdGEiOnsiQzE0NjU4MTI2OTEzODkiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDdcL3BpY3R1cmVfMS5qcGciLCJsaW5rdXJsIjoiIn19LCJpZCI6InBpY3R1cmUiLCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsInBhZGRpbmd0b3AiOiIwIiwicGFkZGluZ2xlZnQiOiIwIn19LCJNMTQ2NTgxMjcyODgyMSI6eyJwYXJhbXMiOnsicGxhY2Vob2xkZXIiOiJcdThiZjdcdThmOTNcdTUxNjVcdTUxNzNcdTk1MmVcdTViNTdcdThmZGJcdTg4NGNcdTY0MWNcdTdkMjIifSwic3R5bGUiOnsiaW5wdXRiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsImJhY2tncm91bmQiOiIjZjFmMWYyIiwiaWNvbmNvbG9yIjoiI2I0YjRiNCIsImNvbG9yIjoiIzk5OTk5OSIsInBhZGRpbmd0b3AiOiIxMCIsInBhZGRpbmdsZWZ0IjoiMTAiLCJ0ZXh0YWxpZ24iOiJsZWZ0Iiwic2VhcmNoc3R5bGUiOiIifSwiaWQiOiJzZWFyY2gifSwiTTE0NjU4MTI3MzkxOTciOnsicGFyYW1zIjp7InJvdyI6IjMifSwiZGF0YSI6eyJDMTQ2NTgxMjczOTE5NyI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0N1wvcGljdHVyZXdfMS5qcGciLCJsaW5rdXJsIjoiIn0sIkMxNDY1ODEyNzM5MTk4Ijp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQ3XC9waWN0dXJld18yLmpwZyIsImxpbmt1cmwiOiIifSwiQzE0NjU4MTI3MzkxOTkiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDdcL3BpY3R1cmV3XzMuanBnIiwibGlua3VybCI6IiJ9fSwiaWQiOiJwaWN0dXJldyIsInN0eWxlIjp7ImJhY2tncm91bmQiOiIjZmZmZmZmIiwicGFkZGluZ3RvcCI6IjAiLCJwYWRkaW5nbGVmdCI6IjUifX0sIk0xNDY1ODEyNzg0NTY1Ijp7ImRhdGEiOnsiQzE0NjU4MTI3ODQ1NjUiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDdcL3BpY3R1cmVfMy5qcGciLCJsaW5rdXJsIjoiIn0sIk0xNDY1ODEyODE5OTQ4Ijp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQ3XC9waWN0dXJlXzIuanBnIiwibGlua3VybCI6IiJ9fSwiaWQiOiJwaWN0dXJlIiwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJwYWRkaW5ndG9wIjoiNCIsInBhZGRpbmdsZWZ0IjoiMCJ9fSwiTTE0NjU4MTI4NzU5ODgiOnsicGFyYW1zIjp7InJvdyI6IjIifSwiZGF0YSI6eyJDMTQ2NTgxMjg3NTk4OCI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0N1wvcGljdHVyZXdfNC5qcGciLCJsaW5rdXJsIjoiIn0sIkMxNDY1ODEyODc1OTg5Ijp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQ3XC9waWN0dXJld181LmpwZyIsImxpbmt1cmwiOiIifSwiQzE0NjU4MTI4NzU5OTAiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDdcL3BpY3R1cmV3XzYuanBnIiwibGlua3VybCI6IiJ9LCJDMTQ2NTgxMjg3NTk5MSI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0N1wvcGljdHVyZXdfNy5qcGciLCJsaW5rdXJsIjoiIn19LCJpZCI6InBpY3R1cmV3Iiwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJwYWRkaW5ndG9wIjoiMCIsInBhZGRpbmdsZWZ0IjoiMCJ9fSwiTTE0NjU4NzI4OTQxMjAiOnsic3R5bGUiOnsiaGVpZ2h0IjoiMTAiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiJ9LCJpZCI6ImJsYW5rIn0sIk0xNDY1ODcyODMyODk1Ijp7InBhcmFtcyI6eyJ0aXRsZSI6Ilx1NzBlZFx1OTUwMFx1NTU0Nlx1NTRjMSIsImljb24iOiIifSwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmMjMyNGMiLCJjb2xvciI6IiNmZmZmZmYiLCJ0ZXh0YWxpZ24iOiJjZW50ZXIiLCJmb250c2l6ZSI6IjE4IiwicGFkZGluZ3RvcCI6IjUiLCJwYWRkaW5nbGVmdCI6IjUifSwiaWQiOiJ0aXRsZSJ9LCJNMTQ2NTgxMjkwNDA1MyI6eyJwYXJhbXMiOnsic2hvd3RpdGxlIjoiMSIsInNob3dwcmljZSI6IjEiLCJnb29kc2RhdGEiOiIwIiwiY2F0ZWlkIjoiIiwiY2F0ZW5hbWUiOiIiLCJncm91cGlkIjoiIiwiZ3JvdXBuYW1lIjoiIiwiZ29vZHNzb3J0IjoiMCIsImdvb2RzbnVtIjoiNiIsInNob3dpY29uIjoiMSIsImljb25wb3NpdGlvbiI6ImxlZnQgdG9wIn0sInN0eWxlIjp7Imxpc3RzdHlsZSI6ImJsb2NrIiwiYnV5c3R5bGUiOiJidXlidG4tMSIsImdvb2RzaWNvbiI6InJlY29tbWFuZCIsInByaWNlY29sb3IiOiIjZWQyODIyIiwiaWNvbnBhZGRpbmd0b3AiOiIwIiwiaWNvbnBhZGRpbmdsZWZ0IjoiMCIsImJ1eWJ0bmNvbG9yIjoiI2ZlNTQ1NSIsImljb256b29tIjoiMTAwIiwidGl0bGVjb2xvciI6IiMyNjI2MjYifSwiZGF0YSI6eyJDMTQ2NTgxMjkwNDA1MyI6eyJ0aHVtYiI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvaW1hZ2VzXC9kZWZhdWx0XC9nb29kcy0xLmpwZyIsInByaWNlIjoiMjAuMDAiLCJ0aXRsZSI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1NTU0Nlx1NTRjMVx1NjgwN1x1OTg5OCIsImdpZCI6IiJ9LCJDMTQ2NTgxMjkwNDA1NCI6eyJ0aHVtYiI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvaW1hZ2VzXC9kZWZhdWx0XC9nb29kcy0yLmpwZyIsInByaWNlIjoiMjAuMDAiLCJ0aXRsZSI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1NTU0Nlx1NTRjMVx1NjgwN1x1OTg5OCIsImdpZCI6IiJ9LCJDMTQ2NTgxMjkwNDA1NSI6eyJ0aHVtYiI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvaW1hZ2VzXC9kZWZhdWx0XC9nb29kcy0zLmpwZyIsInByaWNlIjoiMjAuMDAiLCJ0aXRsZSI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1NTU0Nlx1NTRjMVx1NjgwN1x1OTg5OCIsImdpZCI6IiJ9LCJDMTQ2NTgxMjkwNDA1NiI6eyJ0aHVtYiI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvaW1hZ2VzXC9kZWZhdWx0XC9nb29kcy00LmpwZyIsInByaWNlIjoiMjAuMDAiLCJ0aXRsZSI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1NTU0Nlx1NTRjMVx1NjgwN1x1OTg5OCIsImdpZCI6IiJ9fSwiaWQiOiJnb29kcyJ9LCJNMTQ2NTg4ODU1MjYwNiI6eyJwYXJhbXMiOnsiY29udGVudCI6IlBIQWdjM1I1YkdVOUluUmxlSFF0WVd4cFoyNDZJR05sYm5SbGNqc2lQdVdidnVlSmgrYWRwZWE2a09TNmp1ZTlrZWU3bk8rOGpPZUppT2FkZytXOWt1V09uK1M5bk9pQWhlYUpnT2FjaVR3dmNEND0ifSwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJwYWRkaW5nIjoiMjAifSwiaWQiOiJyaWNodGV4dCJ9fX0=','../addons/ewei_shopv2/plugin/diypage/static/template/default7/preview.jpg',7,0,0,0),(8,0,2,'系统模板08','eyJwYWdlIjp7InR5cGUiOiIyIiwidGl0bGUiOiJcdTMwMTBcdTZhMjFcdTY3N2ZcdTMwMTFcdTdjZmJcdTdlZGZcdTZhMjFcdTY3N2YwOCIsIm5hbWUiOiJcdTMwMTBcdTZhMjFcdTY3N2ZcdTMwMTFcdTdjZmJcdTdlZGZcdTZhMjFcdTY3N2YwOCIsImRlc2MiOiIiLCJpY29uIjoiIiwia2V5d29yZCI6IiIsImJhY2tncm91bmQiOiIjZmFmYWZhIiwiZGl5bWVudSI6Ii0xIn0sIml0ZW1zIjp7Ik0xNDY1ODEyOTk3MDQ1Ijp7ImRhdGEiOnsiQzE0NjU4MTI5OTcwNDUiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDhcL3BpY3R1cmVfMS5qcGciLCJsaW5rdXJsIjoiIn19LCJpZCI6InBpY3R1cmUiLCJzdHlsZSI6eyJwYWRkaW5ndG9wIjoiMCIsInBhZGRpbmdsZWZ0IjoiMCJ9fSwiTTE0NjU4MTMwMTc1NDkiOnsicGFyYW1zIjp7InJvdyI6IjMifSwiZGF0YSI6eyJDMTQ2NTgxMzAxNzU1MCI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0OFwvcGljdHVyZXdfMS5qcGciLCJsaW5rdXJsIjoiIn0sIkMxNDY1ODEzMDE3NTUxIjp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQ4XC9waWN0dXJld18yLmpwZyIsImxpbmt1cmwiOiIifSwiQzE0NjU4MTMwMTc1NTIiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDhcL3BpY3R1cmV3XzMuanBnIiwibGlua3VybCI6IiJ9fSwiaWQiOiJwaWN0dXJldyIsInN0eWxlIjp7ImJhY2tncm91bmQiOiIjZmZmZmZmIiwicGFkZGluZ3RvcCI6IjAiLCJwYWRkaW5nbGVmdCI6IjAifX0sIk0xNDY1ODEzMDQyODc2Ijp7ImRhdGEiOnsiQzE0NjU4MTMwNDI4NzYiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDhcL3BpY3R1cmVfMi5qcGciLCJsaW5rdXJsIjoiIn0sIkMxNDY1ODEzMDQyODc3Ijp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQ4XC9waWN0dXJlXzMuanBnIiwibGlua3VybCI6IiJ9fSwiaWQiOiJwaWN0dXJlIiwic3R5bGUiOnsicGFkZGluZ3RvcCI6IjAiLCJwYWRkaW5nbGVmdCI6IjAifX0sIk0xNDY1ODEzMDg4ODA0Ijp7InBhcmFtcyI6eyJyb3ciOiI0In0sImRhdGEiOnsiQzE0NjU4MTMwODg4MDQiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDhcL3BpY3R1cmV3XzQuanBnIiwibGlua3VybCI6IiJ9LCJDMTQ2NTgxMzA4ODgwNSI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL3RlbXBsYXRlXC9kZWZhdWx0OFwvcGljdHVyZXdfNS5qcGciLCJsaW5rdXJsIjoiIn0sIkMxNDY1ODEzMDg4ODA2Ijp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvdGVtcGxhdGVcL2RlZmF1bHQ4XC9waWN0dXJld182LmpwZyIsImxpbmt1cmwiOiIifSwiQzE0NjU4MTMwODg4MDciOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC90ZW1wbGF0ZVwvZGVmYXVsdDhcL3BpY3R1cmV3XzcuanBnIiwibGlua3VybCI6IiJ9fSwiaWQiOiJwaWN0dXJldyIsInN0eWxlIjp7ImJhY2tncm91bmQiOiIjZmZmZmZmIiwicGFkZGluZ3RvcCI6IjAiLCJwYWRkaW5nbGVmdCI6IjAifX0sIk0xNDY1ODEzMTMxMzgwIjp7InBhcmFtcyI6eyJzaG93dGl0bGUiOiIxIiwic2hvd3ByaWNlIjoiMSIsImdvb2RzZGF0YSI6IjAiLCJjYXRlaWQiOiIiLCJjYXRlbmFtZSI6IiIsImdyb3VwaWQiOiIiLCJncm91cG5hbWUiOiIiLCJnb29kc3NvcnQiOiIwIiwiZ29vZHNudW0iOiI2Iiwic2hvd2ljb24iOiIxIiwiaWNvbnBvc2l0aW9uIjoibGVmdCB0b3AifSwic3R5bGUiOnsibGlzdHN0eWxlIjoiYmxvY2siLCJidXlzdHlsZSI6ImJ1eWJ0bi0xIiwiZ29vZHNpY29uIjoicmVjb21tYW5kIiwicHJpY2Vjb2xvciI6IiNlZDI4MjIiLCJpY29ucGFkZGluZ3RvcCI6IjAiLCJpY29ucGFkZGluZ2xlZnQiOiIwIiwiYnV5YnRuY29sb3IiOiIjZmU1NDU1IiwiaWNvbnpvb20iOiIxMDAiLCJ0aXRsZWNvbG9yIjoiIzI2MjYyNiJ9LCJkYXRhIjp7IkMxNDY1ODEzMTMxMzgwIjp7InRodW1iIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2dvb2RzLTEuanBnIiwicHJpY2UiOiIyMC4wMCIsInRpdGxlIjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU1NTQ2XHU1NGMxXHU2ODA3XHU5ODk4IiwiZ2lkIjoiIn0sIkMxNDY1ODEzMTMxMzgxIjp7InRodW1iIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2dvb2RzLTIuanBnIiwicHJpY2UiOiIyMC4wMCIsInRpdGxlIjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU1NTQ2XHU1NGMxXHU2ODA3XHU5ODk4IiwiZ2lkIjoiIn0sIkMxNDY1ODEzMTMxMzgyIjp7InRodW1iIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2dvb2RzLTMuanBnIiwicHJpY2UiOiIyMC4wMCIsInRpdGxlIjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU1NTQ2XHU1NGMxXHU2ODA3XHU5ODk4IiwiZ2lkIjoiIn0sIkMxNDY1ODEzMTMxMzgzIjp7InRodW1iIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2dvb2RzLTQuanBnIiwicHJpY2UiOiIyMC4wMCIsInRpdGxlIjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU1NTQ2XHU1NGMxXHU2ODA3XHU5ODk4IiwiZ2lkIjoiIn19LCJpZCI6Imdvb2RzIn0sIk0xNDY1ODg4ODMxMjc4Ijp7InBhcmFtcyI6eyJjb250ZW50IjoiUEhBZ2MzUjViR1U5SW5SbGVIUXRZV3hwWjI0NklHTmxiblJsY2pzaVB1V2J2dWVKaCthZHBlYTZrT1M2anVlOWtlZTduTys4ak9lSmlPYWRnK1c5a3VXT24rUzluT2lBaGVhSmdPYWNpVHd2Y0Q0PSJ9LCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsInBhZGRpbmciOiIyMCJ9LCJpZCI6InJpY2h0ZXh0In19fQ==','../addons/ewei_shopv2/plugin/diypage/static/template/default8/preview.jpg',8,0,0,0),(9,0,3,'会员中心01','eyJwYWdlIjp7InR5cGUiOiIzIiwidGl0bGUiOiJcdTRmMWFcdTU0NThcdTRlMmRcdTVmYzMiLCJuYW1lIjoiXHU0ZjFhXHU1NDU4XHU0ZTJkXHU1ZmMzIiwiZGVzYyI6IiIsImljb24iOiIiLCJrZXl3b3JkIjoiIiwiYmFja2dyb3VuZCI6IiNmYWZhZmEiLCJkaXltZW51IjoiMCIsImZvbGxvd2JhciI6IjAiLCJ2aXNpdCI6IjAiLCJ2aXNpdGxldmVsIjp7Im1lbWJlciI6IiIsImNvbW1pc3Npb24iOiIifSwibm92aXNpdCI6eyJ0aXRsZSI6IiIsImxpbmsiOiIifX0sIml0ZW1zIjp7Ik0xNDc0NTI2MTM0ODE0Ijp7InBhcmFtcyI6eyJzdHlsZSI6ImRlZmF1bHQxIiwibGV2ZWxsaW5rIjoiIiwic2V0aWNvbiI6Imljb24tc2V0dGluZ3MiLCJzZXRsaW5rIjoiIiwibGVmdG5hdiI6Ilx1NTE0NVx1NTAzYyIsImxlZnRuYXZsaW5rIjoiIiwicmlnaHRuYXYiOiJcdTUxNTFcdTYzNjIiLCJyaWdodG5hdmxpbmsiOiIifSwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZTU0NTUiLCJ0ZXh0Y29sb3IiOiIjZmZmZmZmIiwidGV4dGxpZ2h0IjoiI2ZlZjMxZiIsImhlYWRzdHlsZSI6IiJ9LCJpbmZvIjp7ImF2YXRhciI6IiIsIm5pY2tuYW1lIjoiIiwibGV2ZWxuYW1lIjoiIiwidGV4dG1vbmV5IjoiIiwidGV4dGNyZWRpdCI6IiIsIm1vbmV5IjoiIiwiY3JlZGl0IjoiIn0sImlkIjoibWVtYmVyIn0sIk0xNDc0NTI2MTM4OTEwIjp7InBhcmFtcyI6eyJsaW5rdXJsIjoiIiwidGl0bGUiOiJcdTdlZDFcdTViOWFcdTYyNGJcdTY3M2FcdTUzZjciLCJ0ZXh0IjoiXHU1OTgyXHU2NzljXHU2MGE4XHU3NTI4XHU2MjRiXHU2NzNhXHU1M2Y3XHU2Y2U4XHU1MThjXHU4ZmM3XHU0ZjFhXHU1NDU4XHU2MjE2XHU2MGE4XHU2MGYzXHU5MDFhXHU4ZmM3XHU1ZmFlXHU0ZmUxXHU1OTE2XHU4ZDJkXHU3MjY5XHU4YmY3XHU3ZWQxXHU1YjlhXHU2MGE4XHU3Njg0XHU2MjRiXHU2NzNhXHU1M2Y3XHU3ODAxIiwiaWNvbmNsYXNzIjoiaWNvbi1tb2JpbGUifSwic3R5bGUiOnsibWFyZ2ludG9wIjoiMTAiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsInRpdGxlY29sb3IiOiIjZmYwMDExIiwidGV4dGNvbG9yIjoiIzk5OTk5OSIsImljb25jb2xvciI6IiM5OTk5OTkifSwiaWQiOiJiaW5kbW9iaWxlIn0sIk0xNDc0NTI2MTQzNDg3Ijp7InN0eWxlIjp7Im1hcmdpbnRvcCI6IjEwIiwiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJpY29uY29sb3IiOiIjOTk5OTk5IiwidGV4dGNvbG9yIjoiIzMzMzMzMyIsInJlbWFya2NvbG9yIjoiIzg4ODg4OCJ9LCJkYXRhIjp7IkMxNDc0NTI2MTQzNDg5Ijp7InRleHQiOiJcdTYyMTFcdTc2ODRcdThiYTJcdTUzNTUiLCJsaW5rdXJsIjoiIiwiaWNvbmNsYXNzIjoiaWNvbi1saXN0IiwicmVtYXJrIjoiXHU2N2U1XHU3NzBiXHU1MTY4XHU5MGU4IiwiZG90bnVtIjoiIn19LCJpZCI6Imxpc3RtZW51In0sIk0xNDc0NTI2MTgxNDMxIjp7InBhcmFtcyI6eyJyb3dudW0iOiI0IiwiYm9yZGVyIjoiMSIsImJvcmRlcnRvcCI6IjAiLCJib3JkZXJib3R0b20iOiIxIn0sInN0eWxlIjp7ImJhY2tncm91bmQiOiIjZmZmZmZmIiwiYm9yZGVyY29sb3IiOiIjZWJlYmViIiwidGV4dGNvbG9yIjoiIzdhN2E3YSIsImljb25jb2xvciI6IiNhYWFhYWEiLCJkb3Rjb2xvciI6IiNmZjAwMTEifSwiZGF0YSI6eyJDMTQ3NDUyNjE4MTQzMSI6eyJpY29uY2xhc3MiOiJpY29uLWNhcmQiLCJ0ZXh0IjoiXHU1Zjg1XHU0ZWQ4XHU2YjNlIiwibGlua3VybCI6IiIsImRvdG51bSI6IjAifSwiQzE0NzQ1MjYxODE0MzIiOnsiaWNvbmNsYXNzIjoiaWNvbi1ib3giLCJ0ZXh0IjoiXHU1Zjg1XHU1M2QxXHU4ZDI3IiwibGlua3VybCI6IiIsImRvdG51bSI6IjAifSwiQzE0NzQ1MjYxODE0MzMiOnsiaWNvbmNsYXNzIjoiaWNvbi1kZWxpdmVyIiwidGV4dCI6Ilx1NWY4NVx1NjUzNlx1OGQyNyIsImxpbmt1cmwiOiIiLCJkb3RudW0iOiIwIn0sIkMxNDc0NTI2MTgxNDM0Ijp7Imljb25jbGFzcyI6Imljb24tZWxlY3RyaWNhbCIsInRleHQiOiJcdTkwMDBcdTYzNjJcdThkMjciLCJsaW5rdXJsIjoiIiwiZG90bnVtIjoiMCJ9fSwiaWQiOiJpY29uZ3JvdXAifSwiTTE0NzQ1MjYxOTkxMDIiOnsic3R5bGUiOnsibWFyZ2ludG9wIjoiMTAiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsImljb25jb2xvciI6IiM5OTk5OTkiLCJ0ZXh0Y29sb3IiOiIjMzMzMzMzIiwicmVtYXJrY29sb3IiOiIjODg4ODg4In0sImRhdGEiOnsiQzE0NzQ1MjYxOTkxMDIiOnsidGV4dCI6Ilx1NTIwNlx1OTUwMFx1NGUyZFx1NWZjMyIsImxpbmt1cmwiOiIiLCJpY29uY2xhc3MiOiJpY29uLWdyb3VwIiwicmVtYXJrIjoiXHU2N2U1XHU3NzBiIiwiZG90bnVtIjoiIn0sIkMxNDc0NTI2MTk5MTAzIjp7InRleHQiOiJcdTc5ZWZcdTUyMDZcdTdiN2VcdTUyMzAiLCJsaW5rdXJsIjoiIiwiaWNvbmNsYXNzIjoiaWNvbi1naWZ0cyIsInJlbWFyayI6Ilx1NjdlNVx1NzcwYiIsImRvdG51bSI6IiJ9LCJDMTQ3NDUyNjE5OTEwNCI6eyJ0ZXh0IjoiXHU3OWVmXHU1MjA2XHU1NTQ2XHU1N2NlIiwibGlua3VybCI6IiIsImljb25jbGFzcyI6Imljb24tY3JlZGl0bGV2ZWwiLCJyZW1hcmsiOiJcdTY3ZTVcdTc3MGIiLCJkb3RudW0iOiIifX0sImlkIjoibGlzdG1lbnUifSwiTTE0NzQ1MjYyMjIyMDYiOnsic3R5bGUiOnsibWFyZ2ludG9wIjoiMTAiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsImljb25jb2xvciI6IiM5OTk5OTkiLCJ0ZXh0Y29sb3IiOiIjMzMzMzMzIiwicmVtYXJrY29sb3IiOiIjODg4ODg4In0sImRhdGEiOnsiQzE0NzQ1MjYyMjIyMDYiOnsidGV4dCI6Ilx1OTg4Nlx1NTNkNlx1NGYxOFx1NjBlMFx1NTIzOCIsImxpbmt1cmwiOiIiLCJpY29uY2xhc3MiOiJpY29uLXNhbWUiLCJyZW1hcmsiOiJcdTY3ZTVcdTc3MGIiLCJkb3RudW0iOiIifSwiQzE0NzQ1MjYyMjIyMDciOnsidGV4dCI6Ilx1NjIxMVx1NzY4NFx1NGYxOFx1NjBlMFx1NTIzOCIsImxpbmt1cmwiOiIiLCJpY29uY2xhc3MiOiJpY29uLWNhcmQiLCJyZW1hcmsiOiJcdTY3ZTVcdTc3MGIiLCJkb3RudW0iOiIifX0sImlkIjoibGlzdG1lbnUifSwiTTE0NzQ1MjYyNTM2MTQiOnsic3R5bGUiOnsibWFyZ2ludG9wIjoiMTAiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsImljb25jb2xvciI6IiM5OTk5OTkiLCJ0ZXh0Y29sb3IiOiIjMzMzMzMzIiwicmVtYXJrY29sb3IiOiIjODg4ODg4In0sImRhdGEiOnsiQzE0NzQ1MjYyNTM2MTQiOnsidGV4dCI6Ilx1NzllZlx1NTIwNlx1NjM5Mlx1ODg0YyIsImxpbmt1cmwiOiIiLCJpY29uY2xhc3MiOiJpY29uLXJhbmsiLCJyZW1hcmsiOiJcdTY3ZTVcdTc3MGIiLCJkb3RudW0iOiIifSwiQzE0NzQ1MjYyNTM2MTUiOnsidGV4dCI6Ilx1NmQ4OFx1OGQzOVx1NjM5Mlx1ODg0YyIsImxpbmt1cmwiOiIiLCJpY29uY2xhc3MiOiJpY29uLW1vbmV5IiwicmVtYXJrIjoiXHU2N2U1XHU3NzBiIiwiZG90bnVtIjoiIn19LCJpZCI6Imxpc3RtZW51In0sIk0xNDc0NTI2MjgxNzYwIjp7InN0eWxlIjp7Im1hcmdpbnRvcCI6IjEwIiwiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJpY29uY29sb3IiOiIjOTk5OTk5IiwidGV4dGNvbG9yIjoiIzMzMzMzMyIsInJlbWFya2NvbG9yIjoiIzg4ODg4OCJ9LCJkYXRhIjp7IkMxNDc0NTI2MjgxNzYwIjp7InRleHQiOiJcdTYyMTFcdTc2ODRcdThkMmRcdTcyNjlcdThmNjYiLCJsaW5rdXJsIjoiIiwiaWNvbmNsYXNzIjoiaWNvbi1jYXJ0IiwicmVtYXJrIjoiXHU2N2U1XHU3NzBiIiwiZG90bnVtIjoiIn0sIkMxNDc0NTI2MjgxNzYxIjp7InRleHQiOiJcdTYyMTFcdTc2ODRcdTUxNzNcdTZjZTgiLCJsaW5rdXJsIjoiIiwiaWNvbmNsYXNzIjoiaWNvbi1saWtlIiwicmVtYXJrIjoiXHU2N2U1XHU3NzBiIiwiZG90bnVtIjoiIn0sIkMxNDc0NTI2MjgxNzYyIjp7InRleHQiOiJcdTYyMTFcdTc2ODRcdThkYjNcdThmZjkiLCJsaW5rdXJsIjoiIiwiaWNvbmNsYXNzIjoiaWNvbi1mb290cHJpbnQiLCJyZW1hcmsiOiJcdTY3ZTVcdTc3MGIiLCJkb3RudW0iOiIifSwiTTE0NzQ1MjYzMDA1NDMiOnsidGV4dCI6Ilx1NmQ4OFx1NjA2Zlx1NjNkMFx1OTE5Mlx1OGJiZVx1N2Y2ZSIsImxpbmt1cmwiOiIiLCJpY29uY2xhc3MiOiJpY29uLW5vdGljZSIsInJlbWFyayI6Ilx1NjdlNVx1NzcwYiIsImRvdG51bSI6IiJ9fSwiaWQiOiJsaXN0bWVudSJ9LCJNMTQ3NDUyNjMwNzI3MCI6eyJzdHlsZSI6eyJtYXJnaW50b3AiOiIxMCIsImJhY2tncm91bmQiOiIjZmZmZmZmIiwiaWNvbmNvbG9yIjoiIzk5OTk5OSIsInRleHRjb2xvciI6IiMzMzMzMzMiLCJyZW1hcmtjb2xvciI6IiM4ODg4ODgifSwiZGF0YSI6eyJDMTQ3NDUyNjMwNzI3MCI6eyJ0ZXh0IjoiXHU2NTM2XHU4ZDI3XHU1NzMwXHU1NzQwXHU3YmExXHU3NDA2IiwibGlua3VybCI6IiIsImljb25jbGFzcyI6Imljb24tYWRkcmVzcyIsInJlbWFyayI6Ilx1NjdlNVx1NzcwYiIsImRvdG51bSI6IiJ9LCJDMTQ3NDUyNjMwNzI3MSI6eyJ0ZXh0IjoiXHU1ZTJlXHU1MmE5XHU0ZTJkXHU1ZmMzIiwibGlua3VybCI6IiIsImljb25jbGFzcyI6Imljb24tcXVlc3Rpb25maWxsIiwicmVtYXJrIjoiXHU2N2U1XHU3NzBiIiwiZG90bnVtIjoiIn19LCJpZCI6Imxpc3RtZW51In0sIk0xNDc0NTk3NzI2NTU2Ijp7InBhcmFtcyI6eyJiaW5kdXJsIjoiIiwibG9nb3V0dXJsIjoiIn0sInN0eWxlIjp7InRleHRjb2xvciI6IiNmZjAwMTEiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsIm1hcmdpbnRvcCI6IjEwIn0sImlkIjoibG9nb3V0In0sIk0xNDc0NTk3OTcxMjE4Ijp7InBhcmFtcyI6eyJjb250ZW50IjoiUEhBZ2MzUjViR1U5SW5SbGVIUXRZV3hwWjI0NklHTmxiblJsY2pzaVB1ZUppT2FkZythSmdPYWNpU0FvWXlrZ2VIaDQ1WldHNVorT1BDOXdQZz09In0sInN0eWxlIjp7ImJhY2tncm91bmQiOiIjZmZmZmZmIiwicGFkZGluZyI6IjIwIn0sImlkIjoicmljaHRleHQifX19','../addons/ewei_shopv2/plugin/diypage/static/template/member1/preview.jpg',9,0,0,0),(10,0,4,'分销中心01','eyJwYWdlIjp7InR5cGUiOiI0IiwidGl0bGUiOiJcdThiZjdcdThmOTNcdTUxNjVcdTk4NzVcdTk3NjJcdTY4MDdcdTk4OTgiLCJuYW1lIjoiXHU2NzJhXHU1NDdkXHU1NDBkXHU5ODc1XHU5NzYyIiwiZGVzYyI6IiIsImljb24iOiIiLCJrZXl3b3JkIjoiIiwiYmFja2dyb3VuZCI6IiNmYWZhZmEiLCJkaXltZW51IjoiLTEiLCJmb2xsb3diYXIiOiIwIiwidmlzaXQiOiIwIiwidmlzaXRsZXZlbCI6eyJtZW1iZXIiOiIiLCJjb21taXNzaW9uIjoiIn0sIm5vdmlzaXQiOnsidGl0bGUiOiIiLCJsaW5rIjoiIn19LCJpdGVtcyI6eyJNMTQ3NTk3NjIxMDU0NiI6eyJwYXJhbXMiOnsic3R5bGUiOiJkZWZhdWx0MSIsInNldGljb24iOiJpY29uLXNldHRpbmdzIiwic2V0bGluayI6IiIsImxlZnRuYXYiOiJcdTYzZDBcdTczYjAxIiwibGVmdG5hdmxpbmsiOiIiLCJyaWdodG5hdiI6Ilx1NjNkMFx1NzNiMDIiLCJyaWdodG5hdmxpbmsiOiIiLCJjZW50ZXJuYXYiOiJcdTYzZDBcdTczYjAiLCJjZW50ZXJuYXZsaW5rIjoiIn0sInN0eWxlIjp7ImJhY2tncm91bmQiOiIjZmU1NDU1IiwidGV4dGNvbG9yIjoiI2ZmZmZmZiIsInRleHRsaWdodCI6IiNmZWYzMWYifSwiaWQiOiJtZW1iZXJjIn0sIk0xNDc1OTc2MjEyMzA1Ijp7InBhcmFtcyI6eyJyb3dudW0iOiIzIn0sInN0eWxlIjp7ImJhY2tncm91bmQiOiIjZmZmZmZmIiwidGlwY29sb3IiOiIjZmViMzEyIn0sImRhdGEiOnsiQzE0NzU5NzYyMTIzMDUiOnsiaWNvbmNsYXNzIjoiaWNvbi1tb25leSIsImljb25jb2xvciI6IiNmZWIzMTIiLCJ0ZXh0IjoiXHU1MjA2XHU5NTAwXHU0ZjYzXHU5MWQxIiwidGV4dGNvbG9yIjoiIzY2NjY2NiIsImxpbmt1cmwiOiIiLCJ0aXBudW0iOiIwLjAwIiwidGlwdGV4dCI6Ilx1NTE0MyJ9LCJDMTQ3NTk3NjIxMjMwNiI6eyJpY29uY2xhc3MiOiJpY29uLWxpc3QiLCJpY29uY29sb3IiOiIjNTBiNmZlIiwidGV4dCI6Ilx1NGY2M1x1OTFkMVx1NjYwZVx1N2VjNiIsInRleHRjb2xvciI6IiM2NjY2NjYiLCJsaW5rdXJsIjoiIiwidGlwbnVtIjoiNTAiLCJ0aXB0ZXh0IjoiXHU3YjE0In0sIkMxNDc1OTc2MjEyMzA4Ijp7Imljb25jbGFzcyI6Imljb24tbWFuYWdlb3JkZXIiLCJpY29uY29sb3IiOiIjZmY3NDFkIiwidGV4dCI6Ilx1NjNkMFx1NzNiMFx1NjYwZVx1N2VjNiIsInRleHRjb2xvciI6IiM2NjY2NjYiLCJsaW5rdXJsIjoiIiwidGlwbnVtIjoiMTAiLCJ0aXB0ZXh0IjoiXHU3YjE0In0sIkMxNDc1OTc2MjEyMzA5Ijp7Imljb25jbGFzcyI6Imljb24tZ3JvdXAiLCJpY29uY29sb3IiOiIjZmY3NDFkIiwidGV4dCI6Ilx1NjIxMVx1NzY4NFx1NGUwYlx1N2ViZiIsInRleHRjb2xvciI6IiM2NjY2NjYiLCJsaW5rdXJsIjoiIiwidGlwbnVtIjoiMiIsInRpcHRleHQiOiJcdTRlYmEifSwiQzE0NzU5NzYyMTIzMTAiOnsiaWNvbmNsYXNzIjoiaWNvbi1xcmNvZGUiLCJpY29uY29sb3IiOiIjZmViMzEyIiwidGV4dCI6Ilx1NjNhOFx1NWU3Zlx1NGU4Y1x1N2VmNFx1NzgwMSIsInRleHRjb2xvciI6IiM2NjY2NjYiLCJsaW5rdXJsIjoiIiwidGlwbnVtIjoiIiwidGlwdGV4dCI6IiJ9LCJDMTQ3NTk3NjIxMjMxMSI6eyJpY29uY2xhc3MiOiJpY29uLXNob3BmaWxsIiwiaWNvbmNvbG9yIjoiIzUwYjZmZSIsInRleHQiOiJcdTVjMGZcdTVlOTdcdThiYmVcdTdmNmUiLCJ0ZXh0Y29sb3IiOiIjNjY2NjY2IiwibGlua3VybCI6IiIsInRpcG51bSI6IiIsInRpcHRleHQiOiIifSwiQzE0NzU5NzYyMTIzMTIiOnsiaWNvbmNsYXNzIjoiaWNvbi1yYW5rIiwiaWNvbmNvbG9yIjoiI2ZmNzQxZCIsInRleHQiOiJcdTRmNjNcdTkxZDFcdTYzOTJcdTU0MGQiLCJ0ZXh0Y29sb3IiOiIjNjY2NjY2IiwibGlua3VybCI6IiIsInRpcG51bSI6IiIsInRpcHRleHQiOiIifX0sImlkIjoiYmxvY2tncm91cCJ9fX0=','../addons/ewei_shopv2/plugin/diypage/static/template/commission1/preview.jpg',10,0,0,0),(11,0,5,'商品详情','eyJwYWdlIjp7InR5cGUiOiI1IiwidGl0bGUiOiJcdTU1NDZcdTU0YzFcdThiZTZcdTYwYzUiLCJuYW1lIjoiXHU1NTQ2XHU1NGMxXHU4YmU2XHU2MGM1IiwiZGVzYyI6IiIsImljb24iOiIiLCJrZXl3b3JkIjoiIiwiYmFja2dyb3VuZCI6IiNmYWZhZmEiLCJkaXltZW51IjoiLTEiLCJmb2xsb3diYXIiOiIwIiwidmlzaXQiOiIwIiwidmlzaXRsZXZlbCI6eyJtZW1iZXIiOiIiLCJjb21taXNzaW9uIjoiIn0sIm5vdmlzaXQiOnsidGl0bGUiOiIiLCJsaW5rIjoiIn0sImRpeWxheWVyIjoiMSJ9LCJpdGVtcyI6eyJNMTQ3ODc4Mjg4ODAyOCI6eyJ0eXBlIjoiNSIsIm1heCI6IjEiLCJwYXJhbXMiOnsiZ29vZHN0ZXh0IjoiXHU1NTQ2XHU1NGMxIiwiZGV0YWlsdGV4dCI6Ilx1OGJlNlx1NjBjNSJ9LCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2Y3ZjdmNyIsInRleHRjb2xvciI6IiM2NjY2NjYiLCJhY3RpdmVjb2xvciI6IiNlZjRmNGYifSwiaWQiOiJkZXRhaWxfdGFiIn0sIk0xNDc4NzgyODkwMTA3Ijp7InR5cGUiOiI1IiwibWF4IjoiMSIsInN0eWxlIjp7ImRvdHN0eWxlIjoicmVjdGFuZ2xlIiwiZG90YWxpZ24iOiJsZWZ0IiwiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJsZWZ0cmlnaHQiOiI1IiwiYm90dG9tIjoiNSIsIm9wYWNpdHkiOiIwLjgifSwiaWQiOiJkZXRhaWxfc3dpcGUifSwiTTE0Nzg3ODMxMzUzNjUiOnsidHlwZSI6IjUiLCJtYXgiOiIxIiwicGFyYW1zIjp7InNoYXJlIjoiXHU1MjA2XHU0ZWFiIiwic2hhcmVfbGluayI6IiJ9LCJzdHlsZSI6eyJtYXJnaW50b3AiOiIwIiwibWFyZ2luYm90dG9tIjoiMCIsImJhY2tncm91bmQiOiIjZmZmZmZmIiwidGl0bGVjb2xvciI6IiMzMzMzMzMiLCJzdWJ0aXRsZWNvbG9yIjoiI2VmNGY0ZiIsInByaWNlY29sb3IiOiIjZWY0ZjRmIiwidGV4dGNvbG9yIjoiI2MwYzBjMCIsInRpbWVjb2xvciI6IiNlZjRmNGYiLCJ0aW1ldGV4dGNvbG9yIjoiI2VmNGY0ZiJ9LCJpZCI6ImRldGFpbF9pbmZvIn0sIk0xNDc4NzgyOTAzODE5Ijp7InR5cGUiOiI1IiwibWF4IjoiMSIsInN0eWxlIjp7Im1hcmdpbnRvcCI6IjAiLCJtYXJnaW5ib3R0b20iOiIwIiwiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJ0ZXh0Y29sb3IiOiIjNjY2NjY2IiwidGV4dGNvbG9yaGlnaCI6IiNlZjRmNGYifSwiZGF0YSI6eyJDMTQ3ODc4MjkwMzgxOSI6eyJuYW1lIjoiXHU0ZThjXHU2YjIxXHU4ZDJkXHU0ZTcwIiwidHlwZSI6ImVyY2kifSwiQzE0Nzg3ODI5MDM4MjAiOnsibmFtZSI6Ilx1NGYxYVx1NTQ1OFx1NGVmNyIsInR5cGUiOiJodWl5dWFuIn0sIkMxNDc4NzgyOTAzODIxIjp7Im5hbWUiOiJcdTRmMThcdTYwZTAiLCJ0eXBlIjoieW91aHVpIn0sIkMxNDc4NzgyOTAzODIyIjp7Im5hbWUiOiJcdTc5ZWZcdTUyMDYiLCJ0eXBlIjoiamlmZW4ifSwiQzE0Nzg3ODI5MDM4MjMiOnsibmFtZSI6Ilx1NGUwZFx1OTE0ZFx1OTAwMVx1NTMzYVx1NTdkZiIsInR5cGUiOiJidXBlaXNvbmcifSwiQzE0Nzg3ODI5MDM4MjQiOnsibmFtZSI6Ilx1NTU0Nlx1NTRjMVx1NjgwN1x1N2I3ZSIsInR5cGUiOiJiaWFvcWlhbiJ9fSwiaWQiOiJkZXRhaWxfc2FsZSJ9LCJNMTQ3ODc4MzE5MDI1NSI6eyJ0eXBlIjoiNSIsIm1heCI6IjEiLCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsInRleHRjb2xvciI6IiMzMzMzMzMiLCJtYXJnaW50b3AiOiIxMCIsIm1hcmdpbmJvdHRvbSI6IjAifSwiaWQiOiJkZXRhaWxfc3BlYyJ9LCJNMTQ3ODc4MzE5NjIxOSI6eyJ0eXBlIjoiNSIsIm1heCI6IjEiLCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsIm1hcmdpbnRvcCI6IjEwIiwibWFyZ2luYm90dG9tIjoiMCIsInRleHRjb2xvciI6IiM3YzdjN2MifSwiaWQiOiJkZXRhaWxfcGFja2FnZSJ9LCJNMTQ3ODc4MjkyNDA3NiI6eyJ0eXBlIjoiNSIsIm1heCI6IjEiLCJwYXJhbXMiOnsic2hvcGxvZ28iOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2Mlwvc3RhdGljXC9pbWFnZXNcL2Rlc2lnbmVyLmpwZyIsInNob3BuYW1lIjoiIiwic2hvcGRlc2MiOiIiLCJoaWRlbnVtIjoiMCIsImxlZnRuYXZ0ZXh0IjoiXHU1MTY4XHU5MGU4XHU1NTQ2XHU1NGMxIiwibGVmdG5hdmxpbmsiOiIiLCJyaWdodG5hdnRleHQiOiJcdThmZGJcdTVlOTdcdTkwMWJcdTkwMWIiLCJyaWdodG5hdmxpbmsiOiIifSwic3R5bGUiOnsibWFyZ2ludG9wIjoiMTAiLCJtYXJnaW5ib3R0b20iOiIwIiwiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJnb29kc251bWNvbG9yIjoiIzMzMzMzMyIsImdvb2RzdGV4dGNvbG9yIjoiIzdjN2M3YyIsInJpZ2h0bmF2Y29sb3IiOiIjN2M3YzdjIiwic2hvcG5hbWVjb2xvciI6IiMzMzMzMzMiLCJzaG9wZGVzY2NvbG9yIjoiIzQ0NDQ0NCJ9LCJpZCI6ImRldGFpbF9zaG9wIn0sIk0xNDc4NzgyOTI4ODg0Ijp7InR5cGUiOiI1IiwibWF4IjoiMSIsInN0eWxlIjp7ImJhY2tncm91bmQiOiIjZmZmZmZmIiwibWFyZ2ludG9wIjoiMTAiLCJtYXJnaW5ib3R0b20iOiIwIiwidGl0bGVjb2xvciI6IiMzMzMzMzMiLCJzaG9wbmFtZWNvbG9yIjoiIzMzMzMzMyIsInNob3BpbmZvY29sb3IiOiIjNjY2NjY2IiwibmF2dGVsY29sb3IiOiIjMDA4MDAwIiwibmF2bG9jYXRpb25jb2xvciI6IiNmZjk5MDAifSwiaWQiOiJkZXRhaWxfc3RvcmUifSwiTTE0Nzg3ODMyMTAxNDciOnsidHlwZSI6IjUiLCJtYXgiOiIxIiwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJtYXJnaW50b3AiOiIxMCIsIm1hcmdpbmJvdHRvbSI6IjAifSwiaWQiOiJkZXRhaWxfYnV5c2hvdyJ9LCJNMTQ3ODc4MzIxNDg3OSI6eyJ0eXBlIjoiNSIsIm1heCI6IjEiLCJzdHlsZSI6eyJtYXJnaW50b3AiOiIxMCIsIm1hcmdpbmJvdHRvbSI6IjEwIiwiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJtYWluY29sb3IiOiIjZmQ1NDU0Iiwic3ViY29sb3IiOiIjN2M3YzdjIiwidGV4dGNvbG9yIjoiIzMzMzMzMyJ9LCJpZCI6ImRldGFpbF9jb21tZW50In0sIk0xNDc4NzgzMjI1MTU4Ijp7InR5cGUiOiI1IiwibWF4IjoiMSIsInBhcmFtcyI6eyJoaWRlbGlrZSI6IjAiLCJoaWRlc2hvcCI6IjAiLCJoaWRlY2FydCI6IjAiLCJoaWRlY2FydGJ0biI6IjAiLCJ0ZXh0YnV5IjoiXHU3YWNiXHU1MjNiXHU4ZDJkXHU0ZTcwIiwiZ29vZHN0ZXh0IjoiXHU1NTQ2XHU1NGMxIiwibGlrZXRleHQiOiJcdTUxNzNcdTZjZTgiLCJsaWtlaWNvbmNsYXNzIjoiaWNvbi1saWtlIiwibGlrZWxpbmsiOiJpY29uLWxpa2UiLCJzaG9wdGV4dCI6Ilx1NWU5N1x1OTRmYSIsInNob3BpY29uY2xhc3MiOiJpY29uLXNob3AiLCJjYXJ0dGV4dCI6Ilx1OGQyZFx1NzI2OVx1OGY2NiIsImNhcnRpY29uY2xhc3MiOiJpY29uLWNhcnQifSwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJ0ZXh0Y29sb3IiOiIjOTk5OTk5IiwiaWNvbmNvbG9yIjoiIzk5OTk5OSIsImNhcnRjb2xvciI6IiNmZTk0MDIiLCJidXljb2xvciI6IiNmZDU1NTUiLCJkb3Rjb2xvciI6IiNmZjAwMTEifSwiaWQiOiJkZXRhaWxfbmF2YmFyIn19fQ==','../addons/ewei_shopv2/plugin/diypage/static/template/detail1/preview.jpg',11,0,0,0),(12,0,7,'整点秒杀','eyJwYWdlIjp7InR5cGUiOiI3IiwidGl0bGUiOiJcdTY1NzRcdTcwYjlcdTc5ZDJcdTY3NDAiLCJuYW1lIjoiXHU2NTc0XHU3MGI5XHU3OWQyXHU2NzQwIiwiZGVzYyI6IiIsImljb24iOiIiLCJrZXl3b3JkIjoiIiwiYmFja2dyb3VuZCI6IiNmYWZhZmEiLCJkaXltZW51IjoiLTEiLCJmb2xsb3diYXIiOiIwIiwidmlzaXQiOiIwIiwidmlzaXRsZXZlbCI6eyJtZW1iZXIiOiIiLCJjb21taXNzaW9uIjoiIn0sIm5vdmlzaXQiOnsidGl0bGUiOiIiLCJsaW5rIjoiIn19LCJpdGVtcyI6eyJNMTQ4MDQ5ODExNTc4MCI6eyJ0eXBlIjoiNyIsIm1heCI6IjEiLCJzdHlsZSI6eyJtYXJnaW50b3AiOiIwIiwiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJjb2xvciI6IiMzMzMzMzMiLCJiZ2NvbG9yIjoiI2ZmZmZmZiIsInNlbGVjdGVkY29sb3IiOiIjZmYzMzAwIiwic2VsZWN0ZWRiZ2NvbG9yIjoiI2ZmZmZmZiJ9LCJpZCI6InNlY2tpbGxfdGltZXMifSwiTTE0ODA0OTgxMTgwMTkiOnsidHlwZSI6IjciLCJtYXgiOiIxIiwic3R5bGUiOnsibWFyZ2ludG9wIjoiMTAiLCJtYXJnaW5ib3R0b20iOiIwIiwiYmFja2dyb3VuZCI6IiNmZmZmZmYifSwiaWQiOiJzZWNraWxsX2FkdnMifSwiTTE0ODA0OTgxMTcwNDMiOnsidHlwZSI6IjciLCJtYXgiOiIxIiwic3R5bGUiOnsibWFyZ2ludG9wIjoiMTAiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsImNvbG9yIjoiIzMzMzMzMyIsImJnY29sb3IiOiIjZmZmZmZmIiwic2VsZWN0ZWRjb2xvciI6IiNlZjRmNGYiLCJzZWxlY3RlZGJnY29sb3IiOiIjZmZmZmZmIn0sImlkIjoic2Vja2lsbF9yb29tcyJ9LCJNMTQ4MDQ5ODExODQ1MyI6eyJ0eXBlIjoiNyIsIm1heCI6IjEiLCJwYXJhbXMiOnsidGl0bGV0ZXh0IjoiXHU1MTQ4XHU0ZTBiXHU1MzU1XHU1MTQ4XHU1Zjk3XHU1NGU2fiIsInRpdGxlb3ZlcnRleHQiOiJcdThmZDhcdTUzZWZcdTRlZTVcdTdlZTdcdTdlZWRcdTYyYTJcdThkMmRcdTU0ZTZ+IiwidGl0bGV3YWl0dGV4dCI6Ilx1NTM3M1x1NWMwNlx1NWYwMFx1NTljYiBcdTUxNDhcdTRlMGJcdTUzNTVcdTUxNDhcdTVmOTdcdTU0ZTYiLCJidG50ZXh0IjoiXHU2MmEyXHU4ZDJkXHU0ZTJkIiwiYnRub3ZlcnRleHQiOiJcdTVkZjJcdTYyYTJcdTViOGMiLCJidG53YWl0dGV4dCI6Ilx1N2I0OVx1NWY4NVx1NjJhMlx1OGQyZCJ9LCJzdHlsZSI6eyJtYXJnaW50b3AiOiIxMCIsIm1hcmdpbmJvdHRvbSI6IjAiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsInRvcGJnY29sb3IiOiIjZjBmMmY1IiwidG9wY29sb3IiOiIjMzMzMzMzIiwidGltZWJnY29sb3IiOiIjNDY0NTUzIiwidGltZWNvbG9yIjoiI2ZmZmZmZiIsInRpdGxlY29sb3IiOiIjMzMzMzMzIiwicHJpY2Vjb2xvciI6IiNlZjRmNGYiLCJtYXJrZXRwcmljZWNvbG9yIjoiIzk0OTU5OCIsImJ0bmJnY29sb3IiOiIjZWY0ZjRmIiwiYnRub3ZlcmJnY29sb3IiOiIjZjdmN2Y3IiwiYnRud2FpdGJnY29sb3IiOiIjMDRiZTAyIiwiYnRuY29sb3IiOiIjZmZmZmZmIiwiYnRub3ZlcmNvbG9yIjoiIzMzMzMzMyIsImJ0bndhaXRjb2xvciI6IiNmZmZmZmYiLCJwcm9jZXNzdGV4dGNvbG9yIjoiI2QwZDFkMiIsInByb2Nlc3NiZ2NvbG9yIjoiI2ZmOGY4ZiJ9LCJpZCI6InNlY2tpbGxfbGlzdCJ9fX0=','../addons/ewei_shopv2/plugin/diypage/static/template/seckill/preview.png',12,0,0,0),(13,0,6,'积分商城','eyJwYWdlIjp7InR5cGUiOiI2IiwidGl0bGUiOiJcdTc5ZWZcdTUyMDZcdTU1NDZcdTU3Y2UiLCJuYW1lIjoiXHU2ZDRiXHU4YmQ1XHU3OWVmXHU1MjA2XHU1NTQ2XHU1N2NlXHU5ODc1XHU5NzYyIiwiZGVzYyI6IiIsImljb24iOiIiLCJrZXl3b3JkIjoiIiwiYmFja2dyb3VuZCI6IiNmYWZhZmEiLCJkaXltZW51IjoiLTEiLCJmb2xsb3diYXIiOiIwIiwidmlzaXQiOiIwIiwidmlzaXRsZXZlbCI6eyJtZW1iZXIiOiIiLCJjb21taXNzaW9uIjoiIn0sIm5vdmlzaXQiOnsidGl0bGUiOiIiLCJsaW5rIjoiIn19LCJpdGVtcyI6eyJNMTQ3OTI2MTA2MTY0NSI6eyJzdHlsZSI6eyJkb3RzdHlsZSI6InJvdW5kIiwiZG90YWxpZ24iOiJjZW50ZXIiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsImxlZnRyaWdodCI6IjUiLCJib3R0b20iOiI1Iiwib3BhY2l0eSI6IjAuOCJ9LCJkYXRhIjp7IkMxNDc5MjYxMDYxNjQ1Ijp7ImltZ3VybCI6Imh0dHA6XC9cL29mNm9kaGRxMS5ia3QuY2xvdWRkbi5jb21cLzA2M2E2ZWM4NGY0NWE3MGQ2Y2NhOGQ4ZjI2NWQxYjcyLmpwZyIsImxpbmt1cmwiOiIuXC9pbmRleC5waHA/aT0xMiZjPWVudHJ5Jm09ZXdlaV9zaG9wdjImZG89bW9iaWxlJnI9Y3JlZGl0c2hvcC5kZXRhaWwmaWQ9MTE3In0sIkMxNDc5MjYxMDYxNjQ2Ijp7ImltZ3VybCI6Imh0dHA6XC9cL29mNm9kaGRxMS5ia3QuY2xvdWRkbi5jb21cLzQwMTgzYzEyY2M0MWIxYWYwMjY3NDIwYzUwNjQyODliLmpwZyIsImxpbmt1cmwiOiIuXC9pbmRleC5waHA/aT0xMiZjPWVudHJ5Jm09ZXdlaV9zaG9wdjImZG89bW9iaWxlJnI9Y3JlZGl0c2hvcC5saXN0cyJ9fSwiaWQiOiJiYW5uZXIifSwiTTE0NzkyNjgxMTQxNjEiOnsic3R5bGUiOnsibWFyZ2ludG9wIjoiMTAiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiJ9LCJkYXRhIjp7IkMxNDc5MjY4MTE0MTYxIjp7InRleHQiOiJcdTYyMTFcdTc2ODRcdTc5ZWZcdTUyMDYiLCJpY29uY2xhc3MiOiJpY29uLWppZmVuIiwidGV4dGNvbG9yIjoiIzY2NjY2NiIsImljb25jb2xvciI6IiM2NjY2NjYiLCJsaW5rdXJsIjoiLlwvaW5kZXgucGhwP2k9MTImYz1lbnRyeSZtPWV3ZWlfc2hvcHYyJmRvPW1vYmlsZSZyPWNyZWRpdHNob3AuY3JlZGl0bG9nIn0sIkMxNDc5MjY4MTE0MTYyIjp7InRleHQiOiJcdTUxNTFcdTYzNjJcdThiYjBcdTVmNTUiLCJpY29uY2xhc3MiOiJpY29uLWxpc3QiLCJ0ZXh0Y29sb3IiOiIjNjY2NjY2IiwiaWNvbmNvbG9yIjoiIzY2NjY2NiIsImxpbmt1cmwiOiIuXC9pbmRleC5waHA/aT0xMiZjPWVudHJ5Jm09ZXdlaV9zaG9wdjImZG89bW9iaWxlJnI9Y3JlZGl0c2hvcC5sb2cifX0sImlkIjoibWVudTIifSwiTTE0NzkyOTA3OTU0MjciOnsicGFyYW1zIjp7InBsYWNlaG9sZGVyIjoiXHU4YmY3XHU4ZjkzXHU1MTY1XHU1MTczXHU5NTJlXHU1YjU3XHU4ZmRiXHU4ODRjXHU2NDFjXHU3ZDIyIiwiZ29vZHN0eXBlIjoiMSJ9LCJzdHlsZSI6eyJpbnB1dGJhY2tncm91bmQiOiIjZmZmZmZmIiwiYmFja2dyb3VuZCI6IiNmMWYxZjIiLCJpY29uY29sb3IiOiIjYjRiNGI0IiwiY29sb3IiOiIjOTk5OTk5IiwicGFkZGluZ3RvcCI6IjYiLCJwYWRkaW5nbGVmdCI6IjEwIiwidGV4dGFsaWduIjoibGVmdCIsInNlYXJjaHN0eWxlIjoiIn0sImlkIjoic2VhcmNoIn0sIk0xNDc5NTQ0NjE5NDQwIjp7InN0eWxlIjp7ImhlaWdodCI6IjEwIiwiYmFja2dyb3VuZCI6IiNmYWZhZmEifSwiaWQiOiJibGFuayJ9LCJNMTQ3OTI2MTA3NjMzMyI6eyJzdHlsZSI6eyJuYXZzdHlsZSI6IiIsImJhY2tncm91bmQiOiIjZmZmZmZmIiwicm93bnVtIjoiNCIsInNob3d0eXBlIjoiMCIsInNob3dkb3QiOiIxIiwicGFnZW51bSI6IjgifSwiZGF0YSI6eyJDMTQ3OTI2MTA3NjMzMyI6eyJpbWd1cmwiOiJodHRwOlwvXC9vZjZvZGhkcTEuYmt0LmNsb3VkZG4uY29tXC9mNGM0ZWZlNjEwMzJiNGE5N2VjYTAzNWM3ZTcyNTA2OC5wbmciLCJsaW5rdXJsIjoiIiwidGV4dCI6Ilx1NzNiMFx1OTFkMVx1N2VhMlx1NTMwNSIsImNvbG9yIjoiIzY2NjY2NiJ9LCJDMTQ3OTI2MTA3NjMzNCI6eyJpbWd1cmwiOiJodHRwOlwvXC9vZjZvZGhkcTEuYmt0LmNsb3VkZG4uY29tXC83MTg2ZWI1NDE2OWExMzU1YTcwMjQxNjA1OGY1ODg2My5wbmciLCJsaW5rdXJsIjoiIiwidGV4dCI6Ilx1N2NiZVx1N2Y4ZVx1NWI5ZVx1NzI2OSIsImNvbG9yIjoiIzY2NjY2NiJ9LCJDMTQ3OTI2MTA3NjMzNSI6eyJpbWd1cmwiOiJodHRwOlwvXC9vZjZvZGhkcTEuYmt0LmNsb3VkZG4uY29tXC85NzFhODQxYzI1NzdlZDlhYjQyNDJlOTkxZjU5YWE1My5wbmciLCJsaW5rdXJsIjoiIiwidGV4dCI6Ilx1NGYxOFx1NjBlMFx1NTIzOCIsImNvbG9yIjoiIzY2NjY2NiJ9LCJDMTQ3OTI2MTA3NjMzNiI6eyJpbWd1cmwiOiJodHRwOlwvXC9vZjZvZGhkcTEuYmt0LmNsb3VkZG4uY29tXC80NWE3NDYwOTRlOWM5NmY2ZTY5Njg0OWFlNmYxMDFhZS5wbmciLCJsaW5rdXJsIjoiIiwidGV4dCI6Ilx1NGY1OVx1OTg5ZFx1NTk1Nlx1NTJiMSIsImNvbG9yIjoiIzY2NjY2NiJ9fSwiaWQiOiJtZW51In0sIk0xNDc5MjYxNDUwNzM0Ijp7InN0eWxlIjp7Im1hcmdpbnRvcCI6IjEwIiwiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJpY29uY29sb3IiOiIjOTk5OTk5IiwidGV4dGNvbG9yIjoiIzMzMzMzMyIsInJlbWFya2NvbG9yIjoiIzg4ODg4OCJ9LCJkYXRhIjp7IkMxNDc5MjYxNDUwNzM0Ijp7InRleHQiOiJcdTdjYmVcdTdmOGVcdTViOWVcdTcyNjlcdTYyYmRcdTU5NTYiLCJsaW5rdXJsIjoiIiwiaWNvbmNsYXNzIjoiaWNvbi1naWZ0cyIsInJlbWFyayI6Ilx1NjZmNFx1NTkxYSIsImRvdG51bSI6IiJ9fSwiaWQiOiJsaXN0bWVudSJ9LCJNMTQ3OTU0Mzc4MTg2NyI6eyJwYXJhbXMiOnsiZ29vZHN0eXBlIjoiMSIsInNob3d0aXRsZSI6IjEiLCJzaG93cHJpY2UiOiIxIiwic2hvd3RhZyI6IjIiLCJnb29kc2RhdGEiOiI1IiwiY2F0ZWlkIjoiIiwiY2F0ZW5hbWUiOiIiLCJncm91cGlkIjoiIiwiZ3JvdXBuYW1lIjoiIiwiZ29vZHNzb3J0IjoiMCIsImdvb2RzbnVtIjoiNiIsInNob3dpY29uIjoiMSIsImljb25wb3NpdGlvbiI6ImxlZnQgdG9wIiwicHJvZHVjdHByaWNlIjoiMSIsImdvb2Rzc2Nyb2xsIjoiMSJ9LCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsImxpc3RzdHlsZSI6ImJsb2NrIiwiYnV5c3R5bGUiOiJidXlidG4tMSIsImdvb2RzaWNvbiI6InJlY29tbWFuZCIsInByaWNlY29sb3IiOiIjZWQyODIyIiwiaWNvbnBhZGRpbmd0b3AiOiIwIiwiaWNvbnBhZGRpbmdsZWZ0IjoiMCIsImJ1eWJ0bmNvbG9yIjoiI2ZlNTQ1NSIsImljb256b29tIjoiMTAwIiwidGl0bGVjb2xvciI6IiMyNjI2MjYiLCJ0YWdiYWNrZ3JvdW5kIjoiI2ZlNTQ1NSJ9LCJkYXRhIjp7IkMxNDc5NTQzNzgxODY3Ijp7InRodW1iIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2dvb2RzLTEuanBnIiwicHJpY2UiOiIyMC4wMCIsInRpdGxlIjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU1NTQ2XHU1NGMxXHU2ODA3XHU5ODk4IiwiZ2lkIjoiIiwiYmFyZ2FpbiI6IjAiLCJjcmVkaXQiOiIwIiwiY3R5cGUiOiIxIn0sIkMxNDc5NTQzNzgxODY4Ijp7InRodW1iIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2dvb2RzLTIuanBnIiwicHJpY2UiOiIyMC4wMCIsInRpdGxlIjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU1NTQ2XHU1NGMxXHU2ODA3XHU5ODk4IiwiZ2lkIjoiIiwiYmFyZ2FpbiI6IjAiLCJjcmVkaXQiOiIwIiwiY3R5cGUiOiIxIn0sIkMxNDc5NTQzNzgxODY5Ijp7InRodW1iIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2dvb2RzLTMuanBnIiwicHJpY2UiOiIyMC4wMCIsInRpdGxlIjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU1NTQ2XHU1NGMxXHU2ODA3XHU5ODk4IiwiZ2lkIjoiIiwiYmFyZ2FpbiI6IjAiLCJjcmVkaXQiOiIwIiwiY3R5cGUiOiIwIn0sIkMxNDc5NTQzNzgxODcwIjp7InRodW1iIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2dvb2RzLTQuanBnIiwicHJpY2UiOiIyMC4wMCIsInRpdGxlIjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU1NTQ2XHU1NGMxXHU2ODA3XHU5ODk4IiwiZ2lkIjoiIiwiYmFyZ2FpbiI6IjAiLCJjcmVkaXQiOiIwIiwiY3R5cGUiOiIwIn19LCJpZCI6Imdvb2RzIn0sIk0xNDc5MjYxNTk0MDc3Ijp7InN0eWxlIjp7Im1hcmdpbnRvcCI6IjEwIiwiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJpY29uY29sb3IiOiIjOTk5OTk5IiwidGV4dGNvbG9yIjoiIzMzMzMzMyIsInJlbWFya2NvbG9yIjoiIzg4ODg4OCJ9LCJkYXRhIjp7IkMxNDc5MjYxNTk0MDc3Ijp7InRleHQiOiJcdTU1NDZcdTU3Y2VcdTRmMThcdTYwZTBcdTUyMzgiLCJsaW5rdXJsIjoiIiwiaWNvbmNsYXNzIjoiaWNvbi1naWZ0cyIsInJlbWFyayI6Ilx1NjZmNFx1NTkxYSIsImRvdG51bSI6IiJ9fSwiaWQiOiJsaXN0bWVudSJ9LCJNMTQ3OTI2MTY1NTkxOSI6eyJwYXJhbXMiOnsic2hvd3RpdGxlIjoiMSIsInNob3dwcmljZSI6IjEiLCJnb29kc2RhdGEiOiIxIiwiY2F0ZWlkIjoiOTAiLCJjYXRlbmFtZSI6Ilx1NmQ0Ylx1OGJkNVx1NTIwNlx1N2M3YjAxMCIsImdyb3VwaWQiOiIiLCJncm91cG5hbWUiOiIiLCJnb29kc3NvcnQiOiIwIiwiZ29vZHNudW0iOiI2Iiwic2hvd2ljb24iOiIxIiwiaWNvbnBvc2l0aW9uIjoibGVmdCB0b3AiLCJnb29kc3R5cGUiOiIxIiwiZ29vZHNzY3JvbGwiOiIwIn0sInN0eWxlIjp7Imxpc3RzdHlsZSI6IiIsImJ1eXN0eWxlIjoiYnV5YnRuLTEiLCJnb29kc2ljb24iOiJyZWNvbW1hbmQiLCJwcmljZWNvbG9yIjoiI2VkMjgyMiIsImljb25wYWRkaW5ndG9wIjoiMCIsImljb25wYWRkaW5nbGVmdCI6IjAiLCJidXlidG5jb2xvciI6IiNmZTU0NTUiLCJpY29uem9vbSI6IjEwMCIsInRpdGxlY29sb3IiOiIjMjYyNjI2In0sImRhdGEiOnsiQzE0NzkyNjE2NTU5MTkiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMS5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIiLCJiYXJnYWluIjoiMCJ9LCJDMTQ3OTI2MTY1NTkyMCI6eyJ0aHVtYiI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvaW1hZ2VzXC9kZWZhdWx0XC9nb29kcy0yLmpwZyIsInByaWNlIjoiMjAuMDAiLCJ0aXRsZSI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1NTU0Nlx1NTRjMVx1NjgwN1x1OTg5OCIsImdpZCI6IiIsImJhcmdhaW4iOiIwIn0sIkMxNDc5MjYxNjU1OTIxIjp7InRodW1iIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2dvb2RzLTMuanBnIiwicHJpY2UiOiIyMC4wMCIsInRpdGxlIjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU1NTQ2XHU1NGMxXHU2ODA3XHU5ODk4IiwiZ2lkIjoiIiwiYmFyZ2FpbiI6IjAifSwiQzE0NzkyNjE2NTU5MjIiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtNC5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIiLCJiYXJnYWluIjoiMCJ9fSwiaWQiOiJnb29kcyJ9fX0=','../addons/ewei_shopv2/plugin/diypage/static/template/creditshop/preview.png',13,0,0,0),(14,0,8,'兑换中心','eyJwYWdlIjp7InR5cGUiOiI4IiwidGl0bGUiOiJcdTUxNTFcdTYzNjJcdTRlMmRcdTVmYzMiLCJuYW1lIjoiXHU1MTUxXHU2MzYyXHU0ZTJkXHU1ZmMzXHU2YTIxXHU2NzdmIiwiZGVzYyI6IiIsImljb24iOiIiLCJrZXl3b3JkIjoiIiwiYmFja2dyb3VuZCI6IiNmYWZhZmEiLCJkaXltZW51IjoiLTEiLCJkaXlsYXllciI6IjAiLCJkaXlnb3RvcCI6IjAiLCJmb2xsb3diYXIiOiIwIiwidmlzaXQiOiIwIiwidmlzaXRsZXZlbCI6eyJtZW1iZXIiOiIiLCJjb21taXNzaW9uIjoiIn0sIm5vdmlzaXQiOnsidGl0bGUiOiIiLCJsaW5rIjoiIn19LCJpdGVtcyI6eyJNMTQ4MjM3Mjk0MjA3NSI6eyJtYXgiOiIxIiwidHlwZSI6IjgiLCJwYXJhbXMiOnsiZGF0YXR5cGUiOiIwIn0sInN0eWxlIjp7ImRvdHN0eWxlIjoicm91bmQiLCJkb3RhbGlnbiI6ImNlbnRlciIsImJhY2tncm91bmQiOiIjZmZmZmZmIiwibGVmdHJpZ2h0IjoiNSIsImJvdHRvbSI6IjUiLCJvcGFjaXR5IjoiMC44In0sImRhdGEiOnsiQzE0ODIzNzI5NDIwNzUiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0xLmpwZyIsImxpbmt1cmwiOiIifSwiQzE0ODIzNzI5NDIwNzYiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0yLmpwZyIsImxpbmt1cmwiOiIifX0sImlkIjoiZXhjaGFuZ2VfYmFubmVyIn0sIk0xNDgyMzcyOTQyNTE1Ijp7Im1heCI6IjEiLCJ0eXBlIjoiOCIsInBhcmFtcyI6eyJwcmV2aWV3IjoiMCIsInRpdGxlIjoiXHU1MTUxXHU2MzYyXHU3ODAxXHU1MTUxXHU2MzYyIiwicGxhY2Vob2xkZXIiOiJcdThiZjdcdThmOTNcdTUxNjVcdTUxNTFcdTYzNjJcdTc4MDEiLCJidG50ZXh0IjoiXHU3YWNiXHU1MzczXHU1MTUxXHU2MzYyIiwiYmFja2J0biI6Ilx1OGZkNFx1NTZkZVx1OTFjZFx1NjViMFx1OGY5M1x1NTE2NVx1NTE1MVx1NjM2Mlx1NzgwMSIsImV4YnRudGV4dCI6Ilx1NTE1MVx1NjM2MiIsImV4YnRuMnRleHQiOiJcdTVkZjJcdTUxNTFcdTYzNjIiLCJjcmVkaXRpY29uIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2ljb25fY3JlZGl0LnBuZyIsIm1vbmV5aWNvbiI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvaW1hZ2VzXC9kZWZhdWx0XC9pY29uX21vbmV5LnBuZyIsImNvdXBvbmljb24iOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvaWNvbl9jb3Vwb24ucG5nIiwicmVkYmFnaWNvbiI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvaW1hZ2VzXC9kZWZhdWx0XC9pY29uX3JlZGJhZy5wbmciLCJnb29kc2ljb24iOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvaWNvbl9nb29kcy5wbmcifSwic3R5bGUiOnsidGl0bGVjb2xvciI6IiM0NDQ0NDQiLCJidG5jb2xvciI6IiNmZmZmZmYiLCJidG5iYWNrZ3JvdW5kIjoiI2VkNTU2NSIsImlucHV0Y29sb3IiOiIjNjY2NjY2IiwiaW5wdXRiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsImlucHV0Ym9yZGVyIjoiI2VmZWZlZiIsImNvZGVjb2xvciI6IiM0NDQ0NDQiLCJudW1jb2xvciI6IiM5OTk5OTkiLCJleGJ0bmNvbG9yIjoiI2ZmZmZmZiIsImV4YnRuYmFja2dyb3VuZCI6IiNlZDU1NjUiLCJleGJ0bjJjb2xvciI6IiNmZmZmZmYiLCJleGJ0bjJiYWNrZ3JvdW5kIjoiI2NjY2NjYyIsImJhY2tidG5jb2xvciI6IiM0NDQ0NDQiLCJiYWNrYnRuYm9yZGVyIjoiI2U3ZWFlYyIsImJhY2tidG5iYWNrZ3JvdW5kIjoiI2Y3ZjdmNyIsImdvb2RzdGl0bGUiOiIjNDQ0NDQ0IiwiZ29vZHNwcmljZSI6IiNhYWFhYWEifSwiaWQiOiJleGNoYW5nZV9pbnB1dCJ9LCJNMTQ4MjM3Mjk0MzE3MyI6eyJtYXgiOiIxIiwidHlwZSI6IjgiLCJwYXJhbXMiOnsicnVsZXRpdGxlIjoiXHU1MTUxXHU2MzYyXHU4OWM0XHU1MjE5In0sInN0eWxlIjp7InJ1bGV0aXRsZWNvbG9yIjoiIzU1NTU1NSJ9LCJpZCI6ImV4Y2hhbmdlX3J1bGUifX19','../addons/ewei_shopv2/plugin/diypage/static/template/exchange/preview.png',14,0,0,0),(15,6,2,'首页_所有插件','eyJwYWdlIjp7InR5cGUiOiIyIiwidGl0bGUiOiJcdTk5OTZcdTk4NzUiLCJuYW1lIjoiXHU2MjExXHU3Njg0XHU5OTk2XHU5ODc1IiwiZGVzYyI6Ilx1OTk5Nlx1OTg3NSIsImljb24iOiIiLCJrZXl3b3JkIjoiIiwiYmFja2dyb3VuZCI6IiNmYWZhZmEiLCJkaXltZW51IjoiLTEiLCJkaXlsYXllciI6IjAiLCJkaXlnb3RvcCI6IjAiLCJmb2xsb3diYXIiOiIwIiwidmlzaXQiOiIwIiwidmlzaXRsZXZlbCI6eyJtZW1iZXIiOiIiLCJjb21taXNzaW9uIjoiIn0sIm5vdmlzaXQiOnsidGl0bGUiOiIiLCJsaW5rIjoiIn19LCJpdGVtcyI6eyJNMTUwNDYxODE2NzM1MSI6eyJpc3RvcCI6IjEiLCJtYXgiOiIxIiwicGFyYW1zIjp7ImxlZnRuYXYiOiIxIiwicmlnaHRuYXYiOiIxIiwibGVmdG5hdmljb24iOiJpY29uLXNob3AiLCJyaWdodG5hdmljb24iOiJpY29uLWNhcnQiLCJzZWFyY2hzdHlsZSI6InJvdW5kIiwicGxhY2Vob2xkZXIiOiJcdThmOTNcdTUxNjVcdTUxNzNcdTk1MmVcdTViNTdcdThmZGJcdTg4NGNcdTY0MWNcdTdkMjIifSwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiMwMDAwMDAiLCJvcGFjaXR5IjoiMC44Iiwib3BhY2l0eWlucHV0IjoiMC44IiwibGVmdG5hdmNvbG9yIjoiI2ZmZmZmZiIsInJpZ2h0bmF2Y29sb3IiOiIjZmZmZmZmIiwic2VhcmNoYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJzZWFyY2h0ZXh0Y29sb3IiOiIjNjY2NjY2In0sImlkIjoiZml4ZWRzZWFyY2gifSwiTTE1MDQ2MTgxMTkwMzAiOnsicGFyYW1zIjp7Imljb251cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvaG90ZG90LmpwZyIsIm5vdGljZWRhdGEiOiIwIiwic3BlZWQiOiI0Iiwibm90aWNlbnVtIjoiNSJ9LCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsImljb25jb2xvciI6IiNmZDU0NTQiLCJjb2xvciI6IiM2NjY2NjYiLCJib3JkZXJjb2xvciI6IiNlMmUyZTIifSwiZGF0YSI6eyJDMTUwNDYxODExOTAzMCI6eyJ0aXRsZSI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1N2IyY1x1NGUwMFx1Njc2MVx1ODFlYVx1NWI5YVx1NGU0OVx1NTE2Y1x1NTQ0YVx1NzY4NFx1NjgwN1x1OTg5OCIsImxpbmt1cmwiOiIifSwiQzE1MDQ2MTgxMTkwMzEiOnsidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTdiMmNcdTRlOGNcdTY3NjFcdTgxZWFcdTViOWFcdTRlNDlcdTUxNmNcdTU0NGFcdTc2ODRcdTY4MDdcdTk4OTgiLCJsaW5rdXJsIjoiIn19LCJpZCI6Im5vdGljZSJ9LCJNMTUwNDYxODE3Njk2OCI6eyJwYXJhbXMiOnsiZ29vZHN0eXBlIjoiMCIsInNob3d0aXRsZSI6IjEiLCJzaG93cHJpY2UiOiIxIiwic2hvd3RhZyI6IjAiLCJnb29kc2RhdGEiOiIwIiwiY2F0ZWlkIjoiIiwiY2F0ZW5hbWUiOiIiLCJncm91cGlkIjoiIiwiZ3JvdXBuYW1lIjoiIiwiZ29vZHNzb3J0IjoiMCIsImdvb2RzbnVtIjoiNiIsInNob3dpY29uIjoiMSIsImljb25wb3NpdGlvbiI6ImxlZnQgdG9wIiwicHJvZHVjdHByaWNlIjoiMSIsInNob3dwcm9kdWN0cHJpY2UiOiIwIiwic2hvd3NhbGVzIjoiMCIsInByb2R1Y3RwcmljZXRleHQiOiJcdTUzOWZcdTRlZjciLCJzYWxlc3RleHQiOiJcdTk1MDBcdTkxY2YiLCJwcm9kdWN0cHJpY2VsaW5lIjoiMCJ9LCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2ZhZmFmYSIsImxpc3RzdHlsZSI6ImJsb2NrIiwiYnV5c3R5bGUiOiJidXlidG4tMSIsImdvb2RzaWNvbiI6InJlY29tbWFuZCIsInByaWNlY29sb3IiOiIjZWQyODIyIiwicHJvZHVjdHByaWNlY29sb3IiOiIjNzc3Nzc3IiwiaWNvbnBhZGRpbmd0b3AiOiIwIiwiaWNvbnBhZGRpbmdsZWZ0IjoiMCIsImJ1eWJ0bmNvbG9yIjoiI2ZlNTQ1NSIsImljb256b29tIjoiMTAwIiwidGl0bGVjb2xvciI6IiMyNjI2MjYiLCJ0YWdiYWNrZ3JvdW5kIjoiI2ZlNTQ1NSIsInNhbGVzY29sb3IiOiIjNzc3Nzc3In0sImRhdGEiOnsiQzE1MDQ2MTgxNzY5NjgiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMS5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIiLCJiYXJnYWluIjoiMCIsImNyZWRpdCI6IjAiLCJjdHlwZSI6IjEifSwiQzE1MDQ2MTgxNzY5NjkiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMi5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIiLCJiYXJnYWluIjoiMCIsImNyZWRpdCI6IjAiLCJjdHlwZSI6IjEifSwiQzE1MDQ2MTgxNzY5NzAiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtMy5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIiLCJiYXJnYWluIjoiMCIsImNyZWRpdCI6IjAiLCJjdHlwZSI6IjAifSwiQzE1MDQ2MTgxNzY5NzEiOnsidGh1bWIiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvZ29vZHMtNC5qcGciLCJwcmljZSI6IjIwLjAwIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTU0YzFcdTY4MDdcdTk4OTgiLCJnaWQiOiIiLCJiYXJnYWluIjoiMCIsImNyZWRpdCI6IjAiLCJjdHlwZSI6IjAifX0sImlkIjoiZ29vZHMifSwiTTE1MDQ2MTgxODI4MTkiOnsicGFyYW1zIjp7Im1lcmNoZGF0YSI6IjAiLCJtZXJjaG51bSI6IjYiLCJtZXJjaHNvcnQiOiIiLCJjYXRlbmFtZSI6IiIsImNhdGVpZCI6IiIsImdyb3VwbmFtZSI6IiIsImdyb3VwaWQiOiIiLCJvcGVubG9jYXRpb24iOiIwIn0sInN0eWxlIjp7ImJhY2tncm91bmQiOiIjZmZmZmZmIiwidGl0bGVjb2xvciI6IiMzMzMzMzMiLCJ0ZXh0Y29sb3IiOiIjNjY2NjY2IiwicmFuZ2Vjb2xvciI6IiMwMDgwMDAiLCJsb2NhdGlvbmNvbG9yIjoiI2ZmOTkwMCIsIm1hcmdpbnRvcCI6IjEwIn0sImRhdGEiOnsiQzE1MDQ2MTgxODI4MTkiOnsibmFtZSI6Ilx1NTU0Nlx1NjIzN1x1NTQwZFx1NzlmMEEiLCJkZXNjIjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU1NTQ2XHU2MjM3QVx1NzY4NFx1NGVjYlx1N2VjZCIsInRodW1iIjoiIiwibWVyY2hpZCI6IiJ9LCJDMTUwNDYxODE4MjgyMCI6eyJuYW1lIjoiXHU1NTQ2XHU2MjM3XHU1NDBkXHU3OWYwQiIsImRlc2MiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTU1NDZcdTYyMzdCXHU3Njg0XHU0ZWNiXHU3ZWNkIiwidGh1bWIiOiIiLCJtZXJjaGlkIjoiIn0sIkMxNTA0NjE4MTgyODIxIjp7Im5hbWUiOiJcdTU1NDZcdTYyMzdcdTU0MGRcdTc5ZjBDIiwiZGVzYyI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1NTU0Nlx1NjIzN0NcdTc2ODRcdTRlY2JcdTdlY2QiLCJ0aHVtYiI6IiIsIm1lcmNoaWQiOiIifX0sImlkIjoibWVyY2hncm91cCJ9LCJNMTUwNDYxODE4ODMyNyI6eyJtYXgiOiIyIiwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJjb2xvciI6IiM2NjY2NjYiLCJhY3RpdmViYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsImFjdGl2ZWNvbG9yIjoiI2VmNGY0ZiIsInNjcm9sbG51bSI6IjMifSwiZGF0YSI6eyJDMTUwNDYxODE4ODMyNyI6eyJ0ZXh0IjoiXHU5MDA5XHU5ODc5XHU1MzYxXHU2NTg3XHU1YjU3IiwibGlua3VybCI6IiJ9LCJDMTUwNDYxODE4ODMyOCI6eyJ0ZXh0IjoiXHU5MDA5XHU5ODc5XHU1MzYxXHU2NTg3XHU1YjU3IiwibGlua3VybCI6IiJ9fSwiaWQiOiJ0YWJiYXIifSwiTTE1MDQ2MTgxOTE0NzAiOnsic3R5bGUiOnsibWFyZ2ludG9wIjoiMTAiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsImljb25jb2xvciI6IiM5OTk5OTkiLCJ0ZXh0Y29sb3IiOiIjMzMzMzMzIiwicmVtYXJrY29sb3IiOiIjODg4ODg4In0sImRhdGEiOnsiQzE1MDQ2MTgxOTE0NzAiOnsidGV4dCI6Ilx1NjU4N1x1NWI1NzEiLCJsaW5rdXJsIjoiIiwiaWNvbmNsYXNzIjoiaWNvbi1ob21lIiwicmVtYXJrIjoiXHU2N2U1XHU3NzBiIiwiZG90bnVtIjoiIn0sIkMxNTA0NjE4MTkxNDcxIjp7InRleHQiOiJcdTY1ODdcdTViNTcyIiwibGlua3VybCI6IiIsImljb25jbGFzcyI6Imljb24taG9tZSIsInJlbWFyayI6Ilx1NjdlNVx1NzcwYiIsImRvdG51bSI6IiJ9LCJDMTUwNDYxODE5MTQ3MiI6eyJ0ZXh0IjoiXHU2NTg3XHU1YjU3MyIsImxpbmt1cmwiOiIiLCJpY29uY2xhc3MiOiJpY29uLWhvbWUiLCJyZW1hcmsiOiJcdTY3ZTVcdTc3MGIiLCJkb3RudW0iOiIifX0sImlkIjoibGlzdG1lbnUifSwiTTE1MDQ2MTgxOTM0NTAiOnsicGFyYW1zIjp7ImNvbnRlbnQiOiIifSwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJwYWRkaW5nIjoiMCJ9LCJpZCI6InJpY2h0ZXh0In0sIk0xNTA0NjE4MTk2MzExIjp7InBhcmFtcyI6eyJ0aXRsZSI6IiIsImljb24iOiIifSwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJjb2xvciI6IiM2NjY2NjYiLCJ0ZXh0YWxpZ24iOiJsZWZ0IiwiZm9udHNpemUiOiIxMiIsInBhZGRpbmd0b3AiOiI1IiwicGFkZGluZ2xlZnQiOiI1In0sImlkIjoidGl0bGUifSwiTTE1MDQ2MTgxOTc5NTkiOnsic3R5bGUiOnsiaGVpZ2h0IjoiMiIsImJhY2tncm91bmQiOiIjZmZmZmZmIiwiYm9yZGVyIjoiIzAwMDAwMCIsInBhZGRpbmciOiIxMCIsImxpbmVzdHlsZSI6InNvbGlkIn0sImlkIjoibGluZSJ9LCJNMTUwNDYxODIwMTg5MCI6eyJzdHlsZSI6eyJoZWlnaHQiOiIyMCIsImJhY2tncm91bmQiOiIjZmZmZmZmIn0sImlkIjoiYmxhbmsifSwiTTE1MDQ2MTgyMDM5MjciOnsic3R5bGUiOnsibmF2c3R5bGUiOiIiLCJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsInJvd251bSI6IjQiLCJzaG93dHlwZSI6IjAiLCJwYWdlbnVtIjoiOCIsInNob3dkb3QiOiIxIn0sImRhdGEiOnsiQzE1MDQ2MTgyMDM5MjciOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2ljb24tMS5wbmciLCJsaW5rdXJsIjoiIiwidGV4dCI6Ilx1NjMwOVx1OTRhZVx1NjU4N1x1NWI1NzEiLCJjb2xvciI6IiM2NjY2NjYifSwiQzE1MDQ2MTgyMDM5MjgiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2ljb24tMi5wbmciLCJsaW5rdXJsIjoiIiwidGV4dCI6Ilx1NjMwOVx1OTRhZVx1NjU4N1x1NWI1NzIiLCJjb2xvciI6IiM2NjY2NjYifSwiQzE1MDQ2MTgyMDM5MjkiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2ljb24tMy5wbmciLCJsaW5rdXJsIjoiIiwidGV4dCI6Ilx1NjMwOVx1OTRhZVx1NjU4N1x1NWI1NzMiLCJjb2xvciI6IiM2NjY2NjYifSwiQzE1MDQ2MTgyMDM5MzAiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2ljb24tNC5wbmciLCJsaW5rdXJsIjoiIiwidGV4dCI6Ilx1NjMwOVx1OTRhZVx1NjU4N1x1NWI1NzQiLCJjb2xvciI6IiM2NjY2NjYifX0sImlkIjoibWVudSJ9LCJNMTUwNDYxODIwNjYzMyI6eyJzdHlsZSI6eyJtYXJnaW50b3AiOiIxMCIsImJhY2tncm91bmQiOiIjZmZmZmZmIn0sImRhdGEiOnsiQzE1MDQ2MTgyMDY2MzMiOnsidGV4dCI6Ilx1NjIxMVx1NzY4NFx1NzllZlx1NTIwNiIsImljb25jbGFzcyI6IiIsInRleHRjb2xvciI6IiM2NjY2NjYiLCJpY29uY29sb3IiOiIjNjY2NjY2IiwibGlua3VybCI6IiJ9LCJDMTUwNDYxODIwNjYzNCI6eyJ0ZXh0IjoiXHU1MTUxXHU2MzYyXHU4YmIwXHU1ZjU1IiwiaWNvbmNsYXNzIjoiIiwidGV4dGNvbG9yIjoiIzY2NjY2NiIsImljb25jb2xvciI6IiM2NjY2NjYiLCJsaW5rdXJsIjoiIn19LCJpZCI6Im1lbnUyIn0sIk0xNTA0NjE4MjA4NDcyIjp7InN0eWxlIjp7InBhZGRpbmd0b3AiOiIwIiwicGFkZGluZ2xlZnQiOiIwIn0sImRhdGEiOnsiQzE1MDQ2MTgyMDg0NzMiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0xLmpwZyIsImxpbmt1cmwiOiIifSwiQzE1MDQ2MTgyMDg0NzQiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0yLmpwZyIsImxpbmt1cmwiOiIifX0sImlkIjoicGljdHVyZSJ9LCJNMTUwNDYxODIxMTE4OSI6eyJzdHlsZSI6eyJkb3RzdHlsZSI6InJlY3RhbmdsZSIsImRvdGFsaWduIjoibGVmdCIsImJhY2tncm91bmQiOiIjZmZmZmZmIiwibGVmdHJpZ2h0IjoiNSIsImJvdHRvbSI6IjUiLCJvcGFjaXR5IjoiMC44In0sImRhdGEiOnsiQzE1MDQ2MTgyMTExODkiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0xLmpwZyIsImxpbmt1cmwiOiIifSwiQzE1MDQ2MTgyMTExOTAiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0yLmpwZyIsImxpbmt1cmwiOiIifX0sImlkIjoiYmFubmVyIn0sIk0xNTA0NjE4MjE0MTkwIjp7InBhcmFtcyI6eyJyb3ciOiIxIiwic2hvd3R5cGUiOiIwIiwicGFnZW51bSI6IjIifSwic3R5bGUiOnsicGFkZGluZ3RvcCI6IjAiLCJwYWRkaW5nbGVmdCI6IjAiLCJzaG93ZG90IjoiMCIsInNob3didG4iOiIwIn0sImRhdGEiOnsiQzE1MDQ2MTgyMTQxOTAiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0xLmpwZyIsImxpbmt1cmwiOiIifSwiQzE1MDQ2MTgyMTQxOTEiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0yLmpwZyIsImxpbmt1cmwiOiIifSwiQzE1MDQ2MTgyMTQxOTIiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0xLmpwZyIsImxpbmt1cmwiOiIifSwiQzE1MDQ2MTgyMTQxOTMiOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL2Jhbm5lci0yLmpwZyIsImxpbmt1cmwiOiIifX0sImlkIjoicGljdHVyZXcifSwiTTE1MDQ2MTgyMTc3MzciOnsicGFyYW1zIjp7ImhpZGV0ZXh0IjoiMCIsInNob3d0eXBlIjoiMCIsInJvd251bSI6IjMiLCJzaG93YnRuIjoiMCJ9LCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsInBhZGRpbmd0b3AiOiIzIiwicGFkZGluZ2xlZnQiOiI1IiwidGl0bGVhbGlnbiI6ImxlZnQiLCJ0ZXh0YWxpZ24iOiJsZWZ0IiwidGl0bGVjb2xvciI6IiNmZmZmZmYiLCJ0ZXh0Y29sb3IiOiIjNjY2NjY2In0sImRhdGEiOnsiQzE1MDQ2MTgyMTc3MzciOnsiaW1ndXJsIjoiLi5cL2FkZG9uc1wvZXdlaV9zaG9wdjJcL3BsdWdpblwvZGl5cGFnZVwvc3RhdGljXC9pbWFnZXNcL2RlZmF1bHRcL21vdmllLXBvc3Rlci5qcGciLCJsaW5rdXJsIjoiIiwidGl0bGUiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTRlMGFcdTY4MDdcdTk4OTgiLCJ0ZXh0IjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU0ZTBiXHU2ODA3XHU5ODk4In0sIkMxNTA0NjE4MjE3NzM5Ijp7ImltZ3VybCI6Ii4uXC9hZGRvbnNcL2V3ZWlfc2hvcHYyXC9wbHVnaW5cL2RpeXBhZ2VcL3N0YXRpY1wvaW1hZ2VzXC9kZWZhdWx0XC9tb3ZpZS1wb3N0ZXIuanBnIiwibGlua3VybCI6IiIsInRpdGxlIjoiXHU4ZmQ5XHU5MWNjXHU2NjJmXHU0ZTBhXHU2ODA3XHU5ODk4IiwidGV4dCI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1NGUwYlx1NjgwN1x1OTg5OCJ9LCJDMTUwNDYxODIxNzc0MCI6eyJpbWd1cmwiOiIuLlwvYWRkb25zXC9ld2VpX3Nob3B2MlwvcGx1Z2luXC9kaXlwYWdlXC9zdGF0aWNcL2ltYWdlc1wvZGVmYXVsdFwvbW92aWUtcG9zdGVyLmpwZyIsImxpbmt1cmwiOiIiLCJ0aXRsZSI6Ilx1OGZkOVx1OTFjY1x1NjYyZlx1NGUwYVx1NjgwN1x1OTg5OCIsInRleHQiOiJcdThmZDlcdTkxY2NcdTY2MmZcdTRlMGJcdTY4MDdcdTk4OTgifX0sImlkIjoicGljdHVyZXMifSwiTTE1MDQ2MTgyMjAxMDQiOnsicGFyYW1zIjp7InJvd251bSI6IjQiLCJib3JkZXIiOiIxIiwiYm9yZGVydG9wIjoiMSIsImJvcmRlcmJvdHRvbSI6IjEifSwic3R5bGUiOnsiYmFja2dyb3VuZCI6IiNmZmZmZmYiLCJib3JkZXJjb2xvciI6IiNlYmViZWIiLCJ0ZXh0Y29sb3IiOiIjN2E3YTdhIiwiaWNvbmNvbG9yIjoiI2FhYWFhYSIsImRvdGNvbG9yIjoiI2ZmMDAxMSJ9LCJkYXRhIjp7IkMxNTA0NjE4MjIwMTA0Ijp7Imljb25jbGFzcyI6Imljb24tY2FyZCIsInRleHQiOiJcdTVmODVcdTRlZDhcdTZiM2UiLCJsaW5rdXJsIjoiIiwiZG90bnVtIjoiMCJ9LCJDMTUwNDYxODIyMDEwNSI6eyJpY29uY2xhc3MiOiJpY29uLWJveCIsInRleHQiOiJcdTVmODVcdTUzZDFcdThkMjciLCJsaW5rdXJsIjoiIiwiZG90bnVtIjoiMCJ9LCJDMTUwNDYxODIyMDEwNiI6eyJpY29uY2xhc3MiOiJpY29uLWRlbGl2ZXIiLCJ0ZXh0IjoiXHU1Zjg1XHU2NTM2XHU4ZDI3IiwibGlua3VybCI6IiIsImRvdG51bSI6IjAifSwiQzE1MDQ2MTgyMjAxMDciOnsiaWNvbmNsYXNzIjoiaWNvbi1lbGVjdHJpY2FsIiwidGV4dCI6Ilx1OTAwMFx1NjM2Mlx1OGQyNyIsImxpbmt1cmwiOiIiLCJkb3RudW0iOiIwIn19LCJpZCI6Imljb25ncm91cCJ9LCJNMTUwNDYxODIyMjI3OCI6eyJwYXJhbXMiOnsidGl0bGUiOiJcdTY3MmFcdTViOWFcdTRlNDlcdTk3ZjNcdTk4OTFcdTRmZTFcdTYwNmYiLCJzdWJ0aXRsZSI6Ilx1NTI2Zlx1NjgwN1x1OTg5OCIsInBsYXllcnN0eWxlIjoiMCIsImF1dG9wbGF5IjoiMCIsImxvb3BwbGF5IjoiMCIsInBhdXNlc3RvcCI6IjAiLCJoZWFkYWxpZ24iOiJsZWZ0IiwiaGVhZHR5cGUiOiIiLCJoZWFkdXJsIjoiIn0sInN0eWxlIjp7ImJhY2tncm91bmQiOiIjZjFmMWYxIiwiYm9yZGVyY29sb3IiOiIjZWRlZGVkIiwidGV4dGNvbG9yIjoiIzMzMzMzMyIsInN1YnRpdGxlY29sb3IiOiIjNjY2NjY2IiwidGltZWNvbG9yIjoiIzY2NjY2NiIsInBhZGRpbmd0b3AiOiIyMCIsInBhZGRpbmdsZWZ0IjoiMjAiLCJ3aWR0aCI6IjgwIn0sImlkIjoiYXVkaW8ifSwiTTE1MDQ2MTgyMjMyMjIiOnsicGFyYW1zIjp7ImNvdXBvbnN0eWxlIjoiMyJ9LCJzdHlsZSI6eyJiYWNrZ3JvdW5kIjoiI2ZmZmZmZiIsIm1hcmdpbnRvcCI6IjEwIiwibWFyZ2lubGVmdCI6IjUifSwiZGF0YSI6eyJDMTUwNDYxODIyMzIyMiI6eyJuYW1lIjoiXHU0ZjE4XHU2MGUwXHU1MjM4XHU1NDBkXHU3OWYwIiwiZGVzYyI6Ilx1NmVlMTEwMFx1NTE0M1x1NTNlZlx1NzUyOCIsInByaWNlIjoiXHVmZmU1ODkuOTAiLCJjb3Vwb25pZCI6IiIsImJhY2tncm91bmQiOiIjZmZlYWVjIiwiYm9yZGVyY29sb3IiOiIjZmY5M2IyIiwidGV4dGNvbG9yIjoiI2ZhNTI2MiJ9LCJDMTUwNDYxODIyMzIyMyI6eyJuYW1lIjoiXHU0ZjE4XHU2MGUwXHU1MjM4XHU1NDBkXHU3OWYwIiwiZGVzYyI6Ilx1NmVlMTEwMFx1NTE0M1x1NTNlZlx1NzUyOCIsInByaWNlIjoiXHVmZmU1ODkuOTAiLCJjb3Vwb25pZCI6IiIsImJhY2tncm91bmQiOiIjZjNmZmVmIiwiYm9yZGVyY29sb3IiOiIjOThlMjdmIiwidGV4dGNvbG9yIjoiIzdhY2Y4ZCJ9LCJDMTUwNDYxODIyMzIyNCI6eyJuYW1lIjoiXHU0ZjE4XHU2MGUwXHU1MjM4XHU1NDBkXHU3OWYwIiwiZGVzYyI6Ilx1NmVlMTEwMFx1NTE0M1x1NTNlZlx1NzUyOCIsInByaWNlIjoiXHVmZmU1ODkuOTAiLCJjb3Vwb25pZCI6IiIsImJhY2tncm91bmQiOiIjZmZlYWUzIiwiYm9yZGVyY29sb3IiOiIjZmZhNDkyIiwidGV4dGNvbG9yIjoiI2ZmOTY2NCJ9fSwiaWQiOiJjb3Vwb24ifSwiTTE1MDQ2MTgxMjY1NjUiOnsicGFyYW1zIjp7InBsYWNlaG9sZGVyIjoiXHU4YmY3XHU4ZjkzXHU1MTY1XHU1MTczXHU5NTJlXHU1YjU3XHU4ZmRiXHU4ODRjXHU2NDFjXHU3ZDIyIn0sInN0eWxlIjp7ImlucHV0YmFja2dyb3VuZCI6IiNmZmZmZmYiLCJiYWNrZ3JvdW5kIjoiI2YxZjFmMiIsImljb25jb2xvciI6IiNiNGI0YjQiLCJjb2xvciI6IiM5OTk5OTkiLCJwYWRkaW5ndG9wIjoiMTAiLCJwYWRkaW5nbGVmdCI6IjEwIiwidGV4dGFsaWduIjoibGVmdCIsInNlYXJjaHN0eWxlIjoiIn0sImlkIjoic2VhcmNoIn19fQ==','',0,0,0,0);
/*!40000 ALTER TABLE `ims_ewei_shop_diypage_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_diypage_template_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_diypage_template_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_diypage_template_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `merch` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_diypage_template_category`
--

LOCK TABLES `ims_ewei_shop_diypage_template_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_diypage_template_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_diypage_template_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_exchange_cart`
--

DROP TABLE IF EXISTS `ims_ewei_shop_exchange_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_exchange_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT NULL,
  `openid` varchar(100) DEFAULT NULL,
  `goodsid` int(11) DEFAULT NULL,
  `total` int(10) DEFAULT '1',
  `marketprice` decimal(10,2) DEFAULT NULL,
  `optionid` int(11) DEFAULT NULL,
  `selected` tinyint(1) DEFAULT '1',
  `deleted` tinyint(1) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `groupid` int(11) DEFAULT NULL,
  `serial` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_exchange_cart`
--

LOCK TABLES `ims_ewei_shop_exchange_cart` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_exchange_cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_exchange_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_exchange_code`
--

DROP TABLE IF EXISTS `ims_ewei_shop_exchange_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_exchange_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) NOT NULL DEFAULT '0',
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `endtime` datetime NOT NULL DEFAULT '2016-10-01 00:00:00',
  `status` int(2) NOT NULL DEFAULT '1',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `count` int(11) NOT NULL DEFAULT '0',
  `key` varchar(255) NOT NULL DEFAULT '',
  `type` int(11) NOT NULL DEFAULT '0',
  `scene` int(11) NOT NULL DEFAULT '0',
  `qrcode_url` varchar(255) NOT NULL DEFAULT '',
  `serial` varchar(255) NOT NULL DEFAULT '',
  `balancestatus` int(11) DEFAULT '1',
  `redstatus` int(11) DEFAULT '1',
  `scorestatus` int(11) DEFAULT '1',
  `couponstatus` int(11) DEFAULT '1',
  `goodsstatus` int(11) DEFAULT NULL,
  `repeatcount` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`,`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_exchange_code`
--

LOCK TABLES `ims_ewei_shop_exchange_code` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_exchange_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_exchange_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_exchange_group`
--

DROP TABLE IF EXISTS `ims_ewei_shop_exchange_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_exchange_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `type` int(2) NOT NULL DEFAULT '0',
  `endtime` datetime NOT NULL DEFAULT '2016-10-01 00:00:00',
  `mode` int(2) NOT NULL DEFAULT '0',
  `status` int(2) NOT NULL DEFAULT '0',
  `max` int(2) NOT NULL DEFAULT '0',
  `value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `starttime` datetime NOT NULL DEFAULT '2016-10-01 00:00:00',
  `goods` text,
  `score` int(11) NOT NULL DEFAULT '0',
  `coupon` text,
  `use` int(11) NOT NULL DEFAULT '0',
  `total` int(11) NOT NULL DEFAULT '0',
  `red` decimal(10,2) NOT NULL DEFAULT '0.00',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `balance_left` decimal(10,2) NOT NULL DEFAULT '0.00',
  `balance_right` decimal(10,2) NOT NULL DEFAULT '0.00',
  `red_left` decimal(10,2) NOT NULL DEFAULT '0.00',
  `red_right` decimal(10,2) NOT NULL DEFAULT '0.00',
  `score_left` int(11) NOT NULL DEFAULT '0',
  `score_right` int(11) NOT NULL DEFAULT '0',
  `balance_type` int(11) NOT NULL,
  `red_type` int(11) NOT NULL,
  `score_type` int(11) NOT NULL,
  `title_reply` varchar(255) NOT NULL DEFAULT '',
  `img` varchar(255) NOT NULL DEFAULT '',
  `content` varchar(255) NOT NULL DEFAULT '',
  `rule` text NOT NULL,
  `coupon_type` varchar(255) DEFAULT NULL,
  `basic_content` varchar(500) NOT NULL DEFAULT '',
  `reply_type` int(11) NOT NULL DEFAULT '0',
  `code_type` int(11) NOT NULL DEFAULT '0',
  `binding` int(11) NOT NULL DEFAULT '0',
  `showcount` int(11) DEFAULT '0',
  `postage` decimal(10,2) DEFAULT '0.00',
  `postage_type` int(11) DEFAULT '0',
  `banner` varchar(800) DEFAULT '',
  `keyword_reply` int(11) DEFAULT '0',
  `reply_status` int(11) DEFAULT '1',
  `reply_keyword` varchar(255) DEFAULT '',
  `input_banner` varchar(255) DEFAULT '',
  `diypage` int(11) NOT NULL DEFAULT '0',
  `sendname` varchar(255) DEFAULT '',
  `wishing` varchar(255) DEFAULT '',
  `actname` varchar(255) DEFAULT '',
  `remark` varchar(255) DEFAULT '',
  `repeat` tinyint(1) NOT NULL DEFAULT '0',
  `koulingstart` varchar(255) NOT NULL DEFAULT '',
  `koulingend` varchar(255) NOT NULL DEFAULT '',
  `kouling` tinyint(1) NOT NULL DEFAULT '0',
  `chufa` varchar(255) NOT NULL DEFAULT '',
  `chufaend` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_exchange_group`
--

LOCK TABLES `ims_ewei_shop_exchange_group` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_exchange_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_exchange_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_exchange_query`
--

DROP TABLE IF EXISTS `ims_ewei_shop_exchange_query`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_exchange_query` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `querykey` varchar(255) NOT NULL DEFAULT '',
  `querytime` int(11) NOT NULL DEFAULT '0',
  `unfreeze` int(11) NOT NULL DEFAULT '0',
  `errorcount` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`openid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_exchange_query`
--

LOCK TABLES `ims_ewei_shop_exchange_query` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_exchange_query` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_exchange_query` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_exchange_record`
--

DROP TABLE IF EXISTS `ims_ewei_shop_exchange_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_exchange_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL DEFAULT '',
  `uniacid` int(11) DEFAULT NULL,
  `goods` text,
  `orderid` varchar(255) NOT NULL DEFAULT '',
  `time` int(11) NOT NULL,
  `openid` varchar(255) NOT NULL DEFAULT '',
  `mode` int(11) NOT NULL DEFAULT '0',
  `balance` decimal(10,2) DEFAULT '0.00',
  `red` decimal(10,2) NOT NULL DEFAULT '0.00',
  `coupon` text,
  `score` int(11) NOT NULL DEFAULT '0',
  `nickname` varchar(255) NOT NULL DEFAULT '',
  `groupid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `serial` varchar(255) NOT NULL DEFAULT '',
  `ordersn` varchar(255) NOT NULL DEFAULT '',
  `goods_title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_exchange_record`
--

LOCK TABLES `ims_ewei_shop_exchange_record` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_exchange_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_exchange_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_exchange_setting`
--

DROP TABLE IF EXISTS `ims_ewei_shop_exchange_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_exchange_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `freeze` int(11) NOT NULL DEFAULT '0',
  `mistake` int(11) NOT NULL DEFAULT '0',
  `grouplimit` int(11) NOT NULL DEFAULT '0',
  `alllimit` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_exchange_setting`
--

LOCK TABLES `ims_ewei_shop_exchange_setting` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_exchange_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_exchange_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_exhelper_express`
--

DROP TABLE IF EXISTS `ims_ewei_shop_exhelper_express`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_exhelper_express` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `type` int(1) NOT NULL DEFAULT '1',
  `expressname` varchar(255) DEFAULT '',
  `expresscom` varchar(255) NOT NULL DEFAULT '',
  `express` varchar(255) NOT NULL DEFAULT '',
  `width` decimal(10,2) DEFAULT '0.00',
  `datas` text,
  `height` decimal(10,2) DEFAULT '0.00',
  `bg` varchar(255) DEFAULT '',
  `isdefault` tinyint(3) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_isdefault` (`isdefault`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_exhelper_express`
--

LOCK TABLES `ims_ewei_shop_exhelper_express` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_exhelper_express` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_exhelper_express` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_exhelper_senduser`
--

DROP TABLE IF EXISTS `ims_ewei_shop_exhelper_senduser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_exhelper_senduser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `sendername` varchar(255) DEFAULT '',
  `sendertel` varchar(255) DEFAULT '',
  `sendersign` varchar(255) DEFAULT '',
  `sendercode` int(11) DEFAULT NULL,
  `senderaddress` varchar(255) DEFAULT '',
  `sendercity` varchar(255) DEFAULT NULL,
  `isdefault` tinyint(3) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_isdefault` (`isdefault`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_exhelper_senduser`
--

LOCK TABLES `ims_ewei_shop_exhelper_senduser` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_exhelper_senduser` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_exhelper_senduser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_exhelper_sys`
--

DROP TABLE IF EXISTS `ims_ewei_shop_exhelper_sys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_exhelper_sys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(20) NOT NULL DEFAULT 'localhost',
  `port` int(11) NOT NULL DEFAULT '8000',
  `ip_cloud` varchar(255) NOT NULL DEFAULT '',
  `port_cloud` int(11) NOT NULL DEFAULT '8000',
  `is_cloud` int(1) NOT NULL DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_exhelper_sys`
--

LOCK TABLES `ims_ewei_shop_exhelper_sys` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_exhelper_sys` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_exhelper_sys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_express`
--

DROP TABLE IF EXISTS `ims_ewei_shop_express`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_express` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT '',
  `express` varchar(50) DEFAULT '',
  `status` tinyint(1) DEFAULT '1',
  `displayorder` tinyint(3) unsigned DEFAULT '0',
  `code` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_express`
--

LOCK TABLES `ims_ewei_shop_express` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_express` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_express` VALUES (1,'顺丰','shunfeng',1,0,''),(2,'申通','shentong',1,0,''),(3,'韵达快运','yunda',1,0,''),(4,'天天快递','tiantian',1,0,''),(5,'圆通速递','yuantong',1,0,''),(6,'中通速递','zhongtong',1,0,''),(7,'ems快递','ems',1,0,''),(8,'汇通快运','huitongkuaidi',1,0,''),(9,'全峰快递','quanfengkuaidi',1,0,''),(10,'宅急送','zhaijisong',1,0,''),(11,'aae全球专递','aae',1,0,''),(12,'安捷快递','anjie',1,0,''),(13,'安信达快递','anxindakuaixi',1,0,''),(14,'彪记快递','biaojikuaidi',1,0,''),(15,'bht','bht',1,0,''),(16,'百福东方国际物流','baifudongfang',1,0,''),(17,'中国东方（COE）','coe',1,0,''),(18,'长宇物流','changyuwuliu',1,0,''),(19,'大田物流','datianwuliu',1,0,''),(20,'德邦物流','debangwuliu',1,0,''),(21,'dhl','dhl',1,0,''),(22,'dpex','dpex',1,0,''),(23,'d速快递','dsukuaidi',1,0,''),(24,'递四方','disifang',1,0,''),(25,'fedex（国外）','fedex',1,0,''),(26,'飞康达物流','feikangda',1,0,''),(27,'凤凰快递','fenghuangkuaidi',1,0,''),(28,'飞快达','feikuaida',1,0,''),(29,'国通快递','guotongkuaidi',1,0,''),(30,'港中能达物流','ganzhongnengda',1,0,''),(31,'广东邮政物流','guangdongyouzhengwuliu',1,0,''),(32,'共速达','gongsuda',1,0,''),(33,'恒路物流','hengluwuliu',1,0,''),(34,'华夏龙物流','huaxialongwuliu',1,0,''),(35,'海红','haihongwangsong',1,0,''),(36,'海外环球','haiwaihuanqiu',1,0,''),(37,'佳怡物流','jiayiwuliu',1,0,''),(38,'京广速递','jinguangsudikuaijian',1,0,''),(39,'急先达','jixianda',1,0,''),(40,'佳吉物流','jjwl',1,0,''),(41,'加运美物流','jymwl',1,0,''),(42,'金大物流','jindawuliu',1,0,''),(43,'嘉里大通','jialidatong',1,0,''),(44,'晋越快递','jykd',1,0,''),(45,'快捷速递','kuaijiesudi',1,0,''),(46,'联邦快递（国内）','lianb',1,0,''),(47,'联昊通物流','lianhaowuliu',1,0,''),(48,'龙邦物流','longbanwuliu',1,0,''),(49,'立即送','lijisong',1,0,''),(50,'乐捷递','lejiedi',1,0,''),(51,'民航快递','minghangkuaidi',1,0,''),(52,'美国快递','meiguokuaidi',1,0,''),(53,'门对门','menduimen',1,0,''),(54,'OCS','ocs',1,0,''),(55,'配思货运','peisihuoyunkuaidi',1,0,''),(56,'全晨快递','quanchenkuaidi',1,0,''),(57,'全际通物流','quanjitong',1,0,''),(58,'全日通快递','quanritongkuaidi',1,0,''),(59,'全一快递','quanyikuaidi',1,0,''),(60,'如风达','rufengda',1,0,''),(61,'三态速递','santaisudi',1,0,''),(62,'盛辉物流','shenghuiwuliu',1,0,''),(63,'速尔物流','sue',1,0,''),(64,'盛丰物流','shengfeng',1,0,''),(65,'赛澳递','saiaodi',1,0,''),(66,'天地华宇','tiandihuayu',1,0,''),(67,'tnt','tnt',1,0,''),(68,'ups','ups',1,0,''),(69,'万家物流','wanjiawuliu',1,0,''),(70,'文捷航空速递','wenjiesudi',1,0,''),(71,'伍圆','wuyuan',1,0,''),(72,'万象物流','wxwl',1,0,''),(73,'新邦物流','xinbangwuliu',1,0,''),(74,'信丰物流','xinfengwuliu',1,0,''),(75,'亚风速递','yafengsudi',1,0,''),(76,'一邦速递','yibangwuliu',1,0,''),(77,'优速物流','youshuwuliu',1,0,''),(78,'邮政包裹挂号信','youzhengguonei',1,0,''),(79,'邮政国际包裹挂号信','youzhengguoji',1,0,''),(80,'远成物流','yuanchengwuliu',1,0,''),(81,'源伟丰快递','yuanweifeng',1,0,''),(82,'元智捷诚快递','yuanzhijiecheng',1,0,''),(83,'运通快递','yuntongkuaidi',1,0,''),(84,'越丰物流','yuefengwuliu',1,0,''),(85,'源安达','yad',1,0,''),(86,'银捷速递','yinjiesudi',1,0,''),(87,'中铁快运','zhongtiekuaiyun',1,0,''),(88,'中邮物流','zhongyouwuliu',1,0,''),(89,'忠信达','zhongxinda',1,0,''),(90,'芝麻开门','zhimakaimen',1,0,''),(91,'安能物流','annengwuliu',1,0,'');
/*!40000 ALTER TABLE `ims_ewei_shop_express` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_express_cache`
--

DROP TABLE IF EXISTS `ims_ewei_shop_express_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_express_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expresssn` varchar(50) DEFAULT NULL,
  `express` varchar(50) DEFAULT NULL,
  `lasttime` int(11) NOT NULL,
  `datas` text,
  PRIMARY KEY (`id`),
  KEY `idx_expresssn` (`expresssn`) USING BTREE,
  KEY `idx_express` (`express`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_express_cache`
--

LOCK TABLES `ims_ewei_shop_express_cache` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_express_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_express_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_feedback`
--

DROP TABLE IF EXISTS `ims_ewei_shop_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(50) DEFAULT '0',
  `type` tinyint(1) DEFAULT '1',
  `status` tinyint(1) DEFAULT '0',
  `feedbackid` varchar(100) DEFAULT '',
  `transid` varchar(100) DEFAULT '',
  `reason` varchar(1000) DEFAULT '',
  `solution` varchar(1000) DEFAULT '',
  `remark` varchar(1000) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_feedbackid` (`feedbackid`),
  KEY `idx_createtime` (`createtime`),
  KEY `idx_transid` (`transid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_feedback`
--

LOCK TABLES `ims_ewei_shop_feedback` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_form`
--

DROP TABLE IF EXISTS `ims_ewei_shop_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_form` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `isrequire` tinyint(3) DEFAULT '0',
  `key` varchar(255) DEFAULT '',
  `title` varchar(255) DEFAULT '',
  `type` varchar(255) DEFAULT '',
  `values` text,
  `cate` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_form`
--

LOCK TABLES `ims_ewei_shop_form` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_form_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_form_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_form_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_form_category`
--

LOCK TABLES `ims_ewei_shop_form_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_form_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_form_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_fullback_goods`
--

DROP TABLE IF EXISTS `ims_ewei_shop_fullback_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_fullback_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `type` tinyint(3) NOT NULL DEFAULT '0',
  `goodsid` int(11) NOT NULL DEFAULT '0',
  `titles` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `marketprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `minallfullbackallprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `maxallfullbackallprice` decimal(10,2) NOT NULL,
  `minallfullbackallratio` decimal(10,2) DEFAULT NULL,
  `maxallfullbackallratio` decimal(10,2) DEFAULT NULL,
  `day` int(11) NOT NULL DEFAULT '0',
  `fullbackprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `fullbackratio` decimal(10,2) DEFAULT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `displayorder` int(11) NOT NULL DEFAULT '0',
  `hasoption` tinyint(3) NOT NULL DEFAULT '0',
  `optionid` text NOT NULL,
  `startday` int(11) NOT NULL DEFAULT '0',
  `refund` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_fullback_goods`
--

LOCK TABLES `ims_ewei_shop_fullback_goods` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_fullback_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_fullback_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_fullback_log`
--

DROP TABLE IF EXISTS `ims_ewei_shop_fullback_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_fullback_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `openid` varchar(50) NOT NULL,
  `orderid` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `priceevery` decimal(10,2) NOT NULL,
  `day` int(10) NOT NULL,
  `fullbackday` int(10) NOT NULL,
  `createtime` int(10) NOT NULL,
  `fullbacktime` int(10) NOT NULL,
  `isfullback` tinyint(3) NOT NULL DEFAULT '0',
  `goodsid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_fullback_log`
--

LOCK TABLES `ims_ewei_shop_fullback_log` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_fullback_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_fullback_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_funbar`
--

DROP TABLE IF EXISTS `ims_ewei_shop_funbar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_funbar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `datas` text,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_funbar`
--

LOCK TABLES `ims_ewei_shop_funbar` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_funbar` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_funbar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_gift`
--

DROP TABLE IF EXISTS `ims_ewei_shop_gift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_gift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `activity` tinyint(3) NOT NULL DEFAULT '1',
  `orderprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `goodsid` varchar(255) NOT NULL,
  `giftgoodsid` varchar(255) NOT NULL,
  `starttime` int(11) NOT NULL DEFAULT '0',
  `endtime` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `displayorder` int(11) NOT NULL DEFAULT '0',
  `share_title` varchar(255) NOT NULL,
  `share_icon` varchar(255) NOT NULL,
  `share_desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_gift`
--

LOCK TABLES `ims_ewei_shop_gift` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_gift` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_gift` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_globonus_bill`
--

DROP TABLE IF EXISTS `ims_ewei_shop_globonus_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_globonus_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `billno` varchar(100) DEFAULT '',
  `paytype` int(11) DEFAULT '0',
  `year` int(11) DEFAULT '0',
  `month` int(11) DEFAULT '0',
  `week` int(11) DEFAULT '0',
  `ordercount` int(11) DEFAULT '0',
  `ordermoney` decimal(10,2) DEFAULT '0.00',
  `bonusmoney` decimal(10,2) DEFAULT '0.00',
  `bonusmoney_send` decimal(10,2) DEFAULT '0.00',
  `bonusmoney_pay` decimal(10,2) DEFAULT '0.00',
  `paytime` int(11) DEFAULT '0',
  `partnercount` int(11) DEFAULT '0',
  `createtime` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  `starttime` int(11) DEFAULT '0',
  `endtime` int(11) DEFAULT '0',
  `confirmtime` int(11) DEFAULT '0',
  `bonusordermoney` decimal(10,2) DEFAULT '0.00',
  `bonusrate` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_paytype` (`paytype`),
  KEY `idx_createtime` (`createtime`),
  KEY `idx_paytime` (`paytime`),
  KEY `idx_status` (`status`),
  KEY `idx_month` (`month`),
  KEY `idx_week` (`week`),
  KEY `idx_year` (`year`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_globonus_bill`
--

LOCK TABLES `ims_ewei_shop_globonus_bill` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_globonus_bill` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_globonus_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_globonus_billo`
--

DROP TABLE IF EXISTS `ims_ewei_shop_globonus_billo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_globonus_billo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `billid` int(11) DEFAULT '0',
  `orderid` int(11) DEFAULT '0',
  `ordermoney` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `idx_billid` (`billid`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_globonus_billo`
--

LOCK TABLES `ims_ewei_shop_globonus_billo` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_globonus_billo` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_globonus_billo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_globonus_billp`
--

DROP TABLE IF EXISTS `ims_ewei_shop_globonus_billp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_globonus_billp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `billid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `payno` varchar(255) DEFAULT '',
  `paytype` tinyint(3) DEFAULT '0',
  `bonus` decimal(10,2) DEFAULT '0.00',
  `money` decimal(10,2) DEFAULT '0.00',
  `realmoney` decimal(10,2) DEFAULT '0.00',
  `paymoney` decimal(10,2) DEFAULT '0.00',
  `charge` decimal(10,2) DEFAULT '0.00',
  `chargemoney` decimal(10,2) DEFAULT '0.00',
  `status` tinyint(3) DEFAULT '0',
  `reason` varchar(255) DEFAULT '',
  `paytime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_billid` (`billid`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_globonus_billp`
--

LOCK TABLES `ims_ewei_shop_globonus_billp` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_globonus_billp` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_globonus_billp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_globonus_level`
--

DROP TABLE IF EXISTS `ims_ewei_shop_globonus_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_globonus_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `levelname` varchar(50) DEFAULT '',
  `bonus` decimal(10,4) DEFAULT '0.0000',
  `ordermoney` decimal(10,2) DEFAULT '0.00',
  `ordercount` int(11) DEFAULT '0',
  `commissionmoney` decimal(10,2) DEFAULT '0.00',
  `bonusmoney` decimal(10,2) DEFAULT '0.00',
  `downcount` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_globonus_level`
--

LOCK TABLES `ims_ewei_shop_globonus_level` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_globonus_level` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_globonus_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_goods`
--

DROP TABLE IF EXISTS `ims_ewei_shop_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `pcate` int(11) DEFAULT '0',
  `ccate` int(11) DEFAULT '0',
  `type` tinyint(1) DEFAULT '1',
  `status` tinyint(1) DEFAULT '1',
  `displayorder` int(11) DEFAULT '0',
  `title` varchar(100) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `unit` varchar(5) DEFAULT '',
  `description` varchar(1000) DEFAULT NULL,
  `content` text,
  `goodssn` varchar(50) DEFAULT '',
  `productsn` varchar(50) DEFAULT '',
  `productprice` decimal(10,2) DEFAULT '0.00',
  `marketprice` decimal(10,2) DEFAULT '0.00',
  `costprice` decimal(10,2) DEFAULT '0.00',
  `originalprice` decimal(10,2) DEFAULT '0.00',
  `total` int(10) DEFAULT '0',
  `totalcnf` int(11) DEFAULT '0',
  `sales` int(11) DEFAULT '0',
  `salesreal` int(11) DEFAULT '0',
  `spec` varchar(5000) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  `weight` decimal(10,2) DEFAULT '0.00',
  `credit` varchar(255) DEFAULT NULL,
  `maxbuy` int(11) DEFAULT '0',
  `usermaxbuy` int(11) DEFAULT '0',
  `hasoption` int(11) DEFAULT '0',
  `dispatch` int(11) DEFAULT '0',
  `thumb_url` text,
  `isnew` tinyint(1) DEFAULT '0',
  `ishot` tinyint(1) DEFAULT '0',
  `isdiscount` tinyint(1) DEFAULT '0',
  `isrecommand` tinyint(1) DEFAULT '0',
  `issendfree` tinyint(1) DEFAULT '0',
  `istime` tinyint(1) DEFAULT '0',
  `iscomment` tinyint(1) DEFAULT '0',
  `timestart` int(11) DEFAULT '0',
  `timeend` int(11) DEFAULT '0',
  `viewcount` int(11) DEFAULT '0',
  `deleted` tinyint(3) DEFAULT '0',
  `hascommission` tinyint(3) DEFAULT '0',
  `commission1_rate` decimal(10,2) DEFAULT '0.00',
  `commission1_pay` decimal(10,2) DEFAULT '0.00',
  `commission2_rate` decimal(10,2) DEFAULT '0.00',
  `commission2_pay` decimal(10,2) DEFAULT '0.00',
  `commission3_rate` decimal(10,2) DEFAULT '0.00',
  `commission3_pay` decimal(10,2) DEFAULT '0.00',
  `score` decimal(10,2) DEFAULT '0.00',
  `taobaoid` varchar(255) DEFAULT '',
  `taotaoid` varchar(255) DEFAULT '',
  `taobaourl` varchar(255) DEFAULT '',
  `updatetime` int(11) DEFAULT '0',
  `share_title` varchar(255) DEFAULT '',
  `share_icon` varchar(255) DEFAULT '',
  `cash` tinyint(3) DEFAULT '0',
  `commission_thumb` varchar(255) DEFAULT '',
  `isnodiscount` tinyint(3) DEFAULT '0',
  `showlevels` text,
  `buylevels` text,
  `showgroups` text,
  `buygroups` text,
  `isverify` tinyint(3) DEFAULT '0',
  `storeids` text,
  `noticeopenid` varchar(255) DEFAULT '',
  `tcate` int(11) DEFAULT '0',
  `noticetype` text,
  `needfollow` tinyint(3) DEFAULT '0',
  `followtip` varchar(255) DEFAULT '',
  `followurl` varchar(255) DEFAULT '',
  `deduct` decimal(10,2) DEFAULT '0.00',
  `virtual` int(11) DEFAULT '0',
  `ccates` text,
  `discounts` text,
  `nocommission` tinyint(3) DEFAULT '0',
  `hidecommission` tinyint(3) DEFAULT '0',
  `pcates` text,
  `tcates` text,
  `cates` text,
  `artid` int(11) DEFAULT '0',
  `detail_logo` varchar(255) DEFAULT '',
  `detail_shopname` varchar(255) DEFAULT '',
  `detail_btntext1` varchar(255) DEFAULT '',
  `detail_btnurl1` varchar(255) DEFAULT '',
  `detail_btntext2` varchar(255) DEFAULT '',
  `detail_btnurl2` varchar(255) DEFAULT '',
  `detail_totaltitle` varchar(255) DEFAULT '',
  `saleupdate42392` tinyint(3) DEFAULT '0',
  `deduct2` decimal(10,2) DEFAULT '0.00',
  `ednum` int(11) DEFAULT '0',
  `edmoney` decimal(10,2) DEFAULT '0.00',
  `edareas` text,
  `diyformtype` tinyint(1) DEFAULT '0',
  `diyformid` int(11) DEFAULT '0',
  `diymode` tinyint(1) DEFAULT '0',
  `dispatchtype` tinyint(1) DEFAULT '0',
  `dispatchid` int(11) DEFAULT '0',
  `dispatchprice` decimal(10,2) DEFAULT '0.00',
  `manydeduct` tinyint(1) DEFAULT '0',
  `shorttitle` varchar(255) DEFAULT '',
  `isdiscount_title` varchar(255) DEFAULT '',
  `isdiscount_time` int(11) DEFAULT '0',
  `isdiscount_discounts` text,
  `commission` text,
  `saleupdate37975` tinyint(3) DEFAULT '0',
  `shopid` int(11) DEFAULT '0',
  `allcates` text,
  `minbuy` int(11) DEFAULT '0',
  `invoice` tinyint(3) DEFAULT '0',
  `repair` tinyint(3) DEFAULT '0',
  `seven` tinyint(3) DEFAULT '0',
  `money` varchar(255) DEFAULT '',
  `minprice` decimal(10,2) DEFAULT '0.00',
  `maxprice` decimal(10,2) DEFAULT '0.00',
  `province` varchar(255) DEFAULT '',
  `city` varchar(255) DEFAULT '',
  `buyshow` tinyint(1) DEFAULT '0',
  `buycontent` text,
  `saleupdate51117` tinyint(3) DEFAULT '0',
  `virtualsend` tinyint(1) DEFAULT '0',
  `virtualsendcontent` text,
  `verifytype` tinyint(1) DEFAULT '0',
  `diyfields` text,
  `diysaveid` int(11) DEFAULT '0',
  `diysave` tinyint(1) DEFAULT '0',
  `quality` tinyint(3) DEFAULT '0',
  `groupstype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `showtotal` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subtitle` varchar(255) DEFAULT '',
  `minpriceupdated` tinyint(1) DEFAULT '0',
  `sharebtn` tinyint(1) NOT NULL DEFAULT '0',
  `catesinit3` text,
  `showtotaladd` tinyint(1) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  `checked` tinyint(3) DEFAULT '0',
  `thumb_first` tinyint(3) DEFAULT '0',
  `merchsale` tinyint(1) DEFAULT '0',
  `keywords` varchar(255) DEFAULT '',
  `catch_id` varchar(255) DEFAULT '',
  `catch_url` varchar(255) DEFAULT '',
  `catch_source` varchar(255) DEFAULT '',
  `saleupdate40170` tinyint(3) DEFAULT '0',
  `saleupdate35843` tinyint(3) DEFAULT '0',
  `labelname` text,
  `autoreceive` int(11) DEFAULT '0',
  `cannotrefund` tinyint(3) DEFAULT '0',
  `saleupdate33219` tinyint(3) DEFAULT '0',
  `bargain` int(11) DEFAULT '0',
  `buyagain` decimal(10,2) DEFAULT '0.00',
  `buyagain_islong` tinyint(1) DEFAULT '0',
  `buyagain_condition` tinyint(1) DEFAULT '0',
  `buyagain_sale` tinyint(1) DEFAULT '0',
  `buyagain_commission` text,
  `saleupdate32484` tinyint(3) DEFAULT '0',
  `saleupdate36586` tinyint(3) DEFAULT '0',
  `diypage` int(11) DEFAULT NULL,
  `cashier` tinyint(1) DEFAULT '0',
  `saleupdate53481` tinyint(3) DEFAULT '0',
  `saleupdate30424` tinyint(3) DEFAULT '0',
  `isendtime` tinyint(3) NOT NULL DEFAULT '0',
  `usetime` int(11) NOT NULL DEFAULT '0',
  `endtime` int(11) NOT NULL DEFAULT '0',
  `merchdisplayorder` int(11) NOT NULL DEFAULT '0',
  `exchange_stock` int(11) DEFAULT '0',
  `exchange_postage` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ispresell` tinyint(3) NOT NULL DEFAULT '0',
  `presellprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `presellover` tinyint(3) NOT NULL DEFAULT '0',
  `presellovertime` int(11) NOT NULL,
  `presellstart` tinyint(3) NOT NULL DEFAULT '0',
  `preselltimestart` int(11) NOT NULL DEFAULT '0',
  `presellend` tinyint(3) NOT NULL DEFAULT '0',
  `preselltimeend` int(11) NOT NULL DEFAULT '0',
  `presellsendtype` tinyint(3) NOT NULL DEFAULT '0',
  `presellsendstatrttime` int(11) NOT NULL DEFAULT '0',
  `presellsendtime` int(11) NOT NULL DEFAULT '0',
  `edareas_code` text NOT NULL,
  `unite_total` tinyint(3) NOT NULL DEFAULT '0',
  `buyagain_price` decimal(10,2) DEFAULT '0.00',
  `threen` varchar(255) DEFAULT '',
  `intervalfloor` tinyint(1) DEFAULT '0',
  `intervalprice` varchar(512) DEFAULT '',
  `isfullback` tinyint(3) NOT NULL DEFAULT '0',
  `isstatustime` tinyint(3) NOT NULL DEFAULT '0',
  `statustimestart` int(10) NOT NULL DEFAULT '0',
  `statustimeend` int(10) NOT NULL DEFAULT '0',
  `nosearch` tinyint(1) NOT NULL DEFAULT '0',
  `showsales` tinyint(3) NOT NULL DEFAULT '1',
  `islive` int(11) NOT NULL DEFAULT '0',
  `liveprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `opencard` tinyint(1) DEFAULT '0',
  `cardid` varchar(255) DEFAULT '',
  `verifygoodsnum` int(11) DEFAULT '1',
  `verifygoodsdays` int(11) DEFAULT '1',
  `verifygoodslimittype` tinyint(1) DEFAULT '0',
  `verifygoodslimitdate` int(11) DEFAULT '0',
  `minliveprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `maxliveprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `dowpayment` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tempid` int(11) NOT NULL DEFAULT '0',
  `isstoreprice` tinyint(11) NOT NULL DEFAULT '0',
  `beforehours` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_pcate` (`pcate`),
  KEY `idx_ccate` (`ccate`),
  KEY `idx_isnew` (`isnew`),
  KEY `idx_ishot` (`ishot`),
  KEY `idx_isdiscount` (`isdiscount`),
  KEY `idx_isrecommand` (`isrecommand`),
  KEY `idx_iscomment` (`iscomment`),
  KEY `idx_issendfree` (`issendfree`),
  KEY `idx_istime` (`istime`),
  KEY `idx_deleted` (`deleted`),
  KEY `idx_tcate` (`tcate`),
  KEY `idx_scate` (`tcate`),
  KEY `idx_merchid` (`merchid`),
  KEY `idx_checked` (`checked`),
  FULLTEXT KEY `idx_buylevels` (`buylevels`),
  FULLTEXT KEY `idx_showgroups` (`showgroups`),
  FULLTEXT KEY `idx_buygroups` (`buygroups`)
) ENGINE=MyISAM AUTO_INCREMENT=213 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_goods`
--

LOCK TABLES `ims_ewei_shop_goods` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_goods` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_goods` VALUES (199,6,1174,1177,1,1,0,'华为 Mate 9 4GB+64GB版 摩卡金 移动联通电信4G手机 双卡双待','images/6/2017/08/y71L0PPbfzWj81bS5fNIPb110H5NHf.jpg','','','<div class=\"ETab\" id=\"detail\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); line-height: 18px; font-family: tahoma, arial,;\" sans=\"\" hiragino=\"\" microsoft=\"\"><div class=\"tab-con\" style=\"margin: 0px; padding: 10px 0px; -ms-zoom: 1;\"><div style=\"margin: 0px; padding: 0px;\" data-tab=\"item\"><div class=\"p-parameter\" style=\"margin: 0px 0px 10px; padding: 0px 10px 10px; border-bottom-color: rgb(238, 238, 238); border-bottom-width: 1px; border-bottom-style: solid;\"><ul class=\"parameter1 p-parameter-list list-paddingleft-2\" style=\"list-style-type: none;\"><li><div class=\"detail\" style=\"margin: 0px; padding: 0px; width: 197px; float: right; display: inline; min-height: 0px;\"><p title=\"1920*1080(FHD)\" style=\"padding: 0px; width: 197px; overflow: hidden; margin-top: 0px; margin-bottom: 4px; -ms-text-overflow: ellipsis;\">分辨率：1920*1080(FHD)</p></div></li><li><p><span class=\"i-camera\" style=\"margin: 2px 0px 0px -37px; padding: 0px; width: 33px; height: 33px; line-height: 1000px; overflow: hidden; float: left; background-image: none;\" 0px=\"\"></span></p><div class=\"detail\" style=\"margin: 0px; padding: 0px; width: 197px; float: right; display: inline; min-height: 0px;\"><p title=\"1200万像素；2000万像素\" style=\"padding: 0px; width: 197px; overflow: hidden; margin-top: 0px; margin-bottom: 4px; -ms-text-overflow: ellipsis;\">后置摄像头：1200万像素；2000万像素</p><p title=\"800万像素\" style=\"padding: 0px; width: 197px; overflow: hidden; margin-top: 0px; margin-bottom: 4px; -ms-text-overflow: ellipsis;\">前置摄像头：800万像素</p></div></li><li><p><span class=\"i-cpu\" style=\"margin: 2px 0px 0px -37px; padding: 0px; width: 33px; height: 33px; line-height: 1000px; overflow: hidden; float: left; background-image: none;\" 0px=\"\"></span></p><div class=\"detail\" style=\"margin: 0px; padding: 0px; width: 197px; float: right; display: inline; min-height: 0px;\"><p title=\"八核\" style=\"padding: 0px; width: 197px; overflow: hidden; margin-top: 0px; margin-bottom: 4px; -ms-text-overflow: ellipsis;\">核&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;数：八核</p><p title=\"最高2.4GHz\" style=\"padding: 0px; width: 197px; overflow: hidden; margin-top: 0px; margin-bottom: 4px; -ms-text-overflow: ellipsis;\">频&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;率：最高2.4GHz</p></div></li><li><p>品牌：&nbsp;<a style=\"margin: 0px; padding: 0px; color: rgb(94, 105, 173); text-decoration: none;\" href=\"https://list.jd.com/list.html?cat=9987,653,655&ev=exbrand_8557\" target=\"_blank\" clstag=\"shangpin|keycount|product|pinpai_1\">华为（HUAWEI）</a></p></li><li><p>商品名称：华为Mate9</p></li><li><p>商品编号：3888284</p></li><li><p>商品毛重：0.62kg</p></li><li><p>商品产地：中国大陆</p></li><li><p>系统：安卓（Android）</p></li><li><p>运行内存：4GB</p></li><li><p>后置摄像头像素：后置双摄像头</p></li><li><p>电池容量：4000mAh-5999mAh</p></li><li><p>机身内存：64GB</p></li><li><p>热点：双卡双待，指纹识别，拍照神器，支持NFC</p></li></ul><p class=\"more-par\" style=\"padding: 0px 20px 0px 0px; text-align: right; margin-top: -5px; margin-bottom: 0px;\"><a class=\"J-more-param\" style=\"margin: 0px; padding: 0px; color: rgb(0, 90, 160); text-decoration: none;\" href=\"https://item.jd.com/3888284.html?jd_pop=330a3580-6cb7-49e3-898e-5e797ca86097&abt=3#product-detail\">更多参数<span class=\"txt-arr\">>></span></a></p></div><div id=\"suyuan-video\" style=\"margin: 0px; padding: 0px;\"></div><div id=\"J-detail-banner\" style=\"margin: 0px; padding: 0px; text-align: center;\"><a title=\"\" id=\"p-cat-insert\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none;\" href=\"https://c-nfa.jd.com/adclick?keyStr=6PQwtwh0f06syGHwQVvRO2qQjwLJ5GHB8CWaVmO7akw8kRNUgm14u0WFAY6zp+eaNiAYfgtpim82Oa05ikX84x5CIfTJRReV1A+6g3l/ieva1BhLEfFnI0qAZK+qzBPh4fLWlvRBkxoM4QrINBB7LW8iFgASk57is1B9+1eSu9/T1xeVbhyP5068x0ZumNwlIKIrYbrgFrOPmktALViZRaoO5QSjDWj1B+x1MFW4tggXdB6+xYvIVbp72QuLT2IooMAQ3bcUj1N8/HKedLH4IhdaQIXFwVr/s4LXUlM4GARBl1UjN3r7NBiDe1tKCB2Gbsp6jeIk7+P29X+ulgTRNGMrkblAuVHrstMOAbWDPYo=&cv=2.0&url=https://sale.jd.com/act/IknONw6aWQGyELR.html?cpdad=1DLSUE\" target=\"_blank\"><img width=\"990\" style=\"margin: 0px; padding: 0px; border: 0px currentColor; border-image: none; width: 990px; vertical-align: middle;\" alt=\"\" src=\"https://img11.360buyimg.com/da/jfs/t7753/76/1991416365/353908/8a3525e4/59a618cbNe8ee4bf4.png\"/></a></div><div class=\"detail-content clearfix\" style=\"background: rgb(247, 247, 247); margin: 10px 0px; padding: 0px; position: relative;\" data-name=\"z-have-detail-nav\"><div class=\"detail-content-wrap\" style=\"margin: 0px; padding: 0px; width: 990px; float: left; background-color: rgb(255, 255, 255);\"><div class=\"detail-content-item\" style=\"margin: 0px; padding: 0px; width: 990px;\"><div id=\"activity_header\" style=\"margin: 0px; padding: 0px;\" clstag=\"shangpin|keycount|product|activityheader\"></div><div id=\"J-detail-content\" style=\"margin: 0px; padding: 0px;\"><div style=\"margin: 0px; padding: 0px; text-align: center;\"><div class=\"content_tpl\" style=\"margin: 0px auto; padding: 0px; width: 750px;\"><div class=\"formwork\" style=\"margin: 0px; padding: 10px 0px; width: 750px; text-align: left; line-height: 23px; overflow: hidden; font-family: Arial, Helvetica, sans-serif; font-size: 14px; border-bottom-color: rgb(230, 230, 230); border-bottom-width: 1px; border-bottom-style: dashed;\"></div></div><div class=\"content_tpl\" style=\"margin: 0px auto; padding: 0px; width: 750px;\"><div class=\"formwork\" style=\"margin: 0px; padding: 10px 0px; width: 750px; text-align: left; line-height: 23px; overflow: hidden; font-family: Arial, Helvetica, sans-serif; font-size: 14px; border-bottom-color: rgb(230, 230, 230); border-bottom-width: 1px; border-bottom-style: dashed;\"><div class=\"formwork_img\" style=\"margin: 0px auto; padding: 0px; width: 750px; text-align: center;\"><img style=\"margin: 0px; padding: 0px; border: 0px currentColor; border-image: none; vertical-align: middle;\" alt=\"\" src=\"https://img30.360buyimg.com/jgsq-productsoa/jfs/t3955/228/1473928367/1896172/532d771d/58c10320N54c43387.jpg\"/><br/></div></div></div></div><br/></div><div id=\"activity_footer\" style=\"margin: 0px; padding: 0px;\" clstag=\"shangpin|keycount|product|activityfooter\"></div></div></div></div><div class=\"clb\" style=\"margin: 0px; padding: 0px; clear: both;\"></div></div></div></div><div class=\"m m-content guarantee\" id=\"guarantee\" style=\"margin: 0px 0px 15px; padding: 0px; color: rgb(102, 102, 102); line-height: 18px; overflow: hidden; font-family: tahoma, arial,;\" sans=\"\" hiragino=\"\" microsoft=\"\"><div class=\"mt\" style=\"margin: 0px; padding: 10px; border: 1px solid rgb(238, 238, 238); border-image: none; overflow: hidden; position: relative; background-color: rgb(247, 247, 247);\"><h3 style=\"margin: 0px; padding: 0px; line-height: normal; font-family:;\" microsoft=\"\">售后保障</h3></div><div class=\"mc\" style=\"margin: 0px; padding: 0px; overflow: visible;\"><div class=\"item-detail item-detail-copyright\" style=\"margin: 0px; padding: 10px; line-height: 21.6px;\"><div class=\"serve-agree-bd\" style=\"margin: 0px; padding: 20px 20px 20px 62px;\"><ul class=\" list-paddingleft-2\" style=\"list-style-type: none;\"><li><p><span class=\"goods\" style=\"background: none; margin: 0px; padding: 0px 10px 0px 0px; width: 32px; height: 32px; vertical-align: bottom; display: inline-block;\"></span>&nbsp;<strong style=\"margin: 0px; padding: 8px 0px 3px; display: inline-block;\">厂家服务</strong></p></li><li><p>本产品全国联保，享受三包服务，质保期为：一年质保<br/>如因质量问题或故障，凭厂商维修中心或特约维修点的质量检测证明，享受7日内退货，15日内换货，15日以上在质保期内享受免费保修等三包服务！<br/>(注:如厂家在商品介绍中有售后保障的说明,则此商品按照厂家说明执行售后保障服务。) 您可以查询本品牌在各地售后服务中心的联系方式，<a style=\"margin: 0px; padding: 0px; color: rgb(0, 90, 160); text-decoration: none;\" href=\"http://www.huawei.com/cn/\" target=\"_blank\">请点击这儿查询......</a><br/><br/>品牌官方网站：<a style=\"margin: 0px; padding: 0px; color: rgb(0, 90, 160); text-decoration: none;\" href=\"http://www.huawei.com/cn/\" target=\"_blank\">http://www.huawei.com/cn/</a><br/>售后服务电话：400-830-8300</p></li><li><p><span class=\"goods\" style=\"background: none; margin: 0px; padding: 0px 10px 0px 0px; width: 32px; height: 32px; vertical-align: bottom; display: inline-block;\"></span>&nbsp;<strong style=\"margin: 0px; padding: 8px 0px 3px; display: inline-block;\">京东承诺</strong></p></li><li><p>京东平台卖家销售并发货的商品，由平台卖家提供发票和相应的售后服务。请您放心购买！<br/>注：因厂家会在没有任何提前通知的情况下更改产品包装、产地或者一些附件，本司不能确保客户收到的货物与商城图片、产地、附件说明完全一致。只能确保为原厂正货！并且保证与当时市场上同样主流新品一致。若本商城没有及时更新，请大家谅解！</p></li><li><p><span class=\"goods\" style=\"background: none; margin: 0px; padding: 0px 10px 0px 0px; width: 32px; height: 32px; vertical-align: bottom; display: inline-block;\"></span><strong style=\"margin: 0px; padding: 8px 0px 3px; display: inline-block;\">正品行货</strong></p></li><li><p>京东商城向您保证所售商品均为正品行货，京东自营商品开具机打发票或电子发票。</p></li><li><p><span class=\"unprofor\" style=\"background: none; margin: 0px; padding: 0px 10px 0px 0px; width: 32px; height: 32px; vertical-align: bottom; display: inline-block;\"></span><strong style=\"margin: 0px; padding: 8px 0px 3px; display: inline-block;\">全国联保</strong></p></li><li><p>凭质保证书及京东商城发票，可享受全国联保服务（奢侈品、钟表除外；奢侈品、钟表由京东联系保修，享受法定三包售后服务），与您亲临商场选购的商品享受相同的质量保证。京东商城还为您提供具有竞争力的商品价格和<a style=\"margin: 0px; padding: 0px; color: rgb(0, 90, 160); text-decoration: none;\" href=\"https://help.jd.com/help/question-892.html\" target=\"_blank\">运费政策</a>，请您放心购买！&nbsp;<br/><br/>注：因厂家会在没有任何提前通知的情况下更改产品包装、产地或者一些附件，本司不能确保客户收到的货物与商城图片、产地、附件说明完全一致。只能确保为原厂正货！并且保证与当时市场上同样主流新品一致。若本商城没有及时更新，请大家谅解！</p></li></ul></div><div id=\"state\" style=\"margin: 0px; padding: 0px;\"><strong style=\"margin: 0px; padding: 8px 0px 3px; color: rgb(228, 57, 60); display: inline-block;\">权利声明：</strong><br/>京东上的所有商品信息、客户评价、商品咨询、网友讨论等内容，是京东重要的经营资源，未经许可，禁止非法转载使用。<p style=\"padding: 0px; margin-top: 0px; margin-bottom: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">注：</strong>本站商品信息均来自于合作方，其真实性、准确性和合法性由信息拥有者（合作方）负责。本站不提供任何保证，并不承担任何法律责任。</p><br/><strong style=\"margin: 0px; padding: 8px 0px 3px; color: rgb(228, 57, 60); display: inline-block;\">价格说明：</strong><br/><p style=\"padding: 0px; margin-top: 0px; margin-bottom: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">京东价：</strong>京东价为商品的销售价，是您最终决定是否购买商品的依据。</p><p style=\"padding: 0px; margin-top: 0px; margin-bottom: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">划线价：</strong>商品展示的划横线价格为参考价，该价格可能是品牌专柜标价、商品吊牌价或由品牌供应商提供的正品零售价（如厂商指导价、建议零售价等）或该商品在京东平台上曾经展示过的销售价；由于地区、时间的差异性和市场行情波动，品牌专柜标价、商品吊牌价等可能会与您购物时展示的不一致，该价格仅供您参考。</p><p style=\"padding: 0px; margin-top: 0px; margin-bottom: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">折扣：</strong>如无特殊说明，折扣指销售商在原价、或划线价（如品牌专柜标价、商品吊牌价、厂商指导价、厂商建议零售价）等某一价格基础上计算出的优惠比例或优惠金额；如有疑问，您可在购买前联系销售商进行咨询。</p><p style=\"padding: 0px; margin-top: 0px; margin-bottom: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">异常问题：</strong>商品促销信息以商品详情页“促销”栏中的信息为准；商品的具体售价以订单结算页价格为准；如您发现活动商品售价或促销信息有异常，建议购买前先联系销售商咨询。</p></div></div></div></div><div class=\"m m-content comment\" id=\"comment\" style=\"margin: 0px 0px 15px; padding: 0px; color: rgb(102, 102, 102); line-height: 18px; overflow: hidden; font-family: tahoma, arial,;\" sans=\"\" hiragino=\"\" microsoft=\"\"><div class=\"mt\" style=\"margin: 0px; padding: 10px; border: 1px solid rgb(238, 238, 238); border-image: none; overflow: hidden; position: relative; background-color: rgb(247, 247, 247);\"><h3 style=\"margin: 0px; padding: 0px; line-height: normal; font-family:;\" microsoft=\"\"><br/></h3></div></div>','','','3999.00','3599.00','3299.00','0.00',9991,0,8,4,'',1504106606,'0.00','',0,0,0,0,'a:4:{i:1;s:51:\"images/6/2017/08/Hsaztc6GfcD1DfGyF3vGTY1G1fJ11D.jpg\";i:2;s:51:\"images/6/2017/08/iX1157L8SLvQV6L5wWlQQx8isIh5IV.jpg\";i:3;s:51:\"images/6/2017/08/iVcEq4v1LWqRzbRqV4XbeE5tXECZJq.jpg\";i:4;s:51:\"images/6/2017/08/a46LO6o4wOoSPnqSslloA4n1m7SgxX.jpg\";}',1,1,0,1,1,0,0,0,0,26,0,0,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','',0,'','',2,'',1,'','','','',0,'','',1180,'',0,'','','0.00',0,'','{\"type\":\"0\",\"default\":\"10\",\"default_pay\":\"\",\"level7\":\"9.5\",\"level7_pay\":\"\",\"level6\":\"8.8\",\"level6_pay\":\"\",\"level5\":\"8\",\"level5_pay\":\"\"}',0,0,'','1180','1180',0,'','','','','','','',0,'0.00',0,'0.00','',0,0,0,0,0,'0.00',0,'华为 Mate 9','',1504106340,'{\"type\":0,\"default\":{\"option0\":\"\"},\"level7\":{\"option0\":\"\"},\"level6\":{\"option0\":\"\"},\"level5\":{\"option0\":\"\"}}','{\"type\":0}',0,0,NULL,0,1,1,1,'','3599.00','3599.00','请选择省份','请选择城市',0,'',0,0,'',0,NULL,0,0,1,0,1,'华为 Mate 9 4GB+64GB版 摩卡金 移动联通电信4G手机 双卡双待',0,0,NULL,0,0,0,1,0,'华为| Mate 9 |','','','',0,0,'a:1:{i:0;s:6:\"华为\";}',7,0,0,0,'0.00',0,0,0,NULL,0,0,0,0,0,0,0,0,0,0,0,'0.00',0,'3599.00',1,0,0,0,0,0,1,1504106340,3,'',0,'0.00','',0,'',0,1,1504106340,1506784740,0,1,0,'0.00',0,'',1,1,0,0,'0.00','0.00','0.00',0,0,0),(200,6,1183,1184,1,1,0,'Sukin 苏芊 水润保湿护肤三件套 乳液+爽肤水+洗面奶 [125ml*3]','images/6/2017/09/QL96EOFx6h3lxDMN8OE9dNZhDyxrHm.jpg','','','<div class=\"wrap itemPage\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; width: 1349px; overflow: hidden; min-width: 320px;\"><div class=\"\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px;\"><div class=\"main\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px;\"><div class=\"main-con my-tab-wrap\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px 12px 50px; padding: 0px;\"><div class=\"product-basic\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px;\"><div class=\"product-img\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; width: 1325px; height: 300px; overflow: hidden; text-align: center;\"><div class=\"scroll-img-box\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; width: 1325px; overflow: hidden; position: relative;\"><div id=\"slider1\" class=\"img-box\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px auto; padding: 0px; width: 1325px; height: 300px; overflow: hidden; visibility: visible; list-style: none; position: relative;\"><ul class=\"focus-img-list list-paddingleft-2\" style=\"list-style-type: none;\"><li><p><a style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); display: block;\"><br/></a></p></li></ul></div></div></div><div class=\"product-detail detail-show\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 20px 0px 0px; padding: 0px; width: 1325px; overflow: hidden;\"><p style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin-top: 0px; margin-bottom: 0px; padding: 0px; font-size: 1.7rem;\"><img src=\"http://img.minshengec.com/shop/detail//2017/05/13/74261494653286106.jpg\" title=\"74261494653286106.jpg\" alt=\"x1.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/06/16/57671497595870366.jpg\" title=\"57671497595870366.jpg\" alt=\"x2.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/05/13/96101494653309753.jpg\" title=\"96101494653309753.jpg\" alt=\"x3.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/05/13/25411494653318571.jpg\" title=\"25411494653318571.jpg\" alt=\"x4.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/05/13/60771494653329602.jpg\" title=\"60771494653329602.jpg\" alt=\"x5.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/05/13/69441494653351466.jpg\" title=\"69441494653351466.jpg\" alt=\"x6.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/05/13/10281494653361691.jpg\" title=\"10281494653361691.jpg\" alt=\"x7.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/></p></div></div></div></div></div></div><div class=\"item-cart-box\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; width: 1349px; position: fixed; left: 0px; bottom: 0px; height: 50px; background: rgb(255, 255, 255); border-top: 1px solid rgb(231, 231, 231); z-index: 99;\"><div class=\"edit-ctrl-inner\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 8px 12px; padding: 0px; height: 50px;\"><div class=\"item-cart-num-outer box\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 1px; display: inline-block; width: 331.25px; height: 33px; float: left; background: rgb(226, 226, 226); border-radius: 5px;\"><span class=\"icon-basket-1 item-cart-num addCart-end trackEvent\" id=\"gocart\" data-trackevent=\"tocart|click|life|10873331\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); display: inline-block; width: 331.25px; height: 33px; line-height: 33px; text-align: center; font-size: 2.2rem; color: rgb(197, 197, 197); background: rgb(255, 255, 255); border-radius: 5px; position: relative;\"><span class=\"num\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); position: absolute; right: -4px; top: -4px; width: 16px; height: 16px; font-size: 1rem; color: rgb(255, 255, 255); background: rgb(242, 71, 58); line-height: 16px; border-radius: 50%;\">0</span></span><p class=\"cbx\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin-top: 0px; margin-bottom: 0px; padding: 0px; font-size: 1.7rem; position: absolute; left: 539.594px; top: 14px; opacity: 0;\"><img src=\"http://img.minshengec.com/img/topic/goshoping/images/add1.png\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1.5rem;\"/></p></div><a id=\"itemcart\" class=\"item-cart-btn item-btn-addCart trackEvent btn\" data-trackevent=\"zhAppClickAddCart|click|life|10873331\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); display: inline-block; float: right; height: 35px; line-height: 35px; text-align: center; color: rgb(255, 255, 255); background: rgb(242, 71, 58); border-radius: 5px; font-size: 1.6rem; width: 927.5px;\">加入购物车</a></div></div><div class=\"address-box\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; width: 1349px; background: rgb(255, 255, 255); overflow: hidden; z-index: 999; position: fixed; left: 0px; bottom: 0px; height: 0px;\"><div class=\"address-bar\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; width: 1349px; overflow: hidden; height: 30px; line-height: 30px; border-bottom: 1px solid rgb(204, 204, 204);\"><p style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin-top: 0px; margin-bottom: 0px; padding: 0px; font-size: 1.7rem; font-family: \" microsoft=\"\" white-space:=\"\" text-align:=\"\"><br/></p></div></div><p><br/></p>','','','298.00','0.01','119.00','0.00',893,0,39,3,'',1504324009,'0.00','',0,0,0,0,'a:2:{i:1;s:51:\"images/6/2017/09/rXW75MjxaZ5xqVxs83WtSz63iAX5lI.jpg\";i:2;s:51:\"images/6/2017/09/vDi5Ra2nn0r22SNJAn5ry0orarrRrN.jpg\";}',1,1,0,1,1,0,0,0,0,40,0,0,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','',0,'','',2,'',0,'','','','',0,'','',0,'',0,'','','0.00',0,'1184','{\"type\":\"0\",\"default\":\"\",\"default_pay\":\"\",\"level7\":\"\",\"level7_pay\":\"\",\"level6\":\"\",\"level6_pay\":\"\",\"level5\":\"\",\"level5_pay\":\"\"}',0,0,'','','1184',0,'','','','','','','',0,'0.00',0,'0.00','',0,0,0,0,0,'0.00',0,'【保税区现货】水润保湿护肤三件套 乳液+爽肤水+洗面奶 [125ml*3]','',1504323840,'{\"type\":0,\"default\":{\"option0\":\"\"},\"level7\":{\"option0\":\"\"},\"level6\":{\"option0\":\"\"},\"level5\":{\"option0\":\"\"}}','{\"type\":0}',0,0,NULL,0,1,0,1,'','0.01','0.01','请选择省份','请选择城市',0,'',0,0,'',0,NULL,0,0,1,0,1,'【保税区现货】水润保湿护肤三件套 乳液+爽肤水+洗面奶 [125ml*3]',0,0,NULL,0,0,0,1,0,'【保税区现货】水润保湿护肤三件套 乳液+爽肤水+洗面奶','','','',0,0,'N;',1,0,0,0,'0.00',0,0,0,NULL,0,0,0,1,0,0,0,0,0,0,0,'0.00',0,'0.00',0,0,0,0,0,0,0,1504323840,0,'',0,'0.00','',0,'',0,0,1504323840,1506915840,0,1,0,'0.00',0,'',1,1,0,0,'0.00','0.00','0.00',0,0,0),(201,6,1183,1184,1,1,0,'红景天精纯莹透幼白养肤保湿套装6件套 [套装]','images/6/2017/09/ZV20RVomRy5v2Koyr595i23YK53k3r.jpg','','','<div class=\"wrap itemPage\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; width: 1349px; overflow: hidden; min-width: 320px;\"><div class=\"\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px;\"><div class=\"main\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px;\"><div class=\"main-con my-tab-wrap\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px 12px 50px; padding: 0px;\"><div class=\"product-basic\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px;\"><div class=\"product-img\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; width: 1325px; height: 300px; overflow: hidden; text-align: center;\"><div class=\"scroll-img-box\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; width: 1325px; overflow: hidden; position: relative;\"><div id=\"slider1\" class=\"img-box\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px auto; padding: 0px; width: 1325px; height: 300px; overflow: hidden; visibility: visible; list-style: none; position: relative;\"><ul class=\"focus-img-list list-paddingleft-2\" style=\"list-style-type: none;\"><li><p><a style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); display: block;\"><img id=\"imgUrl\" src=\"http://img.minshengec.com/product/pics/2017/5/12/422868/422868-4-17202-1-400_400.jpg\" width=\"100%\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; height: 300px; width: 300px;\"/></a></p></li><li><p><a style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); display: block;\"><img id=\"imgUrl\" src=\"http://img.minshengec.com/product/pics/2017/5/12/422868/422868-4-17202-2-400_400.jpg\" width=\"100%\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; height: 300px; width: 300px;\"/></a></p></li><li><p><a style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); display: block;\"><img id=\"imgUrl\" src=\"http://img.minshengec.com/product/pics/2017/5/12/422868/422868-4-17202-3-400_400.jpg\" width=\"100%\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; height: 300px; width: 300px;\"/></a></p></li><li><p><a style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); display: block;\"><img id=\"imgUrl\" src=\"http://img.minshengec.com/product/pics/2017/5/12/422868/422868-4-17202-4-400_400.jpg\" width=\"100%\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; height: 300px; width: 300px;\"/></a></p></li><li><p><a style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); display: block;\"><img id=\"imgUrl\" src=\"http://img.minshengec.com/product/pics/2017/5/12/422868/422868-4-17202-5-400_400.jpg\" width=\"100%\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; height: 300px; width: 300px;\"/></a></p></li></ul></div><ul id=\"pagenavi1\" class=\"focus-page list-paddingleft-2\" style=\"list-style-type: none;\"><li><p><a href=\"http://life.minshengec.com/mobilewechat/wechat/product/item.do?productId=10940482#\" class=\"\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-decoration-line: none; display: block; width: 12px; height: 12px; background: rgb(163, 163, 163); border-radius: 50%; opacity: 0.8;\"></a></p></li><li><p></p></li><li><p><a href=\"http://life.minshengec.com/mobilewechat/wechat/product/item.do?productId=10940482#\" class=\"\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-decoration-line: none; display: block; width: 12px; height: 12px; background: rgb(163, 163, 163); border-radius: 50%; opacity: 0.8;\"></a></p></li><li><p></p></li><li><p><a href=\"http://life.minshengec.com/mobilewechat/wechat/product/item.do?productId=10940482#\" class=\"\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-decoration-line: none; display: block; width: 12px; height: 12px; background: rgb(163, 163, 163); border-radius: 50%; opacity: 0.8;\"></a></p></li><li><p></p></li><li><p><a href=\"http://life.minshengec.com/mobilewechat/wechat/product/item.do?productId=10940482#\" class=\"active\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-decoration-line: none; display: block; width: 12px; height: 12px; background: rgb(21, 136, 216); border-radius: 50%; opacity: 0.8;\"></a></p></li><li><p></p></li><li><p><a href=\"http://life.minshengec.com/mobilewechat/wechat/product/item.do?productId=10940482#\" class=\"\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-decoration-line: none; display: block; width: 12px; height: 12px; background: rgb(163, 163, 163); border-radius: 50%; opacity: 0.8;\"></a></p></li></ul></div></div><div class=\"product-about\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; position: relative;\"><div class=\"item-intro\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 10px 60px 10px 0px; padding: 0px; overflow: hidden;\"><h2 class=\"item-title\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; font-size: 1.6rem; font-weight: 400; overflow: hidden; height: 40px; line-height: 20px; color: rgb(73, 81, 99); word-break: break-all; text-overflow: ellipsis;\">相宜本草 红景天精纯莹透幼白养肤保湿套装6件套 [套装]</h2><div class=\"price-box\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; overflow: hidden; height: 30px;\"><span class=\"ms-price\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); font-size: 2rem; color: rgb(242, 71, 58); line-height: 30px;\"><span style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); font-size: 1.7rem;\">¥</span><span id=\"stprice\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\">249.00</span>&nbsp;</span><span class=\"mkt-price\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); font-size: 1.2rem; color: rgb(177, 177, 177); text-decoration-line: line-through;\"><span style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\">¥</span><strong id=\"stmarketprice\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\">494.00</strong></span></div><a id=\"life_share\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); display: block;\"><img src=\"http://img.minshengec.com/img/topic/2017/2/13/share.png\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; height: 3rem; position: absolute; top: 0px; right: 10px;\"/></a><a class=\"icon-minus decrease disabled\" style=\"text-align: center; outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); width: 25px; height: 25px; line-height: 25px; color: rgb(143, 143, 143); border-right: 1px solid rgb(178, 178, 178); background: rgb(235, 234, 234); display: inline !important;\"><img src=\"http://img.minshengec.com/scm/upload/image/20170510/6363003602747756527237462.jpg\" title=\"红景天养肤礼盒_01.jpg\" style=\"background-color: rgb(247, 247, 247); outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/><img src=\"http://img.minshengec.com/scm/upload/image/20170510/6363003603094090765807695.jpg\" title=\"红景天养肤礼盒_02.jpg\" style=\"background-color: rgb(247, 247, 247); outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/><img src=\"http://img.minshengec.com/scm/upload/image/20170510/6363003602761797215981566.jpg\" title=\"红景天养肤礼盒_03.jpg\" style=\"background-color: rgb(247, 247, 247); outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/><img src=\"http://img.minshengec.com/scm/upload/image/20170510/6363003602953684511173965.jpg\" title=\"红景天养肤礼盒_04.jpg\" style=\"background-color: rgb(247, 247, 247); outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/><img src=\"http://img.minshengec.com/scm/upload/image/20170510/6363003602970846217161406.jpg\" title=\"红景天养肤礼盒_05.jpg\" style=\"background-color: rgb(247, 247, 247); outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/><img src=\"http://img.minshengec.com/scm/upload/image/20170510/6363003603295339534730105.jpg\" title=\"红景天养肤礼盒_06.jpg\" style=\"background-color: rgb(247, 247, 247); outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/><img src=\"http://img.minshengec.com/scm/upload/image/20170510/6363003603324981643287240.jpg\" title=\"红景天养肤礼盒_07.jpg\" style=\"background-color: rgb(247, 247, 247); outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/><img src=\"http://img.minshengec.com/scm/upload/image/20170510/6363003603516869393181467.jpg\" title=\"红景天养肤礼盒_08.jpg\" style=\"background-color: rgb(247, 247, 247); outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/><img src=\"http://img.minshengec.com/scm/upload/image/20170510/6363003603604233426783945.jpg\" title=\"红景天养肤礼盒_09.jpg\" style=\"background-color: rgb(247, 247, 247); outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/><img src=\"http://img.minshengec.com/scm/upload/image/20170510/6363003603596434044526516.jpg\" title=\"红景天养肤礼盒_10.jpg\" style=\"background-color: rgb(247, 247, 247); outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/><img src=\"http://img.minshengec.com/scm/upload/image/20170510/6363003603782081937934068.jpg\" title=\"红景天养肤礼盒_11.jpg\" style=\"background-color: rgb(247, 247, 247); outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1325px;\"/></a></div></div></div></div></div></div></div><div class=\"item-cart-box\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; width: 1349px; position: fixed; left: 0px; bottom: 0px; height: 50px; background: rgb(255, 255, 255); border-top: 1px solid rgb(231, 231, 231); z-index: 99;\"><div class=\"edit-ctrl-inner\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 8px 12px; padding: 0px; height: 50px;\"><div class=\"item-cart-num-outer box\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 1px; display: inline-block; width: 331.25px; height: 33px; float: left; background: rgb(226, 226, 226); border-radius: 5px;\"><span class=\"icon-basket-1 item-cart-num addCart-end trackEvent\" id=\"gocart\" data-trackevent=\"tocart|click|life|10873331\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); display: inline-block; width: 331.25px; height: 33px; line-height: 33px; text-align: center; font-size: 2.2rem; color: rgb(197, 197, 197); background: rgb(255, 255, 255); border-radius: 5px; position: relative;\"><span class=\"num\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); position: absolute; right: -4px; top: -4px; width: 16px; height: 16px; font-size: 1rem; color: rgb(255, 255, 255); background: rgb(242, 71, 58); line-height: 16px; border-radius: 50%;\">0</span></span><p class=\"cbx\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin-top: 0px; margin-bottom: 0px; padding: 0px; font-size: 1.7rem; position: absolute; left: 539.594px; top: 14px; opacity: 0;\"><img src=\"http://img.minshengec.com/img/topic/goshoping/images/add1.png\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1.5rem;\"/></p></div><a id=\"itemcart\" class=\"item-cart-btn item-btn-addCart trackEvent btn\" data-trackevent=\"zhAppClickAddCart|click|life|10873331\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); display: inline-block; float: right; height: 35px; line-height: 35px; text-align: center; color: rgb(255, 255, 255); background: rgb(242, 71, 58); border-radius: 5px; font-size: 1.6rem; width: 927.5px;\">加入购物车</a></div></div><div class=\"address-box\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; width: 1349px; background: rgb(255, 255, 255); overflow: hidden; z-index: 999; position: fixed; left: 0px; bottom: 0px; height: 0px;\"><div class=\"address-bar\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; width: 1349px; overflow: hidden; height: 30px; line-height: 30px; border-bottom: 1px solid rgb(204, 204, 204);\"><p style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin-top: 0px; margin-bottom: 0px; padding: 0px; font-size: 1.7rem; font-family: \" microsoft=\"\" white-space:=\"\" text-align:=\"\"><br/></p></div></div><p><br/></p>','','','494.00','249.00','249.00','0.00',998,0,3,1,'',1504324308,'0.00','',0,0,0,0,'a:2:{i:1;s:51:\"images/6/2017/09/rlyyAkyaVK8KNMA3o33F1yyF81nQKa.jpg\";i:2;s:51:\"images/6/2017/09/Az3Wbbt4P4r9tg3TPGczCPrL3bRJ9T.jpg\";}',1,1,0,1,1,0,0,0,0,3,0,0,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','',0,'','',0,'',0,'','','','',0,'','',0,'',0,'','','0.00',0,'1184','{\"type\":\"0\",\"default\":\"\",\"default_pay\":\"\",\"level7\":\"\",\"level7_pay\":\"\",\"level6\":\"\",\"level6_pay\":\"\",\"level5\":\"\",\"level5_pay\":\"\"}',0,0,'','','1184',0,'','','','','','','',0,'0.00',0,'0.00','',0,0,0,0,0,'0.00',0,'相宜本草','',1504324140,'{\"type\":0,\"default\":{\"option0\":\"\"},\"level7\":{\"option0\":\"\"},\"level6\":{\"option0\":\"\"},\"level5\":{\"option0\":\"\"}}','{\"type\":0}',0,0,NULL,0,1,0,1,'','249.00','249.00','请选择省份','请选择城市',0,'',0,0,'',0,NULL,0,0,1,0,0,'相宜本草 红景天精纯莹透幼白养肤保湿套装6件套 [套装]',0,0,NULL,0,0,0,1,0,'相宜本草','','','',0,0,'N;',0,1,0,0,'0.00',0,0,0,NULL,0,0,0,0,0,0,0,0,0,0,0,'0.00',0,'0.00',0,0,0,0,0,0,0,1504324140,0,'',0,'0.00','',0,'',0,1,1504324140,1527652140,0,1,0,'0.00',0,'',1,1,0,0,'0.00','0.00','0.00',0,0,0),(202,6,1183,1184,1,1,0,'LANCOME 兰蔻 法国小黑瓶系列经典礼盒','images/6/2017/09/z80g1eA5ijs6SG0ZsiZ5zeziSJz555.jpg','','','','','','3888.00','1099.00','899.00','0.00',666,0,6,0,'',1504324613,'0.00','',0,0,0,0,'a:2:{i:1;s:51:\"images/6/2017/09/Oo1M1enny99084Z1y14loO4M18Uc71.jpg\";i:2;s:51:\"images/6/2017/09/k7rllslYzm24ldq9ZlL742l79Ms2R1.jpg\";}',0,0,0,1,0,0,0,0,0,7,0,0,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','',0,'','',2,'',0,'','','','',0,'','',0,'',0,'','','0.00',0,'1184','{\"type\":\"0\",\"default\":\"\",\"default_pay\":\"\",\"level7\":\"\",\"level7_pay\":\"\",\"level6\":\"\",\"level6_pay\":\"\",\"level5\":\"\",\"level5_pay\":\"\"}',0,0,'','','1184',0,'','','','','','','',0,'0.00',0,'0.00','',0,0,0,0,0,'0.00',0,'【香港直邮】法国小黑瓶系列经典礼盒 [精华肌底液50ml+眼霜15ml]','',1504324440,'{\"type\":0,\"default\":{\"option0\":\"\"},\"level7\":{\"option0\":\"\"},\"level6\":{\"option0\":\"\"},\"level5\":{\"option0\":\"\"}}','{\"type\":0}',0,0,NULL,0,1,1,1,'','1099.00','1099.00','请选择省份','请选择城市',0,'',0,0,'',0,NULL,0,0,1,0,0,'【香港直邮】法国小黑瓶系列经典礼盒 [精华肌底液50ml+眼霜15ml]',0,0,NULL,0,0,0,1,0,'【香港直邮】法国小黑瓶系列经典礼盒 [精华肌底液50ml+眼霜15ml]','','','',0,0,'N;',0,0,0,0,'0.00',0,0,0,NULL,0,0,0,1,0,0,0,0,0,0,0,'0.00',0,'0.00',0,0,0,0,0,0,0,1504324440,0,'',0,'0.00','',0,'',0,0,1504324440,1506916440,0,0,0,'0.00',0,'',1,1,0,0,'0.00','0.00','0.00',0,0,0),(203,6,1176,0,1,1,0,'SNOOPY史努比 【限时抢购】 俏皮马卡龙防水夜光儿童时尚手表 下单即送','images/6/2017/09/De417eS19TARZSl1hY5e704eU7C45E.jpg','','','<div class=\"wrap itemPage\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; width: 1023px; overflow: hidden; min-width: 320px;\"><div class=\"\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px;\"><div class=\"main\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px;\"><div class=\"main-con my-tab-wrap\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px 12px 50px; padding: 0px;\"><div class=\"product-basic\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px;\"><div class=\"product-detail detail-show\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 20px 0px 0px; padding: 0px; width: 999px; overflow: hidden;\"><p style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin-top: 0px; margin-bottom: 0px; padding: 0px; font-size: 1.7rem;\"><img src=\"http://img.minshengec.com/shop/detail//2017/08/29/67781503985440804.jpg\" title=\"67781503985440804.jpg\" alt=\"750-.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/29/27151503985449780.jpg\" title=\"27151503985449780.jpg\" alt=\"750.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/></p></div></div></div></div></div></div><div class=\"item-cart-box\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; width: 1023px; position: fixed; left: 0px; bottom: 0px; height: 50px; background: rgb(255, 255, 255); border-top: 1px solid rgb(231, 231, 231); z-index: 99;\"><div class=\"edit-ctrl-inner\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 8px 12px; padding: 0px; height: 50px;\"><div class=\"item-cart-num-outer box\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 1px; display: inline-block; width: 249.75px; height: 33px; float: left; background: rgb(226, 226, 226); border-radius: 5px;\"><span class=\"icon-basket-1 item-cart-num addCart-end trackEvent\" id=\"gocart\" data-trackevent=\"tocart|click|life|10873331\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); display: inline-block; width: 249.75px; height: 33px; line-height: 33px; text-align: center; font-size: 2.2rem; color: rgb(197, 197, 197); background: rgb(255, 255, 255); border-radius: 5px; position: relative;\"><span style=\"color: rgb(0, 0, 0); font-family: \"Microsoft YaHei\", Arial, Helvetica, sans-serif; font-size: 12px; text-align: start; background-color: rgb(226, 226, 226);\"></span></span></div></div></div><p><br/></p>','','','289.00','128.00','89.00','0.00',264,0,12,0,'',1504424398,'0.00','',0,0,1,0,'a:4:{i:1;s:51:\"images/6/2017/09/NgLM2LbCR9C0l9dr9BBH03k3CpBCpR.jpg\";i:2;s:51:\"images/6/2017/09/Djjf0ApMQ03Zr8rvMm3F8qn8tr8pvD.jpg\";i:3;s:51:\"images/6/2017/09/rjZZ0NQOy2N1Y1JwMSI0nOCnpMYqDz.jpg\";i:4;s:51:\"images/6/2017/09/z2J97xJ2RPlI792J0J5D25R2W29L7r.jpg\";}',1,1,0,1,1,0,0,0,0,9,0,0,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','',0,'','',2,'',0,'','','','',0,'','',0,'',0,'','','0.00',0,'','{\"type\":\"0\",\"default\":\"\",\"default_pay\":\"\",\"level7\":\"\",\"level7_pay\":\"\",\"level6\":\"\",\"level6_pay\":\"\",\"level5\":\"\",\"level5_pay\":\"\"}',0,0,'1176','','1176',0,'','','','','','','',0,'0.00',0,'0.00','',0,0,0,0,0,'0.00',0,'文具五件套+电池 [SNW735EC-2607BU-B蓝色大]','',1504423980,'{\"type\":1,\"default\":{\"option405\":\"\",\"option406\":\"\",\"option407\":\"\"},\"level7\":{\"option405\":\"\",\"option406\":\"\",\"option407\":\"\"},\"level6\":{\"option405\":\"\",\"option406\":\"\",\"option407\":\"\"},\"level5\":{\"option405\":\"\",\"option406\":\"\",\"option407\":\"\"}}','{\"type\":0,\"default\":{\"option405\":[],\"option406\":[],\"option407\":[]}}',0,0,NULL,0,1,1,1,'','128.00','158.00','请选择省份','请选择城市',0,'',0,0,'',0,NULL,0,0,1,0,1,'文具五件套+电池 [SNW735EC-2607BU-B蓝色大]',0,0,NULL,0,0,0,1,0,'文具五件套+电池 [SNW735EC-2607BU-B蓝色大]','','','',0,0,'N;',0,0,0,0,'0.00',0,0,0,NULL,0,0,0,1,0,0,0,0,0,0,0,'0.00',0,'0.00',0,0,0,0,0,0,0,1504423980,0,'',0,'0.00','',0,'',0,0,1504423980,1507015980,0,1,0,'0.00',0,'',1,1,0,0,'0.00','0.00','0.00',0,0,0),(204,6,1176,0,1,1,0,'格玛仕 韩版超薄 时尚潮流石英女式时装镶水钻腕表 [玫金色2105-CR-B2-DW]','images/6/2017/09/V1yNIw1OErYwyliLlbtWe6oOyW6Ybb.jpg','','','<div class=\"wrap itemPage\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; width: 1023px; overflow: hidden; min-width: 320px; font-family: \" microsoft=\"\" font-size:=\"\" white-space:=\"\" background-color:=\"\"><div class=\"\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px;\"><div class=\"main\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px;\"><div class=\"main-con my-tab-wrap\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px 12px 50px; padding: 0px;\"><div class=\"product-basic\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px;\"><div class=\"product-detail detail-show\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 20px 0px 0px; padding: 0px; width: 999px; overflow: hidden;\"><p style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin-top: 0px; margin-bottom: 0px; padding: 0px; font-size: 1.7rem;\"><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/75901502444776355.jpg\" title=\"75901502444776355.jpg\" alt=\"750_01.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/62181502444781378.jpg\" title=\"62181502444781378.jpg\" alt=\"750_02.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/43481502444787128.jpg\" title=\"43481502444787128.jpg\" alt=\"750_03.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/19791502444792219.jpg\" title=\"19791502444792219.jpg\" alt=\"750_04.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/48121502444796785.jpg\" title=\"48121502444796785.jpg\" alt=\"750_05.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/30661502444801904.jpg\" title=\"30661502444801904.jpg\" alt=\"750_06.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/66461502444807318.jpg\" title=\"66461502444807318.jpg\" alt=\"750_07.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/84651502444813364.jpg\" title=\"84651502444813364.jpg\" alt=\"750_08.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/46211502444819837.jpg\" title=\"46211502444819837.jpg\" alt=\"750_09.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/22381502444826122.jpg\" title=\"22381502444826122.jpg\" alt=\"750_10.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/14911502444837625.jpg\" title=\"14911502444837625.jpg\" alt=\"750_11.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/8691502444842604.jpg\" title=\"8691502444842604.jpg\" alt=\"750_12.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/48291502444847633.jpg\" title=\"48291502444847633.jpg\" alt=\"750_13.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/26211502444852252.jpg\" title=\"26211502444852252.jpg\" alt=\"750_14.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/37501502444856770.jpg\" title=\"37501502444856770.jpg\" alt=\"750_15.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/87431502444861458.jpg\" title=\"87431502444861458.jpg\" alt=\"750_16.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/40361502444867002.jpg\" title=\"40361502444867002.jpg\" alt=\"750_17.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/9241502444872936.jpg\" title=\"9241502444872936.jpg\" alt=\"750_17.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/16891502444877967.jpg\" title=\"16891502444877967.jpg\" alt=\"750_18.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/15551502444883990.jpg\" title=\"15551502444883990.jpg\" alt=\"750_19.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/56291502444889453.jpg\" title=\"56291502444889453.jpg\" alt=\"750_20.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/56461502444895462.jpg\" title=\"56461502444895462.jpg\" alt=\"750_21.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/><img src=\"http://img.minshengec.com/shop/detail//2017/08/11/63761502444902356.jpg\" title=\"63761502444902356.jpg\" alt=\"750_22.jpg\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 999px;\"/></p></div></div></div></div></div></div><div class=\"item-cart-box\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 0px; width: 1023px; position: fixed; left: 0px; bottom: 0px; height: 50px; background: rgb(255, 255, 255); border-top: 1px solid rgb(231, 231, 231); z-index: 99; font-family: \" microsoft=\"\" font-size:=\"\" white-space:=\"\"><div class=\"edit-ctrl-inner\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 8px 12px; padding: 0px; height: 50px;\"><div class=\"item-cart-num-outer box\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin: 0px; padding: 1px; display: inline-block; width: 249.75px; height: 33px; float: left; background: rgb(226, 226, 226); border-radius: 5px;\"><span class=\"icon-basket-1 item-cart-num addCart-end trackEvent\" id=\"gocart\" data-trackevent=\"tocart|click|life|10873331\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); display: inline-block; width: 249.75px; height: 33px; line-height: 33px; text-align: center; font-size: 2.2rem; color: rgb(197, 197, 197); background: rgb(255, 255, 255); border-radius: 5px; position: relative;\"><span class=\"num\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); position: absolute; right: -4px; top: -4px; width: 16px; height: 16px; font-size: 1rem; color: rgb(255, 255, 255); background: rgb(242, 71, 58); line-height: 16px; border-radius: 50%;\">0</span></span><p class=\"cbx\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); margin-top: 0px; margin-bottom: 0px; padding: 0px; font-size: 1.7rem; position: absolute; left: 409.188px; top: 14px; opacity: 0;\"><img src=\"http://img.minshengec.com/img/topic/goshoping/images/add1.png\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); border: 0px; width: 1.5rem;\"/></p></div><a id=\"itemcart\" class=\"item-cart-btn item-btn-addCart trackEvent btn\" data-trackevent=\"zhAppClickAddCart|click|life|10873331\" style=\"outline: none; text-size-adjust: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); display: inline-block; float: right; height: 35px; line-height: 35px; text-align: center; color: rgb(255, 255, 255); background: rgb(242, 71, 58); border-radius: 5px; font-size: 1.6rem; width: 699.297px;\">加入购物车</a></div></div><p><br/></p>','','','768.00','460.00','420.00','0.00',87,0,8,1,'',1504425335,'0.00','',0,0,0,0,'a:3:{i:1;s:51:\"images/6/2017/09/KKzrEcac22C28u6R8ARECCec666666.jpg\";i:2;s:51:\"images/6/2017/09/IrnOOxtTXv2mLsRtzzdjjvSxJJyS2t.jpg\";i:3;s:51:\"images/6/2017/09/W9O99t515KfTKXb28koTYtO52VB5Oo.jpg\";}',1,1,0,1,1,0,0,0,0,12,0,0,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','',0,'','',2,'',0,'','','','',0,'','',0,'',0,'','','0.00',0,'','{\"type\":\"0\",\"default\":\"\",\"default_pay\":\"\",\"level7\":\"\",\"level7_pay\":\"\",\"level6\":\"\",\"level6_pay\":\"\",\"level5\":\"\",\"level5_pay\":\"\"}',0,0,'1176','','1176',0,'','','','','','','',0,'0.00',0,'0.00','',0,0,0,0,0,'0.00',0,'时尚潮流石英女式时装镶水钻腕表 [玫金色2105-CR-B2-DW]','',1504425060,'{\"type\":0,\"default\":{\"option0\":\"\"},\"level7\":{\"option0\":\"\"},\"level6\":{\"option0\":\"\"},\"level5\":{\"option0\":\"\"}}','{\"type\":0}',0,0,NULL,0,1,1,1,'','460.00','460.00','请选择省份','请选择城市',0,'',0,0,'',0,NULL,0,0,1,0,0,'时尚潮流石英女式时装镶水钻腕表 [玫金色2105-CR-B2-DW]',0,0,NULL,0,0,0,1,0,'时尚潮流石英女式时装镶水钻腕表 [玫金色2105-CR-B2-DW]','','','',0,0,'N;',0,0,0,0,'0.00',0,0,0,NULL,0,0,0,1,0,0,0,0,0,0,0,'0.00',0,'0.00',0,0,0,0,0,0,0,1504425060,0,'',0,'0.00','',0,'',0,0,1504425060,1507017060,0,1,0,'0.00',0,'',1,1,0,0,'0.00','0.00','0.00',0,0,0),(205,6,1174,1179,1,1,0,'【早付尾款 早发货】Apple/苹果 iPhone 6s 32G 全网通4G智能手机','images/6/2017/09/To2J5V5LSB27sO1J1ST2Gwgv6gsVQ7Y1.jpg','',NULL,'<div>  <a href=\"//detail.tmall.com/item.htm?spm=0.0.0.0.1FTaxP&id=542839248599\" target=\"_blank\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/IOMOa9rR5ooF0A0U0Ph808OPAp9rp0HN.jpg\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/GwohCuWhwHkzOVbiuhw6y9HwCkhyBWku.jpg\" /></a> <a href=\"//detail.tmall.com/item.htm?spm=0.0.0.0.4mGtvM&id=542878483702\" target=\"_blank\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/hq4m59lyz4Qe5V65H5Ov6Z54fqa5F5O6.jpg\" /></a> <a href=\"//suning.tmall.com/p/rd421910.htm\" target=\"_blank\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/pQ6uMSEmouRiasMHRe2ikQOfOvs21Dv6.jpg\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/ZWbJIc48x7Tc387a8j1B6J1pp4i81IbP.jpg\" /></a> <img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/x07SjnnbLiNjKJ272gi9WwlG4lKWbL67.jpg\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/q333Szp9rn3V0mv1lOMqzRPLSnrMRPO3.jpg\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/DR3u3JjDJj545vv5Ywos4rd1jgzggY2S.jpg\" size=\"790x1500\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/VU8VH1Z881CL791DCVU76Tc99899T5hF.jpg\" size=\"790x80\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/bk0yL6z613Aa37LJmjln3vvNl6L76M3j.jpg\" size=\"790x1426\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/NKvc7O1IBn2w2ItzLo1kofwFlinmCbeg.jpg\" size=\"790x1500\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/X8h0yVXFuh5C8n98vy0wvuvVh8HVuxv8.jpg\" size=\"790x1056\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/Pmee89u4Eug1Im5A8JBM6UJ33MzJnB83.jpg\"> </div>','','','0.00','4588.00','0.00','0.00',0,0,0,0,'',1504616432,'0.00',NULL,0,0,1,0,'a:3:{i:0;s:53:\"images/6/2017/09/h9D6UDodbdu7zOPPgQGm9TV6gKgg7j77.jpg\";i:1;s:53:\"images/6/2017/09/C37PF0f0zv7JqAlv0a0z93F00Rf9wPLr.jpg\";i:2;s:53:\"images/6/2017/09/z6DpTfW7y8WlEEm6Mx8x4zEDf5Z4pMEW.jpg\";}',0,0,0,0,0,0,0,0,0,0,0,0,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','',1504616629,'','',0,'',0,'','','','',0,'','',0,NULL,0,'','','0.00',0,NULL,NULL,0,0,NULL,NULL,'1179',0,'','','','','','','',0,'0.00',0,'0.00',NULL,0,0,0,0,0,'0.00',0,'','',0,NULL,NULL,0,0,NULL,0,0,0,0,'','4588.00','4588.00','','',0,NULL,0,0,NULL,0,NULL,0,0,0,0,0,'',0,0,NULL,0,0,0,0,0,'','522155891308','http://item.taobao.com/item.htm?id=522155891308','taobao',0,0,NULL,0,0,0,0,'0.00',0,0,0,NULL,0,0,NULL,0,0,0,0,0,0,0,0,'0.00',0,'0.00',0,0,0,0,0,0,0,0,0,'',0,'0.00','',0,'',0,0,0,0,0,1,0,'0.00',0,'',1,1,0,0,'0.00','0.00','0.00',0,0,0),(206,6,1174,0,1,1,0,'TCL D49A620U 49英寸64位14核HDR真4K安卓智能网络液晶平板电视','images/6/2017/09/vmmkSnNmzURb4xteyeY9M0JsYOXkIsxe.jpg','',NULL,'<p><img src=\"http://wx.adjyc.com/attachment/images/6/2017/09/d4l5elVvm1ldaVzRqqaaA9999M4VSVES.jpg\" align=\"absmiddle\" size=\"790x300\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/HKz4JJjOx4kIJsLcIO51KSOalikOqIQJ.jpg\" size=\"790x316\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/xzJVgiUgHji9AIJXXNntg7V99KJxZ79W.jpg\" size=\"790x594\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/zaMUXMA1hAx4ESiH7EceeXm8844cEExA.jpg\" size=\"790x600\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/C1EGKQQ65ydE6EF1Z0b80y4E1461cc74.jpg\" size=\"790x600\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/gQHJ7p507KG50tV55ugMtt9T5hm0XqP5.jpg\" size=\"790x665\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/zoO0y2RIeuC9Y7gyhG2G4u0220gwwYhO.jpg\" size=\"790x576\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/CNCzdyzDmkGkYkc7mfz2cegz5kUNGB5K.jpg\" size=\"790x919\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/ztQ7PON7PrE15Qs5OtoT73tAHRTO1QHP.jpg\" size=\"790x651\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/g8wL68z3oLw35356wZO5hWZ991O559lx.jpg\" size=\"790x984\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/X97ABb90B5xZ068jADVJ7KkQ5V82DA87.jpg\" size=\"790x1039\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/Uzt6IPEi2l69LSlL69JBt6DpB9tJ626I.jpg\" size=\"790x640\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/Ok0q1K50pv1f0UOF05fjfFOQ0G5JTqZk.jpg\" size=\"790x906\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/Q0B8U885B70TAf618Z44100UB04FbFtT.jpg\" size=\"790x667\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/ua12wzT1sB4IISiboasbIiZ6bvSv6iBi.jpg\" size=\"790x585\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/bozvPY62t9pyNLkKcp7slcotnLpN9OdY.jpg\" size=\"790x974\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/YZn12JeT7jCteBjcnJN441Wn7n7ndJNc.jpg\" size=\"790x1053\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/yQe7U7EehSqJYkTcXPkq7DCFyFhHddHT.jpg\" size=\"790x1177\" /></p>','','','0.00','3399.00','0.00','0.00',7,0,701,0,'',1504616716,'0.00',NULL,0,0,1,0,'a:4:{i:0;s:53:\"images/6/2017/09/J9II49Hah9rdqoAya8MA2rI994mq0nqH.jpg\";i:1;s:53:\"images/6/2017/09/GuIU8roBWWbl5b8iUUJ0wixXzOZOggWo.jpg\";i:2;s:53:\"images/6/2017/09/mCzc45LGR3gg63Tc3eUlI45uL4zUfJjL.jpg\";i:3;s:53:\"images/6/2017/09/i23ZJad3aAZDJA3vaCUuuDAAxsA3UgCY.jpg\";}',0,0,0,1,0,0,0,0,0,1,0,0,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','',1504616716,'','',0,'',0,'','','','',0,'','',0,NULL,0,'','','0.00',0,NULL,NULL,0,0,NULL,NULL,'1174',0,'','','','','','','',0,'0.00',0,'0.00',NULL,0,0,0,0,0,'0.00',0,'','',0,NULL,NULL,0,0,NULL,0,0,0,0,'','3399.00','3399.00','','',0,NULL,0,0,NULL,0,NULL,0,0,0,0,0,'',0,0,NULL,0,0,0,0,0,'','542225813793','https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15791796626.3.19335493NlLOoz&id=542225813793&scene=taobao_shop&skuId=3422140902630','taobao',0,0,NULL,0,0,0,0,'0.00',0,0,0,NULL,0,0,NULL,0,0,0,0,0,0,0,0,'0.00',0,'0.00',0,0,0,0,0,0,0,0,0,'',0,'0.00','',0,'',0,0,0,0,0,1,0,'0.00',0,'',1,1,0,0,'0.00','0.00','0.00',0,0,0),(207,6,1174,0,1,1,0,'【3期免息】honor/荣耀 荣耀8高配 4+64G全网通4G手机','images/6/2017/09/h11L495LcC2dj2sI4e4iS8jBl690dzc5.jpg','',NULL,'<p><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/Gm55X03r7C75q50538t7870fCY7jF0h5.jpg\" size=\"790x45\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/a9at2h724028GHKE0HT4zQQy9htZ4q78.jpg\" size=\"750x852\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/g2c8czO0c989290azIcAc6ao6ZGxXB2O.jpg\" size=\"750x858\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/WjkCnp00UKR9HRhPb3znio3bO03pzopn.jpg\" size=\"750x1025\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/t4BBSz44s6eB4eS2662S24E9zfS9rBz9.jpg\" size=\"750x873\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/qDoFueYYUUr090ic0ZuET9TZy4oiDUR0.jpg\" size=\"750x1076\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/q1B2lbZ6MvelUULL9L19N6xKTwXOue92.jpg\" size=\"750x1008\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/P510iN4ao2CCc2OOcA10Ni1442C05JZz.jpg\" size=\"750x1012\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/iTHIkL26gPCxl1gK6ya1I2L6I0PIiiMH.jpg\" size=\"750x1252\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/zAk2NNZ04oD42HNDr0KZ0rHKne598lq9.jpg\" size=\"750x1055\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/BK0K2vint5264v543404rr5aM022z266.jpg\" size=\"750x1151\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/ZPfzyglEIEpPBqzBMeH4SE5y3pB4EY5g.jpg\" size=\"790x410\" /></p>','','','0.00','2499.00','0.00','0.00',292,0,3229,0,'',1504616718,'0.00',NULL,0,0,1,0,'a:4:{i:0;s:53:\"images/6/2017/09/O7D75r2BR2112r4VyD41B84M8n1n917B.jpg\";i:1;s:53:\"images/6/2017/09/f0uRpFFEP8EERE880yyTuEhSBeTR8GHr.jpg\";i:2;s:53:\"images/6/2017/09/GG457hFAjhg7aGJ1a67G7EHae6af1aE1.jpg\";i:3;s:53:\"images/6/2017/09/HMY8479zFI6YMi47dY4d9IK4mU8Kq9D8.jpg\";}',0,0,0,1,0,0,0,0,0,0,0,0,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','',1504616718,'','',0,'',0,'','','','',0,'','',0,NULL,0,'','','0.00',0,NULL,NULL,0,0,NULL,NULL,'1174',0,'','','','','','','',0,'0.00',0,'0.00',NULL,0,0,0,0,0,'0.00',0,'','',0,NULL,NULL,0,0,NULL,0,0,0,0,'','2499.00','2499.00','','',0,NULL,0,0,NULL,0,NULL,0,0,0,0,0,'',0,0,NULL,0,0,0,0,0,'','537605741122','https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15791796626.2.19335493NlLOoz&id=537605741122&scene=taobao_shop&sku_properties=5919063:6536025;12304035:3222911;122216431:27772','taobao',0,0,NULL,0,0,0,0,'0.00',0,0,0,NULL,0,0,NULL,0,0,0,0,0,0,0,0,'0.00',0,'0.00',0,0,0,0,0,0,0,0,0,'',0,'0.00','',0,'',0,0,0,0,0,1,0,'0.00',0,'',1,1,0,0,'0.00','0.00','0.00',0,0,0),(208,6,1176,0,1,1,0,'施华洛世奇闪耀水晶质感星星项链耳钉首饰套装配饰5140839','images/6/2017/09/icd0mY09Pyj5c7C42I52C2QKPCJGLYcd.jpg','',NULL,'<img class=\"desc_anchor\" id=\"desc-module-1\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/S44J90Njyz90y5wv74jM9Pk1wmv4yzcv.gif\"><img alt=\"5140839.jpg\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/e2lb6477Z4u422t6T622NGdBF080B64Z.jpg\" size=\"790x5270\" />','','','0.00','1490.00','0.00','0.00',30,0,2,0,'',1504617532,'0.00',NULL,0,0,1,0,'a:4:{i:0;s:53:\"images/6/2017/09/KZS4SG1507ngUNZ5Ao0e4uO145NsjUnu.jpg\";i:1;s:53:\"images/6/2017/09/Req1q1ZYf1s36Qh6yFESpHqQ0m97mQmQ.jpg\";i:2;s:53:\"images/6/2017/09/gzMJ6afA8AqbAiEItZQ4I8ja8QzvmiF4.jpg\";i:3;s:53:\"images/6/2017/09/iv7xRQnM2rqNr2M3Gg57v7Bzq2Mvx7ul.jpg\";}',1,1,1,1,0,0,0,0,0,0,0,0,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','',1504617532,'','',0,'',0,'','','','',0,'','',0,NULL,0,'','','0.00',0,NULL,NULL,0,0,NULL,NULL,'1176,1183',0,'','','','','','','',0,'0.00',0,'0.00',NULL,0,0,0,0,0,'0.00',0,'','',0,NULL,NULL,0,0,NULL,0,0,0,0,'','1490.00','1490.00','','',0,NULL,0,0,NULL,0,NULL,0,0,0,0,0,'',0,0,NULL,0,0,0,0,0,'','556734757086','https://detail.tmall.hk/hk/item.htm?spm=a220m.1000858.1000725.46.4c6378100iQg3r&id=556734757086&skuId=3611682498097&areaId=350200&user_id=2010071101&cat_id=2&is_b=1&rn=bcd493e6b0a2ed330f3d2226dd7ff316','taobao',0,0,NULL,0,0,0,0,'0.00',0,0,0,NULL,0,0,NULL,0,0,0,0,0,0,0,0,'0.00',0,'0.00',0,0,0,0,0,0,0,0,0,'',0,'0.00','',0,'',0,0,0,0,0,1,0,'0.00',0,'',1,1,0,0,'0.00','0.00','0.00',0,0,0),(209,6,1176,0,1,1,0,'施华洛世奇 Get Wide手镯 时尚简约阔身设计首饰配饰','images/6/2017/09/OwpWR4w40xw5VxR00cwwLP0IC02120OI.jpg','',NULL,'<img class=\"desc_anchor\" id=\"desc-module-1\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/l69R0K2EUM0VNgz9GGpnKFwzffG6PN2f.gif\"><p><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/JJ7VFH0O0olHOC0zULQI9FlOV0oqf7Uz.jpg\" size=\"790x420\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/qMYWZm5mY677ss2QaW3wCMCzkW5uysYW.jpg\" size=\"790x402\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/qfeN7w8IMEN48wTIIVR7rg88teII4iuZ.jpg\" size=\"790x493\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/E5Eet8DZNM87kxPmDpmNPYk7M0T0oOmx.jpg\" size=\"790x318\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/MlCrRZ8JvCefZbEXMff7BlC8VvZLR8FB.jpg\" size=\"790x600\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/hdWO4Vv7LOPjj5OwpX0ZPOb5VDjs707L.jpg\" size=\"790x600\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/hMhYfY61F9VomO8mTP3o5zVLFxxt9hlF.jpg\" size=\"790x600\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/vrJ7Lt15Jr9c4ToO147L9797JSFrz3r2.jpg\" size=\"790x600\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/zsSTsJbzXsQJgUCGUGsqkdGGmoGMTcC7.jpg\" size=\"790x834\"><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/iN44WWbjYXYjW4yWjyNyXYVWDfw8x1YB.jpg\" size=\"790x379\" /></p>','','','0.00','1790.00','0.00','0.00',21,0,18,0,'',1504617534,'0.00',NULL,0,0,1,0,'a:4:{i:0;s:53:\"images/6/2017/09/CYy42tFpKvITV4yFD49ZzVKvzKgP6kd9.jpg\";i:1;s:53:\"images/6/2017/09/YMZIb8c7IE3MU3z3zcV93S8k53MFKmss.jpg\";i:2;s:53:\"images/6/2017/09/XHjH31yj7g77wU0yw01iwYjyZNiGKgle.jpg\";i:3;s:53:\"images/6/2017/09/LnFu9q8n8EuJU8QvJFEnSF924sfnVc98.jpg\";}',1,1,1,1,0,0,0,0,0,0,0,0,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','',1504617535,'','',0,'',0,'','','','',0,'','',0,NULL,0,'','','0.00',0,NULL,NULL,0,0,NULL,NULL,'1176,1183',0,'','','','','','','',0,'0.00',0,'0.00',NULL,0,0,0,0,0,'0.00',0,'','',0,NULL,NULL,0,0,NULL,0,0,0,0,'','1790.00','1790.00','','',0,NULL,0,0,NULL,0,NULL,0,0,0,0,0,'',0,0,NULL,0,0,0,0,0,'','545970731242','https://detail.tmall.com/item.htm?spm=a220m.1000858.1000725.36.4c6378100iQg3r&id=545970731242&skuId=3461045547958&areaId=350200&user_id=2576722561&cat_id=2&is_b=1&rn=bcd493e6b0a2ed330f3d2226dd7ff316','taobao',0,0,NULL,0,0,0,0,'0.00',0,0,0,NULL,0,0,NULL,0,0,0,0,0,0,0,0,'0.00',0,'0.00',0,0,0,0,0,0,0,0,0,'',0,'0.00','',0,'',0,0,0,0,0,1,0,'0.00',0,'',1,1,0,0,'0.00','0.00','0.00',0,0,0),(210,6,1174,1178,1,1,0,'施华洛世奇 Cherie手链 妩媚渐变粉红色水晶般质地小花束手链首饰','images/6/2017/09/E8B7s39T7P6lZ9422Pl6KRSSbR7B8j8l.jpg','','','<p><img class=\"desc_anchor\" id=\"desc-module-1\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/QiGo8QKl8oCXkUX2ucK8GXO27v7l2Uuu.gif\"/></p><p><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/EG2ftVy83E33nYGjAP1favpY1X3nA3zN.jpg\" size=\"790x420\"/><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/baFA11bbYK1AMCiRKFoMPKOmY2K6yfOi.jpg\" size=\"790x435\"/><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/FdT8c0ytwyHJ38VF5GCcSC8Fg5ZYZvjd.jpg\" size=\"790x783\"/><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/b7AB85FL5a8FLkLgPK58KBkdFPg6mC7f.jpg\" size=\"790x530\"/><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/HakFP3EEKKpea3ArER0RpX2ZPRa23eAa.jpg\" size=\"790x413\"/><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/oR811h27l32IipU0H0pu3v3399262Uru.jpg\" size=\"790x1185\"/></p>','','','0.00','1420.00','0.00','0.00',55,0,37,0,'',1504617536,'0.00','',0,0,0,0,'a:4:{i:1;s:53:\"images/6/2017/09/i3SvhXObzLXfv9hD3uuzsof9kkfBgKxu.jpg\";i:2;s:53:\"images/6/2017/09/G8K8Clz6enEMl1YekiNfh8LknhEmEK8K.jpg\";i:3;s:53:\"images/6/2017/09/jLi1KiiI37ID47kO4XzL7I3LNJx0D3d0.jpg\";i:4;s:53:\"images/6/2017/09/v5zGvX58rdkLhwlzWur5klLlG9uGVJV8.jpg\";}',0,0,1,1,0,0,0,0,0,0,0,0,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','',1504617536,'','',0,'',0,'','','','',0,'','',0,'',0,'','','0.00',0,'1178','{\"type\":\"0\",\"default\":\"\",\"default_pay\":\"\",\"level7\":\"\",\"level7_pay\":\"\",\"level6\":\"\",\"level6_pay\":\"\",\"level5\":\"\",\"level5_pay\":\"\"}',0,0,'1175,1176,1183','','1178,1175,1176,1183',0,'','','','','','','',0,'0.00',0,'0.00','',0,0,0,0,0,'0.00',0,'','',1504617720,'{\"type\":0,\"default\":{\"option0\":\"\"},\"level7\":{\"option0\":\"\"},\"level6\":{\"option0\":\"\"},\"level5\":{\"option0\":\"\"}}','{\"type\":0}',0,0,NULL,0,0,0,0,'','1420.00','1420.00','请选择省份','请选择城市',0,'',0,0,'',0,NULL,0,0,0,0,0,'',0,0,NULL,0,0,0,0,0,'','525903378849','https://detail.tmall.com/item.htm?spm=a220m.1000858.1000725.31.4c6378100iQg3r&id=525903378849&areaId=350200&user_id=2576722561&cat_id=2&is_b=1&rn=bcd493e6b0a2ed330f3d2226dd7ff316','taobao',0,0,'N;',0,0,0,0,'0.00',0,0,0,NULL,0,0,0,0,0,0,0,0,0,0,0,'0.00',0,'0.00',0,0,0,0,0,0,0,1504617720,0,'',0,'0.00','',0,'',0,0,1504617720,1507209720,0,1,0,'0.00',0,'',1,1,0,0,'0.00','0.00','0.00',0,0,0),(211,6,1176,0,1,1,0,'Swarovski/施华洛世奇手镯魅力可调手链女首饰女士饰品5279415','images/6/2017/09/Dq4sSR4RZquGAaa3JURge05e4oS4GHE9.jpg','',NULL,'<img class=\"desc_anchor\" id=\"desc-module-1\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/BO70393RoO7bR030zO70q09q7m9op0Eb.gif\"><p><img src=\"http://wx.adjyc.com/attachment/images/6/2017/09/VjKK48CZP0FFJ4Sf2FFxj204ZcjKAF8v.jpg\" align=\"absmiddle\" size=\"790x431\"><img src=\"http://wx.adjyc.com/attachment/images/6/2017/09/wR4mP481uJd16688vaQqApd9w9OD49jV.jpg\" align=\"absmiddle\" size=\"790x549\"><img src=\"http://wx.adjyc.com/attachment/images/6/2017/09/fty1GXmaypLN1aamXmWcgzPw6MgNYTaP.jpg\" align=\"absmiddle\" size=\"790x723\"><img src=\"http://wx.adjyc.com/attachment/images/6/2017/09/VU2hwV4Jj73UujV9d6u341dU41uUIHuU.jpg\" align=\"absmiddle\" size=\"790x789\"><img src=\"http://wx.adjyc.com/attachment/images/6/2017/09/u3qAmMLLAKmSLa81a1MYAc1A3SUSAAyG.jpg\" align=\"absmiddle\" size=\"790x1025\"> </p>','','','0.00','1250.00','0.00','0.00',4,0,1,0,'',1504617537,'0.00',NULL,0,0,0,0,'a:4:{i:0;s:53:\"images/6/2017/09/KfefuNXf1G2vb5495nfXvXbfhUf2VMVx.jpg\";i:1;s:53:\"images/6/2017/09/hrH7RhSsu28Hs08u0Jzg0hwz85KpSU80.jpg\";i:2;s:53:\"images/6/2017/09/AoOVvOqu8MwCQOh0OqZMRjH4vU8HC0WM.jpg\";i:3;s:53:\"images/6/2017/09/Y2LY34i5LL0q4BQ472L50Z4R24RS43LJ.jpg\";}',1,1,1,1,1,0,0,0,0,0,0,0,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','',1504617537,'','',0,'',0,'','','','',0,'','',0,NULL,0,'','','0.00',0,NULL,NULL,0,0,NULL,NULL,'1176,1183',0,'','','','','','','',0,'0.00',0,'0.00',NULL,0,0,0,0,0,'0.00',0,'','',0,NULL,NULL,0,0,NULL,0,0,0,0,'','1250.00','1250.00','','',0,NULL,0,0,NULL,0,NULL,0,0,0,0,0,'',0,0,NULL,0,0,0,0,0,'','556163042004','https://detail.tmall.hk/hk/item.htm?spm=a220m.1000858.1000725.26.4c6378100iQg3r&id=556163042004&areaId=350200&user_id=2636123813&cat_id=2&is_b=1&rn=bcd493e6b0a2ed330f3d2226dd7ff316','taobao',0,0,NULL,0,0,0,0,'0.00',0,0,0,NULL,0,0,NULL,0,0,0,0,0,0,0,0,'0.00',0,'0.00',0,0,0,0,0,0,0,0,0,'',0,'0.00','',0,'',0,0,0,0,0,1,0,'0.00',0,'',1,1,0,0,'0.00','0.00','0.00',0,0,0),(212,6,1176,0,1,1,0,'施华洛世奇Swarovski 红色心型水晶质感项链耳钉首饰套装5198937','images/6/2017/09/e7jN0NO433wrn3zU8Iv7Jrf3FNS3NJ3W.jpg','',NULL,'<img class=\"desc_anchor\" id=\"desc-module-1\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/z57jb3kj38SZsCIRcO7ja8oij9BUBUQ4.gif\"><p><img align=\"absmiddle\" src=\"http://wx.adjyc.com/attachment/images/6/2017/09/PClg23WDk9g2Z9616rKrZ3l1d2pl2SzA.jpg\" size=\"790x5270\" /></p>','','','0.00','1700.00','0.00','0.00',7,0,4,0,'',1504617539,'0.00',NULL,0,0,1,0,'a:3:{i:0;s:53:\"images/6/2017/09/DzRG88g2iWMEw82ww4x182iz8WZWWwNe.jpg\";i:1;s:53:\"images/6/2017/09/R5K5090dyz0mypzdPv005ITz050lOdik.jpg\";i:2;s:53:\"images/6/2017/09/OeE9I7qEe6698788BqBL227927B92Ie2.jpg\";}',1,1,0,1,0,0,0,0,0,0,0,0,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','',1504617539,'','',0,'',0,'','','','',0,'','',0,NULL,0,'','','0.00',0,NULL,NULL,0,0,NULL,NULL,'1176,1183',0,'','','','','','','',0,'0.00',0,'0.00',NULL,0,0,0,0,0,'0.00',0,'','',0,NULL,NULL,0,0,NULL,0,0,0,0,'','1700.00','1700.00','','',0,NULL,0,0,NULL,0,NULL,0,0,0,0,0,'',0,0,NULL,0,0,0,0,0,'','536082578238','https://detail.tmall.hk/hk/item.htm?spm=a220m.1000858.1000725.11.4c6378100iQg3r&id=536082578238&skuId=3498601970324&areaId=350200&user_id=2010071101&cat_id=2&is_b=1&rn=bcd493e6b0a2ed330f3d2226dd7ff316','taobao',0,0,NULL,0,0,0,0,'0.00',0,0,0,NULL,0,0,NULL,0,0,0,0,0,0,0,0,'0.00',0,'0.00',0,0,0,0,0,0,0,0,0,'',0,'0.00','',0,'',0,0,0,0,0,1,0,'0.00',0,'',1,1,0,0,'0.00','0.00','0.00',0,0,0);
/*!40000 ALTER TABLE `ims_ewei_shop_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_goods_cards`
--

DROP TABLE IF EXISTS `ims_ewei_shop_goods_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_goods_cards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT NULL,
  `card_id` varchar(255) DEFAULT NULL,
  `card_title` varchar(255) DEFAULT NULL,
  `card_brand_name` varchar(255) DEFAULT NULL,
  `card_totalquantity` int(11) DEFAULT NULL,
  `card_quantity` int(11) DEFAULT NULL,
  `card_logoimg` varchar(255) DEFAULT NULL,
  `card_logowxurl` varchar(255) DEFAULT NULL,
  `card_backgroundtype` tinyint(1) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `card_backgroundimg` varchar(255) DEFAULT NULL,
  `card_backgroundwxurl` varchar(255) DEFAULT NULL,
  `prerogative` varchar(255) DEFAULT NULL,
  `card_description` varchar(255) DEFAULT NULL,
  `freewifi` tinyint(1) DEFAULT NULL,
  `withpet` tinyint(1) DEFAULT NULL,
  `freepark` tinyint(1) DEFAULT NULL,
  `deliver` tinyint(1) DEFAULT NULL,
  `custom_cell1` tinyint(1) DEFAULT NULL,
  `custom_cell1_name` varchar(255) DEFAULT NULL,
  `custom_cell1_tips` varchar(255) DEFAULT NULL,
  `custom_cell1_url` varchar(255) DEFAULT NULL,
  `color2` varchar(20) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_goods_cards`
--

LOCK TABLES `ims_ewei_shop_goods_cards` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_goods_cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_goods_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_goods_comment`
--

DROP TABLE IF EXISTS `ims_ewei_shop_goods_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_goods_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `goodsid` int(10) DEFAULT '0',
  `openid` varchar(50) DEFAULT '',
  `nickname` varchar(50) DEFAULT '',
  `headimgurl` varchar(255) DEFAULT '',
  `content` varchar(255) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_goodsid` (`goodsid`),
  KEY `idx_openid` (`openid`),
  KEY `idx_createtime` (`createtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_goods_comment`
--

LOCK TABLES `ims_ewei_shop_goods_comment` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_goods_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_goods_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_goods_group`
--

DROP TABLE IF EXISTS `ims_ewei_shop_goods_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_goods_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `goodsids` varchar(255) NOT NULL DEFAULT '',
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `merchid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_goods_group`
--

LOCK TABLES `ims_ewei_shop_goods_group` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_goods_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_goods_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_goods_label`
--

DROP TABLE IF EXISTS `ims_ewei_shop_goods_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_goods_label` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `label` varchar(255) NOT NULL DEFAULT '',
  `labelname` text NOT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `displayorder` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_goods_label`
--

LOCK TABLES `ims_ewei_shop_goods_label` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_goods_label` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_goods_label` VALUES (1,6,'手机','a:4:{i:0;s:6:\"华为\";i:1;s:6:\"小米\";i:2;s:6:\"苹果\";i:3;s:9:\"小辣椒\";}',1,0),(2,6,'首饰','a:6:{i:0;s:6:\"项链\";i:1;s:6:\"手镯\";i:2;s:6:\"耳钉\";i:3;s:6:\"砖石\";i:4;s:6:\"银饰\";i:5;s:6:\"黄金\";}',1,0);
/*!40000 ALTER TABLE `ims_ewei_shop_goods_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_goods_labelstyle`
--

DROP TABLE IF EXISTS `ims_ewei_shop_goods_labelstyle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_goods_labelstyle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `style` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_goods_labelstyle`
--

LOCK TABLES `ims_ewei_shop_goods_labelstyle` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_goods_labelstyle` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_goods_labelstyle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_goods_option`
--

DROP TABLE IF EXISTS `ims_ewei_shop_goods_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_goods_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `goodsid` int(10) DEFAULT '0',
  `title` varchar(50) DEFAULT '',
  `thumb` varchar(60) DEFAULT '',
  `productprice` decimal(10,2) DEFAULT '0.00',
  `marketprice` decimal(10,2) DEFAULT '0.00',
  `costprice` decimal(10,2) DEFAULT '0.00',
  `stock` int(11) DEFAULT '0',
  `weight` decimal(10,2) DEFAULT '0.00',
  `displayorder` int(11) DEFAULT '0',
  `specs` text,
  `skuId` varchar(255) DEFAULT '',
  `goodssn` varchar(255) DEFAULT '',
  `productsn` varchar(255) DEFAULT '',
  `virtual` int(11) DEFAULT '0',
  `exchange_stock` int(11) DEFAULT '0',
  `exchange_postage` decimal(10,2) NOT NULL DEFAULT '0.00',
  `presellprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `day` int(3) NOT NULL,
  `allfullbackprice` decimal(10,2) NOT NULL,
  `fullbackprice` decimal(10,2) NOT NULL,
  `allfullbackratio` decimal(10,2) DEFAULT NULL,
  `fullbackratio` decimal(10,2) DEFAULT NULL,
  `isfullback` tinyint(3) NOT NULL,
  `islive` int(11) NOT NULL,
  `liveprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_goodsid` (`goodsid`),
  KEY `idx_displayorder` (`displayorder`)
) ENGINE=MyISAM AUTO_INCREMENT=421 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_goods_option`
--

LOCK TABLES `ims_ewei_shop_goods_option` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_goods_option` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_goods_option` VALUES (405,6,203,'11寸','','128.00','128.00','128.00',88,'0.00',0,'291','','','',0,0,'0.00','0.00',0,'0.00','0.00',NULL,NULL,0,0,'0.00'),(406,6,203,'12寸','','138.00','138.00','138.00',88,'0.00',0,'292','','','',0,0,'0.00','0.00',0,'0.00','0.00',NULL,NULL,0,0,'0.00'),(407,6,203,'13寸','','158.00','158.00','158.00',88,'0.00',0,'293','','','',0,0,'0.00','0.00',0,'0.00','0.00',NULL,NULL,0,0,'0.00'),(408,6,205,'无需合约版+玫瑰金色+官方标配+32GB','','0.00','4588.00','0.00',0,'0.00',0,'294_297_299_300','3426426922608','','',0,0,'0.00','0.00',0,'0.00','0.00',NULL,NULL,0,0,'0.00'),(409,6,205,'无需合约版+金色+官方标配+32GB','','0.00','4588.00','0.00',0,'0.00',1,'294_296_299_300','3426426710995','','',0,0,'0.00','0.00',0,'0.00','0.00',NULL,NULL,0,0,'0.00'),(410,6,205,'无需合约版+深空灰色+官方标配+32GB','','0.00','4588.00','0.00',0,'0.00',2,'294_298_299_300','3426488195544','','',0,0,'0.00','0.00',0,'0.00','0.00',NULL,NULL,0,0,'0.00'),(411,6,205,'无需合约版+银色+官方标配+32GB','','0.00','4588.00','0.00',0,'0.00',3,'294_295_299_300','3426426906491','','',0,0,'0.00','0.00',0,'0.00','0.00',NULL,NULL,0,0,'0.00'),(412,6,206,'黑色+官方标配','','0.00','3399.00','0.00',7,'0.00',0,'301_302','3422140902630','','',0,0,'0.00','0.00',0,'0.00','0.00',NULL,NULL,0,0,'0.00'),(413,6,207,'珠光白+官方标配+64GB+中国大陆','','0.00','2499.00','0.00',37,'0.00',0,'303_307_308_309','3212303485830','','',0,0,'0.00','0.00',0,'0.00','0.00',NULL,NULL,0,0,'0.00'),(414,6,207,'魅海蓝+官方标配+64GB+中国大陆','','0.00','2499.00','0.00',200,'0.00',1,'305_307_308_309','3212303485832','','',0,0,'0.00','0.00',0,'0.00','0.00',NULL,NULL,0,0,'0.00'),(415,6,207,'幻夜黑+官方标配+64GB+中国大陆','','0.00','2499.00','0.00',55,'0.00',2,'306_307_308_309','3212303485833','','',0,0,'0.00','0.00',0,'0.00','0.00',NULL,NULL,0,0,'0.00'),(416,6,207,'流光金+官方标配+64GB+中国大陆','','0.00','2499.00','0.00',0,'0.00',3,'304_307_308_309','3212303485831','','',0,0,'0.00','0.00',0,'0.00','0.00',NULL,NULL,0,0,'0.00'),(417,6,208,'5140839','','0.00','1490.00','0.00',30,'0.00',0,'310','3611682498097','','',0,0,'0.00','0.00',0,'0.00','0.00',NULL,NULL,0,0,'0.00'),(418,6,209,'镀玫瑰金色M','','0.00','1790.00','0.00',9,'0.00',0,'312','3461045547959','','',0,0,'0.00','0.00',0,'0.00','0.00',NULL,NULL,0,0,'0.00'),(419,6,209,'镀玫瑰金色S','','0.00','1790.00','0.00',12,'0.00',1,'311','3461045547958','','',0,0,'0.00','0.00',0,'0.00','0.00',NULL,NULL,0,0,'0.00'),(420,6,212,'库存更新快，拍前咨询客服是否现货5198937','','0.00','1700.00','0.00',7,'0.00',0,'313','3498601970324','','',0,0,'0.00','0.00',0,'0.00','0.00',NULL,NULL,0,0,'0.00');
/*!40000 ALTER TABLE `ims_ewei_shop_goods_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_goods_param`
--

DROP TABLE IF EXISTS `ims_ewei_shop_goods_param`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_goods_param` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `goodsid` int(10) DEFAULT '0',
  `title` varchar(50) DEFAULT '',
  `value` text,
  `displayorder` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_goodsid` (`goodsid`),
  KEY `idx_displayorder` (`displayorder`)
) ENGINE=MyISAM AUTO_INCREMENT=1231 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_goods_param`
--

LOCK TABLES `ims_ewei_shop_goods_param` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_goods_param` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_goods_param` VALUES (1110,6,203,'','',0),(1111,6,205,'CPU品牌','Apple/苹果',0),(1112,6,205,'CPU型号','其他',1),(1113,6,205,'品牌','Apple/苹果',2),(1114,6,205,'Apple型号','iPhone 6s',3),(1115,6,205,'上市时间','2015年9月',4),(1116,6,205,'网络类型','无需合约版',5),(1117,6,205,'款式','直板',6),(1118,6,205,'机身颜色','银色,金色,玫瑰金色,深空灰色',7),(1119,6,205,'套餐类型','官方标配',8),(1120,6,205,'后置摄像头','1200万',9),(1121,6,205,'操作系统','IOS9',10),(1122,6,205,'附加功能','光线感应,电子罗盘,距离感应,重力感应,WIFI上网,GPS导航,GPRS上网,单卡单待',11),(1123,6,205,'售后服务','全国联保',12),(1124,6,205,'触摸屏类型','具备 3D Touch 技术的 Retina HD 显示屏',13),(1125,6,205,'运行内存RAM','2GB',14),(1126,6,205,'存储容量','32GB',15),(1127,6,205,'键盘类型','虚拟触屏键盘',16),(1128,6,205,'厚度','7.1毫米（0.28英寸）',17),(1129,6,205,'分辨率','1334 x 750 像素分辨率，326ppi',18),(1130,6,205,'手机类型','拍照手机,音乐手机,时尚手机,智能手机,4G手机',19),(1131,6,205,'电池类型','不可拆卸式电池',20),(1132,6,205,'摄像头类型','双摄像头（前后）',21),(1133,6,205,'视频显示格式','4k',22),(1134,6,205,'网络模式','无需合约版',23),(1135,6,205,'核心数','64 位架构的 A9 芯片 嵌入式 M9 运动协处理器',24),(1136,6,205,'电池容量','1715mAh',25),(1137,6,205,'机身厚度','7.1毫米（0.28英寸）',26),(1138,6,205,'版本类型','中国大陆',27),(1139,6,206,'上市时间','2015-03',0),(1140,6,206,'净重(不含底座)','17.0kg',1),(1141,6,206,'净重(含底座)','18.0kg',2),(1142,6,206,'包装尺寸','1320x150x830mm',3),(1143,6,206,'含边框整屏尺寸','1100x63x638mm',4),(1144,6,206,'品牌','TCL',5),(1145,6,206,'TCL LED型号','D49A620U',6),(1146,6,206,'堆码层数极限','3层',7),(1147,6,206,'屏幕尺寸','49英寸',8),(1148,6,206,'毛重','22.0kg',9),(1149,6,206,'电视形态','平板',10),(1150,6,206,'能效备案号','无',11),(1151,6,206,'视频显示格式','2160p',12),(1152,6,206,'分辨率','3840x2160',13),(1153,6,206,'HDMI接口数量','2个',14),(1154,6,206,'背光灯类型','LED发光二极管',15),(1155,6,206,'屏幕比例','16:9',16),(1156,6,206,'颜色分类','黑色',17),(1157,6,206,'套餐类型','官方标配',18),(1158,6,206,'3D类型','无',19),(1159,6,206,'能效等级','无',20),(1160,6,206,'售后服务','全国联保',21),(1161,6,206,'接口类型','AV,HDMI,RF射频接口,USB',22),(1162,6,206,'同城服务','同城卖家送货上门',23),(1163,6,206,'网络连接方式','全部支持',24),(1164,6,206,'操作系统','安卓',25),(1165,6,206,'扫描方式','逐行扫描',26),(1166,6,206,'接收制式','PAL,NTSC',27),(1167,6,206,'主机尺寸（不含底座）mm','1100×63×638',28),(1168,6,206,'电视类型','LED电视',29),(1169,6,206,'操作系统名称','Android',30),(1170,6,207,'CPU品牌','海思',0),(1171,6,207,'CPU型号','麒麟950',1),(1172,6,207,'产品名称','荣耀8 4GB+64GB 全网通版',2),(1173,6,207,'品牌','honor/荣耀',3),(1174,6,207,'型号','荣耀8 4GB+64GB 全网通版',4),(1175,6,207,'网络类型','不详',5),(1176,6,207,'款式','直板',6),(1177,6,207,'机身颜色','珠光白,流光金,魅海蓝,幻夜黑,樱语粉',7),(1178,6,207,'套餐类型','官方标配',8),(1179,6,207,'后置摄像头','双1200万',9),(1180,6,207,'操作系统','华为 EMUI 4.1 + Android 6.0',10),(1181,6,207,'附加功能','重力感应',11),(1182,6,207,'售后服务','全国联保',12),(1183,6,207,'触摸屏类型','多点触控触摸屏',13),(1184,6,207,'运行内存RAM','4GB',14),(1185,6,207,'存储容量','64GB',15),(1186,6,207,'键盘类型','不详',16),(1187,6,207,'分辨率','1920x1080',17),(1188,6,207,'手机类型','拍照手机,音乐手机,智能手机,商务手机',18),(1189,6,207,'电池类型','不可拆卸式电池',19),(1190,6,207,'摄像头类型','三摄像头（后双）',20),(1191,6,207,'视频显示格式','3gp，mp4，wmv，rm，rmvb，asf',21),(1192,6,207,'网络模式','不详',22),(1193,6,207,'核心数','4*2.3GHz + 4*1.8GHz + 微智核I5',23),(1194,6,207,'版本类型','中国大陆',24),(1195,6,208,'链子材质','合金/镀银/镀金',0),(1196,6,208,'销售渠道类型','商场同款(线上线下都销售)',1),(1197,6,208,'品牌','Swarovski/施华洛世奇',2),(1198,6,208,'颜色分类','5140839',3),(1199,6,208,'图案','星星/日月/云朵/宇宙',4),(1200,6,208,'风格','甜美',5),(1201,6,208,'是否现货','现货',6),(1202,6,208,'成色','全新',7),(1203,6,208,'货号','5140839',8),(1204,6,208,'价格区间','1001-3000元',9),(1205,6,209,'上市时间','2017年春夏',0),(1206,6,209,'是否商场同款','否',1),(1207,6,209,'材质','合金/镀银/镀金',2),(1208,6,209,'销售渠道类型','商场同款(线上线下都销售)',3),(1209,6,209,'颜色分类','镀玫瑰金色S,镀玫瑰金色M',4),(1210,6,209,'品牌','Swarovski/施华洛世奇',5),(1211,6,209,'价格区间','1001-3000元',6),(1212,6,209,'货号','5294947',7),(1213,6,210,'是否商场同款','是',0),(1214,6,210,'材质','合金/镀银/镀金',1),(1215,6,210,'销售渠道类型','商场同款(线上线下都销售)',2),(1216,6,210,'品牌','Swarovski/施华洛世奇',3),(1217,6,210,'价格区间','1001-3000元',4),(1218,6,210,'货号','5198981',5),(1219,6,211,'材质','合金/镀银/镀金',0),(1220,6,211,'品牌','Swarovski/施华洛世奇',1),(1221,6,211,'适用性别','女',2),(1222,6,211,'是否现货','现货',3),(1223,6,211,'价格区间','1001-3000元',4),(1224,6,211,'货号','5279415',5),(1225,6,212,'链子材质','合金/镀银/镀金',0),(1226,6,212,'品牌','Swarovski/施华洛世奇',1),(1227,6,212,'颜色分类','库存更新快，拍前咨询客服是否现货5198937',2),(1228,6,212,'成色','全新',3),(1229,6,212,'货号','5198937',4),(1230,6,212,'价格区间','1001-3000元',5);
/*!40000 ALTER TABLE `ims_ewei_shop_goods_param` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_goods_spec`
--

DROP TABLE IF EXISTS `ims_ewei_shop_goods_spec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_goods_spec` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `goodsid` int(11) DEFAULT '0',
  `title` varchar(50) DEFAULT '',
  `description` varchar(1000) DEFAULT '',
  `displaytype` tinyint(3) DEFAULT '0',
  `content` text,
  `displayorder` int(11) DEFAULT '0',
  `propId` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_goodsid` (`goodsid`),
  KEY `idx_displayorder` (`displayorder`)
) ENGINE=MyISAM AUTO_INCREMENT=107 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_goods_spec`
--

LOCK TABLES `ims_ewei_shop_goods_spec` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_goods_spec` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_goods_spec` VALUES (93,6,203,'大小','',0,'a:3:{i:0;s:3:\"291\";i:1;s:3:\"292\";i:2;s:3:\"293\";}',0,''),(94,6,205,'网络类型','',0,'a:1:{i:0;s:3:\"294\";}',0,'10004'),(95,6,205,'机身颜色','',0,'a:4:{i:0;s:3:\"295\";i:1;s:3:\"296\";i:2;s:3:\"297\";i:3;s:3:\"298\";}',1,'1627207'),(96,6,205,'套餐类型','',0,'a:1:{i:0;s:3:\"299\";}',2,'5919063'),(97,6,205,'存储容量','',0,'a:1:{i:0;s:3:\"300\";}',3,'12304035'),(98,6,206,'颜色分类','',0,NULL,0,'1627207'),(99,6,206,'套餐类型','',0,NULL,1,'5919063'),(100,6,207,'机身颜色','',0,NULL,0,'1627207'),(101,6,207,'套餐类型','',0,NULL,1,'5919063'),(102,6,207,'存储容量','',0,NULL,2,'12304035'),(103,6,207,'版本类型','',0,NULL,3,'122216431'),(104,6,208,'颜色分类','',0,NULL,0,'1627207'),(105,6,209,'颜色分类','',0,'a:2:{i:0;s:3:\"311\";i:1;s:3:\"312\";}',0,'1627207'),(106,6,212,'颜色分类','',0,NULL,0,'1627207');
/*!40000 ALTER TABLE `ims_ewei_shop_goods_spec` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_goods_spec_item`
--

DROP TABLE IF EXISTS `ims_ewei_shop_goods_spec_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_goods_spec_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `specid` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `show` int(11) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `valueId` varchar(255) DEFAULT '',
  `virtual` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_specid` (`specid`),
  KEY `idx_show` (`show`),
  KEY `idx_displayorder` (`displayorder`)
) ENGINE=MyISAM AUTO_INCREMENT=314 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_goods_spec_item`
--

LOCK TABLES `ims_ewei_shop_goods_spec_item` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_goods_spec_item` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_goods_spec_item` VALUES (291,6,93,'11寸','',1,0,'',0),(292,6,93,'12寸','',1,1,'',0),(293,6,93,'13寸','',1,2,'',0),(294,6,94,'无需合约版','',1,0,'709990523',0),(295,6,95,'银色','images/6/2017/09/t77Bzv0Lb9o5wHw5WkTKow559Z5Wh67k.jpg',1,0,'28330',0),(296,6,95,'金色','images/6/2017/09/dtArlLStQTrb8Por6sTP2rRpuLTRLlLu.jpg',1,1,'28328',0),(297,6,95,'玫瑰金色','images/6/2017/09/UZizylSlKU1hom5kpk1SIsuYi44YH2yh.jpg',1,2,'3470059',0),(298,6,95,'深空灰色','images/6/2017/09/fUhg5Hwg2923LgZHCw32SP9k2zKFWE2g.jpg',1,3,'382328443',0),(299,6,96,'官方标配','',1,0,'6536025',0),(300,6,97,'32GB','',1,0,'116177',0),(301,6,98,'黑色','',1,0,'28341',0),(302,6,99,'官方标配','',1,0,'6536025',0),(303,6,100,'珠光白','images/6/2017/09/Hj8Hf8MxGH2RjfJXRVJjh0o8Ggiq2PNj.jpg',1,0,'28320',0),(304,6,100,'流光金','images/6/2017/09/aTn7W09l41fm6T51Dylr9lWt400r5VY5.jpg',1,1,'28324',0),(305,6,100,'魅海蓝','images/6/2017/09/f60mxdDQ08E0Z0E8V8VLq39QX8D80DVz.jpg',1,2,'28338',0),(306,6,100,'幻夜黑','images/6/2017/09/Qp6ZB3pPs1ZpabBB11o9O6OCOBUl6fua.jpg',1,3,'28341',0),(307,6,101,'官方标配','',1,0,'6536025',0),(308,6,102,'64GB','',1,0,'3222911',0),(309,6,103,'中国大陆','',1,0,'27772',0),(310,6,104,'5140839','',1,0,'3232484',0),(311,6,105,'镀玫瑰金色S','images/6/2017/09/cm6Zq6YZ3jygdmszGQ3k3Z618NAJqO5N.jpg',1,0,'90554',0),(312,6,105,'镀玫瑰金色M','images/6/2017/09/MBMAb6UkJTDBMK0ffb7AdmUkWFwq7B7H.jpg',1,1,'60092',0),(313,6,106,'库存更新快，拍前咨询客服是否现货5198937','',1,0,'28327',0);
/*!40000 ALTER TABLE `ims_ewei_shop_goods_spec_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_goodscode_good`
--

DROP TABLE IF EXISTS `ims_ewei_shop_goodscode_good`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_goodscode_good` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `goodsid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `qrcode` varchar(255) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `displayorder` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_goodscode_good`
--

LOCK TABLES `ims_ewei_shop_goodscode_good` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_goodscode_good` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_goodscode_good` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_groups_adv`
--

DROP TABLE IF EXISTS `ims_ewei_shop_groups_adv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_groups_adv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `advname` varchar(50) DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `enabled` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_enabled` (`enabled`),
  KEY `idx_displayorder` (`displayorder`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_groups_adv`
--

LOCK TABLES `ims_ewei_shop_groups_adv` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_adv` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_adv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_groups_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_groups_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_groups_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `displayorder` tinyint(3) unsigned DEFAULT '0',
  `enabled` tinyint(1) DEFAULT '1',
  `advimg` varchar(255) DEFAULT '',
  `advurl` varchar(500) DEFAULT '',
  `isrecommand` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_displayorder` (`displayorder`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_groups_category`
--

LOCK TABLES `ims_ewei_shop_groups_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_groups_goods`
--

DROP TABLE IF EXISTS `ims_ewei_shop_groups_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_groups_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `displayorder` int(11) unsigned DEFAULT '0',
  `uniacid` int(11) DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `category` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stock` int(11) NOT NULL DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `groupsprice` decimal(10,2) DEFAULT '0.00',
  `singleprice` decimal(10,2) DEFAULT '0.00',
  `goodsnum` int(11) NOT NULL DEFAULT '1',
  `units` varchar(255) NOT NULL DEFAULT '件',
  `freight` decimal(10,2) DEFAULT '0.00',
  `endtime` int(11) unsigned NOT NULL DEFAULT '0',
  `groupnum` int(10) NOT NULL DEFAULT '0',
  `sales` int(10) NOT NULL DEFAULT '0',
  `thumb` varchar(255) DEFAULT '',
  `description` varchar(1000) DEFAULT NULL,
  `content` text,
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `ishot` tinyint(3) NOT NULL DEFAULT '0',
  `deleted` tinyint(3) NOT NULL DEFAULT '0',
  `goodsid` int(11) NOT NULL DEFAULT '0',
  `followneed` tinyint(2) NOT NULL DEFAULT '0',
  `followtext` varchar(255) DEFAULT NULL,
  `share_title` varchar(255) DEFAULT NULL,
  `share_icon` varchar(255) DEFAULT NULL,
  `share_desc` varchar(500) DEFAULT NULL,
  `goodssn` varchar(50) DEFAULT NULL,
  `productsn` varchar(50) DEFAULT NULL,
  `showstock` tinyint(2) NOT NULL,
  `purchaselimit` int(11) NOT NULL DEFAULT '0',
  `single` tinyint(2) NOT NULL DEFAULT '0',
  `dispatchtype` tinyint(2) NOT NULL,
  `dispatchid` int(11) NOT NULL,
  `isindex` tinyint(3) NOT NULL DEFAULT '0',
  `followurl` varchar(255) DEFAULT NULL,
  `deduct` decimal(10,2) NOT NULL DEFAULT '0.00',
  `rights` tinyint(2) NOT NULL DEFAULT '1',
  `thumb_url` text,
  `gid` int(11) DEFAULT '0',
  `discount` tinyint(3) DEFAULT '0',
  `headstype` tinyint(3) DEFAULT NULL,
  `headsmoney` decimal(10,2) DEFAULT '0.00',
  `headsdiscount` int(11) DEFAULT '0',
  `isdiscount` tinyint(3) DEFAULT '0',
  `isverify` tinyint(3) DEFAULT '0',
  `verifytype` tinyint(3) DEFAULT '0',
  `verifynum` int(11) DEFAULT '0',
  `storeids` text,
  `merchid` int(11) DEFAULT '0',
  `shorttitle` varchar(255) DEFAULT '',
  `teamnum` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_type` (`category`),
  KEY `idx_createtime` (`createtime`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_groups_goods`
--

LOCK TABLES `ims_ewei_shop_groups_goods` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_groups_goods_atlas`
--

DROP TABLE IF EXISTS `ims_ewei_shop_groups_goods_atlas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_groups_goods_atlas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `g_id` int(11) NOT NULL,
  `thumb` varchar(145) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_groups_goods_atlas`
--

LOCK TABLES `ims_ewei_shop_groups_goods_atlas` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_goods_atlas` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_goods_atlas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_groups_order`
--

DROP TABLE IF EXISTS `ims_ewei_shop_groups_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_groups_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `openid` varchar(45) NOT NULL,
  `orderno` varchar(45) NOT NULL,
  `groupnum` int(11) NOT NULL,
  `paytime` int(11) NOT NULL,
  `price` decimal(11,2) DEFAULT '0.00',
  `freight` decimal(11,2) DEFAULT '0.00',
  `status` int(9) NOT NULL,
  `pay_type` varchar(45) DEFAULT NULL,
  `goodid` int(11) NOT NULL,
  `teamid` int(11) NOT NULL,
  `is_team` int(2) NOT NULL,
  `heads` int(11) DEFAULT '0',
  `starttime` int(11) NOT NULL,
  `endtime` int(45) NOT NULL,
  `createtime` int(11) NOT NULL,
  `success` int(2) NOT NULL DEFAULT '0',
  `delete` int(2) NOT NULL DEFAULT '0',
  `credit` int(11) DEFAULT '0',
  `creditmoney` decimal(11,2) DEFAULT '0.00',
  `dispatchid` int(11) DEFAULT NULL,
  `addressid` int(11) NOT NULL DEFAULT '0',
  `address` varchar(1000) DEFAULT NULL,
  `discount` decimal(10,2) DEFAULT '0.00',
  `canceltime` int(11) NOT NULL DEFAULT '0',
  `finishtime` int(11) NOT NULL DEFAULT '0',
  `refundid` int(11) NOT NULL DEFAULT '0',
  `refundstate` tinyint(2) NOT NULL DEFAULT '0',
  `refundtime` int(11) NOT NULL DEFAULT '0',
  `express` varchar(45) DEFAULT NULL,
  `expresscom` varchar(100) DEFAULT NULL,
  `expresssn` varchar(45) DEFAULT NULL,
  `sendtime` int(45) DEFAULT '0',
  `remark` varchar(255) DEFAULT NULL,
  `remarkclose` text,
  `remarksend` text,
  `message` varchar(255) DEFAULT NULL,
  `deleted` int(2) NOT NULL DEFAULT '0',
  `realname` varchar(20) DEFAULT NULL,
  `mobile` varchar(11) DEFAULT NULL,
  `isverify` tinyint(3) DEFAULT '0',
  `verifytype` tinyint(3) DEFAULT '0',
  `verifycode` varchar(45) DEFAULT '0',
  `verifynum` int(11) DEFAULT '0',
  `printstate` int(11) NOT NULL DEFAULT '0',
  `printstate2` int(11) NOT NULL DEFAULT '0',
  `apppay` tinyint(3) NOT NULL DEFAULT '0',
  `isborrow` tinyint(1) DEFAULT '0',
  `borrowopenid` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_groups_order`
--

LOCK TABLES `ims_ewei_shop_groups_order` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_groups_order_refund`
--

DROP TABLE IF EXISTS `ims_ewei_shop_groups_order_refund`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_groups_order_refund` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `openid` varchar(45) NOT NULL DEFAULT '',
  `orderid` int(11) NOT NULL DEFAULT '0',
  `refundno` varchar(45) NOT NULL DEFAULT '0',
  `refundstatus` tinyint(3) NOT NULL DEFAULT '0',
  `refundaddressid` int(11) NOT NULL DEFAULT '0',
  `refundaddress` varchar(1000) NOT NULL DEFAULT '0',
  `content` varchar(255) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `images` varchar(255) DEFAULT NULL,
  `applytime` varchar(45) NOT NULL DEFAULT '0',
  `applycredit` int(11) NOT NULL DEFAULT '0',
  `applyprice` decimal(11,2) NOT NULL DEFAULT '0.00',
  `reply` text,
  `refundtype` varchar(45) DEFAULT NULL,
  `rtype` int(3) NOT NULL DEFAULT '0',
  `refundtime` varchar(45) NOT NULL,
  `endtime` varchar(45) NOT NULL DEFAULT '0',
  `message` varchar(255) DEFAULT NULL,
  `operatetime` varchar(45) NOT NULL DEFAULT '0',
  `realcredit` int(11) NOT NULL,
  `realmoney` decimal(11,2) NOT NULL,
  `express` varchar(45) DEFAULT NULL,
  `expresscom` varchar(100) DEFAULT NULL,
  `expresssn` varchar(45) DEFAULT NULL,
  `sendtime` varchar(45) NOT NULL DEFAULT '0',
  `returntime` int(11) NOT NULL DEFAULT '0',
  `rexpress` varchar(45) DEFAULT NULL,
  `rexpresscom` varchar(100) DEFAULT NULL,
  `rexpresssn` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_groups_order_refund`
--

LOCK TABLES `ims_ewei_shop_groups_order_refund` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_order_refund` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_order_refund` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_groups_paylog`
--

DROP TABLE IF EXISTS `ims_ewei_shop_groups_paylog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_groups_paylog` (
  `plid` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `openid` varchar(40) NOT NULL,
  `tid` varchar(64) NOT NULL,
  `credit` int(10) NOT NULL DEFAULT '0',
  `creditmoney` decimal(10,2) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `module` varchar(50) NOT NULL,
  `tag` varchar(2000) NOT NULL,
  `is_usecard` tinyint(3) unsigned NOT NULL,
  `card_type` tinyint(3) unsigned NOT NULL,
  `card_id` varchar(50) NOT NULL,
  `card_fee` decimal(10,2) unsigned NOT NULL,
  `encrypt_code` varchar(100) NOT NULL,
  `uniontid` varchar(50) NOT NULL,
  PRIMARY KEY (`plid`),
  KEY `idx_openid` (`openid`),
  KEY `idx_tid` (`tid`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `uniontid` (`uniontid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_groups_paylog`
--

LOCK TABLES `ims_ewei_shop_groups_paylog` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_paylog` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_paylog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_groups_set`
--

DROP TABLE IF EXISTS `ims_ewei_shop_groups_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_groups_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` varchar(45) DEFAULT NULL,
  `groups` int(2) NOT NULL DEFAULT '0',
  `followurl` varchar(255) DEFAULT NULL,
  `groupsurl` varchar(255) DEFAULT NULL,
  `share_title` varchar(255) DEFAULT NULL,
  `share_icon` varchar(255) DEFAULT NULL,
  `share_desc` varchar(255) DEFAULT NULL,
  `groups_description` text,
  `description` int(2) NOT NULL DEFAULT '0',
  `followqrcode` varchar(255) DEFAULT NULL,
  `share_url` varchar(255) DEFAULT NULL,
  `creditdeduct` tinyint(2) NOT NULL DEFAULT '0',
  `groupsdeduct` tinyint(2) NOT NULL DEFAULT '0',
  `credit` int(11) NOT NULL DEFAULT '1',
  `groupsmoney` decimal(11,2) NOT NULL DEFAULT '0.00',
  `refund` int(11) NOT NULL DEFAULT '0',
  `refundday` int(11) NOT NULL DEFAULT '0',
  `goodsid` text NOT NULL,
  `rules` text,
  `receive` int(11) DEFAULT '0',
  `discount` tinyint(3) DEFAULT '0',
  `headstype` tinyint(3) DEFAULT '0',
  `headsmoney` decimal(10,2) DEFAULT '0.00',
  `headsdiscount` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_groups_set`
--

LOCK TABLES `ims_ewei_shop_groups_set` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_groups_verify`
--

DROP TABLE IF EXISTS `ims_ewei_shop_groups_verify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_groups_verify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(45) DEFAULT '0',
  `orderid` int(11) DEFAULT '0',
  `verifycode` varchar(45) DEFAULT '',
  `storeid` int(11) DEFAULT '0',
  `verifier` varchar(45) DEFAULT '0',
  `isverify` tinyint(3) DEFAULT '0',
  `verifytime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_groups_verify`
--

LOCK TABLES `ims_ewei_shop_groups_verify` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_verify` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_groups_verify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_live`
--

DROP TABLE IF EXISTS `ims_ewei_shop_live`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_live` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `merchid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `livetype` tinyint(3) NOT NULL DEFAULT '0',
  `liveidentity` varchar(50) NOT NULL,
  `screen` tinyint(3) NOT NULL DEFAULT '0',
  `goodsid` varchar(255) NOT NULL,
  `category` int(11) NOT NULL DEFAULT '0',
  `url` varchar(1000) NOT NULL,
  `thumb` varchar(1000) NOT NULL,
  `hot` tinyint(3) NOT NULL DEFAULT '0',
  `recommend` tinyint(3) NOT NULL DEFAULT '0',
  `living` tinyint(3) NOT NULL DEFAULT '0',
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `displayorder` int(11) NOT NULL DEFAULT '0',
  `livetime` int(10) NOT NULL DEFAULT '0',
  `lastlivetime` int(11) NOT NULL DEFAULT '0',
  `createtime` int(10) NOT NULL DEFAULT '0',
  `introduce` text NOT NULL,
  `packetmoney` decimal(10,2) NOT NULL DEFAULT '0.00',
  `packettotal` int(11) NOT NULL DEFAULT '0',
  `packetprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `packetdes` varchar(255) NOT NULL,
  `couponid` varchar(255) NOT NULL,
  `share_title` varchar(255) NOT NULL,
  `share_icon` varchar(1000) NOT NULL,
  `share_desc` text NOT NULL,
  `share_url` varchar(1000) NOT NULL DEFAULT '',
  `subscribe` int(11) NOT NULL DEFAULT '0',
  `subscribenotice` tinyint(3) NOT NULL DEFAULT '0',
  `visit` int(11) NOT NULL DEFAULT '0',
  `video` varchar(1000) NOT NULL DEFAULT '',
  `covertype` tinyint(3) NOT NULL DEFAULT '0',
  `cover` varchar(1000) NOT NULL DEFAULT '',
  `iscoupon` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_merchid` (`merchid`) USING BTREE,
  KEY `idx_category` (`category`) USING BTREE,
  KEY `idx_hot` (`hot`) USING BTREE,
  KEY `idx_recommend` (`recommend`) USING BTREE,
  KEY `idx_living` (`living`) USING BTREE,
  KEY `idx_status` (`status`) USING BTREE,
  KEY `idx_livetime` (`livetime`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_live`
--

LOCK TABLES `ims_ewei_shop_live` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_live` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_live` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_live_adv`
--

DROP TABLE IF EXISTS `ims_ewei_shop_live_adv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_live_adv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `merchid` int(11) NOT NULL DEFAULT '0',
  `advname` varchar(50) DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `enabled` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_enabled` (`enabled`) USING BTREE,
  KEY `idx_displayorder` (`displayorder`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_live_adv`
--

LOCK TABLES `ims_ewei_shop_live_adv` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_live_adv` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_live_adv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_live_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_live_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_live_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `displayorder` tinyint(3) unsigned DEFAULT '0',
  `enabled` tinyint(1) DEFAULT '1',
  `advimg` varchar(255) DEFAULT '',
  `advurl` varchar(500) DEFAULT '',
  `isrecommand` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_displayorder` (`displayorder`) USING BTREE,
  KEY `idx_enabled` (`enabled`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_live_category`
--

LOCK TABLES `ims_ewei_shop_live_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_live_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_live_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_live_coupon`
--

DROP TABLE IF EXISTS `ims_ewei_shop_live_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_live_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `roomid` int(11) NOT NULL DEFAULT '0',
  `couponid` int(11) NOT NULL DEFAULT '0',
  `coupontotal` int(11) NOT NULL DEFAULT '0',
  `couponlimit` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_roomid` (`roomid`) USING BTREE,
  KEY `idx_couponid` (`couponid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_live_coupon`
--

LOCK TABLES `ims_ewei_shop_live_coupon` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_live_coupon` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_live_coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_live_favorite`
--

DROP TABLE IF EXISTS `ims_ewei_shop_live_favorite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_live_favorite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `roomid` int(11) NOT NULL DEFAULT '0',
  `openid` tinytext NOT NULL,
  `deleted` tinyint(3) NOT NULL DEFAULT '0',
  `createtime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_roomid` (`roomid`) USING BTREE,
  KEY `idx_deleted` (`deleted`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_live_favorite`
--

LOCK TABLES `ims_ewei_shop_live_favorite` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_live_favorite` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_live_favorite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_live_setting`
--

DROP TABLE IF EXISTS `ims_ewei_shop_live_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_live_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `ismember` tinyint(3) NOT NULL DEFAULT '0',
  `share_title` varchar(255) NOT NULL,
  `share_icon` varchar(1000) NOT NULL,
  `share_desc` varchar(255) NOT NULL,
  `share_url` varchar(255) NOT NULL,
  `livenoticetime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_ismember` (`ismember`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_live_setting`
--

LOCK TABLES `ims_ewei_shop_live_setting` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_live_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_live_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_live_view`
--

DROP TABLE IF EXISTS `ims_ewei_shop_live_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_live_view` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `openid` varchar(50) NOT NULL,
  `roomid` int(11) NOT NULL DEFAULT '0',
  `viewing` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_roomid` (`roomid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_live_view`
--

LOCK TABLES `ims_ewei_shop_live_view` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_live_view` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_live_view` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_lottery`
--

DROP TABLE IF EXISTS `ims_ewei_shop_lottery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_lottery` (
  `lottery_id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `lottery_title` varchar(150) DEFAULT NULL,
  `lottery_icon` varchar(255) DEFAULT NULL,
  `lottery_banner` varchar(255) DEFAULT NULL,
  `lottery_cannot` varchar(255) DEFAULT NULL,
  `lottery_type` tinyint(1) DEFAULT NULL,
  `is_delete` tinyint(1) DEFAULT '0',
  `addtime` int(11) DEFAULT NULL,
  `lottery_data` text,
  `is_goods` tinyint(1) DEFAULT '0',
  `lottery_days` int(11) DEFAULT '0',
  `task_type` tinyint(1) DEFAULT '0',
  `task_data` text,
  `start_time` int(11) DEFAULT NULL,
  `end_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`lottery_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_lottery`
--

LOCK TABLES `ims_ewei_shop_lottery` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_lottery` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_lottery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_lottery_default`
--

DROP TABLE IF EXISTS `ims_ewei_shop_lottery_default`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_lottery_default` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `data` text,
  `addtime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_lottery_default`
--

LOCK TABLES `ims_ewei_shop_lottery_default` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_lottery_default` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_lottery_default` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_lottery_join`
--

DROP TABLE IF EXISTS `ims_ewei_shop_lottery_join`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_lottery_join` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `join_user` varchar(255) DEFAULT NULL,
  `lottery_id` int(11) DEFAULT NULL,
  `lottery_num` int(10) DEFAULT '0',
  `lottery_tag` varchar(255) DEFAULT NULL,
  `addtime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_lottery_join`
--

LOCK TABLES `ims_ewei_shop_lottery_join` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_lottery_join` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_lottery_join` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_lottery_log`
--

DROP TABLE IF EXISTS `ims_ewei_shop_lottery_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_lottery_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT NULL,
  `lottery_id` int(11) DEFAULT '0',
  `join_user` varchar(255) DEFAULT NULL,
  `lottery_data` text,
  `is_reward` tinyint(1) DEFAULT '0',
  `addtime` int(11) DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_lottery_log`
--

LOCK TABLES `ims_ewei_shop_lottery_log` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_lottery_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_lottery_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_mc_merchant`
--

DROP TABLE IF EXISTS `ims_ewei_shop_mc_merchant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_mc_merchant` (
  `id` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `merchant_no` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `salt` varchar(8) NOT NULL DEFAULT '',
  `contact_name` varchar(255) NOT NULL DEFAULT '',
  `contact_mobile` varchar(16) NOT NULL DEFAULT '',
  `contact_address` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `createtime` int(11) NOT NULL,
  `validitytime` int(11) NOT NULL,
  `industry` varchar(255) NOT NULL DEFAULT '',
  `remark` varchar(1000) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_mc_merchant`
--

LOCK TABLES `ims_ewei_shop_mc_merchant` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_mc_merchant` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_mc_merchant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_member`
--

DROP TABLE IF EXISTS `ims_ewei_shop_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `uid` int(11) DEFAULT '0',
  `groupid` int(11) DEFAULT '0',
  `level` int(11) DEFAULT '0',
  `agentid` int(11) DEFAULT '0',
  `openid` varchar(50) DEFAULT '',
  `realname` varchar(20) DEFAULT '',
  `mobile` varchar(11) DEFAULT '',
  `pwd` varchar(32) DEFAULT '',
  `weixin` varchar(100) DEFAULT '',
  `content` text,
  `createtime` int(10) DEFAULT '0',
  `agenttime` int(10) DEFAULT '0',
  `status` tinyint(1) DEFAULT '0',
  `isagent` tinyint(1) DEFAULT '0',
  `clickcount` int(11) DEFAULT '0',
  `agentlevel` int(11) DEFAULT '0',
  `noticeset` text,
  `nickname` varchar(255) DEFAULT '',
  `credit1` decimal(10,2) DEFAULT '0.00',
  `credit2` decimal(10,2) DEFAULT '0.00',
  `birthyear` varchar(255) DEFAULT '',
  `birthmonth` varchar(255) DEFAULT '',
  `birthday` varchar(255) DEFAULT '',
  `gender` tinyint(3) DEFAULT '0',
  `avatar` varchar(255) DEFAULT '',
  `province` varchar(255) DEFAULT '',
  `city` varchar(255) DEFAULT '',
  `area` varchar(255) DEFAULT '',
  `childtime` int(11) DEFAULT '0',
  `inviter` int(11) DEFAULT '0',
  `agentnotupgrade` int(11) DEFAULT '0',
  `agentselectgoods` tinyint(3) DEFAULT '0',
  `agentblack` int(11) DEFAULT '0',
  `fixagentid` tinyint(3) DEFAULT '0',
  `diymemberid` int(11) DEFAULT '0',
  `diymemberfields` text,
  `diymemberdata` text,
  `diymemberdataid` int(11) DEFAULT '0',
  `diycommissionid` int(11) DEFAULT '0',
  `diycommissionfields` text,
  `diycommissiondata` text,
  `diycommissiondataid` int(11) DEFAULT '0',
  `isblack` int(11) DEFAULT '0',
  `username` varchar(255) DEFAULT '',
  `commission_total` decimal(10,2) DEFAULT '0.00',
  `endtime2` int(11) DEFAULT '0',
  `ispartner` tinyint(3) DEFAULT '0',
  `partnertime` int(11) DEFAULT '0',
  `partnerstatus` tinyint(3) DEFAULT '0',
  `partnerblack` tinyint(3) DEFAULT '0',
  `partnerlevel` int(11) DEFAULT '0',
  `partnernotupgrade` tinyint(3) DEFAULT '0',
  `diyglobonusid` int(11) DEFAULT '0',
  `diyglobonusdata` text,
  `diyglobonusfields` text,
  `isaagent` tinyint(3) DEFAULT '0',
  `aagentlevel` int(11) DEFAULT '0',
  `aagenttime` int(11) DEFAULT '0',
  `aagentstatus` tinyint(3) DEFAULT '0',
  `aagentblack` tinyint(3) DEFAULT '0',
  `aagentnotupgrade` tinyint(3) DEFAULT '0',
  `aagenttype` tinyint(3) DEFAULT '0',
  `aagentprovinces` text,
  `aagentcitys` text,
  `aagentareas` text,
  `diyaagentid` int(11) DEFAULT '0',
  `diyaagentdata` text,
  `diyaagentfields` text,
  `salt` varchar(32) DEFAULT NULL,
  `mobileverify` tinyint(3) DEFAULT '0',
  `mobileuser` tinyint(3) DEFAULT '0',
  `carrier_mobile` varchar(11) DEFAULT '0',
  `isauthor` tinyint(1) DEFAULT '0',
  `authortime` int(11) DEFAULT '0',
  `authorstatus` tinyint(1) DEFAULT '0',
  `authorblack` tinyint(1) DEFAULT '0',
  `authorlevel` int(11) DEFAULT '0',
  `authornotupgrade` tinyint(1) DEFAULT '0',
  `diyauthorid` int(11) DEFAULT '0',
  `diyauthordata` text,
  `diyauthorfields` text,
  `authorid` int(11) DEFAULT '0',
  `comefrom` varchar(20) DEFAULT NULL,
  `openid_qq` varchar(50) DEFAULT NULL,
  `openid_wx` varchar(50) DEFAULT NULL,
  `diymaxcredit` tinyint(3) DEFAULT '0',
  `maxcredit` int(11) DEFAULT '0',
  `datavalue` varchar(50) NOT NULL DEFAULT '',
  `openid_wa` varchar(50) DEFAULT NULL,
  `nickname_wechat` varchar(255) DEFAULT '',
  `avatar_wechat` varchar(255) DEFAULT '',
  `updateaddress` tinyint(1) NOT NULL DEFAULT '0',
  `membercardid` varchar(255) DEFAULT '',
  `membercardcode` varchar(255) DEFAULT '',
  `membershipnumber` varchar(255) DEFAULT '',
  `membercardactive` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_shareid` (`agentid`),
  KEY `idx_openid` (`openid`),
  KEY `idx_status` (`status`),
  KEY `idx_agenttime` (`agenttime`),
  KEY `idx_isagent` (`isagent`),
  KEY `idx_uid` (`uid`),
  KEY `idx_groupid` (`groupid`),
  KEY `idx_level` (`level`)
) ENGINE=MyISAM AUTO_INCREMENT=2195 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_member`
--

LOCK TABLES `ims_ewei_shop_member` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_member` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_member` VALUES (2188,6,1,0,5,0,'oZo4hw8Wt565YLamn2TJqGExQirA','','','','',NULL,1504154160,0,0,0,0,0,NULL,'街墙','0.00','0.00','','','',1,'http://wx.qlogo.cn/mmopen/HImTr9Y5bJXOQ4MepvkH30XGia86KLWCuMh7tIeoP1EFeCUFlHAnFndPeLkg9gNkTAP5pLcvRam0TTxgobrsQJwlTDnLcCDwM/132','福建','厦门','',0,0,0,0,0,0,0,NULL,NULL,0,0,NULL,NULL,0,0,'','0.00',0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,0,'0',0,0,0,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,'',NULL,'街墙','http://wx.qlogo.cn/mmopen/HImTr9Y5bJXOQ4MepvkH30XGia86KLWCuMh7tIeoP1EFeCUFlHAnFndPeLkg9gNkTAP5pLcvRam0TTxgobrsQJwlTDnLcCDwM/132',1,'','','',0),(2189,6,2,0,0,0,'oZo4hw-Dv3uxhgBm549mY7-ikdyc','','','','',NULL,1504154223,0,0,0,0,0,NULL,'揭果','0.00','0.00','','','',1,'http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLuolb3awl5oJ9aMsUqRysYttMHJNia7eT28Hoxib2ibt6mjibkicrI4wzdfuelDFib2S0JVHTibJB0LtYFw/132','北京','海淀','',0,0,0,0,0,0,0,NULL,NULL,0,0,NULL,NULL,0,0,'','0.00',0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,0,'0',0,0,0,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,'',NULL,'揭果','http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLuolb3awl5oJ9aMsUqRysYttMHJNia7eT28Hoxib2ibt6mjibkicrI4wzdfuelDFib2S0JVHTibJB0LtYFw/132',1,'','','',0),(2190,6,3,0,0,0,'oZo4hw7Rho-Val4FIVX5oKc2OTUI','','','','',NULL,1504164622,0,0,0,0,0,NULL,'冯颖','0.00','0.00','','','',2,'http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTL2Y9PUbicZcT9I8B9vDsNZGxsHCOticXbYJhdGuvZ7TPVOewFzbafn9PRia15IA2qkdq30LqJtqGjOQ/132','北京','','',0,0,0,0,0,0,0,NULL,NULL,0,0,NULL,NULL,0,0,'','0.00',0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,0,'0',0,0,0,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,'',NULL,'冯颖','http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTL2Y9PUbicZcT9I8B9vDsNZGxsHCOticXbYJhdGuvZ7TPVOewFzbafn9PRia15IA2qkdq30LqJtqGjOQ/132',0,'','','',0),(2191,6,0,0,0,0,'ooyv91cPbLRIz1qaX7Fim_cRfjZk','','','','',NULL,1504180041,0,0,0,0,0,NULL,'','0.00','0.00','','','',-1,'','','','',0,0,0,0,0,0,0,NULL,NULL,0,0,NULL,NULL,0,0,'','0.00',0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,0,'0',0,0,0,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,'',NULL,'','',1,'','','',0),(2192,6,0,0,0,0,'oZo4hw84Jkl14EOT-D0UP7IWrrFY','','','','',NULL,1504324997,0,0,0,0,0,NULL,'LinLi','0.00','0.00','','','',2,'http://wx.qlogo.cn/mmopen/rGsuGRgLAPiadvqox55mlTPXtOBibtR8xyDxNzpguXNzd75NfR98eLAiabvfR3DYAOnEEtT2h3XNU3s5TpEjqYMeO3NiakiboAVHia/132','福建','厦门','',0,0,0,0,0,0,0,NULL,NULL,0,0,NULL,NULL,0,0,'','0.00',0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,0,'0',0,0,0,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,'',NULL,'LinLi','http://wx.qlogo.cn/mmopen/rGsuGRgLAPiadvqox55mlTPXtOBibtR8xyDxNzpguXNzd75NfR98eLAiabvfR3DYAOnEEtT2h3XNU3s5TpEjqYMeO3NiakiboAVHia/132',1,'','','',0),(2193,6,4,0,0,0,'oZo4hw8_uBuJA4We7GGNc8oeU_RQ','','','','',NULL,1504520105,0,0,0,0,0,NULL,'中治律所闵瀚霖','0.00','0.00','','','',1,'http://wx.qlogo.cn/mmopen/vi_32/DYAIOgq83eoC9bePPELuxhogB4cSh2575m3EGe8O5Uh2Nicu2mo5pMzIFMLEIgMTLose3KicYv2g1TXAEicrltuuw/132','北京','','',0,0,0,0,0,0,0,NULL,NULL,0,0,NULL,NULL,0,0,'','0.00',0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,0,'0',0,0,0,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,'',NULL,'中治律所闵瀚霖','http://wx.qlogo.cn/mmopen/vi_32/DYAIOgq83eoC9bePPELuxhogB4cSh2575m3EGe8O5Uh2Nicu2mo5pMzIFMLEIgMTLose3KicYv2g1TXAEicrltuuw/132',0,'','','',0),(2194,6,5,0,0,0,'oZo4hw2mx_hd2cIa4_doocGay7-w','','','','',NULL,1504522107,0,0,0,0,0,NULL,'郝叶','0.00','0.00','','','',2,'http://wx.qlogo.cn/mmopen/vi_32/PiajxSqBRaEJ236KCicoePibtMh3bhoxVsbWyTKhquFDxyf4uaVBlg4OofGYBNDCtBX4icCadSyxcxSq9rNUunrvicQ/132','','','',0,0,0,0,0,0,0,NULL,NULL,0,0,NULL,NULL,0,0,'','0.00',0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,0,'0',0,0,0,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,'',NULL,'郝叶','http://wx.qlogo.cn/mmopen/vi_32/PiajxSqBRaEJ236KCicoePibtMh3bhoxVsbWyTKhquFDxyf4uaVBlg4OofGYBNDCtBX4icCadSyxcxSq9rNUunrvicQ/132',0,'','','',0);
/*!40000 ALTER TABLE `ims_ewei_shop_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_member_address`
--

DROP TABLE IF EXISTS `ims_ewei_shop_member_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_member_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(50) DEFAULT '0',
  `realname` varchar(20) DEFAULT '',
  `mobile` varchar(11) DEFAULT '',
  `province` varchar(30) DEFAULT '',
  `city` varchar(30) DEFAULT '',
  `area` varchar(30) DEFAULT '',
  `address` varchar(300) DEFAULT '',
  `isdefault` tinyint(1) DEFAULT '0',
  `zipcode` varchar(255) DEFAULT '',
  `deleted` tinyint(1) DEFAULT '0',
  `street` varchar(50) NOT NULL DEFAULT '',
  `datavalue` varchar(50) NOT NULL DEFAULT '',
  `streetdatavalue` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_openid` (`openid`),
  KEY `idx_isdefault` (`isdefault`),
  KEY `idx_deleted` (`deleted`)
) ENGINE=MyISAM AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_member_address`
--

LOCK TABLES `ims_ewei_shop_member_address` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_member_address` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_member_address` VALUES (83,6,'oZo4hw8Wt565YLamn2TJqGExQirA','揭','18966666666','北京市','北京辖区','东城区','666666',1,'',0,'','',''),(84,6,'ooyv91cPbLRIz1qaX7Fim_cRfjZk','111','18888888888','北京市','北京辖区','朝阳区','11111111',1,'',0,'','',''),(85,6,'oZo4hw84Jkl14EOT-D0UP7IWrrFY','小曦','18046053861','福建省','厦门市','集美区','诚毅学院',1,'',0,'','',''),(86,6,'oZo4hw-Dv3uxhgBm549mY7-ikdyc','哈哈哈','18911705605','北京市','北京辖区','东城区','人都丰富',1,'',0,'','',''),(87,6,'oZo4hw8Wt565YLamn2TJqGExQirA','揭衍强','18959269002','福建省','厦门市','思明区','环岛南路软件园二期望海路10号二栋3层 厦门一品威客网络科技有限公司',0,'',0,'','','');
/*!40000 ALTER TABLE `ims_ewei_shop_member_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_member_cart`
--

DROP TABLE IF EXISTS `ims_ewei_shop_member_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_member_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(100) DEFAULT '',
  `goodsid` int(11) DEFAULT '0',
  `total` int(11) DEFAULT '0',
  `marketprice` decimal(10,2) DEFAULT '0.00',
  `deleted` tinyint(1) DEFAULT '0',
  `optionid` int(11) DEFAULT '0',
  `createtime` int(11) DEFAULT '0',
  `diyformdataid` int(11) DEFAULT '0',
  `diyformdata` text,
  `diyformfields` text,
  `diyformid` int(11) DEFAULT '0',
  `selected` tinyint(1) DEFAULT '1',
  `selectedadd` tinyint(1) DEFAULT '1',
  `merchid` int(11) DEFAULT '0',
  `isnewstore` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_goodsid` (`goodsid`),
  KEY `idx_openid` (`openid`),
  KEY `idx_deleted` (`deleted`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_member_cart`
--

LOCK TABLES `ims_ewei_shop_member_cart` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_member_cart` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_member_cart` VALUES (63,6,'oZo4hw-Dv3uxhgBm549mY7-ikdyc',199,2,'3599.00',1,0,1504172622,0,'false','a:0:{}',0,1,1,0,0),(64,6,'oZo4hw8Wt565YLamn2TJqGExQirA',199,1,'3599.00',1,0,1504269125,0,'false','a:0:{}',0,1,1,0,0),(65,6,'oZo4hw8Wt565YLamn2TJqGExQirA',203,2,'128.00',0,406,1504424705,0,'false','a:0:{}',0,1,1,0,0);
/*!40000 ALTER TABLE `ims_ewei_shop_member_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_member_favorite`
--

DROP TABLE IF EXISTS `ims_ewei_shop_member_favorite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_member_favorite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `goodsid` int(10) DEFAULT '0',
  `openid` varchar(50) DEFAULT '',
  `deleted` tinyint(1) DEFAULT '0',
  `createtime` int(11) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_goodsid` (`goodsid`),
  KEY `idx_openid` (`openid`),
  KEY `idx_deleted` (`deleted`),
  KEY `idx_createtime` (`createtime`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_member_favorite`
--

LOCK TABLES `ims_ewei_shop_member_favorite` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_member_favorite` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_member_favorite` VALUES (26,6,200,'oZo4hw8Wt565YLamn2TJqGExQirA',0,1504324387,0,0),(27,6,199,'oZo4hw8Wt565YLamn2TJqGExQirA',0,1504340419,0,0);
/*!40000 ALTER TABLE `ims_ewei_shop_member_favorite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_member_group`
--

DROP TABLE IF EXISTS `ims_ewei_shop_member_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_member_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `groupname` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_member_group`
--

LOCK TABLES `ims_ewei_shop_member_group` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_member_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_member_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_member_history`
--

DROP TABLE IF EXISTS `ims_ewei_shop_member_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_member_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `goodsid` int(10) DEFAULT '0',
  `openid` varchar(50) DEFAULT '',
  `deleted` tinyint(1) DEFAULT '0',
  `createtime` int(11) DEFAULT '0',
  `times` int(11) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_goodsid` (`goodsid`),
  KEY `idx_openid` (`openid`),
  KEY `idx_deleted` (`deleted`),
  KEY `idx_createtime` (`createtime`)
) ENGINE=MyISAM AUTO_INCREMENT=2275 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_member_history`
--

LOCK TABLES `ims_ewei_shop_member_history` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_member_history` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_member_history` VALUES (2234,6,199,'oZo4hw8Wt565YLamn2TJqGExQirA',0,1504154469,13,0),(2235,6,199,'oZo4hw-Dv3uxhgBm549mY7-ikdyc',0,1504172607,2,0),(2236,6,199,'ooyv91cPbLRIz1qaX7Fim_cRfjZk',0,1504241902,9,0),(2237,6,200,'oZo4hw8Wt565YLamn2TJqGExQirA',0,1504324130,20,0),(2238,6,202,'oZo4hw8Wt565YLamn2TJqGExQirA',0,1504324687,6,0),(2239,6,200,'',0,1504332054,1,0),(2240,6,199,'',0,1504332316,1,0),(2241,6,200,'',0,1504332416,1,0),(2242,6,200,'',0,1504334391,1,0),(2243,6,200,'ooyv91cPbLRIz1qaX7Fim_cRfjZk',0,1504334781,2,0),(2244,6,200,'',0,1504336025,1,0),(2245,6,200,'',0,1504336066,1,0),(2246,6,200,'oZo4hw84Jkl14EOT-D0UP7IWrrFY',0,1504336604,4,0),(2247,6,201,'oZo4hw-Dv3uxhgBm549mY7-ikdyc',0,1504395887,2,0),(2248,6,200,'',0,1504400936,1,0),(2249,6,200,'',0,1504401527,1,0),(2250,6,203,'oZo4hw8Wt565YLamn2TJqGExQirA',0,1504424568,5,0),(2251,6,203,'',0,1504426772,1,0),(2252,6,203,'',0,1504426783,1,0),(2253,6,203,'',0,1504426821,1,0),(2254,6,203,'',0,1504426837,1,0),(2255,6,204,'',0,1504426904,1,0),(2256,6,204,'oZo4hw-Dv3uxhgBm549mY7-ikdyc',0,1504427815,1,0),(2257,6,204,'oZo4hw-Dv3uxhgBm549mY7-ikdyc',0,1504427815,1,0),(2258,6,204,'',0,1504427923,1,0),(2259,6,204,'',0,1504427923,1,0),(2260,6,204,'',0,1504427932,1,0),(2261,6,204,'',0,1504427936,1,0),(2262,6,204,'oZo4hw8Wt565YLamn2TJqGExQirA',0,1504427947,3,0),(2263,6,200,'oZo4hw-Dv3uxhgBm549mY7-ikdyc',0,1504428359,2,0),(2264,6,200,'',0,1504428411,1,0),(2265,6,200,'',0,1504428411,1,0),(2266,6,200,'',0,1504428415,1,0),(2267,6,200,'',0,1504428945,1,0),(2268,6,204,'',0,1504432323,1,0),(2269,6,199,'',0,1504434100,1,0),(2270,6,200,'',0,1504434390,1,0),(2271,6,204,'',0,1504434406,1,0),(2272,6,201,'oZo4hw8Wt565YLamn2TJqGExQirA',0,1504500319,1,0),(2273,6,202,'oZo4hw2mx_hd2cIa4_doocGay7-w',0,1504565845,1,0),(2274,6,206,'oZo4hw8Wt565YLamn2TJqGExQirA',0,1504616810,1,0);
/*!40000 ALTER TABLE `ims_ewei_shop_member_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_member_level`
--

DROP TABLE IF EXISTS `ims_ewei_shop_member_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_member_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `level` int(11) DEFAULT '0',
  `levelname` varchar(50) DEFAULT '',
  `ordermoney` decimal(10,2) DEFAULT '0.00',
  `ordercount` int(10) DEFAULT '0',
  `discount` decimal(10,2) DEFAULT '0.00',
  `enabled` tinyint(3) DEFAULT '0',
  `enabledadd` tinyint(1) DEFAULT '0',
  `buygoods` tinyint(1) NOT NULL DEFAULT '0',
  `goodsids` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_member_level`
--

LOCK TABLES `ims_ewei_shop_member_level` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_member_level` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_member_level` VALUES (5,6,100,'黄金','10000.00',0,'8.80',1,0,0,'N;'),(6,6,50,'白银','8000.00',0,'9.00',1,0,0,'N;'),(7,6,25,'青铜','5000.00',0,'9.50',1,0,0,'N;');
/*!40000 ALTER TABLE `ims_ewei_shop_member_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_member_log`
--

DROP TABLE IF EXISTS `ims_ewei_shop_member_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_member_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `type` tinyint(3) DEFAULT NULL,
  `logno` varchar(255) DEFAULT '',
  `title` varchar(255) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `money` decimal(10,2) DEFAULT '0.00',
  `rechargetype` varchar(255) DEFAULT '',
  `gives` decimal(10,2) DEFAULT NULL,
  `couponid` int(11) DEFAULT '0',
  `transid` varchar(255) DEFAULT '',
  `realmoney` decimal(10,2) DEFAULT '0.00',
  `charge` decimal(10,2) DEFAULT '0.00',
  `deductionmoney` decimal(10,2) DEFAULT '0.00',
  `isborrow` tinyint(3) DEFAULT '0',
  `borrowopenid` varchar(100) DEFAULT '',
  `remark` varchar(255) NOT NULL DEFAULT '',
  `apppay` tinyint(3) NOT NULL DEFAULT '0',
  `alipay` varchar(50) NOT NULL DEFAULT '',
  `bankname` varchar(50) NOT NULL DEFAULT '',
  `bankcard` varchar(50) NOT NULL DEFAULT '',
  `realname` varchar(50) NOT NULL DEFAULT '',
  `applytype` tinyint(3) NOT NULL DEFAULT '0',
  `sendmoney` decimal(10,2) DEFAULT '0.00',
  `senddata` text,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_openid` (`openid`),
  KEY `idx_type` (`type`),
  KEY `idx_createtime` (`createtime`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=111 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_member_log`
--

LOCK TABLES `ims_ewei_shop_member_log` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_member_log` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_member_log` VALUES (107,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'RC20170902162040228239','adjyc会员充值',1504340440,0,'6.00','',NULL,0,'','0.00','0.00','0.00',0,'','',0,'','','','',0,'0.00',NULL),(108,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'RC20170903093523273464','adjyc会员充值',1504402523,1,'99999999.00','system',NULL,0,'','0.00','0.00','0.00',0,'','测试后台充值99999999',0,'','','','',0,'0.00',NULL),(109,6,'oZo4hw7Rho-Val4FIVX5oKc2OTUI',0,'RC20170903160123027758','adjyc会员充值',1504425682,1,'9999999.00','system',NULL,0,'','0.00','0.00','0.00',0,'','测试充值',0,'','','','',0,'0.00',NULL),(110,6,'oZo4hw-Dv3uxhgBm549mY7-ikdyc',0,'RC20170903160139897888','adjyc会员充值',1504425699,1,'99999999.00','system',NULL,0,'','0.00','0.00','0.00',0,'','测试充值',0,'','','','',0,'0.00',NULL);
/*!40000 ALTER TABLE `ims_ewei_shop_member_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_member_mergelog`
--

DROP TABLE IF EXISTS `ims_ewei_shop_member_mergelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_member_mergelog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `mergetime` int(11) NOT NULL DEFAULT '0',
  `openid_a` varchar(30) NOT NULL,
  `openid_b` varchar(30) NOT NULL,
  `mid_a` int(11) NOT NULL,
  `mid_b` int(11) NOT NULL,
  `detail_a` text,
  `detail_b` text,
  `detail_c` text,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_mid_a` (`mid_a`) USING BTREE,
  KEY `idx_mid_b` (`mid_b`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_member_mergelog`
--

LOCK TABLES `ims_ewei_shop_member_mergelog` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_member_mergelog` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_member_mergelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_member_message_template`
--

DROP TABLE IF EXISTS `ims_ewei_shop_member_message_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_member_message_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `template_id` varchar(255) DEFAULT '',
  `first` text NOT NULL,
  `firstcolor` varchar(255) DEFAULT '',
  `data` text NOT NULL,
  `remark` text NOT NULL,
  `remarkcolor` varchar(255) DEFAULT '',
  `url` varchar(255) NOT NULL,
  `createtime` int(11) DEFAULT '0',
  `sendtimes` int(11) DEFAULT '0',
  `sendcount` int(11) DEFAULT '0',
  `typecode` varchar(30) DEFAULT '',
  `messagetype` tinyint(1) DEFAULT '0',
  `send_desc` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_createtime` (`createtime`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_member_message_template`
--

LOCK TABLES `ims_ewei_shop_member_message_template` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_member_message_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_member_message_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_member_message_template_default`
--

DROP TABLE IF EXISTS `ims_ewei_shop_member_message_template_default`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_member_message_template_default` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typecode` varchar(255) DEFAULT NULL,
  `uniacid` int(11) DEFAULT NULL,
  `templateid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_member_message_template_default`
--

LOCK TABLES `ims_ewei_shop_member_message_template_default` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_member_message_template_default` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_member_message_template_default` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_member_message_template_type`
--

DROP TABLE IF EXISTS `ims_ewei_shop_member_message_template_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_member_message_template_type` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `typecode` varchar(255) DEFAULT NULL,
  `templatecode` varchar(255) DEFAULT NULL,
  `templateid` varchar(255) DEFAULT NULL,
  `templatename` varchar(255) DEFAULT NULL,
  `content` varchar(1000) DEFAULT NULL,
  `showtotaladd` tinyint(1) DEFAULT '0',
  `typegroup` varchar(255) DEFAULT '',
  `groupname` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_member_message_template_type`
--

LOCK TABLES `ims_ewei_shop_member_message_template_type` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_member_message_template_type` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_member_message_template_type` VALUES (1,'订单付款通知','saler_pay','OPENTM405584202','xldHFTObiLLm7AK544PzW4bFJGgbS0o8Po4cXOgYEis','订单付款通知','{{first.DATA}}订单编号：{{keyword1.DATA}}商品名称：{{keyword2.DATA}}商品数量：{{keyword3.DATA}}支付金额：{{keyword4.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(2,'自提订单提交成功通知','carrier','OPENTM201594720','W6-XbT9l2Wb9FUUISss9yVZdPU8iEmEes9IZfvNZnbc','订单付款通知','{{first.DATA}}自提码：{{keyword1.DATA}}商品详情：{{keyword2.DATA}}提货地址：{{keyword3.DATA}}提货时间：{{keyword4.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(3,'订单取消通知','cancel','OPENTM201764653','EA6fL2052fvAs7F9w0Dx_UGbVuXmDFqLcrdT4IukWEY','订单关闭提醒','{{first.DATA}}订单商品：{{keyword1.DATA}}订单编号：{{keyword2.DATA}}下单时间：{{keyword3.DATA}}订单金额：{{keyword4.DATA}}关闭时间：{{keyword5.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(4,'订单即将取消通知','willcancel','OPENTM201764653','EA6fL2052fvAs7F9w0Dx_UGbVuXmDFqLcrdT4IukWEY','订单关闭提醒','{{first.DATA}}订单商品：{{keyword1.DATA}}订单编号：{{keyword2.DATA}}下单时间：{{keyword3.DATA}}订单金额：{{keyword4.DATA}}关闭时间：{{keyword5.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(5,'订单支付成功通知','pay','OPENTM405584202','xldHFTObiLLm7AK544PzW4bFJGgbS0o8Po4cXOgYEis','订单支付通知','{{first.DATA}}订单编号：{{keyword1.DATA}}商品名称：{{keyword2.DATA}}商品数量：{{keyword3.DATA}}支付金额：{{keyword4.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(6,'订单发货通知','send','OPENTM401874827','c0Db6XJBYJ0PcdDyDR5YsoGKy6zfvnQrNM97Ml2hBt4','订单发货通知','{{first.DATA}}订单编号：{{keyword1.DATA}}快递公司：{{keyword2.DATA}}快递单号：{{keyword3.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(7,'自动发货通知(虚拟物品及卡密)','virtualsend','OPENTM207793687','c2kQ5Pf7QkBUXhAVQRGpRusO1BS2uu_IBjPlIZ7IbYo','自动发货通知','{{first.DATA}}商品名称：{{keyword1.DATA}}订单号：{{keyword2.DATA}}订单金额：{{keyword3.DATA}}卡密信息：{{keyword4.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(8,'订单状态更新(修改收货地址)(修改价格)','orderstatus','TM00017','v6w5z7I8FMki08ndnGnfHSyx46eyYq9m_cIZUcvwCgU','订单付款通知','{{first.DATA}}订单编号: {{OrderSn.DATA}}订单状态: {{OrderStatus.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(9,'退款成功通知','refund1','TM00430','ez-VqnyVFEX6msJfoegrwMK2qZ6Va02sbOWvaHIMFNw','退款成功通知','{{first.DATA}}退款金额：{{orderProductPrice.DATA}}商品详情：{{orderProductName.DATA}}订单编号：{{orderName.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(10,'换货成功通知','refund3','OPENTM200605630','uS1mhnM85BtUum0s5xmlfEhnDGupvYqUkjK0A5o0sb8','任务处理通知','{{first.DATA}}任务名称：{{keyword1.DATA}}通知类型：{{keyword2.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(11,'退款申请驳回通知','refund2','OPENTM200605630','uS1mhnM85BtUum0s5xmlfEhnDGupvYqUkjK0A5o0sb8','任务处理通知','{{first.DATA}}任务名称：{{keyword1.DATA}}通知类型：{{keyword2.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(12,'充值成功通知','recharge_ok','OPENTM207727673','PWycmpCcbBEOuB99kZK6Lb_S_Ve6rZoigooR8lHtRHk','充值成功提醒','{{first.DATA}}充值金额：{{keyword1.DATA}}充值时间：{{keyword2.DATA}}账户余额：{{keyword3.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(13,'提现成功通知','withdraw_ok','OPENTM207422808','dpgcRnw1OrF_Beo7kgkK_0ThxcEY3nxpGHUPZ9Q4Yt0','提现通知','{{first.DATA}}申请提现金额：{{keyword1.DATA}}取提现手续费：{{keyword2.DATA}}实际到账金额：{{keyword3.DATA}}提现渠道：{{keyword4.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(14,'会员升级通知(任务处理通知)','upgrade','OPENTM200605630','UhLLmFRFoJB21zWe8Ue6s2Wbs6-hwAIcywjXFPEgAfk','任务处理通知','{{first.DATA}}任务名称：{{keyword1.DATA}}通知类型：{{keyword2.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(15,'充值成功通知（后台管理员手动）','backrecharge_ok','OPENTM207727673','8cH0W4PS46ttwb0NKaOsWlZXzp68pFkvhmz8Cx1TFYI','充值成功提醒','{{first.DATA}}充值金额：{{keyword1.DATA}}充值时间：{{keyword2.DATA}}账户余额：{{keyword3.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(16,'积分变动提醒','backpoint_ok','OPENTM207509450','t4X8tcZsZRfiLaxvlZSd9QTgmQTZRpy110DgoJeu4DU','积分变动提醒','{{first.DATA}}获得时间：{{keyword1.DATA}}获得积分：{{keyword2.DATA}}获得原因：{{keyword3.DATA}}当前积分：{{keyword4.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(17,'换货发货通知','refund4','OPENTM401874827','c0Db6XJBYJ0PcdDyDR5YsoGKy6zfvnQrNM97Ml2hBt4','订单发货通知','{{first.DATA}}订单编号：{{keyword1.DATA}}快递公司：{{keyword2.DATA}}快递单号：{{keyword3.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(18,'砍价活动通知','bargain_message','OPENTM200605630',NULL,'任务处理通知','{{first.DATA}}任务名称：{{keyword1.DATA}}通知类型：{{keyword2.DATA}}{{remark.DATA}}',0,'bargain','砍价消息通知'),(19,'拼团活动通知','groups',NULL,NULL,NULL,NULL,0,'groups','拼团消息通知'),(20,'人人分销通知','commission',NULL,NULL,NULL,NULL,0,'commission','分销消息通知'),(21,'商品付款通知','saler_goodpay','OPENTM200605630','','任务处理通知','{{first.DATA}}任务名称：{{keyword1.DATA}}通知类型：{{keyword2.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(22,'砍到底价通知','bargain_fprice','OPENTM200605630','','任务处理通知','{{first.DATA}}任务名称：{{keyword1.DATA}}通知类型：{{keyword2.DATA}}{{remark.DATA}}',0,'bargain','砍价消息通知'),(23,'订单收货通知(卖家)','saler_finish','OPENTM200605630','','任务处理通知','{{first.DATA}}任务名称：{{keyword1.DATA}}通知类型：{{keyword2.DATA}}{{remark.DATA}}',0,'sys','系统消息通知'),(24,'余额兑换成功通知','exchange_balance','OPENTM207727673','','充值成功提醒','{{first.DATA}}充值金额：{{keyword1.DATA}}充值时间：{{keyword2.DATA}}账户余额：{{keyword3.DATA}}{{remark.DATA}}',0,'exchange','兑换中心消息通知'),(25,'积分兑换成功通知','exchange_score','OPENTM207509450','','积分变动提醒','{{first.DATA}}获得时间：{{keyword1.DATA}}获得积分：{{keyword2.DATA}}获得原因：{{keyword3.DATA}}当前积分：{{keyword4.DATA}}{{remark.DATA}}',0,'exchange','兑换中心消息通知'),(26,'兑换中心余额充值通知','exchange_recharge','OPENTM207727673','','充值成功提醒','{{first.DATA}}充值金额：{{keyword1.DATA}}充值时间：{{keyword2.DATA}}账户余额：{{keyword3.DATA}}{{remark.DATA}}',0,'exchange','兑换中心消息通知');
/*!40000 ALTER TABLE `ims_ewei_shop_member_message_template_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_member_printer`
--

DROP TABLE IF EXISTS `ims_ewei_shop_member_printer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_member_printer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `type` tinyint(3) DEFAULT '0',
  `print_data` text,
  `createtime` int(11) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_createtime` (`createtime`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_member_printer`
--

LOCK TABLES `ims_ewei_shop_member_printer` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_member_printer` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_member_printer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_member_printer_template`
--

DROP TABLE IF EXISTS `ims_ewei_shop_member_printer_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_member_printer_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `type` tinyint(3) DEFAULT '0',
  `print_title` varchar(255) DEFAULT '',
  `print_style` varchar(255) DEFAULT '',
  `print_data` text,
  `code` varchar(500) DEFAULT '',
  `qrcode` varchar(500) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  `goodssn` tinyint(1) NOT NULL DEFAULT '0',
  `productsn` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_createtime` (`createtime`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_member_printer_template`
--

LOCK TABLES `ims_ewei_shop_member_printer_template` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_member_printer_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_member_printer_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_member_rank`
--

DROP TABLE IF EXISTS `ims_ewei_shop_member_rank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_member_rank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  `num` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_member_rank`
--

LOCK TABLES `ims_ewei_shop_member_rank` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_member_rank` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_member_rank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_merch_account`
--

DROP TABLE IF EXISTS `ims_ewei_shop_merch_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_merch_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `merchid` int(11) DEFAULT '0',
  `username` varchar(255) DEFAULT '',
  `pwd` varchar(255) DEFAULT '',
  `salt` varchar(255) DEFAULT '',
  `status` tinyint(3) DEFAULT '0',
  `perms` text,
  `isfounder` tinyint(3) DEFAULT '0',
  `lastip` varchar(255) DEFAULT '',
  `lastvisit` varchar(255) DEFAULT '',
  `roleid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_merchid` (`merchid`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=95 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_merch_account`
--

LOCK TABLES `ims_ewei_shop_merch_account` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_merch_adv`
--

DROP TABLE IF EXISTS `ims_ewei_shop_merch_adv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_merch_adv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `advname` varchar(50) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `displayorder` int(11) DEFAULT NULL,
  `enabled` int(11) DEFAULT NULL,
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_merchid` (`merchid`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_merch_adv`
--

LOCK TABLES `ims_ewei_shop_merch_adv` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_adv` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_adv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_merch_banner`
--

DROP TABLE IF EXISTS `ims_ewei_shop_merch_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_merch_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `bannername` varchar(50) DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `enabled` int(11) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_enabled` (`enabled`),
  KEY `idx_displayorder` (`displayorder`),
  KEY `idx_merchid` (`merchid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_merch_banner`
--

LOCK TABLES `ims_ewei_shop_merch_banner` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_banner` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_merch_bill`
--

DROP TABLE IF EXISTS `ims_ewei_shop_merch_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_merch_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `applyno` varchar(255) NOT NULL DEFAULT '',
  `merchid` int(11) NOT NULL DEFAULT '0',
  `orderids` text NOT NULL,
  `realprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `realpricerate` decimal(10,2) NOT NULL DEFAULT '0.00',
  `finalprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payrateprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payrate` decimal(10,2) NOT NULL DEFAULT '0.00',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00',
  `applytime` int(11) NOT NULL DEFAULT '0',
  `checktime` int(11) NOT NULL DEFAULT '0',
  `paytime` int(11) NOT NULL DEFAULT '0',
  `invalidtime` int(11) NOT NULL DEFAULT '0',
  `refusetime` int(11) NOT NULL DEFAULT '0',
  `remark` text NOT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `ordernum` int(11) NOT NULL DEFAULT '0',
  `orderprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `passrealprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `passrealpricerate` decimal(10,2) NOT NULL DEFAULT '0.00',
  `passorderids` text NOT NULL,
  `passordernum` int(11) NOT NULL DEFAULT '0',
  `passorderprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `alipay` varchar(50) NOT NULL DEFAULT '',
  `bankname` varchar(50) NOT NULL DEFAULT '',
  `bankcard` varchar(50) NOT NULL DEFAULT '',
  `applyrealname` varchar(50) NOT NULL DEFAULT '',
  `applytype` tinyint(3) NOT NULL DEFAULT '0',
  `handpay` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_merchid` (`merchid`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_merch_bill`
--

LOCK TABLES `ims_ewei_shop_merch_bill` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_bill` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_merch_billo`
--

DROP TABLE IF EXISTS `ims_ewei_shop_merch_billo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_merch_billo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `billid` int(11) NOT NULL DEFAULT '0',
  `orderid` int(11) NOT NULL DEFAULT '0',
  `ordermoney` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_merch_billo`
--

LOCK TABLES `ims_ewei_shop_merch_billo` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_billo` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_billo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_merch_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_merch_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_merch_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `catename` varchar(255) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  `status` tinyint(1) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `thumb` varchar(500) DEFAULT '',
  `isrecommand` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_merch_category`
--

LOCK TABLES `ims_ewei_shop_merch_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_merch_category_swipe`
--

DROP TABLE IF EXISTS `ims_ewei_shop_merch_category_swipe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_merch_category_swipe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  `status` tinyint(1) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `thumb` varchar(500) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_merch_category_swipe`
--

LOCK TABLES `ims_ewei_shop_merch_category_swipe` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_category_swipe` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_category_swipe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_merch_clearing`
--

DROP TABLE IF EXISTS `ims_ewei_shop_merch_clearing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_merch_clearing` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `merchid` int(11) NOT NULL DEFAULT '0',
  `clearno` varchar(64) NOT NULL DEFAULT '',
  `goodsprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `dispatchprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `deductprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `deductcredit2` decimal(10,2) NOT NULL DEFAULT '0.00',
  `discountprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `deductenough` decimal(10,2) NOT NULL DEFAULT '0.00',
  `merchdeductenough` decimal(10,2) NOT NULL DEFAULT '0.00',
  `isdiscountprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `createtime` int(10) unsigned NOT NULL DEFAULT '0',
  `starttime` int(10) unsigned NOT NULL DEFAULT '0',
  `endtime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `realprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `realpricerate` decimal(10,2) NOT NULL DEFAULT '0.00',
  `finalprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `remark` varchar(2000) NOT NULL DEFAULT '',
  `paytime` int(11) NOT NULL DEFAULT '0',
  `payrate` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `merchid` (`merchid`),
  KEY `starttime` (`starttime`),
  KEY `endtime` (`endtime`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_merch_clearing`
--

LOCK TABLES `ims_ewei_shop_merch_clearing` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_clearing` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_clearing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_merch_group`
--

DROP TABLE IF EXISTS `ims_ewei_shop_merch_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_merch_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `groupname` varchar(255) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  `isdefault` tinyint(1) DEFAULT '0',
  `goodschecked` tinyint(1) DEFAULT '0',
  `commissionchecked` tinyint(1) DEFAULT '0',
  `changepricechecked` tinyint(1) DEFAULT '0',
  `finishchecked` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_merch_group`
--

LOCK TABLES `ims_ewei_shop_merch_group` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_merch_nav`
--

DROP TABLE IF EXISTS `ims_ewei_shop_merch_nav`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_merch_nav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `navname` varchar(255) DEFAULT '',
  `icon` varchar(255) DEFAULT '',
  `url` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_merchid` (`merchid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_merch_nav`
--

LOCK TABLES `ims_ewei_shop_merch_nav` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_nav` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_nav` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_merch_notice`
--

DROP TABLE IF EXISTS `ims_ewei_shop_merch_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_merch_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `detail` text,
  `status` tinyint(3) DEFAULT '0',
  `createtime` int(11) DEFAULT NULL,
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_merchid` (`merchid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_merch_notice`
--

LOCK TABLES `ims_ewei_shop_merch_notice` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_merch_perm_log`
--

DROP TABLE IF EXISTS `ims_ewei_shop_merch_perm_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_merch_perm_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `uniacid` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT '',
  `type` varchar(255) DEFAULT '',
  `op` text,
  `ip` varchar(255) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_createtime` (`createtime`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_merchid` (`merchid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=489 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_merch_perm_log`
--

LOCK TABLES `ims_ewei_shop_merch_perm_log` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_perm_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_perm_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_merch_perm_role`
--

DROP TABLE IF EXISTS `ims_ewei_shop_merch_perm_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_merch_perm_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  `rolename` varchar(255) DEFAULT '',
  `status` tinyint(3) DEFAULT '0',
  `perms` text,
  `deleted` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_status` (`status`),
  KEY `idx_deleted` (`deleted`),
  KEY `merchid` (`merchid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_merch_perm_role`
--

LOCK TABLES `ims_ewei_shop_merch_perm_role` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_perm_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_perm_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_merch_reg`
--

DROP TABLE IF EXISTS `ims_ewei_shop_merch_reg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_merch_reg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `merchname` varchar(255) DEFAULT '',
  `salecate` varchar(255) DEFAULT '',
  `desc` varchar(500) DEFAULT '',
  `realname` varchar(255) DEFAULT '',
  `mobile` varchar(255) DEFAULT '',
  `status` tinyint(3) DEFAULT '0',
  `diyformdata` text,
  `diyformfields` text,
  `applytime` int(11) DEFAULT '0',
  `reason` text,
  `uname` varchar(50) NOT NULL DEFAULT '',
  `upass` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=112 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_merch_reg`
--

LOCK TABLES `ims_ewei_shop_merch_reg` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_reg` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_reg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_merch_saler`
--

DROP TABLE IF EXISTS `ims_ewei_shop_merch_saler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_merch_saler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `storeid` int(11) DEFAULT '0',
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `status` tinyint(3) DEFAULT '0',
  `salername` varchar(255) DEFAULT '',
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_storeid` (`storeid`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_merchid` (`merchid`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_merch_saler`
--

LOCK TABLES `ims_ewei_shop_merch_saler` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_saler` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_saler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_merch_store`
--

DROP TABLE IF EXISTS `ims_ewei_shop_merch_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_merch_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `storename` varchar(255) DEFAULT '',
  `address` varchar(255) DEFAULT '',
  `tel` varchar(255) DEFAULT '',
  `lat` varchar(255) DEFAULT '',
  `lng` varchar(255) DEFAULT '',
  `status` tinyint(3) DEFAULT '0',
  `type` tinyint(1) DEFAULT '0',
  `realname` varchar(255) DEFAULT '',
  `mobile` varchar(255) DEFAULT '',
  `fetchtime` varchar(255) DEFAULT '',
  `logo` varchar(255) DEFAULT '',
  `saletime` varchar(255) DEFAULT '',
  `desc` text,
  `displayorder` int(11) DEFAULT '0',
  `commission_total` decimal(10,2) DEFAULT NULL,
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_status` (`status`),
  KEY `idx_merchid` (`merchid`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_merch_store`
--

LOCK TABLES `ims_ewei_shop_merch_store` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_merch_user`
--

DROP TABLE IF EXISTS `ims_ewei_shop_merch_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_merch_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `regid` int(11) DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `groupid` int(11) DEFAULT '0',
  `merchno` varchar(255) NOT NULL DEFAULT '',
  `merchname` varchar(255) NOT NULL DEFAULT '',
  `salecate` varchar(255) NOT NULL DEFAULT '',
  `desc` varchar(500) NOT NULL DEFAULT '',
  `realname` varchar(255) NOT NULL DEFAULT '',
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `status` tinyint(3) DEFAULT '0',
  `accounttime` int(11) DEFAULT '0',
  `diyformdata` text,
  `diyformfields` text,
  `applytime` int(11) DEFAULT '0',
  `accounttotal` int(11) DEFAULT '0',
  `remark` text,
  `jointime` int(11) DEFAULT '0',
  `accountid` int(11) DEFAULT '0',
  `sets` text,
  `logo` varchar(255) NOT NULL DEFAULT '',
  `payopenid` varchar(32) NOT NULL DEFAULT '',
  `payrate` decimal(10,2) NOT NULL DEFAULT '0.00',
  `isrecommand` tinyint(1) DEFAULT '0',
  `cateid` int(11) DEFAULT '0',
  `address` varchar(255) DEFAULT '',
  `tel` varchar(255) DEFAULT '',
  `lat` varchar(255) DEFAULT '',
  `lng` varchar(255) DEFAULT '',
  `pluginset` text NOT NULL,
  `uname` varchar(50) NOT NULL DEFAULT '',
  `upass` varchar(255) NOT NULL DEFAULT '',
  `maxgoods` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_status` (`status`),
  KEY `idx_groupid` (`groupid`),
  KEY `idx_regid` (`regid`),
  KEY `idx_cateid` (`cateid`)
) ENGINE=MyISAM AUTO_INCREMENT=97 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_merch_user`
--

LOCK TABLES `ims_ewei_shop_merch_user` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_merch_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_multi_shop`
--

DROP TABLE IF EXISTS `ims_ewei_shop_multi_shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_multi_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `uid` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT '',
  `company` varchar(255) DEFAULT '',
  `sales` varchar(255) DEFAULT '',
  `starttime` int(11) DEFAULT '0',
  `endtime` int(11) DEFAULT '0',
  `applytime` int(11) DEFAULT '0',
  `jointime` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  `refusecontent` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_multi_shop`
--

LOCK TABLES `ims_ewei_shop_multi_shop` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_multi_shop` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_multi_shop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_nav`
--

DROP TABLE IF EXISTS `ims_ewei_shop_nav`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_nav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `navname` varchar(255) DEFAULT '',
  `icon` varchar(255) DEFAULT '',
  `url` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  `iswxapp` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_nav`
--

LOCK TABLES `ims_ewei_shop_nav` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_nav` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_nav` VALUES (14,6,'首页导航1','images/6/2017/09/NOs96ZbI0u0cZ7sS77o7rk59rY99UV.jpg','',0,0,0),(15,6,'首页导航2','images/6/2017/09/bNO6q4BzEj55KmJZNx3j56hL0qRXNn.jpg','',0,0,0),(16,6,'首页导航3','images/6/2017/09/ed5J57Z3sSc7JWC5583lDrdrwDH5wL.jpg','',0,0,0),(17,6,'进口','images/6/2017/09/rEuz781u0YrcqAi0AARJZAiEAcAq1J.png','',0,1,0),(18,6,'生鲜','images/6/2017/09/Oy86u6Y26U6BY2KZ6duVEb2DuUe6D6.png','',0,1,0),(19,6,'领券','images/6/2017/09/z7VvDvEvlYfwifYvUVv5vVvyFvDwjG.png','',0,1,0),(20,6,'惠赚钱','images/6/2017/09/F4e55cvi5wnWEuhJCl5EjecJe4gcLg.png','',0,1,0);
/*!40000 ALTER TABLE `ims_ewei_shop_nav` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_newstore_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_newstore_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_newstore_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `uniacid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_newstore_category`
--

LOCK TABLES `ims_ewei_shop_newstore_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_newstore_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_newstore_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_notice`
--

DROP TABLE IF EXISTS `ims_ewei_shop_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `detail` text,
  `status` tinyint(3) DEFAULT '0',
  `createtime` int(11) DEFAULT NULL,
  `shopid` int(11) DEFAULT '0',
  `iswxapp` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_notice`
--

LOCK TABLES `ims_ewei_shop_notice` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_notice` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_notice` VALUES (2,6,0,'公告','images/6/2017/08/gV9xXX9sUB88fv5lteHHHFBxfH5Hk5.jpg','','<p><span style=\"font: 50px/80px 微软雅黑, sans-serif; text-align: center; color: rgb(51, 51, 51); text-transform: none; text-indent: 0px; letter-spacing: normal; word-spacing: 0px; white-space: normal; widows: 1; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;\">我们帮您解决</span><span style=\"font: 50px/80px 微软雅黑, sans-serif; text-align: center; color: rgb(51, 51, 51); text-transform: none; text-indent: 0px; letter-spacing: normal; word-spacing: 0px; float: none; display: inline !important; white-space: normal; widows: 1; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;\"><span class=\"Apple-converted-space\">&nbsp;</span></span><strong class=\"red\" style=\"text-align: center; color: red; text-transform: none; line-height: 80px; text-indent: 0px; letter-spacing: normal; font-family: 微软雅黑, sans-serif; font-size: 50px; font-style: normal; font-variant: normal; word-spacing: 0px; white-space: normal; widows: 1; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;\">这些问题</strong></p>',1,1504154752,0,0);
/*!40000 ALTER TABLE `ims_ewei_shop_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_order`
--

DROP TABLE IF EXISTS `ims_ewei_shop_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(50) DEFAULT '',
  `agentid` int(11) DEFAULT '0',
  `ordersn` varchar(30) DEFAULT '',
  `price` decimal(10,2) DEFAULT '0.00',
  `goodsprice` decimal(10,2) DEFAULT '0.00',
  `discountprice` decimal(10,2) DEFAULT '0.00',
  `status` tinyint(3) DEFAULT '0',
  `paytype` tinyint(1) DEFAULT '0',
  `transid` varchar(30) DEFAULT '0',
  `remark` varchar(1000) DEFAULT '',
  `addressid` int(11) DEFAULT '0',
  `dispatchprice` decimal(10,2) DEFAULT '0.00',
  `dispatchid` int(10) DEFAULT '0',
  `createtime` int(10) DEFAULT NULL,
  `dispatchtype` tinyint(3) DEFAULT '0',
  `carrier` text,
  `refundid` int(11) DEFAULT '0',
  `iscomment` tinyint(3) DEFAULT '0',
  `creditadd` tinyint(3) DEFAULT '0',
  `deleted` tinyint(3) DEFAULT '0',
  `userdeleted` tinyint(3) DEFAULT '0',
  `finishtime` int(11) DEFAULT '0',
  `paytime` int(11) DEFAULT '0',
  `expresscom` varchar(30) NOT NULL DEFAULT '',
  `expresssn` varchar(50) NOT NULL DEFAULT '',
  `express` varchar(255) DEFAULT '',
  `sendtime` int(11) DEFAULT '0',
  `fetchtime` int(11) DEFAULT '0',
  `cash` tinyint(3) DEFAULT '0',
  `canceltime` int(11) DEFAULT NULL,
  `cancelpaytime` int(11) DEFAULT '0',
  `refundtime` int(11) DEFAULT '0',
  `isverify` tinyint(3) DEFAULT '0',
  `verified` tinyint(3) DEFAULT '0',
  `verifyopenid` varchar(255) DEFAULT '',
  `verifycode` varchar(255) DEFAULT '',
  `verifytime` int(11) DEFAULT '0',
  `verifystoreid` int(11) DEFAULT '0',
  `deductprice` decimal(10,2) DEFAULT '0.00',
  `deductcredit` int(10) DEFAULT '0',
  `deductcredit2` decimal(10,2) DEFAULT '0.00',
  `deductenough` decimal(10,2) DEFAULT '0.00',
  `virtual` int(11) DEFAULT '0',
  `virtual_info` text,
  `virtual_str` text,
  `address` text,
  `sysdeleted` tinyint(3) DEFAULT '0',
  `ordersn2` int(11) DEFAULT '0',
  `changeprice` decimal(10,2) DEFAULT '0.00',
  `changedispatchprice` decimal(10,2) DEFAULT '0.00',
  `oldprice` decimal(10,2) DEFAULT '0.00',
  `olddispatchprice` decimal(10,2) DEFAULT '0.00',
  `isvirtual` tinyint(3) DEFAULT '0',
  `couponid` int(11) DEFAULT '0',
  `couponprice` decimal(10,2) DEFAULT '0.00',
  `diyformdata` text,
  `diyformfields` text,
  `diyformid` int(11) DEFAULT '0',
  `storeid` int(11) DEFAULT '0',
  `printstate` tinyint(1) DEFAULT '0',
  `printstate2` tinyint(1) DEFAULT '0',
  `address_send` text,
  `refundstate` tinyint(3) DEFAULT '0',
  `closereason` text,
  `remarksaler` text,
  `remarkclose` text,
  `remarksend` text,
  `ismr` int(1) NOT NULL DEFAULT '0',
  `isdiscountprice` decimal(10,2) DEFAULT '0.00',
  `isvirtualsend` tinyint(1) DEFAULT '0',
  `virtualsend_info` text,
  `verifyinfo` text,
  `verifytype` tinyint(1) DEFAULT '0',
  `verifycodes` text,
  `invoicename` varchar(255) DEFAULT '',
  `merchid` int(11) DEFAULT '0',
  `ismerch` tinyint(1) DEFAULT '0',
  `parentid` int(11) DEFAULT '0',
  `isparent` tinyint(1) DEFAULT '0',
  `grprice` decimal(10,2) DEFAULT '0.00',
  `merchshow` tinyint(1) DEFAULT '0',
  `merchdeductenough` decimal(10,2) DEFAULT '0.00',
  `couponmerchid` int(11) DEFAULT '0',
  `isglobonus` tinyint(3) DEFAULT '0',
  `merchapply` tinyint(1) DEFAULT '0',
  `isabonus` tinyint(3) DEFAULT '0',
  `isborrow` tinyint(3) DEFAULT '0',
  `borrowopenid` varchar(100) DEFAULT '',
  `merchisdiscountprice` decimal(10,2) DEFAULT '0.00',
  `apppay` tinyint(3) NOT NULL DEFAULT '0',
  `coupongoodprice` decimal(10,2) DEFAULT '1.00',
  `buyagainprice` decimal(10,2) DEFAULT '0.00',
  `authorid` int(11) DEFAULT '0',
  `isauthor` tinyint(1) DEFAULT '0',
  `ispackage` tinyint(3) DEFAULT '0',
  `packageid` int(11) DEFAULT '0',
  `taskdiscountprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `seckilldiscountprice` decimal(10,2) DEFAULT '0.00',
  `verifyendtime` int(11) NOT NULL DEFAULT '0',
  `willcancelmessage` tinyint(1) DEFAULT '0',
  `sendtype` tinyint(3) NOT NULL DEFAULT '0',
  `lotterydiscountprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `contype` tinyint(1) DEFAULT '0',
  `wxid` int(11) DEFAULT '0',
  `wxcardid` varchar(50) DEFAULT '',
  `wxcode` varchar(50) DEFAULT '',
  `dispatchkey` varchar(30) NOT NULL DEFAULT '',
  `quickid` int(11) NOT NULL DEFAULT '0',
  `istrade` tinyint(3) NOT NULL DEFAULT '0',
  `isnewstore` tinyint(3) NOT NULL DEFAULT '0',
  `liveid` int(11) DEFAULT NULL,
  `ordersn_trade` varchar(32) DEFAULT NULL,
  `tradestatus` tinyint(1) DEFAULT '0',
  `tradepaytype` tinyint(1) DEFAULT NULL,
  `tradepaytime` int(11) DEFAULT '0',
  `dowpayment` decimal(10,2) NOT NULL DEFAULT '0.00',
  `betweenprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `isshare` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_openid` (`openid`),
  KEY `idx_shareid` (`agentid`),
  KEY `idx_status` (`status`),
  KEY `idx_createtime` (`createtime`),
  KEY `idx_refundid` (`refundid`),
  KEY `idx_paytime` (`paytime`),
  KEY `idx_finishtime` (`finishtime`),
  KEY `idx_merchid` (`merchid`)
) ENGINE=MyISAM AUTO_INCREMENT=187 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_order`
--

LOCK TABLES `ims_ewei_shop_order` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_order` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_order` VALUES (157,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170831124433986260','3579.00','3599.00','0.00',-1,3,'','',83,'0.00',0,1504154673,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504269088,0,0,0,0,'','',0,0,'0.00',0,'0.00','20.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','3579.00','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,'信息填写错误，重新拍',NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'3599.00',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(158,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170831193048721249','3579.00','3599.00','0.00',0,3,'','',83,'0.00',0,1504179048,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,NULL,0,0,0,0,'','',0,0,'0.00',0,'0.00','20.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','3579.00','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'3599.00',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(159,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170831193134060256','3579.00','3599.00','0.00',-1,0,'','',83,'0.00',0,1504179094,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504440521,0,0,0,0,'','',0,0,'0.00',0,'0.00','20.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','3579.00','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'3599.00',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(160,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170901202942011838','3579.00','3599.00','0.00',-1,0,'','',83,'0.00',0,1504268982,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504536772,0,0,0,0,'','',0,0,'0.00',0,'0.00','20.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','3579.00','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'3599.00',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(161,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170901203229727825','3579.00','3599.00','0.00',1,11,'','',83,'0.00',0,1504269149,0,'a:0:{}',0,0,0,0,0,0,1504272870,'','','',0,0,1,NULL,0,0,0,0,'','',0,0,'0.00',0,'0.00','20.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','3579.00','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'3599.00',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(162,6,'ooyv91cPbLRIz1qaX7Fim_cRfjZk',0,'SH20170901211719862658','3579.00','3599.00','0.00',0,3,'','',84,'0.00',0,1504271839,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,NULL,0,0,0,0,'','',0,0,'0.00',0,'0.00','20.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"84\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"ooyv91cPbLRIz1qaX7Fim_cRfjZk\";s:8:\"realname\";s:3:\"111\";s:6:\"mobile\";s:11:\"18888888888\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"朝阳区\";s:7:\"address\";s:8:\"11111111\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','3579.00','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'3599.00',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(163,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170902114913414004','137.00','139.00','0.00',-1,0,'','',83,'0.00',0,1504324153,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504585441,0,0,0,0,'','',0,0,'0.00',0,'0.00','2.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','137.00','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'139.00',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(164,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170902120029923499','0.01','0.01','0.00',1,21,'','',83,'0.00',0,1504324829,0,'a:0:{}',8,0,0,0,0,0,1504324845,'','','',0,0,1,NULL,0,0,0,0,'','',0,0,'0.00',0,'0.00','0.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','0.01','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,1,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'0.01',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(165,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170902143034696269','0.01','0.01','0.00',-1,0,'','',83,'0.00',0,1504333834,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504598150,0,0,0,0,'','',0,0,'0.00',0,'0.00','0.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','0.01','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'0.01',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(166,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170902145247546262','0.01','0.01','0.00',-1,0,'','',83,'0.00',0,1504335167,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504598150,0,0,0,0,'','',0,0,'0.00',0,'0.00','0.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','0.01','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'0.01',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(167,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170902150249445952','0.01','0.01','0.00',-1,0,'','',83,'0.00',0,1504335769,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504598150,0,0,0,0,'','',0,0,'0.00',0,'0.00','0.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','0.01','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'0.01',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(168,6,'oZo4hw84Jkl14EOT-D0UP7IWrrFY',0,'SH20170902151753676864','0.01','0.01','0.00',-1,0,'','',85,'0.00',0,1504336673,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504598150,0,0,0,0,'','',0,0,'0.00',0,'0.00','0.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"85\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw84Jkl14EOT-D0UP7IWrrFY\";s:8:\"realname\";s:6:\"小曦\";s:6:\"mobile\";s:11:\"18046053861\";s:8:\"province\";s:9:\"福建省\";s:4:\"city\";s:9:\"厦门市\";s:4:\"area\";s:9:\"集美区\";s:7:\"address\";s:12:\"诚毅学院\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','0.01','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'0.01',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(169,6,'oZo4hw84Jkl14EOT-D0UP7IWrrFY',0,'SH20170902151854828237','0.01','0.01','0.00',1,21,'','',85,'0.00',0,1504336734,0,'a:0:{}',0,0,0,0,0,0,1504336772,'','','',0,0,1,NULL,0,0,0,0,'','',0,0,'0.00',0,'0.00','0.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"85\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw84Jkl14EOT-D0UP7IWrrFY\";s:8:\"realname\";s:6:\"小曦\";s:6:\"mobile\";s:11:\"18046053861\";s:8:\"province\";s:9:\"福建省\";s:4:\"city\";s:9:\"厦门市\";s:4:\"area\";s:9:\"集美区\";s:7:\"address\";s:12:\"诚毅学院\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','0.01','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'0.01',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(170,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170902152431473627','0.01','0.01','0.00',-1,0,'','',83,'0.00',0,1504337071,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504598150,0,0,0,0,'','',0,0,'0.00',0,'0.00','0.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','0.01','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'0.01',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(171,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170902152501168947','1079.00','1099.00','0.00',-1,0,'','',83,'0.00',0,1504337101,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504598150,0,0,0,0,'','',0,0,'0.00',0,'0.00','20.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','1079.00','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'1099.00',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(172,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170902152625841046','3579.00','3599.00','0.00',-1,0,'','',83,'0.00',0,1504337185,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504598150,0,0,0,0,'','',0,0,'0.00',0,'0.00','20.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','3579.00','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'3599.00',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(173,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170902154037810162','0.01','0.01','0.00',-1,0,'','',83,'0.00',0,1504338037,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504598150,0,0,0,0,'','',0,0,'0.00',0,'0.00','0.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','0.01','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'0.01',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(174,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170902154922821010','1079.00','1099.00','0.00',-1,0,'','',83,'0.00',0,1504338562,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504598150,0,0,0,0,'','',0,0,'0.00',0,'0.00','20.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','1079.00','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'1099.00',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(175,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170902155032133022','1079.00','1099.00','0.00',-1,0,'','',83,'0.00',0,1504338632,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504598150,0,0,0,0,'','',0,0,'0.00',0,'0.00','20.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','1079.00','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'1099.00',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(176,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170902160603844868','0.01','0.01','0.00',-1,0,'','',83,'0.00',0,1504339563,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504616295,0,0,0,0,'','',0,0,'0.00',0,'0.00','0.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','0.01','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'0.01',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(177,6,'oZo4hw84Jkl14EOT-D0UP7IWrrFY',0,'SH20170902161023144224','0.01','0.01','0.00',-1,0,'','',85,'0.00',0,1504339823,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504616295,0,0,0,0,'','',0,0,'0.00',0,'0.00','0.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"85\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw84Jkl14EOT-D0UP7IWrrFY\";s:8:\"realname\";s:6:\"小曦\";s:6:\"mobile\";s:11:\"18046053861\";s:8:\"province\";s:9:\"福建省\";s:4:\"city\";s:9:\"厦门市\";s:4:\"area\";s:9:\"集美区\";s:7:\"address\";s:12:\"诚毅学院\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','0.01','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'0.01',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(178,6,'oZo4hw84Jkl14EOT-D0UP7IWrrFY',0,'SH20170902161639862526','0.01','0.01','0.00',-1,0,'','',85,'0.00',0,1504340199,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504616295,0,0,0,0,'','',0,0,'0.00',0,'0.00','0.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"85\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw84Jkl14EOT-D0UP7IWrrFY\";s:8:\"realname\";s:6:\"小曦\";s:6:\"mobile\";s:11:\"18046053861\";s:8:\"province\";s:9:\"福建省\";s:4:\"city\";s:9:\"厦门市\";s:4:\"area\";s:9:\"集美区\";s:7:\"address\";s:12:\"诚毅学院\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','0.01','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'0.01',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(179,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170902161717169263','3579.00','3599.00','0.00',-1,0,'','',83,'0.00',0,1504340237,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,1504616295,0,0,0,0,'','',0,0,'0.00',0,'0.00','20.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','3579.00','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'3599.00',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(180,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170903091927868054','0.01','0.01','0.00',0,0,'','',83,'0.00',0,1504401567,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,NULL,0,0,0,0,'','',0,0,'0.00',0,'0.00','0.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','0.01','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'0.01',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(181,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170903092852014204','0.01','0.01','0.00',0,0,'','',83,'0.00',0,1504402132,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,NULL,0,0,0,0,'','',0,0,'0.00',0,'0.00','0.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','0.01','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'0.01',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(182,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170903093253617402','0.01','0.01','0.00',1,1,'','',83,'0.00',0,1504402373,0,'a:0:{}',0,0,0,0,0,0,1504404150,'','','',0,0,1,NULL,0,0,0,0,'','',0,0,'0.00',0,'0.00','0.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"83\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:3:\"揭\";s:6:\"mobile\";s:11:\"18966666666\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:6:\"666666\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','0.01','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'0.01',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(183,6,'oZo4hw-Dv3uxhgBm549mY7-ikdyc',0,'SH20170903120755615843','7178.00','7198.00','0.00',0,0,'','',86,'0.00',0,1504411675,0,'a:0:{}',0,0,0,0,0,0,0,'','','',0,0,1,NULL,0,0,0,0,'','',0,0,'0.00',0,'0.00','20.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"86\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw-Dv3uxhgBm549mY7-ikdyc\";s:8:\"realname\";s:9:\"哈哈哈\";s:6:\"mobile\";s:11:\"18911705605\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:12:\"人都丰富\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','7178.00','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'7198.00',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(184,6,'oZo4hw-Dv3uxhgBm549mY7-ikdyc',0,'SH20170903163902499845','455.00','460.00','0.00',1,1,'','',86,'0.00',0,1504427942,0,'a:0:{}',0,0,0,0,0,0,1504428052,'','','',0,0,1,NULL,0,0,0,0,'','',0,0,'0.00',0,'0.00','5.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"86\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw-Dv3uxhgBm549mY7-ikdyc\";s:8:\"realname\";s:9:\"哈哈哈\";s:6:\"mobile\";s:11:\"18911705605\";s:8:\"province\";s:9:\"北京市\";s:4:\"city\";s:12:\"北京辖区\";s:4:\"area\";s:9:\"东城区\";s:7:\"address\";s:12:\"人都丰富\";s:9:\"isdefault\";s:1:\"1\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','455.00','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'460.00',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(185,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170904124554822621','244.00','249.00','0.00',1,1,'','',87,'0.00',0,1504500354,0,'a:0:{}',0,0,0,0,0,0,1504500363,'','','',0,0,0,NULL,0,0,0,0,'','',0,0,'0.00',0,'0.00','5.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"87\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:9:\"揭衍强\";s:6:\"mobile\";s:11:\"18959269002\";s:8:\"province\";s:9:\"福建省\";s:4:\"city\";s:9:\"厦门市\";s:4:\"area\";s:9:\"思明区\";s:7:\"address\";s:94:\"环岛南路软件园二期望海路10号二栋3层 厦门一品威客网络科技有限公司\";s:9:\"isdefault\";s:1:\"0\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','244.00','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'249.00',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0),(186,6,'oZo4hw8Wt565YLamn2TJqGExQirA',0,'SH20170904125049787377','10777.00','10797.00','0.00',3,1,'','',87,'0.00',0,1504500649,0,'a:0:{}',0,0,0,0,0,1504500951,1504500657,'顺丰','sf1001','shunfeng',1504500908,0,1,NULL,0,0,0,0,'','',0,0,'0.00',0,'0.00','20.00',0,NULL,NULL,'a:15:{s:2:\"id\";s:2:\"87\";s:7:\"uniacid\";s:1:\"6\";s:6:\"openid\";s:28:\"oZo4hw8Wt565YLamn2TJqGExQirA\";s:8:\"realname\";s:9:\"揭衍强\";s:6:\"mobile\";s:11:\"18959269002\";s:8:\"province\";s:9:\"福建省\";s:4:\"city\";s:9:\"厦门市\";s:4:\"area\";s:9:\"思明区\";s:7:\"address\";s:94:\"环岛南路软件园二期望海路10号二栋3层 厦门一品威客网络科技有限公司\";s:9:\"isdefault\";s:1:\"0\";s:7:\"zipcode\";s:0:\"\";s:7:\"deleted\";s:1:\"0\";s:6:\"street\";s:0:\"\";s:9:\"datavalue\";s:0:\"\";s:15:\"streetdatavalue\";s:0:\"\";}',0,0,'0.00','0.00','10777.00','0.00',0,0,'0.00',NULL,NULL,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,0,'0.00',0,NULL,'a:0:{}',0,'','',0,0,0,0,'10797.00',0,'0.00',0,0,0,0,0,'','0.00',0,'1.00','0.00',0,0,0,0,'0.00','0.00',0,0,0,'0.00',0,0,'0','','',0,0,0,0,NULL,0,NULL,0,'0.00','0.00',0);
/*!40000 ALTER TABLE `ims_ewei_shop_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_order_comment`
--

DROP TABLE IF EXISTS `ims_ewei_shop_order_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_order_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `orderid` int(11) DEFAULT '0',
  `goodsid` int(11) DEFAULT '0',
  `openid` varchar(50) DEFAULT '',
  `nickname` varchar(50) DEFAULT '',
  `headimgurl` varchar(255) DEFAULT '',
  `level` tinyint(3) DEFAULT '0',
  `content` varchar(255) DEFAULT '',
  `images` text,
  `createtime` int(11) DEFAULT '0',
  `deleted` tinyint(3) DEFAULT '0',
  `append_content` varchar(255) DEFAULT '',
  `append_images` text,
  `reply_content` varchar(255) DEFAULT '',
  `reply_images` text,
  `append_reply_content` varchar(255) DEFAULT '',
  `append_reply_images` text,
  `istop` tinyint(3) DEFAULT '0',
  `checked` tinyint(3) NOT NULL DEFAULT '0',
  `replychecked` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_goodsid` (`goodsid`),
  KEY `idx_openid` (`openid`),
  KEY `idx_createtime` (`createtime`),
  KEY `idx_orderid` (`orderid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_order_comment`
--

LOCK TABLES `ims_ewei_shop_order_comment` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_order_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_order_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_order_goods`
--

DROP TABLE IF EXISTS `ims_ewei_shop_order_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_order_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `orderid` int(11) DEFAULT '0',
  `goodsid` int(11) DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `total` int(11) DEFAULT '1',
  `optionid` int(10) DEFAULT '0',
  `createtime` int(11) DEFAULT '0',
  `optionname` text,
  `commission1` text,
  `applytime1` int(11) DEFAULT '0',
  `checktime1` int(10) DEFAULT '0',
  `paytime1` int(11) DEFAULT '0',
  `invalidtime1` int(11) DEFAULT '0',
  `deletetime1` int(11) DEFAULT '0',
  `status1` tinyint(3) DEFAULT '0',
  `content1` text,
  `commission2` text,
  `applytime2` int(11) DEFAULT '0',
  `checktime2` int(10) DEFAULT '0',
  `paytime2` int(11) DEFAULT '0',
  `invalidtime2` int(11) DEFAULT '0',
  `deletetime2` int(11) DEFAULT '0',
  `status2` tinyint(3) DEFAULT '0',
  `content2` text,
  `commission3` text,
  `applytime3` int(11) DEFAULT '0',
  `checktime3` int(10) DEFAULT '0',
  `paytime3` int(11) DEFAULT '0',
  `invalidtime3` int(11) DEFAULT '0',
  `deletetime3` int(11) DEFAULT '0',
  `status3` tinyint(3) DEFAULT '0',
  `content3` text,
  `realprice` decimal(10,2) DEFAULT '0.00',
  `goodssn` varchar(255) DEFAULT '',
  `productsn` varchar(255) DEFAULT '',
  `nocommission` tinyint(3) DEFAULT '0',
  `changeprice` decimal(10,2) DEFAULT '0.00',
  `oldprice` decimal(10,2) DEFAULT '0.00',
  `commissions` text,
  `diyformid` int(11) DEFAULT '0',
  `diyformdataid` int(11) DEFAULT '0',
  `diyformdata` text,
  `diyformfields` text,
  `openid` varchar(255) DEFAULT '',
  `printstate` int(11) NOT NULL DEFAULT '0',
  `printstate2` int(11) NOT NULL DEFAULT '0',
  `rstate` tinyint(3) DEFAULT '0',
  `refundtime` int(11) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  `parentorderid` int(11) DEFAULT '0',
  `merchsale` tinyint(3) NOT NULL DEFAULT '0',
  `isdiscountprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `canbuyagain` tinyint(1) DEFAULT '0',
  `seckill` tinyint(3) DEFAULT '0',
  `seckill_taskid` int(11) DEFAULT '0',
  `seckill_roomid` int(11) DEFAULT '0',
  `seckill_timeid` int(11) DEFAULT '0',
  `is_make` tinyint(1) DEFAULT '0',
  `sendtype` tinyint(3) NOT NULL DEFAULT '0',
  `expresscom` varchar(30) NOT NULL,
  `expresssn` varchar(50) NOT NULL,
  `express` varchar(255) NOT NULL,
  `sendtime` int(11) NOT NULL,
  `finishtime` int(11) NOT NULL,
  `remarksend` text NOT NULL,
  `prohibitrefund` tinyint(3) NOT NULL DEFAULT '0',
  `storeid` varchar(255) NOT NULL,
  `trade_time` int(11) NOT NULL DEFAULT '0',
  `optime` varchar(30) NOT NULL,
  `dowpayment` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tdate_time` int(11) NOT NULL DEFAULT '0',
  `peopleid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_orderid` (`orderid`),
  KEY `idx_goodsid` (`goodsid`),
  KEY `idx_createtime` (`createtime`),
  KEY `idx_applytime1` (`applytime1`),
  KEY `idx_checktime1` (`checktime1`),
  KEY `idx_status1` (`status1`),
  KEY `idx_applytime2` (`applytime2`),
  KEY `idx_checktime2` (`checktime2`),
  KEY `idx_status2` (`status2`),
  KEY `idx_applytime3` (`applytime3`),
  KEY `idx_invalidtime1` (`invalidtime1`),
  KEY `idx_checktime3` (`checktime3`),
  KEY `idx_invalidtime2` (`invalidtime2`),
  KEY `idx_invalidtime3` (`invalidtime3`),
  KEY `idx_status3` (`status3`),
  KEY `idx_paytime1` (`paytime1`),
  KEY `idx_paytime2` (`paytime2`),
  KEY `idx_paytime3` (`paytime3`)
) ENGINE=MyISAM AUTO_INCREMENT=181 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_order_goods`
--

LOCK TABLES `ims_ewei_shop_order_goods` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_order_goods` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_order_goods` VALUES (162,6,157,199,'3599.00',1,0,1504154673,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'3599.00','','',0,'0.00','3599.00',NULL,0,0,'a:0:{}','a:0:{}','oZo4hw8Wt565YLamn2TJqGExQirA',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(163,6,158,199,'3599.00',1,0,1504179048,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'3599.00','','',0,'0.00','3599.00',NULL,0,0,'a:0:{}','a:0:{}','oZo4hw8Wt565YLamn2TJqGExQirA',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(164,6,159,199,'3599.00',1,0,1504179094,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'3599.00','','',0,'0.00','3599.00',NULL,0,0,'a:0:{}','a:0:{}','oZo4hw8Wt565YLamn2TJqGExQirA',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(165,6,160,199,'3599.00',1,0,1504268982,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'3599.00','','',0,'0.00','3599.00',NULL,0,0,'a:0:{}','a:0:{}','oZo4hw8Wt565YLamn2TJqGExQirA',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(166,6,161,199,'3599.00',1,0,1504269149,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'3599.00','','',0,'0.00','3599.00',NULL,0,0,'false','a:0:{}','oZo4hw8Wt565YLamn2TJqGExQirA',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(167,6,162,199,'3599.00',1,0,1504271839,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'3599.00','','',0,'0.00','3599.00',NULL,0,0,'a:0:{}','a:0:{}','ooyv91cPbLRIz1qaX7Fim_cRfjZk',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(168,6,163,200,'139.00',1,0,1504324153,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'139.00','','',0,'0.00','139.00',NULL,0,0,'a:0:{}','a:0:{}','oZo4hw8Wt565YLamn2TJqGExQirA',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(169,6,164,200,'0.01',1,0,1504324829,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'0.01','','',0,'0.00','0.01',NULL,0,0,'a:0:{}','a:0:{}','oZo4hw8Wt565YLamn2TJqGExQirA',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(170,6,168,200,'0.01',1,0,1504336673,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'0.01','','',0,'0.00','0.01',NULL,0,0,'a:0:{}','a:0:{}','oZo4hw84Jkl14EOT-D0UP7IWrrFY',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(171,6,169,200,'0.01',1,0,1504336734,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'0.01','','',0,'0.00','0.01',NULL,0,0,'a:0:{}','a:0:{}','oZo4hw84Jkl14EOT-D0UP7IWrrFY',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(172,6,173,200,'0.01',1,0,1504338037,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'0.01','','',0,'0.00','0.01',NULL,0,0,'a:0:{}','a:0:{}','oZo4hw8Wt565YLamn2TJqGExQirA',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(173,6,177,200,'0.01',1,0,1504339823,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'0.01','','',0,'0.00','0.01',NULL,0,0,'a:0:{}','a:0:{}','oZo4hw84Jkl14EOT-D0UP7IWrrFY',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(174,6,180,200,'0.01',1,0,1504401567,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'0.01','','',0,'0.00','0.01',NULL,0,0,'a:0:{}','a:0:{}','oZo4hw8Wt565YLamn2TJqGExQirA',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(175,6,181,200,'0.01',1,0,1504402132,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'0.01','','',0,'0.00','0.01',NULL,0,0,'a:0:{}','a:0:{}','oZo4hw8Wt565YLamn2TJqGExQirA',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(176,6,182,200,'0.01',1,0,1504402373,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'0.01','','',0,'0.00','0.01',NULL,0,0,'a:0:{}','a:0:{}','oZo4hw8Wt565YLamn2TJqGExQirA',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(177,6,183,199,'7198.00',2,0,1504411675,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'7198.00','','',0,'0.00','7198.00',NULL,0,0,'false','a:0:{}','oZo4hw-Dv3uxhgBm549mY7-ikdyc',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(178,6,184,204,'460.00',1,0,1504427943,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'460.00','','',0,'0.00','460.00',NULL,0,0,'a:0:{}','a:0:{}','oZo4hw-Dv3uxhgBm549mY7-ikdyc',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(179,6,185,201,'249.00',1,0,1504500354,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'249.00','','',0,'0.00','249.00',NULL,0,0,'a:0:{}','a:0:{}','oZo4hw8Wt565YLamn2TJqGExQirA',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0),(180,6,186,199,'10797.00',3,0,1504500649,'',NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,NULL,'10797.00','','',0,'0.00','10797.00',NULL,0,0,'a:0:{}','a:0:{}','oZo4hw8Wt565YLamn2TJqGExQirA',0,0,0,0,0,0,0,'0.00',0,0,0,0,0,0,0,'','','',0,0,'',0,'',0,'','0.00',0,0);
/*!40000 ALTER TABLE `ims_ewei_shop_order_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_order_peerpay`
--

DROP TABLE IF EXISTS `ims_ewei_shop_order_peerpay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_order_peerpay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `orderid` int(11) NOT NULL DEFAULT '0',
  `peerpay_type` tinyint(1) NOT NULL DEFAULT '0',
  `peerpay_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `peerpay_maxprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `peerpay_realprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `peerpay_selfpay` decimal(10,2) NOT NULL DEFAULT '0.00',
  `peerpay_message` varchar(500) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `createtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`) USING BTREE,
  KEY `orderid` (`orderid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_order_peerpay`
--

LOCK TABLES `ims_ewei_shop_order_peerpay` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_order_peerpay` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_order_peerpay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_order_peerpay_payinfo`
--

DROP TABLE IF EXISTS `ims_ewei_shop_order_peerpay_payinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_order_peerpay_payinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `uname` varchar(255) NOT NULL DEFAULT '',
  `usay` varchar(500) NOT NULL DEFAULT '',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `createtime` int(11) NOT NULL DEFAULT '0',
  `headimg` varchar(255) DEFAULT NULL,
  `refundstatus` tinyint(1) NOT NULL DEFAULT '0',
  `refundprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tid` varchar(255) NOT NULL DEFAULT '',
  `openid` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_order_peerpay_payinfo`
--

LOCK TABLES `ims_ewei_shop_order_peerpay_payinfo` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_order_peerpay_payinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_order_peerpay_payinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_order_refund`
--

DROP TABLE IF EXISTS `ims_ewei_shop_order_refund`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_order_refund` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `orderid` int(11) DEFAULT '0',
  `refundno` varchar(255) DEFAULT '',
  `price` varchar(255) DEFAULT '',
  `reason` varchar(255) DEFAULT '',
  `images` text,
  `content` text,
  `createtime` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  `reply` text,
  `refundtype` tinyint(3) DEFAULT '0',
  `orderprice` decimal(10,2) DEFAULT '0.00',
  `applyprice` decimal(10,2) DEFAULT '0.00',
  `imgs` text,
  `rtype` tinyint(3) DEFAULT '0',
  `refundaddress` text,
  `message` text,
  `express` varchar(100) DEFAULT '',
  `expresscom` varchar(100) DEFAULT '',
  `expresssn` varchar(100) DEFAULT '',
  `operatetime` int(11) DEFAULT '0',
  `sendtime` int(11) DEFAULT '0',
  `returntime` int(11) DEFAULT '0',
  `refundtime` int(11) DEFAULT '0',
  `rexpress` varchar(100) DEFAULT '',
  `rexpresscom` varchar(100) DEFAULT '',
  `rexpresssn` varchar(100) DEFAULT '',
  `refundaddressid` int(11) DEFAULT '0',
  `endtime` int(11) DEFAULT '0',
  `realprice` decimal(10,2) DEFAULT '0.00',
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_createtime` (`createtime`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_order_refund`
--

LOCK TABLES `ims_ewei_shop_order_refund` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_order_refund` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_order_refund` VALUES (8,6,164,'SR20170902120129242470','','不想要了',NULL,'测试',1504324889,0,NULL,0,'0.01','0.01','a:1:{i:0;s:51:\"images/6/2017/09/BucY4YMU62e6wklTLP4YMkg23uwN62.jpg\";}',0,NULL,NULL,'','','',0,0,0,0,'','','',0,0,'0.00',0);
/*!40000 ALTER TABLE `ims_ewei_shop_order_refund` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_package`
--

DROP TABLE IF EXISTS `ims_ewei_shop_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_package` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `freight` decimal(10,2) NOT NULL DEFAULT '0.00',
  `thumb` varchar(255) NOT NULL,
  `starttime` int(11) NOT NULL DEFAULT '0',
  `endtime` int(11) NOT NULL DEFAULT '0',
  `goodsid` varchar(255) NOT NULL,
  `cash` tinyint(3) NOT NULL DEFAULT '0',
  `share_title` varchar(255) NOT NULL,
  `share_icon` varchar(255) NOT NULL,
  `share_desc` varchar(500) NOT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `deleted` tinyint(3) NOT NULL DEFAULT '0',
  `displayorder` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_package`
--

LOCK TABLES `ims_ewei_shop_package` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_package` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_package_goods`
--

DROP TABLE IF EXISTS `ims_ewei_shop_package_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_package_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `goodsid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `option` varchar(255) NOT NULL,
  `goodssn` varchar(255) NOT NULL,
  `productsn` varchar(255) NOT NULL,
  `hasoption` tinyint(3) NOT NULL DEFAULT '0',
  `marketprice` decimal(10,2) DEFAULT '0.00',
  `packageprice` decimal(10,2) DEFAULT '0.00',
  `commission1` decimal(10,2) DEFAULT '0.00',
  `commission2` decimal(10,2) DEFAULT '0.00',
  `commission3` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_package_goods`
--

LOCK TABLES `ims_ewei_shop_package_goods` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_package_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_package_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_package_goods_option`
--

DROP TABLE IF EXISTS `ims_ewei_shop_package_goods_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_package_goods_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `goodsid` int(11) NOT NULL DEFAULT '0',
  `optionid` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `packageprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `marketprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `commission1` decimal(10,2) NOT NULL DEFAULT '0.00',
  `commission2` decimal(10,2) NOT NULL DEFAULT '0.00',
  `commission3` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_package_goods_option`
--

LOCK TABLES `ims_ewei_shop_package_goods_option` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_package_goods_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_package_goods_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_payment`
--

DROP TABLE IF EXISTS `ims_ewei_shop_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(2) NOT NULL DEFAULT '0',
  `appid` varchar(255) DEFAULT '',
  `mch_id` varchar(50) NOT NULL DEFAULT '',
  `apikey` varchar(50) NOT NULL DEFAULT '',
  `sub_appid` varchar(50) DEFAULT '',
  `sub_appsecret` varchar(50) DEFAULT '',
  `sub_mch_id` varchar(50) DEFAULT '',
  `cert_file` text,
  `key_file` text,
  `root_file` text,
  `is_raw` tinyint(1) DEFAULT '0',
  `createtime` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_type` (`type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_payment`
--

LOCK TABLES `ims_ewei_shop_payment` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_payment` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_payment` VALUES (1,6,'微信支付',0,'','','ab235bf8be745b7d2c268ed8723020e2','wxb797d06f10b3f641','ab235bf8be745b7d2c268ed8723020e2','1485461622','','','',0,1504154762);
/*!40000 ALTER TABLE `ims_ewei_shop_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_pc_adv`
--

DROP TABLE IF EXISTS `ims_ewei_shop_pc_adv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_pc_adv` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) unsigned NOT NULL,
  `advname` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `src` varchar(255) NOT NULL,
  `alt` varchar(255) DEFAULT NULL,
  `enabled` tinyint(3) unsigned NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `width` int(11) unsigned NOT NULL,
  `height` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_pc_adv`
--

LOCK TABLES `ims_ewei_shop_pc_adv` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_pc_adv` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_pc_adv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_pc_link`
--

DROP TABLE IF EXISTS `ims_ewei_shop_pc_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_pc_link` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) unsigned NOT NULL,
  `linkname` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `displayorder` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_pc_link`
--

LOCK TABLES `ims_ewei_shop_pc_link` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_pc_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_pc_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_pc_menu`
--

DROP TABLE IF EXISTS `ims_ewei_shop_pc_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_pc_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) unsigned NOT NULL,
  `type` int(11) unsigned DEFAULT '0',
  `displayorder` int(11) unsigned DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `enabled` tinyint(3) unsigned DEFAULT '1',
  `createtime` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_pc_menu`
--

LOCK TABLES `ims_ewei_shop_pc_menu` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_pc_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_pc_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_pc_slide`
--

DROP TABLE IF EXISTS `ims_ewei_shop_pc_slide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_pc_slide` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) unsigned DEFAULT '0',
  `type` int(11) unsigned DEFAULT '0',
  `advname` varchar(50) DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `backcolor` varchar(255) DEFAULT NULL,
  `displayorder` int(11) DEFAULT '0',
  `enabled` int(11) DEFAULT '0',
  `shopid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_enabled` (`enabled`),
  KEY `idx_displayorder` (`displayorder`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_pc_slide`
--

LOCK TABLES `ims_ewei_shop_pc_slide` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_pc_slide` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_pc_slide` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_perm_log`
--

DROP TABLE IF EXISTS `ims_ewei_shop_perm_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_perm_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `uniacid` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT '',
  `type` varchar(255) DEFAULT '',
  `op` text,
  `createtime` int(11) DEFAULT '0',
  `ip` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`uid`),
  KEY `idx_createtime` (`createtime`),
  KEY `idx_uniacid` (`uniacid`),
  FULLTEXT KEY `idx_type` (`type`),
  FULLTEXT KEY `idx_op` (`op`)
) ENGINE=MyISAM AUTO_INCREMENT=6882 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_perm_log`
--

LOCK TABLES `ims_ewei_shop_perm_log` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_perm_log` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_perm_log` VALUES (6725,1,6,'设置-商城设置-修改','sysset.shop.edit','修改系统设置-商城设置',1504103508,'27.154.183.97'),(6726,1,6,'设置-模板设置-修改','sysset.templat.edit','修改系统设置-模板设置',1504103541,'27.154.183.97'),(6727,1,6,'设置-交易设置-修改','sysset.trade.edit','修改系统设置-交易设置',1504103601,'27.154.183.97'),(6728,1,6,'会员管理-会员等级-添加','member.level.add','添加会员等级 ID: 5',1504105345,'27.154.183.97'),(6729,1,6,'会员管理-会员等级-修改','member.level.edit','修改会员等级 ID: 5<br/>等级名称: 黄金->黄金<br/>折扣: ->8.80',1504105394,'27.154.183.97'),(6730,1,6,'会员管理-会员等级-添加','member.level.add','添加会员等级 ID: 6',1504105405,'27.154.183.97'),(6731,1,6,'会员管理-会员等级-添加','member.level.add','添加会员等级 ID: 7',1504105431,'27.154.183.97'),(6732,1,6,'营销-修改满额立减','sale.enough','修改满额立减优惠',1504105504,'27.154.183.97'),(6733,1,6,'营销-修改满额立减','sale.enough','修改满额包邮优惠',1504105514,'27.154.183.97'),(6734,1,6,'营销-修改充值优惠设置','sale.recharge','修改充值优惠设置',1504105540,'27.154.183.97'),(6735,1,6,'','sale.credit1.edit','修改基本积分活动配置',1504105591,'27.154.183.97'),(6736,1,6,'','sale.credit1.edit','修改基本积分活动配置',1504105613,'27.154.183.97'),(6737,1,6,'','shop.category.add','添加分类 ID: 1174',1504105850,'27.154.183.97'),(6738,1,6,'商城管理-配送方式-修改','shop.dispatch.edit','隐藏',1504105859,'27.154.183.97'),(6739,1,6,'商城管理-配送方式-修改','shop.dispatch.edit','隐藏',1504105861,'27.154.183.97'),(6740,1,6,'','shop.category.add','添加分类 ID: 1175',1504105903,'27.154.183.97'),(6741,1,6,'','shop.category.add','添加分类 ID: 1176',1504105921,'27.154.183.97'),(6742,1,6,'设置-分类层级-修改','sysset.category.edit','修改系统设置-分类层级设置',1504105978,'27.154.183.97'),(6743,1,6,'','shop.category.add','添加分类 ID: 1177',1504106010,'27.154.183.97'),(6744,1,6,'','shop.category.add','添加分类 ID: 1178',1504106024,'27.154.183.97'),(6745,1,6,'','shop.category.add','添加分类 ID: 1179',1504106037,'27.154.183.97'),(6746,1,6,'商城管理-配送方式-修改','shop.dispatch.edit','隐藏',1504106059,'27.154.183.97'),(6747,1,6,'','shop.category.add','添加分类 ID: 1180',1504106216,'27.154.183.97'),(6748,1,6,'','shop.category.add','添加分类 ID: 1181',1504106246,'27.154.183.97'),(6749,1,6,'','shop.category.add','添加分类 ID: 1182',1504106275,'27.154.183.97'),(6750,1,6,'商城管理-配送方式-修改','shop.dispatch.edit','隐藏',1504106281,'27.154.183.97'),(6751,1,6,'商城管理-配送方式-修改','shop.dispatch.edit','隐藏',1504106281,'27.154.183.97'),(6752,1,6,'商品管理-添加','goods.add','添加商品 ID: 199<br>是否参与分销 -- 是',1504106606,'27.154.183.97'),(6753,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 199<br>是否参与分销 -- 是',1504106674,'27.154.183.97'),(6754,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 199<br>是否参与分销 -- 是',1504106744,'27.154.183.97'),(6755,1,6,'商品管理-标签管理-添加','goods.label.add','添加标签组 ID: 1',1504106856,'27.154.183.97'),(6756,1,6,'商品管理-标签管理-添加','goods.label.add','添加标签组 ID: 2',1504106914,'27.154.183.97'),(6757,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 199<br>是否参与分销 -- 是',1504107038,'27.154.183.97'),(6758,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 199<br>是否参与分销 -- 是',1504107080,'27.154.183.97'),(6759,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 199<br>是否参与分销 -- 是',1504154570,'218.6.78.20'),(6760,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 199<br>是否参与分销 -- 是',1504154589,'218.6.78.20'),(6761,1,6,'商城管理-公告-添加','shop.notice.add','修改公告 ID: 2',1504154752,'218.6.78.20'),(6762,1,6,'设置-支付方式-修改','sysset.payset.edit','修改系统设置-支付设置',1504154793,'218.6.78.20'),(6763,1,6,'商城管理-幻灯片-添加','shop.adv.add','添加幻灯片 ID: 9',1504155345,'218.6.78.20'),(6764,1,6,'商城管理-幻灯片-添加','shop.adv.add','添加幻灯片 ID: 10',1504155364,'218.6.78.20'),(6765,1,6,'商城管理-幻灯片-添加','shop.adv.add','添加幻灯片 ID: 11',1504155385,'218.6.78.20'),(6766,1,6,'订单-操作-确认付款','order.op.pay','订单确认付款 ID: 161 订单号: SH20170901203229727825',1504272871,'120.41.220.107'),(6767,1,6,'','shop.category.add','添加分类 ID: 1183',1504321911,'120.41.220.107'),(6768,1,6,'','shop.category.add','添加分类 ID: 1184',1504321952,'120.41.220.107'),(6769,1,6,'','shop.category.add','添加分类 ID: 1185',1504321981,'120.41.220.107'),(6770,1,6,'','shop.category.add','添加分类 ID: 1186',1504322001,'120.41.220.107'),(6771,1,6,'商城管理-配送方式-修改','shop.dispatch.edit','隐藏',1504322151,'120.41.220.107'),(6772,1,6,'商城管理-配送方式-修改','shop.dispatch.edit','隐藏',1504322152,'120.41.220.107'),(6773,1,6,'','shop.category.edit','修改分类 ID: 1174',1504322259,'120.41.220.107'),(6774,1,6,'商城管理-幻灯片-修改','shop.adv.edit','修改幻灯片 ID: 9',1504322394,'120.41.220.107'),(6775,1,6,'商城管理-幻灯片-修改','shop.adv.edit','修改幻灯片 ID: 10',1504322411,'120.41.220.107'),(6776,1,6,'商城管理-幻灯片-修改','shop.adv.edit','修改幻灯片 ID: 11',1504322424,'120.41.220.107'),(6777,1,6,'商城管理-幻灯片-添加','shop.adv.add','添加幻灯片 ID: 12',1504322451,'120.41.220.107'),(6778,1,6,'商城管理-幻灯片-添加','shop.adv.add','添加幻灯片 ID: 13',1504322475,'120.41.220.107'),(6779,1,6,'商城管理-首页导航图标-添加','shop.nav.add','添加首页导航 ID: 14',1504322509,'120.41.220.107'),(6780,1,6,'商城管理-首页导航图标-添加','shop.nav.add','添加首页导航 ID: 15',1504322530,'120.41.220.107'),(6781,1,6,'商城管理-首页导航图标-添加','shop.nav.add','添加首页导航 ID: 16',1504322547,'120.41.220.107'),(6782,1,6,'商城管理-首页广告-修改','shop.banner.edit','修改手机端广告轮播',1504322582,'120.41.220.107'),(6783,1,6,'商城管理-首页广告-添加','shop.banner.add','添加广告 ID: 4',1504322604,'120.41.220.107'),(6784,1,6,'商城管理-首页广告-添加','shop.banner.add','添加广告 ID: 5',1504322620,'120.41.220.107'),(6785,1,6,'商城管理-首页广告-添加','shop.banner.add','添加广告 ID: 6',1504322665,'120.41.220.107'),(6786,1,6,'商城管理-首页魔方-修改','shop.cube.edit','修改基本设置',1504322748,'120.41.220.107'),(6787,1,6,'','shop.recommand','修改首页推荐商品设置',1504322796,'120.41.220.107'),(6788,1,6,'商城管理-首页广告-修改','shop.banner.edit','隐藏',1504322884,'120.41.220.107'),(6789,1,6,'商城管理-首页广告-修改','shop.banner.edit','隐藏',1504322884,'120.41.220.107'),(6790,1,6,'商城管理-首页广告-修改','shop.banner.edit','隐藏',1504322887,'120.41.220.107'),(6791,1,6,'商城管理-首页广告-修改','shop.banner.edit','隐藏',1504322906,'120.41.220.107'),(6792,1,6,'商城管理-首页魔方-修改','shop.cube.edit','修改基本设置',1504322956,'120.41.220.107'),(6793,1,6,'','shop.sort','修改首页排版',1504323007,'120.41.220.107'),(6794,1,6,'商城管理-首页导航图标-修改','shop.nav.edit','修改首页导航 ID: 14',1504323361,'120.41.220.107'),(6795,1,6,'商城管理-首页导航图标-修改','shop.nav.edit','修改首页导航 ID: 15',1504323375,'120.41.220.107'),(6796,1,6,'商城管理-首页导航图标-修改','shop.nav.edit','修改首页导航 ID: 16',1504323564,'120.41.220.107'),(6797,1,6,'商城管理-首页导航图标-添加','shop.nav.add','添加首页导航 ID: 17',1504323594,'120.41.220.107'),(6798,1,6,'商城管理-首页导航图标-添加','shop.nav.add','添加首页导航 ID: 18',1504323731,'120.41.220.107'),(6799,1,6,'商城管理-首页导航图标-添加','shop.nav.add','添加首页导航 ID: 19',1504323762,'120.41.220.107'),(6800,1,6,'商城管理-首页导航图标-添加','shop.nav.add','添加首页导航 ID: 20',1504323783,'120.41.220.107'),(6801,1,6,'商城管理-首页导航图标-修改','shop.nav.edit','隐藏',1504323797,'120.41.220.107'),(6802,1,6,'商城管理-首页导航图标-修改','shop.nav.edit','隐藏',1504323798,'120.41.220.107'),(6803,1,6,'商城管理-首页导航图标-修改','shop.nav.edit','隐藏',1504323799,'120.41.220.107'),(6804,1,6,'商品管理-添加','goods.add','添加商品 ID: 200<br>是否参与分销 -- 是',1504324009,'120.41.220.107'),(6805,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 200<br>是否参与分销 -- 是',1504324036,'120.41.220.107'),(6806,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 200<br>是否参与分销 -- 是',1504324108,'120.41.220.107'),(6807,1,6,'商品管理-添加','goods.add','添加商品 ID: 201<br>是否参与分销 -- 是',1504324308,'120.41.220.107'),(6808,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 201<br>是否参与分销 -- 是',1504324341,'120.41.220.107'),(6809,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 201<br>是否参与分销 -- 是',1504324372,'120.41.220.107'),(6810,1,6,'商品管理-修改','goods.edit','下架',1504324422,'120.41.220.107'),(6811,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 201<br>是否参与分销 -- 是',1504324488,'120.41.220.107'),(6812,1,6,'商品管理-添加','goods.add','添加商品 ID: 202<br>是否参与分销 -- 是',1504324613,'120.41.220.107'),(6813,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 202<br>是否参与分销 -- 是',1504324625,'120.41.220.107'),(6814,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 200<br>是否参与分销 -- 是',1504324719,'120.41.220.107'),(6815,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 200<br>是否参与分销 -- 是',1504324735,'120.41.220.107'),(6816,1,6,'财务管理-充值-充值余额','finance.recharge.credit2','充值余额: 99999999 <br/>会员信息: ID: 2188 /  oZo4hw8Wt565YLamn2TJqGExQirA/街墙//',1504402523,'120.41.220.107'),(6817,1,6,'商品管理-添加','goods.add','添加商品 ID: 203<br>是否参与分销 -- 是',1504424399,'120.41.220.107'),(6818,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 203<br>是否参与分销 -- 是',1504424502,'120.41.220.107'),(6819,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 203<br>是否参与分销 -- 是',1504424641,'120.41.220.107'),(6820,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 203<br>是否参与分销 -- 是',1504424742,'120.41.220.107'),(6821,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 203<br>是否参与分销 -- 是',1504425028,'120.41.220.107'),(6822,1,6,'商品管理-添加','goods.add','添加商品 ID: 204<br>是否参与分销 -- 是',1504425336,'120.41.220.107'),(6823,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 204<br>是否参与分销 -- 是',1504425387,'120.41.220.107'),(6824,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 204<br>是否参与分销 -- 是',1504425448,'120.41.220.107'),(6825,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 204<br>是否参与分销 -- 是',1504425541,'120.41.220.107'),(6826,1,6,'','shop.recommand','修改首页推荐商品设置',1504425581,'120.41.220.107'),(6827,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 204<br>是否参与分销 -- 是',1504425604,'120.41.220.107'),(6828,1,6,'财务管理-充值-充值余额','finance.recharge.credit2','充值余额: 9999999 <br/>会员信息: ID: 2190 /  oZo4hw7Rho-Val4FIVX5oKc2OTUI/冯颖//',1504425683,'120.41.220.107'),(6829,1,6,'财务管理-充值-充值余额','finance.recharge.credit2','充值余额: 99999999 <br/>会员信息: ID: 2189 /  oZo4hw-Dv3uxhgBm549mY7-ikdyc/揭果//',1504425700,'120.41.220.107'),(6830,1,6,'设置-商城设置-修改','sysset.shop.edit','修改系统设置-商城设置',1504440609,'120.41.220.107'),(6831,1,6,'设置-商城设置-修改','sysset.shop.edit','修改系统设置-商城设置',1504440625,'120.41.220.107'),(6832,1,6,'设置-商城设置-修改','sysset.shop.edit','修改系统设置-商城设置',1504446988,'120.41.220.107'),(6833,1,6,'设置-商城设置-修改','sysset.shop.edit','修改系统设置-商城设置',1504447015,'120.41.220.107'),(6834,1,6,'设置-交易设置-修改','sysset.trade.edit','修改系统设置-交易设置',1504500280,'218.6.78.20'),(6835,1,6,'人人分销-分销商等级-添加','commission.level.add','添加分销商等级 ID: 3',1504500575,'218.6.78.20'),(6836,1,6,'人人分销-分销商等级-添加','commission.level.add','添加分销商等级 ID: 4',1504500590,'218.6.78.20'),(6837,1,6,'人人分销-分销商等级-添加','commission.level.add','添加分销商等级 ID: 5',1504500602,'218.6.78.20'),(6838,1,6,'订单-操作-发货','order.op.send','订单发货 ID: 186 订单号: SH20170904125049787377 <br/>快递公司: 顺丰 快递单号: sf1001',1504500908,'218.6.78.20'),(6839,1,6,'','shop.sort','修改首页排版',1504585507,'218.6.78.20'),(6840,1,6,'','taobao.main','淘宝抓取宝贝 淘宝id:522155891308',1504616433,'120.41.220.107'),(6841,1,6,'','taobao.main','淘宝抓取宝贝 淘宝id:522155891308',1504616630,'120.41.220.107'),(6842,1,6,'','taobao.main','淘宝抓取宝贝 淘宝id:10940138',1504616630,'120.41.220.107'),(6843,1,6,'','taobao.main','淘宝抓取宝贝 淘宝id:542225813793',1504616718,'120.41.220.107'),(6844,1,6,'','taobao.main','淘宝抓取宝贝 淘宝id:537605741122',1504616720,'120.41.220.107'),(6845,1,6,'商品管理-修改','goods.edit','下架',1504616740,'120.41.220.107'),(6846,1,6,'商品管理-修改','goods.edit','下架',1504616743,'120.41.220.107'),(6847,1,6,'商品管理-修改','goods.edit','下架',1504616745,'120.41.220.107'),(6848,1,6,'商品管理-修改','goods.edit','修改商品推荐状态   ID: 207',1504616785,'120.41.220.107'),(6849,1,6,'商品管理-修改','goods.edit','修改商品推荐状态   ID: 206',1504616787,'120.41.220.107'),(6850,1,6,'','taobao.main','淘宝抓取宝贝 淘宝id:556734757086',1504617533,'120.41.220.107'),(6851,1,6,'','taobao.main','淘宝抓取宝贝 淘宝id:545970731242',1504617534,'120.41.220.107'),(6852,1,6,'','taobao.main','淘宝抓取宝贝 淘宝id:545970731242',1504617535,'120.41.220.107'),(6853,1,6,'','taobao.main','淘宝抓取宝贝 淘宝id:525903378849',1504617537,'120.41.220.107'),(6854,1,6,'','taobao.main','淘宝抓取宝贝 淘宝id:556163042004',1504617538,'120.41.220.107'),(6855,1,6,'','taobao.main','淘宝抓取宝贝 淘宝id:536082578238',1504617540,'120.41.220.107'),(6856,1,6,'商品管理-修改','goods.edit','下架',1504617552,'120.41.220.107'),(6857,1,6,'商品管理-修改','goods.edit','修改商品推荐状态   ID: 211',1504617557,'120.41.220.107'),(6858,1,6,'商品管理-修改','goods.edit','修改商品热卖状态   ID: 211',1504617558,'120.41.220.107'),(6859,1,6,'商品管理-修改','goods.edit','修改商品新品状态   ID: 211',1504617558,'120.41.220.107'),(6860,1,6,'商品管理-修改','goods.edit','修改商品促销状态   ID: 211',1504617560,'120.41.220.107'),(6861,1,6,'商品管理-修改','goods.edit','修改商品包邮状态   ID: 211',1504617560,'120.41.220.107'),(6862,1,6,'商品管理-修改','goods.edit','下架',1504617568,'120.41.220.107'),(6863,1,6,'商品管理-修改','goods.edit','下架',1504617577,'120.41.220.107'),(6864,1,6,'商品管理-修改','goods.edit','修改商品新品状态   ID: 209',1504617582,'120.41.220.107'),(6865,1,6,'商品管理-修改','goods.edit','修改商品热卖状态   ID: 209',1504617583,'120.41.220.107'),(6866,1,6,'商品管理-修改','goods.edit','修改商品推荐状态   ID: 209',1504617583,'120.41.220.107'),(6867,1,6,'商品管理-修改','goods.edit','修改商品新品状态   ID: 208',1504617584,'120.41.220.107'),(6868,1,6,'商品管理-修改','goods.edit','修改商品热卖状态   ID: 208',1504617585,'120.41.220.107'),(6869,1,6,'商品管理-修改','goods.edit','修改商品推荐状态   ID: 208',1504617585,'120.41.220.107'),(6870,1,6,'商品管理-修改','goods.edit','修改商品促销状态   ID: 208',1504617586,'120.41.220.107'),(6871,1,6,'商品管理-修改','goods.edit','修改商品促销状态   ID: 209',1504617586,'120.41.220.107'),(6872,1,6,'商品管理-修改','goods.edit','下架',1504617588,'120.41.220.107'),(6873,1,6,'商品管理-修改','goods.edit','下架',1504617591,'120.41.220.107'),(6874,1,6,'商品管理-修改','goods.edit','修改商品推荐状态   ID: 212',1504617596,'120.41.220.107'),(6875,1,6,'商品管理-修改','goods.edit','修改商品热卖状态   ID: 212',1504617597,'120.41.220.107'),(6876,1,6,'商品管理-修改','goods.edit','修改商品新品状态   ID: 212',1504617598,'120.41.220.107'),(6877,1,6,'商品管理-修改','goods.edit','修改商品促销状态   ID: 210',1504617601,'120.41.220.107'),(6878,1,6,'商品管理-修改','goods.edit','修改商品推荐状态   ID: 210',1504617602,'120.41.220.107'),(6879,1,6,'商品管理-修改','goods.edit','编辑商品 ID: 210<br>是否参与分销 -- 是',1504617770,'120.41.220.107'),(6880,1,6,'店铺装修-系统页面-另存为模板','diypage.page.sys.savetemp','另存为模板 名称:首页_所有插件',1504618253,'120.41.220.107'),(6881,1,6,'店铺装修-系统页面-添加','diypage.page.sys.add','添加系统页面 id: 19  名称:我的首页  关键字: 首页',1504618368,'120.41.220.107');
/*!40000 ALTER TABLE `ims_ewei_shop_perm_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_perm_plugin`
--

DROP TABLE IF EXISTS `ims_ewei_shop_perm_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_perm_plugin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) DEFAULT '0',
  `uid` int(11) DEFAULT '0',
  `type` tinyint(3) DEFAULT '0',
  `plugins` text,
  `coms` text,
  `datas` text,
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`uid`),
  KEY `idx_acid` (`acid`),
  KEY `idx_type` (`type`),
  KEY `idx_uniacid` (`acid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_perm_plugin`
--

LOCK TABLES `ims_ewei_shop_perm_plugin` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_perm_plugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_perm_plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_perm_role`
--

DROP TABLE IF EXISTS `ims_ewei_shop_perm_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_perm_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `rolename` varchar(255) DEFAULT '',
  `status` tinyint(3) DEFAULT '0',
  `perms` text,
  `deleted` tinyint(3) DEFAULT '0',
  `perms2` text,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_status` (`status`),
  KEY `idx_deleted` (`deleted`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_perm_role`
--

LOCK TABLES `ims_ewei_shop_perm_role` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_perm_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_perm_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_perm_user`
--

DROP TABLE IF EXISTS `ims_ewei_shop_perm_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_perm_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `uid` int(11) DEFAULT '0',
  `username` varchar(255) DEFAULT '',
  `password` varchar(255) DEFAULT '',
  `roleid` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `perms` text,
  `deleted` tinyint(3) DEFAULT '0',
  `realname` varchar(255) DEFAULT '',
  `mobile` varchar(255) DEFAULT '',
  `perms2` text,
  `openid` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_uid` (`uid`),
  KEY `idx_roleid` (`roleid`),
  KEY `idx_status` (`status`),
  KEY `idx_deleted` (`deleted`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_perm_user`
--

LOCK TABLES `ims_ewei_shop_perm_user` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_perm_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_perm_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_plugin`
--

DROP TABLE IF EXISTS `ims_ewei_shop_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_plugin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `displayorder` int(11) DEFAULT '0',
  `identity` varchar(50) DEFAULT '',
  `name` varchar(50) DEFAULT '',
  `version` varchar(10) DEFAULT '',
  `author` varchar(20) DEFAULT '',
  `status` int(11) DEFAULT '0',
  `category` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `desc` text,
  `iscom` tinyint(3) DEFAULT '0',
  `deprecated` tinyint(3) DEFAULT '0',
  `isv2` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_displayorder` (`displayorder`),
  KEY `idx_identity` (`identity`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_plugin`
--

LOCK TABLES `ims_ewei_shop_plugin` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_plugin` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_plugin` VALUES (1,1,'qiniu','七牛存储','1.0','官方',1,'tool','../addons/ewei_shopv2/static/images/qiniu.jpg',NULL,1,0,0),(2,2,'taobao','商品助手','1.0','官方',1,'tool','../addons/ewei_shopv2/static/images/taobao.jpg','',0,0,0),(3,3,'commission','人人分销','1.0','官方',1,'biz','../addons/ewei_shopv2/static/images/commission.jpg','',0,0,0),(4,4,'poster','超级海报','1.2','官方',1,'sale','../addons/ewei_shopv2/static/images/poster.jpg','',0,0,0),(5,5,'verify','O2O核销','1.0','官方',1,'biz','../addons/ewei_shopv2/static/images/verify.jpg',NULL,1,0,0),(6,6,'tmessage','会员群发','1.0','官方',1,'tool','../addons/ewei_shopv2/static/images/tmessage.jpg',NULL,1,0,0),(7,7,'perm','分权系统','1.0','官方',1,'help','../addons/ewei_shopv2/static/images/perm.jpg',NULL,1,0,0),(8,8,'sale','营销宝','1.0','官方',1,'sale','../addons/ewei_shopv2/static/images/sale.jpg',NULL,1,0,0),(9,9,'designer','店铺装修V1','1.0','官方',1,'help','../addons/ewei_shopv2/static/images/designer.jpg',NULL,0,1,0),(10,10,'creditshop','积分商城','1.0','官方',1,'biz','../addons/ewei_shopv2/static/images/creditshop.jpg','',0,0,0),(11,11,'virtual','虚拟物品','1.0','官方',1,'biz','../addons/ewei_shopv2/static/images/virtual.jpg',NULL,1,0,0),(12,11,'article','文章营销','1.0','官方',1,'help','../addons/ewei_shopv2/static/images/article.jpg','',0,0,0),(13,13,'coupon','超级券','1.0','官方',1,'sale','../addons/ewei_shopv2/static/images/coupon.jpg',NULL,1,0,0),(14,14,'postera','活动海报','1.0','官方',1,'sale','../addons/ewei_shopv2/static/images/postera.jpg','',0,0,0),(15,16,'system','系统工具','1.0','官方',0,'help','../addons/ewei_shopv2/static/images/system.jpg',NULL,0,1,0),(16,15,'diyform','自定表单','1.0','官方',1,'help','../addons/ewei_shopv2/static/images/diyform.jpg','',0,0,0),(17,16,'exhelper','快递助手','1.0','官方',1,'help','../addons/ewei_shopv2/static/images/exhelper.jpg','',0,0,0),(18,19,'groups','人人拼团','1.0','官方',1,'biz','../addons/ewei_shopv2/static/images/groups.jpg','',0,0,0),(19,20,'diypage','店铺装修','2.0','官方',1,'help','../addons/ewei_shopv2/static/images/designer.jpg','',0,0,0),(20,22,'globonus','全民股东','1.0','官方',1,'biz','../addons/ewei_shopv2/static/images/globonus.jpg','',0,0,0),(21,23,'merch','多商户','1.0','官方',1,'biz','../addons/ewei_shopv2/static/images/merch.jpg','',0,0,1),(22,26,'qa','帮助中心','1.0','官方',1,'help','../addons/ewei_shopv2/static/images/qa.jpg','',0,0,1),(24,27,'sms','短信提醒','1.0','官方',1,'tool','../addons/ewei_shopv2/static/images/sms.jpg','',1,0,1),(25,29,'sign','积分签到','1.0','官方',1,'tool','../addons/ewei_shopv2/static/images/sign.jpg','',0,0,1),(26,30,'sns','全民社区','1.0','官方',1,'sale','../addons/ewei_shopv2/static/images/sns.jpg','',0,0,1),(27,33,'wap','全网通','1.0','官方',1,'tool','','',1,0,1),(28,34,'h5app','H5APP','1.0','官方',1,'tool','','',1,0,1),(29,26,'abonus','区域代理','1.0','官方',1,'biz','../addons/ewei_shopv2/static/images/abonus.jpg','',0,0,1),(30,33,'printer','小票打印机','1.0','官方',1,'tool','','',1,0,1),(31,34,'bargain','砍价活动','1.0','官方',1,'tool','../addons/ewei_shopv2/static/images/bargain.jpg','',0,0,1),(32,35,'task','任务中心','1.0','官方',1,'sale','../addons/ewei_shopv2/static/images/task.jpg','',0,0,1),(33,36,'cashier','收银台','1.0','官方',1,'biz','../addons/ewei_shopv2/static/images/cashier.jpg','',0,0,1),(34,37,'messages','消息群发','1.0','官方',1,'tool','../addons/ewei_shopv2/static/images/messages.jpg','',0,0,1),(35,38,'seckill','整点秒杀','1.0','官方',1,'sale','../addons/ewei_shopv2/static/images/seckill.jpg','',0,0,1),(36,39,'exchange','兑换中心','1.0','官方',1,'biz','../addons/ewei_shopv2/static/images/exchange.jpg','',0,0,1),(37,40,'lottery','游戏营销','1.0','官方',1,'biz','../addons/ewei_shopv2/static/images/lottery.jpg','',0,0,1),(38,41,'wxcard','微信卡券','1.0','官方',1,'sale','','',1,0,1),(39,42,'quick','快速购买','1.0','官方',1,'biz','../addons/ewei_shopv2/static/images/quick.jpg','',0,0,1),(40,43,'mmanage','手机端商家管理中心','1.0','官方',1,'tool','../addons/ewei_shopv2/static/images/mmanage.jpg','',0,0,1),(41,44,'pc','PC端','1.0','二开',1,'tool','../addons/ewei_shopv2/static/images/pc.jpg','',0,0,0),(42,45,'live','互动直播','1.0','官方',1,'sale','../addons/ewei_shopv2/static/images/live.jpg','',0,0,1),(43,46,'universalform','调研报名','1.0','官方',1,'sale','../addons/ewei_shopv2/static/images/dy.jpg','',0,0,1);
/*!40000 ALTER TABLE `ims_ewei_shop_plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_polyapi_key`
--

DROP TABLE IF EXISTS `ims_ewei_shop_polyapi_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_polyapi_key` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `merchid` int(11) NOT NULL DEFAULT '0',
  `appkey` varchar(200) NOT NULL DEFAULT '',
  `token` varchar(200) NOT NULL DEFAULT '',
  `appsecret` varchar(200) NOT NULL DEFAULT '',
  `createtime` int(11) NOT NULL DEFAULT '0',
  `updatetime` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_appkey` (`appkey`) USING BTREE,
  KEY `idx_token` (`token`) USING BTREE,
  KEY `idx_appsecret` (`appsecret`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_polyapi_key`
--

LOCK TABLES `ims_ewei_shop_polyapi_key` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_polyapi_key` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_polyapi_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_poster`
--

DROP TABLE IF EXISTS `ims_ewei_shop_poster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_poster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `type` tinyint(3) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `bg` varchar(255) DEFAULT '',
  `data` text,
  `keyword` varchar(255) DEFAULT '',
  `times` int(11) DEFAULT '0',
  `follows` int(11) DEFAULT '0',
  `isdefault` tinyint(3) DEFAULT '0',
  `resptitle` varchar(255) DEFAULT '',
  `respthumb` varchar(255) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  `respdesc` varchar(255) DEFAULT '',
  `respurl` varchar(255) DEFAULT '',
  `waittext` varchar(255) DEFAULT '',
  `oktext` varchar(255) DEFAULT '',
  `subcredit` int(11) DEFAULT '0',
  `submoney` decimal(10,2) DEFAULT '0.00',
  `reccredit` int(11) DEFAULT '0',
  `recmoney` decimal(10,2) DEFAULT '0.00',
  `paytype` tinyint(1) NOT NULL DEFAULT '0',
  `scantext` varchar(255) DEFAULT '',
  `subtext` varchar(255) DEFAULT '',
  `beagent` tinyint(3) DEFAULT '0',
  `bedown` tinyint(3) DEFAULT '0',
  `isopen` tinyint(3) DEFAULT '0',
  `opentext` varchar(255) DEFAULT '',
  `openurl` varchar(255) DEFAULT '',
  `templateid` varchar(255) DEFAULT '',
  `subpaycontent` text,
  `recpaycontent` varchar(255) DEFAULT '',
  `entrytext` varchar(255) DEFAULT '',
  `reccouponid` int(11) DEFAULT '0',
  `reccouponnum` int(11) DEFAULT '0',
  `subcouponid` int(11) DEFAULT '0',
  `subcouponnum` int(11) DEFAULT '0',
  `resptype` tinyint(3) DEFAULT '0',
  `resptext` text,
  `keyword2` varchar(255) DEFAULT '',
  `resptext11` text,
  `reward_totle` varchar(500) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_type` (`type`),
  KEY `idx_times` (`times`),
  KEY `idx_isdefault` (`isdefault`),
  KEY `idx_createtime` (`createtime`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_poster`
--

LOCK TABLES `ims_ewei_shop_poster` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_poster` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_poster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_poster_log`
--

DROP TABLE IF EXISTS `ims_ewei_shop_poster_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_poster_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `posterid` int(11) DEFAULT '0',
  `from_openid` varchar(255) DEFAULT '',
  `subcredit` int(11) DEFAULT '0',
  `submoney` decimal(10,2) DEFAULT '0.00',
  `reccredit` int(11) DEFAULT '0',
  `recmoney` decimal(10,2) DEFAULT '0.00',
  `createtime` int(11) DEFAULT '0',
  `reccouponid` int(11) DEFAULT '0',
  `reccouponnum` int(11) DEFAULT '0',
  `subcouponid` int(11) DEFAULT '0',
  `subcouponnum` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_openid` (`openid`),
  KEY `idx_createtime` (`createtime`),
  KEY `idx_posterid` (`posterid`),
  KEY `idx_from_openid` (`from_openid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_poster_log`
--

LOCK TABLES `ims_ewei_shop_poster_log` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_poster_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_poster_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_poster_qr`
--

DROP TABLE IF EXISTS `ims_ewei_shop_poster_qr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_poster_qr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(10) unsigned NOT NULL,
  `openid` varchar(100) NOT NULL DEFAULT '',
  `type` tinyint(3) DEFAULT '0',
  `sceneid` int(11) DEFAULT '0',
  `mediaid` varchar(255) DEFAULT '',
  `ticket` varchar(250) NOT NULL,
  `url` varchar(80) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `goodsid` int(11) DEFAULT '0',
  `qrimg` varchar(1000) DEFAULT '',
  `scenestr` varchar(255) DEFAULT '',
  `posterid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_acid` (`acid`),
  KEY `idx_sceneid` (`sceneid`),
  KEY `idx_type` (`type`),
  KEY `idx_openid` (`openid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_poster_qr`
--

LOCK TABLES `ims_ewei_shop_poster_qr` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_poster_qr` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_poster_qr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_poster_scan`
--

DROP TABLE IF EXISTS `ims_ewei_shop_poster_scan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_poster_scan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `posterid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `from_openid` varchar(255) DEFAULT '',
  `scantime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_posterid` (`posterid`),
  KEY `idx_scantime` (`scantime`),
  KEY `idx_openid` (`openid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_poster_scan`
--

LOCK TABLES `ims_ewei_shop_poster_scan` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_poster_scan` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_poster_scan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_postera`
--

DROP TABLE IF EXISTS `ims_ewei_shop_postera`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_postera` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `type` tinyint(3) DEFAULT '0',
  `days` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `bg` varchar(255) DEFAULT '',
  `data` text,
  `keyword` varchar(255) DEFAULT '',
  `isdefault` tinyint(3) DEFAULT '0',
  `resptitle` varchar(255) DEFAULT '',
  `respthumb` varchar(255) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  `respdesc` varchar(255) DEFAULT '',
  `respurl` varchar(255) DEFAULT '',
  `waittext` varchar(255) DEFAULT '',
  `oktext` varchar(255) DEFAULT '',
  `subcredit` int(11) DEFAULT '0',
  `submoney` decimal(10,2) DEFAULT '0.00',
  `reccredit` int(11) DEFAULT '0',
  `recmoney` decimal(10,2) DEFAULT '0.00',
  `scantext` varchar(255) DEFAULT '',
  `subtext` varchar(255) DEFAULT '',
  `beagent` tinyint(3) DEFAULT '0',
  `bedown` tinyint(3) DEFAULT '0',
  `isopen` tinyint(3) DEFAULT '0',
  `opentext` varchar(255) DEFAULT '',
  `openurl` varchar(255) DEFAULT '',
  `paytype` tinyint(1) NOT NULL DEFAULT '0',
  `subpaycontent` text,
  `recpaycontent` varchar(255) DEFAULT '',
  `templateid` varchar(255) DEFAULT '',
  `entrytext` varchar(255) DEFAULT '',
  `reccouponid` int(11) DEFAULT '0',
  `reccouponnum` int(11) DEFAULT '0',
  `subcouponid` int(11) DEFAULT '0',
  `subcouponnum` int(11) DEFAULT '0',
  `timestart` int(11) DEFAULT '0',
  `timeend` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  `goodsid` int(11) DEFAULT '0',
  `starttext` varchar(255) DEFAULT '',
  `endtext` varchar(255) DEFAULT NULL,
  `resptype` tinyint(3) DEFAULT '0',
  `resptext` text,
  `testflag` tinyint(1) DEFAULT '0',
  `keyword2` varchar(255) DEFAULT '',
  `reward_totle` varchar(500) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_type` (`type`),
  KEY `idx_isdefault` (`isdefault`),
  KEY `idx_createtime` (`createtime`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_postera`
--

LOCK TABLES `ims_ewei_shop_postera` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_postera` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_postera` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_postera_log`
--

DROP TABLE IF EXISTS `ims_ewei_shop_postera_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_postera_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `posterid` int(11) DEFAULT '0',
  `from_openid` varchar(255) DEFAULT '',
  `subcredit` int(11) DEFAULT '0',
  `submoney` decimal(10,2) DEFAULT '0.00',
  `reccredit` int(11) DEFAULT '0',
  `recmoney` decimal(10,2) DEFAULT '0.00',
  `createtime` int(11) DEFAULT '0',
  `reccouponid` int(11) DEFAULT '0',
  `reccouponnum` int(11) DEFAULT '0',
  `subcouponid` int(11) DEFAULT '0',
  `subcouponnum` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_openid` (`openid`),
  KEY `idx_createtime` (`createtime`),
  KEY `idx_posteraid` (`posterid`),
  KEY `idx_from_openid` (`from_openid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_postera_log`
--

LOCK TABLES `ims_ewei_shop_postera_log` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_postera_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_postera_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_postera_qr`
--

DROP TABLE IF EXISTS `ims_ewei_shop_postera_qr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_postera_qr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(10) unsigned NOT NULL,
  `openid` varchar(100) NOT NULL DEFAULT '',
  `posterid` int(11) DEFAULT '0',
  `type` tinyint(3) DEFAULT '0',
  `sceneid` int(11) DEFAULT '0',
  `mediaid` varchar(255) DEFAULT '',
  `ticket` varchar(250) NOT NULL,
  `url` varchar(80) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `goodsid` int(11) DEFAULT '0',
  `qrimg` varchar(1000) DEFAULT '',
  `expire` int(11) DEFAULT '0',
  `endtime` int(11) DEFAULT '0',
  `qrtime` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_acid` (`acid`),
  KEY `idx_sceneid` (`sceneid`),
  KEY `idx_type` (`type`),
  KEY `idx_posterid` (`posterid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_postera_qr`
--

LOCK TABLES `ims_ewei_shop_postera_qr` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_postera_qr` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_postera_qr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_qa_adv`
--

DROP TABLE IF EXISTS `ims_ewei_shop_qa_adv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_qa_adv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `advname` varchar(50) DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `enabled` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_enabled` (`enabled`),
  KEY `idx_displayorder` (`displayorder`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_qa_adv`
--

LOCK TABLES `ims_ewei_shop_qa_adv` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_qa_adv` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_qa_adv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_qa_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_qa_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_qa_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `displayorder` tinyint(3) unsigned DEFAULT '0',
  `enabled` tinyint(1) DEFAULT '1',
  `isrecommand` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_displayorder` (`displayorder`),
  KEY `idx_enabled` (`enabled`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_qa_category`
--

LOCK TABLES `ims_ewei_shop_qa_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_qa_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_qa_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_qa_question`
--

DROP TABLE IF EXISTS `ims_ewei_shop_qa_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_qa_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `cate` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext NOT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `isrecommand` tinyint(3) NOT NULL DEFAULT '0',
  `displayorder` int(11) NOT NULL DEFAULT '0',
  `createtime` int(11) NOT NULL DEFAULT '0',
  `lastedittime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_qa_question`
--

LOCK TABLES `ims_ewei_shop_qa_question` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_qa_question` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_qa_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_qa_set`
--

DROP TABLE IF EXISTS `ims_ewei_shop_qa_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_qa_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `showmember` tinyint(3) NOT NULL DEFAULT '0',
  `showtype` tinyint(3) NOT NULL DEFAULT '0',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `enter_title` varchar(255) NOT NULL DEFAULT '',
  `enter_img` varchar(255) NOT NULL DEFAULT '',
  `enter_desc` varchar(255) NOT NULL DEFAULT '',
  `share` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_unaicid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_qa_set`
--

LOCK TABLES `ims_ewei_shop_qa_set` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_qa_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_qa_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_quick`
--

DROP TABLE IF EXISTS `ims_ewei_shop_quick`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_quick` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keyword` varchar(255) DEFAULT NULL,
  `datas` mediumtext,
  `cart` tinyint(3) NOT NULL DEFAULT '0',
  `createtime` int(11) DEFAULT NULL,
  `lasttime` int(11) DEFAULT NULL,
  `share_title` varchar(255) DEFAULT NULL,
  `share_desc` varchar(255) DEFAULT NULL,
  `share_icon` varchar(255) DEFAULT NULL,
  `enter_title` varchar(255) DEFAULT NULL,
  `enter_desc` varchar(255) DEFAULT NULL,
  `enter_icon` varchar(255) DEFAULT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `merchid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_quick`
--

LOCK TABLES `ims_ewei_shop_quick` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_quick` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_quick` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_quick_adv`
--

DROP TABLE IF EXISTS `ims_ewei_shop_quick_adv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_quick_adv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `merchid` int(11) NOT NULL DEFAULT '0',
  `advname` varchar(50) DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `enabled` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_enabled` (`enabled`) USING BTREE,
  KEY `idx_displayorder` (`displayorder`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_quick_adv`
--

LOCK TABLES `ims_ewei_shop_quick_adv` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_quick_adv` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_quick_adv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_quick_cart`
--

DROP TABLE IF EXISTS `ims_ewei_shop_quick_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_quick_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `quickid` int(11) NOT NULL DEFAULT '0',
  `openid` varchar(100) DEFAULT '',
  `goodsid` int(11) DEFAULT '0',
  `total` int(11) DEFAULT '0',
  `marketprice` decimal(10,2) DEFAULT '0.00',
  `deleted` tinyint(1) DEFAULT '0',
  `optionid` int(11) DEFAULT '0',
  `createtime` int(11) DEFAULT '0',
  `diyformdataid` int(11) DEFAULT NULL,
  `diyformdata` text,
  `diyformfields` text,
  `diyformid` int(11) DEFAULT '0',
  `selected` tinyint(1) DEFAULT '1',
  `merchid` int(11) DEFAULT '0',
  `selectedadd` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_goodsid` (`goodsid`) USING BTREE,
  KEY `idx_openid` (`openid`) USING BTREE,
  KEY `idx_deleted` (`deleted`) USING BTREE,
  KEY `idx_merchid` (`merchid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_quick_cart`
--

LOCK TABLES `ims_ewei_shop_quick_cart` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_quick_cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_quick_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_refund_address`
--

DROP TABLE IF EXISTS `ims_ewei_shop_refund_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_refund_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `title` varchar(20) DEFAULT '',
  `name` varchar(20) DEFAULT '',
  `tel` varchar(20) DEFAULT '',
  `mobile` varchar(11) DEFAULT '',
  `province` varchar(30) DEFAULT '',
  `city` varchar(30) DEFAULT '',
  `area` varchar(30) DEFAULT '',
  `address` varchar(300) DEFAULT '',
  `isdefault` tinyint(1) DEFAULT '0',
  `zipcode` varchar(255) DEFAULT '',
  `content` text,
  `deleted` tinyint(1) DEFAULT '0',
  `openid` varchar(50) DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_openid` (`openid`),
  KEY `idx_isdefault` (`isdefault`),
  KEY `idx_deleted` (`deleted`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_refund_address`
--

LOCK TABLES `ims_ewei_shop_refund_address` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_refund_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_refund_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sale_coupon`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sale_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sale_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT '',
  `type` tinyint(3) DEFAULT '0',
  `ckey` decimal(10,2) DEFAULT '0.00',
  `cvalue` decimal(10,2) DEFAULT '0.00',
  `nums` int(11) DEFAULT '0',
  `createtime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_createtime` (`createtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sale_coupon`
--

LOCK TABLES `ims_ewei_shop_sale_coupon` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sale_coupon` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sale_coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sale_coupon_data`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sale_coupon_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sale_coupon_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `couponid` int(11) DEFAULT '0',
  `gettime` int(11) DEFAULT '0',
  `gettype` tinyint(3) DEFAULT '0',
  `usedtime` int(11) DEFAULT '0',
  `orderid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_couponid` (`couponid`),
  KEY `idx_gettime` (`gettime`),
  KEY `idx_gettype` (`gettype`),
  KEY `idx_usedtime` (`usedtime`),
  KEY `idx_orderid` (`orderid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sale_coupon_data`
--

LOCK TABLES `ims_ewei_shop_sale_coupon_data` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sale_coupon_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sale_coupon_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_saler`
--

DROP TABLE IF EXISTS `ims_ewei_shop_saler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_saler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `storeid` int(11) DEFAULT '0',
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `status` tinyint(3) DEFAULT '0',
  `salername` varchar(255) DEFAULT '',
  `username` varchar(50) DEFAULT '',
  `pwd` varchar(255) DEFAULT '',
  `salt` varchar(255) DEFAULT '',
  `lastvisit` varchar(255) DEFAULT '',
  `lastip` varchar(255) DEFAULT '',
  `isfounder` tinyint(3) DEFAULT '0',
  `mobile` varchar(255) DEFAULT '',
  `getmessage` tinyint(1) DEFAULT '0',
  `getnotice` tinyint(1) DEFAULT '0',
  `roleid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_storeid` (`storeid`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_saler`
--

LOCK TABLES `ims_ewei_shop_saler` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_saler` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_saler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_seckill_adv`
--

DROP TABLE IF EXISTS `ims_ewei_shop_seckill_adv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_seckill_adv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `advname` varchar(50) DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `enabled` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_displayorder` (`displayorder`) USING BTREE,
  KEY `idx_enabled` (`enabled`) USING BTREE,
  KEY `idx_uniacid` (`uniacid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_seckill_adv`
--

LOCK TABLES `ims_ewei_shop_seckill_adv` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_seckill_adv` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_seckill_adv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_seckill_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_seckill_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_seckill_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_seckill_category`
--

LOCK TABLES `ims_ewei_shop_seckill_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_seckill_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_seckill_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_seckill_task`
--

DROP TABLE IF EXISTS `ims_ewei_shop_seckill_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_seckill_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `cateid` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `enabled` tinyint(3) DEFAULT '0',
  `page_title` varchar(255) DEFAULT '',
  `share_title` varchar(255) DEFAULT '',
  `share_desc` varchar(255) DEFAULT '',
  `share_icon` varchar(255) DEFAULT '',
  `tag` varchar(10) DEFAULT '',
  `closesec` int(11) DEFAULT '0',
  `oldshow` tinyint(3) DEFAULT '0',
  `times` text,
  `createtime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_status` (`enabled`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_seckill_task`
--

LOCK TABLES `ims_ewei_shop_seckill_task` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_seckill_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_seckill_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_seckill_task_goods`
--

DROP TABLE IF EXISTS `ims_ewei_shop_seckill_task_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_seckill_task_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `taskid` int(11) DEFAULT '0',
  `roomid` int(11) DEFAULT '0',
  `timeid` int(11) DEFAULT '0',
  `goodsid` int(11) DEFAULT '0',
  `optionid` int(11) DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `total` int(11) DEFAULT '0',
  `maxbuy` int(11) DEFAULT '0',
  `totalmaxbuy` int(11) DEFAULT '0',
  `commission1` decimal(10,2) DEFAULT '0.00',
  `commission2` decimal(10,2) DEFAULT '0.00',
  `commission3` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`) USING BTREE,
  KEY `idx_goodsid` (`goodsid`) USING BTREE,
  KEY `idx_optionid` (`optionid`) USING BTREE,
  KEY `idx_displayorder` (`displayorder`) USING BTREE,
  KEY `idx_taskid` (`taskid`) USING BTREE,
  KEY `idx_roomid` (`roomid`) USING BTREE,
  KEY `idx_time` (`timeid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_seckill_task_goods`
--

LOCK TABLES `ims_ewei_shop_seckill_task_goods` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_seckill_task_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_seckill_task_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_seckill_task_room`
--

DROP TABLE IF EXISTS `ims_ewei_shop_seckill_task_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_seckill_task_room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `taskid` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `enabled` tinyint(3) DEFAULT '0',
  `page_title` varchar(255) DEFAULT '',
  `share_title` varchar(255) DEFAULT '',
  `share_desc` varchar(255) DEFAULT '',
  `share_icon` varchar(255) DEFAULT '',
  `oldshow` tinyint(3) DEFAULT '0',
  `tag` varchar(10) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  `diypage` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_taskid` (`taskid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_seckill_task_room`
--

LOCK TABLES `ims_ewei_shop_seckill_task_room` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_seckill_task_room` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_seckill_task_room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_seckill_task_time`
--

DROP TABLE IF EXISTS `ims_ewei_shop_seckill_task_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_seckill_task_time` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `taskid` int(11) DEFAULT '0',
  `time` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_seckill_task_time`
--

LOCK TABLES `ims_ewei_shop_seckill_task_time` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_seckill_task_time` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_seckill_task_time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sendticket`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sendticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sendticket` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `cpid` varchar(200) NOT NULL,
  `expiration` int(11) NOT NULL DEFAULT '0',
  `starttime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `createtime` int(11) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '新人礼包',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sendticket`
--

LOCK TABLES `ims_ewei_shop_sendticket` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sendticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sendticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sendticket_draw`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sendticket_draw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sendticket_draw` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `cpid` varchar(50) NOT NULL,
  `openid` varchar(200) NOT NULL,
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sendticket_draw`
--

LOCK TABLES `ims_ewei_shop_sendticket_draw` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sendticket_draw` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sendticket_draw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sendticket_share`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sendticket_share`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sendticket_share` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `sharetitle` varchar(255) NOT NULL,
  `shareicon` varchar(255) DEFAULT NULL,
  `sharedesc` varchar(255) DEFAULT NULL,
  `expiration` int(11) NOT NULL DEFAULT '0',
  `starttime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `paycpid1` int(11) DEFAULT NULL,
  `paycpid2` int(11) DEFAULT NULL,
  `paycpid3` int(11) DEFAULT NULL,
  `paycpnum1` int(11) DEFAULT NULL,
  `paycpnum2` int(11) DEFAULT NULL,
  `paycpnum3` int(11) DEFAULT NULL,
  `sharecpid1` int(11) DEFAULT NULL,
  `sharecpid2` int(11) DEFAULT NULL,
  `sharecpid3` int(11) DEFAULT NULL,
  `sharecpnum1` int(11) DEFAULT NULL,
  `sharecpnum2` int(11) DEFAULT NULL,
  `sharecpnum3` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `createtime` int(11) NOT NULL,
  `order` int(11) DEFAULT NULL,
  `enough` decimal(10,2) DEFAULT NULL,
  `issync` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sendticket_share`
--

LOCK TABLES `ims_ewei_shop_sendticket_share` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sendticket_share` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sendticket_share` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sign_records`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sign_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sign_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  `openid` varchar(50) NOT NULL DEFAULT '',
  `credit` int(11) NOT NULL DEFAULT '0',
  `log` varchar(255) DEFAULT '',
  `type` tinyint(3) NOT NULL DEFAULT '0',
  `day` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_time` (`time`),
  KEY `idx_type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=602 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sign_records`
--

LOCK TABLES `ims_ewei_shop_sign_records` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sign_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sign_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sign_set`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sign_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sign_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `iscenter` tinyint(3) NOT NULL DEFAULT '0',
  `iscreditshop` tinyint(3) NOT NULL DEFAULT '0',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `desc` varchar(255) NOT NULL DEFAULT '',
  `isopen` tinyint(3) NOT NULL DEFAULT '0',
  `signold` tinyint(3) NOT NULL DEFAULT '0',
  `signold_price` int(11) NOT NULL DEFAULT '0',
  `signold_type` tinyint(3) NOT NULL DEFAULT '0',
  `textsign` varchar(255) NOT NULL DEFAULT '',
  `textsignold` varchar(255) NOT NULL DEFAULT '',
  `textsigned` varchar(255) NOT NULL DEFAULT '',
  `textsignforget` varchar(255) NOT NULL DEFAULT '',
  `maincolor` varchar(20) NOT NULL DEFAULT '',
  `cycle` tinyint(3) NOT NULL DEFAULT '0',
  `reward_default_first` int(11) NOT NULL DEFAULT '0',
  `reward_default_day` int(11) NOT NULL DEFAULT '0',
  `reword_order` text NOT NULL,
  `reword_sum` text NOT NULL,
  `reword_special` text NOT NULL,
  `sign_rule` text NOT NULL,
  `share` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sign_set`
--

LOCK TABLES `ims_ewei_shop_sign_set` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sign_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sign_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sign_user`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sign_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sign_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `order` int(11) NOT NULL DEFAULT '0',
  `orderday` int(11) NOT NULL DEFAULT '0',
  `sum` int(11) NOT NULL DEFAULT '0',
  `signdate` varchar(10) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=146 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sign_user`
--

LOCK TABLES `ims_ewei_shop_sign_user` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sign_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sign_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sms`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(10) NOT NULL DEFAULT '',
  `template` tinyint(3) NOT NULL DEFAULT '0',
  `smstplid` varchar(255) NOT NULL DEFAULT '',
  `smssign` varchar(255) NOT NULL DEFAULT '',
  `content` varchar(100) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sms`
--

LOCK TABLES `ims_ewei_shop_sms` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sms` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sms_set`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sms_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sms_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `juhe` tinyint(3) NOT NULL DEFAULT '0',
  `juhe_key` varchar(255) NOT NULL DEFAULT '',
  `dayu` tinyint(3) NOT NULL DEFAULT '0',
  `dayu_key` varchar(255) NOT NULL DEFAULT '',
  `dayu_secret` varchar(255) NOT NULL DEFAULT '',
  `emay` tinyint(3) NOT NULL DEFAULT '0',
  `emay_url` varchar(255) NOT NULL DEFAULT '',
  `emay_sn` varchar(255) NOT NULL DEFAULT '',
  `emay_pw` varchar(255) NOT NULL DEFAULT '',
  `emay_sk` varchar(255) NOT NULL DEFAULT '',
  `emay_phost` varchar(255) NOT NULL DEFAULT '',
  `emay_pport` int(11) NOT NULL DEFAULT '0',
  `emay_puser` varchar(255) NOT NULL DEFAULT '',
  `emay_ppw` varchar(255) NOT NULL DEFAULT '',
  `emay_out` int(11) NOT NULL DEFAULT '0',
  `emay_outresp` int(11) NOT NULL DEFAULT '30',
  `emay_warn` decimal(10,2) NOT NULL DEFAULT '0.00',
  `emay_mobile` varchar(11) NOT NULL DEFAULT '',
  `emay_warn_time` int(11) NOT NULL DEFAULT '0',
  `aliyun` tinyint(3) NOT NULL DEFAULT '0',
  `aliyun_appcode` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sms_set`
--

LOCK TABLES `ims_ewei_shop_sms_set` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sms_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sms_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sns_adv`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sns_adv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sns_adv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `advname` varchar(50) DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `enabled` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_enabled` (`enabled`),
  KEY `idx_displayorder` (`displayorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sns_adv`
--

LOCK TABLES `ims_ewei_shop_sns_adv` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_adv` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_adv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sns_board`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sns_board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sns_board` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `cid` int(11) DEFAULT '0',
  `title` varchar(50) DEFAULT '',
  `logo` varchar(255) DEFAULT '',
  `desc` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `enabled` int(11) DEFAULT '0',
  `showgroups` text,
  `showlevels` text,
  `postgroups` text,
  `postlevels` text,
  `showagentlevels` text,
  `postagentlevels` text,
  `postcredit` int(11) DEFAULT '0',
  `replycredit` int(11) DEFAULT '0',
  `bestcredit` int(11) DEFAULT '0',
  `bestboardcredit` int(11) DEFAULT '0',
  `notagent` tinyint(3) DEFAULT '0',
  `notagentpost` tinyint(3) DEFAULT '0',
  `topcredit` int(11) DEFAULT '0',
  `topboardcredit` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  `noimage` tinyint(3) DEFAULT '0',
  `novoice` tinyint(3) DEFAULT '0',
  `needfollow` tinyint(3) DEFAULT '0',
  `needpostfollow` tinyint(3) DEFAULT '0',
  `share_title` varchar(255) DEFAULT '',
  `share_icon` varchar(255) DEFAULT '',
  `share_desc` varchar(255) DEFAULT '',
  `keyword` varchar(255) DEFAULT '',
  `isrecommand` tinyint(3) DEFAULT '0',
  `banner` varchar(255) DEFAULT '',
  `needcheck` tinyint(3) DEFAULT '0',
  `needcheckmanager` tinyint(3) DEFAULT '0',
  `needcheckreply` int(11) DEFAULT '0',
  `needcheckreplymanager` int(11) DEFAULT '0',
  `showsnslevels` text,
  `postsnslevels` text,
  `showpartnerlevels` text,
  `postpartnerlevels` text,
  `notpartner` tinyint(3) DEFAULT '0',
  `notpartnerpost` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_enabled` (`enabled`),
  KEY `idx_displayorder` (`displayorder`),
  KEY `idx_cid` (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sns_board`
--

LOCK TABLES `ims_ewei_shop_sns_board` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_board` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_board` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sns_board_follow`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sns_board_follow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sns_board_follow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `bid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `createtime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_bid` (`bid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sns_board_follow`
--

LOCK TABLES `ims_ewei_shop_sns_board_follow` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_board_follow` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_board_follow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sns_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sns_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sns_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `displayorder` tinyint(3) unsigned DEFAULT '0',
  `enabled` tinyint(1) DEFAULT '1',
  `advimg` varchar(255) DEFAULT '',
  `advurl` varchar(500) DEFAULT '',
  `isrecommand` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_enabled` (`enabled`),
  KEY `idx_isrecommand` (`isrecommand`),
  KEY `idx_displayorder` (`displayorder`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sns_category`
--

LOCK TABLES `ims_ewei_shop_sns_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sns_complain`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sns_complain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sns_complain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `type` tinyint(3) NOT NULL,
  `postsid` int(11) NOT NULL DEFAULT '0',
  `defendant` varchar(255) NOT NULL DEFAULT '0',
  `complainant` varchar(255) NOT NULL DEFAULT '0',
  `complaint_type` int(10) NOT NULL DEFAULT '0',
  `complaint_text` text NOT NULL,
  `images` text NOT NULL,
  `createtime` int(11) NOT NULL DEFAULT '0',
  `checkedtime` int(11) NOT NULL DEFAULT '0',
  `checked` tinyint(3) NOT NULL DEFAULT '0',
  `checked_note` varchar(255) NOT NULL,
  `deleted` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sns_complain`
--

LOCK TABLES `ims_ewei_shop_sns_complain` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_complain` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_complain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sns_complaincate`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sns_complaincate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sns_complaincate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `displayorder` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sns_complaincate`
--

LOCK TABLES `ims_ewei_shop_sns_complaincate` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_complaincate` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_complaincate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sns_level`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sns_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sns_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `levelname` varchar(255) DEFAULT '',
  `credit` int(11) DEFAULT '0',
  `enabled` tinyint(3) DEFAULT '0',
  `post` int(11) DEFAULT '0',
  `color` varchar(255) DEFAULT '',
  `bg` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sns_level`
--

LOCK TABLES `ims_ewei_shop_sns_level` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_level` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sns_like`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sns_like`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sns_like` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `pid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_pid` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sns_like`
--

LOCK TABLES `ims_ewei_shop_sns_like` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_like` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_like` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sns_manage`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sns_manage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sns_manage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `bid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `enabled` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_bid` (`bid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sns_manage`
--

LOCK TABLES `ims_ewei_shop_sns_manage` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_manage` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_manage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sns_member`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sns_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sns_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `level` int(11) DEFAULT '0',
  `createtime` int(11) DEFAULT '0',
  `credit` int(11) DEFAULT '0',
  `sign` varchar(255) DEFAULT '',
  `isblack` tinyint(3) DEFAULT '0',
  `notupgrade` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sns_member`
--

LOCK TABLES `ims_ewei_shop_sns_member` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sns_post`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sns_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sns_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `bid` int(11) DEFAULT '0',
  `pid` int(11) DEFAULT '0',
  `rpid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '',
  `avatar` varchar(255) DEFAULT '',
  `nickname` varchar(255) DEFAULT '',
  `title` varchar(50) DEFAULT '',
  `content` text,
  `images` text,
  `voice` varchar(255) DEFAULT NULL,
  `createtime` int(11) DEFAULT '0',
  `replytime` int(11) DEFAULT '0',
  `credit` int(11) DEFAULT '0',
  `views` int(11) DEFAULT '0',
  `islock` tinyint(1) DEFAULT '0',
  `istop` tinyint(1) DEFAULT '0',
  `isboardtop` tinyint(1) DEFAULT '0',
  `isbest` tinyint(1) DEFAULT '0',
  `isboardbest` tinyint(3) DEFAULT '0',
  `deleted` tinyint(3) DEFAULT '0',
  `deletedtime` int(11) DEFAULT '0',
  `checked` tinyint(3) DEFAULT NULL,
  `checktime` int(11) DEFAULT '0',
  `isadmin` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_bid` (`bid`),
  KEY `idx_pid` (`pid`),
  KEY `idx_createtime` (`createtime`),
  KEY `idx_islock` (`islock`),
  KEY `idx_istop` (`istop`),
  KEY `idx_isboardtop` (`isboardtop`),
  KEY `idx_isbest` (`isbest`),
  KEY `idx_deleted` (`deleted`),
  KEY `idx_deletetime` (`deletedtime`),
  KEY `idx_checked` (`checked`),
  KEY `idx_rpid` (`rpid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sns_post`
--

LOCK TABLES `ims_ewei_shop_sns_post` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_post` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_sns_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_store`
--

DROP TABLE IF EXISTS `ims_ewei_shop_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `storename` varchar(255) DEFAULT '',
  `address` varchar(255) DEFAULT '',
  `tel` varchar(255) DEFAULT '',
  `lat` varchar(255) DEFAULT '',
  `lng` varchar(255) DEFAULT '',
  `status` tinyint(3) DEFAULT '0',
  `realname` varchar(255) DEFAULT '',
  `mobile` varchar(255) DEFAULT '',
  `fetchtime` varchar(255) DEFAULT '',
  `type` tinyint(1) DEFAULT '0',
  `logo` varchar(255) DEFAULT '',
  `saletime` varchar(255) DEFAULT '',
  `desc` text,
  `displayorder` int(11) DEFAULT '0',
  `order_printer` varchar(500) DEFAULT '',
  `order_template` int(11) DEFAULT '0',
  `ordertype` varchar(500) DEFAULT '',
  `banner` text,
  `label` varchar(255) DEFAULT NULL,
  `tag` varchar(255) DEFAULT NULL,
  `classify` tinyint(1) DEFAULT NULL,
  `perms` text,
  `citycode` varchar(20) DEFAULT '',
  `opensend` tinyint(3) NOT NULL DEFAULT '0',
  `province` varchar(30) NOT NULL DEFAULT '',
  `city` varchar(30) NOT NULL DEFAULT '',
  `area` varchar(30) NOT NULL DEFAULT '',
  `provincecode` varchar(30) NOT NULL DEFAULT '',
  `areacode` varchar(30) NOT NULL DEFAULT '',
  `diypage` int(11) NOT NULL DEFAULT '0',
  `diypage_ispage` tinyint(3) NOT NULL DEFAULT '0',
  `diypage_list` text,
  `storegroupid` int(11) DEFAULT NULL,
  `cates` text,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_store`
--

LOCK TABLES `ims_ewei_shop_store` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_sysset`
--

DROP TABLE IF EXISTS `ims_ewei_shop_sysset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_sysset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `sets` longtext,
  `plugins` longtext,
  `sec` text,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_sysset`
--

LOCK TABLES `ims_ewei_shop_sysset` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_sysset` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_sysset` VALUES (11,6,'a:5:{s:4:\"shop\";a:19:{s:4:\"name\";s:9:\"融惠联\";s:4:\"logo\";s:51:\"images/6/2017/09/sTK6rdRr2d2T8m2AAireBB82MAMZpM.png\";s:11:\"description\";s:9:\"融惠联\";s:3:\"img\";s:0:\"\";s:7:\"signimg\";s:0:\"\";s:7:\"getinfo\";s:1:\"1\";s:7:\"saleout\";s:0:\"\";s:7:\"loading\";s:0:\"\";s:7:\"diycode\";s:0:\"\";s:6:\"funbar\";s:1:\"0\";s:5:\"style\";s:3:\"new\";s:8:\"catlevel\";s:1:\"3\";s:7:\"catshow\";s:1:\"0\";s:9:\"catadvimg\";s:0:\"\";s:9:\"catadvurl\";s:0:\"\";s:11:\"bannerswipe\";i:0;s:5:\"cubes\";a:4:{i:0;a:2:{s:3:\"img\";s:51:\"images/6/2017/09/nnNjMAgGqNgs3g800ZnDY40AM8QSam.jpg\";s:3:\"url\";s:0:\"\";}i:1;a:2:{s:3:\"img\";s:51:\"images/6/2017/09/a9Jw7fAhmwzvF7t98P70W11VAaxXZf.jpg\";s:3:\"url\";s:0:\"\";}i:2;a:2:{s:3:\"img\";s:51:\"images/6/2017/09/Xj5aP3Zk7r3J3p3Vt33Yt8K86R0KIu.jpg\";s:3:\"url\";s:0:\"\";}i:3;a:2:{s:3:\"img\";s:51:\"images/6/2017/09/KM997qmpN8M9N078DHiM88mhp90q8H.jpg\";s:3:\"url\";s:0:\"\";}}s:15:\"indexrecommands\";a:2:{i:0;s:3:\"199\";i:1;s:3:\"203\";}s:9:\"indexsort\";a:8:{s:3:\"adv\";a:2:{s:4:\"text\";s:9:\"幻灯片\";s:7:\"visible\";i:1;}s:6:\"search\";a:2:{s:4:\"text\";s:9:\"搜索栏\";s:7:\"visible\";i:1;}s:3:\"nav\";a:2:{s:4:\"text\";s:9:\"导航栏\";s:7:\"visible\";i:1;}s:6:\"notice\";a:2:{s:4:\"text\";s:9:\"公告栏\";s:7:\"visible\";i:1;}s:7:\"seckill\";a:2:{s:4:\"text\";s:9:\"秒杀栏\";s:7:\"visible\";i:1;}s:4:\"cube\";a:2:{s:4:\"text\";s:9:\"魔方栏\";s:7:\"visible\";i:1;}s:6:\"banner\";a:2:{s:4:\"text\";s:9:\"广告栏\";s:7:\"visible\";i:1;}s:5:\"goods\";a:2:{s:4:\"text\";s:9:\"推荐栏\";s:7:\"visible\";i:1;}}}s:8:\"template\";a:2:{s:5:\"style\";s:3:\"new\";s:11:\"detail_temp\";s:1:\"0\";}s:5:\"trade\";a:30:{s:12:\"set_realname\";s:1:\"0\";s:10:\"set_mobile\";s:1:\"0\";s:10:\"closeorder\";i:3;s:14:\"willcloseorder\";s:0:\"\";s:9:\"stockwarn\";s:0:\"\";s:7:\"receive\";s:0:\"\";s:10:\"refunddays\";s:0:\"\";s:13:\"refundcontent\";s:0:\"\";s:10:\"credittext\";s:6:\"积分\";s:9:\"moneytext\";s:6:\"余额\";s:13:\"closerecharge\";s:1:\"0\";s:5:\"money\";s:0:\"\";s:6:\"credit\";s:1:\"0\";s:13:\"minimumcharge\";d:0;s:8:\"withdraw\";s:1:\"0\";s:13:\"withdrawmoney\";s:0:\"\";s:14:\"withdrawcharge\";s:0:\"\";s:13:\"withdrawbegin\";d:0;s:11:\"withdrawend\";d:0;s:9:\"maxcredit\";s:1:\"0\";s:12:\"closecomment\";s:1:\"0\";s:16:\"closecommentshow\";s:1:\"0\";s:14:\"commentchecked\";s:1:\"0\";s:12:\"shareaddress\";s:1:\"1\";s:10:\"istimetext\";s:9:\"限时购\";s:15:\"nodispatchareas\";s:7:\"s:0:\"\";\";s:20:\"nodispatchareas_code\";s:7:\"s:0:\"\";\";s:18:\"withdrawcashweixin\";i:0;s:18:\"withdrawcashalipay\";i:0;s:16:\"withdrawcashcard\";i:0;}s:8:\"category\";a:5:{s:5:\"level\";s:1:\"3\";s:4:\"show\";s:1:\"0\";s:5:\"style\";s:1:\"0\";s:6:\"advimg\";s:0:\"\";s:6:\"advurl\";s:0:\"\";}s:3:\"pay\";a:11:{s:9:\"weixin_id\";i:0;s:6:\"weixin\";i:1;s:10:\"weixin_sub\";i:0;s:10:\"weixin_jie\";i:0;s:14:\"weixin_jie_sub\";i:0;s:6:\"alipay\";i:0;s:6:\"credit\";i:1;s:4:\"cash\";i:1;s:10:\"app_wechat\";i:0;s:10:\"app_alipay\";i:0;s:7:\"paytype\";a:3:{s:10:\"commission\";s:1:\"0\";s:8:\"withdraw\";s:1:\"0\";s:7:\"redpack\";s:1:\"0\";}}}','a:1:{s:4:\"sale\";a:9:{s:11:\"enoughmoney\";d:100;s:12:\"enoughdeduct\";d:2;s:7:\"enoughs\";a:2:{i:0;a:2:{s:6:\"enough\";d:200;s:4:\"give\";d:5;}i:1;a:2:{s:6:\"enough\";d:500;s:4:\"give\";d:20;}}s:10:\"enoughfree\";i:1;s:11:\"enoughorder\";d:99;s:11:\"enoughareas\";s:0:\"\";s:8:\"goodsids\";N;s:9:\"recharges\";s:162:\"a:3:{i:0;a:2:{s:6:\"enough\";s:3:\"100\";s:4:\"give\";s:1:\"1\";}i:1;a:2:{s:6:\"enough\";s:3:\"200\";s:4:\"give\";s:1:\"3\";}i:2;a:2:{s:6:\"enough\";s:3:\"300\";s:4:\"give\";s:1:\"5\";}}\";s:7:\"credit1\";s:401:\"a:3:{s:7:\"enough1\";a:2:{i:0;a:3:{s:9:\"enough1_1\";d:100;s:9:\"enough1_2\";d:199;s:5:\"give1\";d:10;}i:1;a:3:{s:9:\"enough1_1\";d:200;s:9:\"enough1_2\";d:9999;s:5:\"give1\";d:20;}}s:7:\"enough2\";a:2:{i:0;a:3:{s:9:\"enough2_1\";d:100;s:9:\"enough2_2\";d:199;s:5:\"give2\";d:10;}i:1;a:3:{s:9:\"enough2_1\";d:200;s:9:\"enough2_2\";d:999;s:5:\"give2\";d:20;}}s:7:\"paytype\";a:4:{i:1;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:3;s:1:\"1\";}}\";}}','a:3:{s:10:\"app_wechat\";a:5:{s:5:\"appid\";s:0:\"\";s:9:\"appsecret\";s:0:\"\";s:9:\"merchname\";s:0:\"\";s:7:\"merchid\";s:0:\"\";s:6:\"apikey\";s:0:\"\";}s:10:\"alipay_pay\";a:4:{s:7:\"partner\";s:0:\"\";s:12:\"account_name\";s:0:\"\";s:5:\"email\";s:0:\"\";s:3:\"key\";s:0:\"\";}s:10:\"app_alipay\";a:3:{s:10:\"public_key\";s:0:\"\";s:11:\"private_key\";s:0:\"\";s:5:\"appid\";s:0:\"\";}}');
/*!40000 ALTER TABLE `ims_ewei_shop_sysset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_adv`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_adv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_adv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `url` varchar(255) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `module` varchar(255) DEFAULT '',
  `status` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_adv`
--

LOCK TABLES `ims_ewei_shop_system_adv` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_adv` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_adv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_article`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT '',
  `author` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `content` text,
  `createtime` int(11) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `cate` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_article`
--

LOCK TABLES `ims_ewei_shop_system_article` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_banner`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `url` varchar(255) DEFAULT '',
  `createtime` int(11) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  `background` varchar(10) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_banner`
--

LOCK TABLES `ims_ewei_shop_system_banner` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_banner` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_case`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_case` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `qr` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  `cate` int(11) DEFAULT '0',
  `description` varchar(255) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_case`
--

LOCK TABLES `ims_ewei_shop_system_case` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_case` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_case` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_casecategory`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_casecategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_casecategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_casecategory`
--

LOCK TABLES `ims_ewei_shop_system_casecategory` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_casecategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_casecategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_category`
--

LOCK TABLES `ims_ewei_shop_system_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_company_article`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_company_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_company_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT '',
  `author` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `content` text,
  `createtime` int(11) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `cate` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_company_article`
--

LOCK TABLES `ims_ewei_shop_system_company_article` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_company_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_company_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_company_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_company_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_company_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_company_category`
--

LOCK TABLES `ims_ewei_shop_system_company_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_company_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_company_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_copyright`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_copyright`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_copyright` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT NULL,
  `copyright` text,
  `bgcolor` varchar(255) DEFAULT '',
  `ismanage` tinyint(3) DEFAULT '0',
  `logo` varchar(255) DEFAULT '',
  `title` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_copyright`
--

LOCK TABLES `ims_ewei_shop_system_copyright` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_copyright` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_copyright` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_copyright_notice`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_copyright_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_copyright_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT '',
  `author` varchar(255) DEFAULT '',
  `content` text,
  `createtime` int(11) DEFAULT '0',
  `displayorder` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_copyright_notice`
--

LOCK TABLES `ims_ewei_shop_system_copyright_notice` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_copyright_notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_copyright_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_guestbook`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_guestbook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_guestbook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` varchar(255) NOT NULL DEFAULT '',
  `nickname` varchar(255) NOT NULL DEFAULT '',
  `createtime` int(11) DEFAULT NULL,
  `email` varchar(255) NOT NULL DEFAULT '',
  `clientip` varchar(64) NOT NULL DEFAULT '',
  `mobile` varchar(11) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_guestbook`
--

LOCK TABLES `ims_ewei_shop_system_guestbook` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_guestbook` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_guestbook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_link`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `displayorder` int(11) DEFAULT NULL,
  `status` tinyint(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_link`
--

LOCK TABLES `ims_ewei_shop_system_link` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_plugingrant_adv`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_plugingrant_adv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_plugingrant_adv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advname` varchar(50) DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `enabled` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_enabled` (`enabled`) USING BTREE,
  KEY `idx_displayorder` (`displayorder`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_plugingrant_adv`
--

LOCK TABLES `ims_ewei_shop_system_plugingrant_adv` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_plugingrant_adv` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_plugingrant_adv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_plugingrant_log`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_plugingrant_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_plugingrant_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logno` varchar(50) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `pluginid` int(11) NOT NULL DEFAULT '0',
  `identity` varchar(50) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `month` int(10) NOT NULL DEFAULT '0',
  `permendtime` int(10) NOT NULL DEFAULT '0',
  `permlasttime` int(10) NOT NULL DEFAULT '0',
  `isperm` tinyint(3) NOT NULL DEFAULT '0',
  `createtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_plugingrant_log`
--

LOCK TABLES `ims_ewei_shop_system_plugingrant_log` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_plugingrant_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_plugingrant_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_plugingrant_order`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_plugingrant_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_plugingrant_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logno` varchar(50) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `pluginid` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `month` int(11) NOT NULL DEFAULT '0',
  `createtime` int(10) NOT NULL DEFAULT '0',
  `paystatus` tinyint(3) NOT NULL DEFAULT '0',
  `paytime` int(10) NOT NULL DEFAULT '0',
  `paytype` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_plugingrant_order`
--

LOCK TABLES `ims_ewei_shop_system_plugingrant_order` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_plugingrant_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_plugingrant_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_plugingrant_package`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_plugingrant_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_plugingrant_package` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pluginid` varchar(255) NOT NULL DEFAULT '',
  `text` varchar(255) DEFAULT NULL,
  `thumb` varchar(1000) DEFAULT NULL,
  `data` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `rec` tinyint(3) NOT NULL DEFAULT '0',
  `desc` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  `displayorder` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_plugingrant_package`
--

LOCK TABLES `ims_ewei_shop_system_plugingrant_package` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_plugingrant_package` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_plugingrant_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_plugingrant_plugin`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_plugingrant_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_plugingrant_plugin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pluginid` int(11) NOT NULL DEFAULT '0',
  `thumb` varchar(1000) NOT NULL,
  `data` text,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `sales` int(11) NOT NULL DEFAULT '0',
  `createtime` int(10) NOT NULL DEFAULT '0',
  `displayorder` int(11) NOT NULL DEFAULT '0',
  `plugintype` tinyint(3) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_plugingrant_plugin`
--

LOCK TABLES `ims_ewei_shop_system_plugingrant_plugin` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_plugingrant_plugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_plugingrant_plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_plugingrant_setting`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_plugingrant_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_plugingrant_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `com` varchar(1000) NOT NULL DEFAULT '',
  `adv` varchar(1000) NOT NULL,
  `plugin` varchar(1000) NOT NULL,
  `customer` varchar(50) NOT NULL DEFAULT '0',
  `contact` text NOT NULL,
  `servertime` varchar(255) DEFAULT NULL,
  `weixin` tinyint(3) NOT NULL DEFAULT '0',
  `appid` varchar(255) DEFAULT NULL,
  `mchid` varchar(255) DEFAULT NULL,
  `apikey` varchar(255) DEFAULT NULL,
  `alipay` tinyint(3) NOT NULL,
  `account` varchar(255) DEFAULT NULL,
  `partner` varchar(255) DEFAULT NULL,
  `secret` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_plugingrant_setting`
--

LOCK TABLES `ims_ewei_shop_system_plugingrant_setting` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_plugingrant_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_plugingrant_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_setting`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) DEFAULT NULL,
  `background` varchar(10) DEFAULT '',
  `casebanner` varchar(255) DEFAULT '',
  `contact` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_setting`
--

LOCK TABLES `ims_ewei_shop_system_setting` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_system_site`
--

DROP TABLE IF EXISTS `ims_ewei_shop_system_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_system_site` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(32) NOT NULL DEFAULT '',
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_system_site`
--

LOCK TABLES `ims_ewei_shop_system_site` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_system_site` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_system_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_task`
--

DROP TABLE IF EXISTS `ims_ewei_shop_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `type` int(11) NOT NULL,
  `starttime` int(11) NOT NULL,
  `endtime` int(11) NOT NULL,
  `dotime` int(11) NOT NULL DEFAULT '0',
  `donetime` int(11) NOT NULL DEFAULT '0',
  `timelimit` float(11,1) NOT NULL,
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `explain` text,
  `require_data` text NOT NULL,
  `reward_data` text NOT NULL,
  `period` int(11) NOT NULL DEFAULT '0',
  `repeat` int(11) NOT NULL DEFAULT '0',
  `maxtimes` int(11) NOT NULL DEFAULT '0',
  `everyhours` float(11,1) NOT NULL DEFAULT '0.0',
  `logo` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_task`
--

LOCK TABLES `ims_ewei_shop_task` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_task_adv`
--

DROP TABLE IF EXISTS `ims_ewei_shop_task_adv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_task_adv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `advname` varchar(50) DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `thumb` varchar(255) DEFAULT '',
  `displayorder` int(11) DEFAULT '0',
  `enabled` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_task_adv`
--

LOCK TABLES `ims_ewei_shop_task_adv` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_task_adv` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_task_adv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_task_default`
--

DROP TABLE IF EXISTS `ims_ewei_shop_task_default`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_task_default` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `data` text,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `bgimg` varchar(255) NOT NULL DEFAULT '',
  `open` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_task_default`
--

LOCK TABLES `ims_ewei_shop_task_default` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_task_default` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_task_default` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_task_extension`
--

DROP TABLE IF EXISTS `ims_ewei_shop_task_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_task_extension` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskname` varchar(255) NOT NULL DEFAULT '',
  `taskclass` varchar(25) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `classify` varchar(255) NOT NULL DEFAULT '',
  `classify_name` varchar(255) NOT NULL DEFAULT '',
  `verb` varchar(255) NOT NULL DEFAULT '',
  `unit` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_task_extension`
--

LOCK TABLES `ims_ewei_shop_task_extension` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_task_extension` DISABLE KEYS */;
INSERT INTO `ims_ewei_shop_task_extension` VALUES (1,'推荐人数','commission_member',1,'number','number','推荐','人'),(2,'分销佣金','commission_money',1,'number','number','达到','元'),(3,'分销订单','commission_order',1,'number','number','达到','笔'),(4,'订单满额','cost_enough',1,'number','number','满','元'),(5,'累计金额','cost_total',1,'number','number','累计','元'),(6,'订单数量','cost_count',1,'number','number','达到','单'),(7,'指定商品','cost_goods',1,'select','select','购买指定商品','件'),(8,'商品评价','cost_comment',1,'number','number','评价订单','次'),(9,'累计充值','cost_rechargetotal',1,'number','number','达到','元'),(10,'充值满额','cost_rechargeenough',1,'number','number','满','元'),(11,'完善信息','member_info',1,'boole','boole','填写手机号','');
/*!40000 ALTER TABLE `ims_ewei_shop_task_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_task_extension_join`
--

DROP TABLE IF EXISTS `ims_ewei_shop_task_extension_join`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_task_extension_join` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `uid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `openid` varchar(255) NOT NULL,
  `require_data` text NOT NULL,
  `progress_data` text NOT NULL,
  `reward_data` text NOT NULL,
  `completetime` int(11) NOT NULL DEFAULT '0',
  `pickuptime` int(11) NOT NULL,
  `endtime` int(11) NOT NULL,
  `dotime` int(11) NOT NULL DEFAULT '0',
  `rewarded` text NOT NULL,
  `logo` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_task_extension_join`
--

LOCK TABLES `ims_ewei_shop_task_extension_join` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_task_extension_join` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_task_extension_join` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_task_join`
--

DROP TABLE IF EXISTS `ims_ewei_shop_task_join`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_task_join` (
  `join_id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `join_user` varchar(100) NOT NULL DEFAULT '',
  `task_id` int(11) NOT NULL DEFAULT '0',
  `task_type` tinyint(1) NOT NULL DEFAULT '0',
  `needcount` int(11) NOT NULL DEFAULT '0',
  `completecount` int(11) NOT NULL DEFAULT '0',
  `reward_data` text,
  `is_reward` tinyint(1) NOT NULL DEFAULT '0',
  `failtime` int(11) NOT NULL DEFAULT '0',
  `addtime` int(11) DEFAULT '0',
  PRIMARY KEY (`join_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_task_join`
--

LOCK TABLES `ims_ewei_shop_task_join` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_task_join` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_task_join` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_task_joiner`
--

DROP TABLE IF EXISTS `ims_ewei_shop_task_joiner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_task_joiner` (
  `complete_id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `task_user` varchar(100) NOT NULL DEFAULT '',
  `joiner_id` varchar(100) NOT NULL DEFAULT '',
  `join_id` int(11) NOT NULL DEFAULT '0',
  `task_id` int(11) NOT NULL DEFAULT '0',
  `task_type` tinyint(1) NOT NULL DEFAULT '0',
  `join_status` tinyint(1) NOT NULL DEFAULT '1',
  `addtime` int(11) DEFAULT NULL,
  PRIMARY KEY (`complete_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_task_joiner`
--

LOCK TABLES `ims_ewei_shop_task_joiner` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_task_joiner` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_task_joiner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_task_log`
--

DROP TABLE IF EXISTS `ims_ewei_shop_task_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_task_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `openid` varchar(100) NOT NULL DEFAULT '',
  `from_openid` varchar(100) NOT NULL DEFAULT '',
  `join_id` int(11) NOT NULL DEFAULT '0',
  `taskid` int(11) DEFAULT '0',
  `task_type` tinyint(1) NOT NULL DEFAULT '0',
  `subdata` text,
  `recdata` text,
  `createtime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_task_log`
--

LOCK TABLES `ims_ewei_shop_task_log` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_task_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_task_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_task_poster`
--

DROP TABLE IF EXISTS `ims_ewei_shop_task_poster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_task_poster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT NULL,
  `days` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `bg` varchar(255) DEFAULT '',
  `data` text,
  `keyword` varchar(255) DEFAULT NULL,
  `resptype` tinyint(1) NOT NULL DEFAULT '0',
  `resptext` text,
  `resptitle` varchar(255) DEFAULT NULL,
  `respthumb` varchar(255) DEFAULT NULL,
  `respdesc` varchar(255) DEFAULT NULL,
  `respurl` varchar(255) DEFAULT NULL,
  `createtime` int(11) DEFAULT NULL,
  `waittext` varchar(255) DEFAULT NULL,
  `oktext` varchar(255) DEFAULT NULL,
  `scantext` varchar(255) DEFAULT NULL,
  `beagent` tinyint(1) NOT NULL DEFAULT '0',
  `bedown` tinyint(1) NOT NULL DEFAULT '0',
  `timestart` int(11) DEFAULT NULL,
  `timeend` int(11) DEFAULT NULL,
  `is_repeat` tinyint(1) DEFAULT '0',
  `getposter` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `starttext` varchar(255) DEFAULT NULL,
  `endtext` varchar(255) DEFAULT NULL,
  `reward_data` text,
  `needcount` int(11) NOT NULL DEFAULT '0',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  `poster_type` tinyint(1) DEFAULT '1',
  `reward_days` int(11) DEFAULT '0',
  `titleicon` text,
  `poster_banner` text,
  `is_goods` tinyint(1) DEFAULT '0',
  `autoposter` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_task_poster`
--

LOCK TABLES `ims_ewei_shop_task_poster` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_task_poster` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_task_poster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_task_poster_qr`
--

DROP TABLE IF EXISTS `ims_ewei_shop_task_poster_qr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_task_poster_qr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL DEFAULT '0',
  `openid` varchar(100) NOT NULL,
  `posterid` int(11) NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `sceneid` int(11) NOT NULL DEFAULT '0',
  `mediaid` varchar(255) DEFAULT NULL,
  `ticket` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `createtime` int(11) DEFAULT NULL,
  `qrimg` varchar(1000) DEFAULT NULL,
  `expire` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_task_poster_qr`
--

LOCK TABLES `ims_ewei_shop_task_poster_qr` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_task_poster_qr` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_task_poster_qr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_universalform_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_universalform_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_universalform_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `merch` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_universalform_category`
--

LOCK TABLES `ims_ewei_shop_universalform_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_universalform_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_universalform_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_universalform_data`
--

DROP TABLE IF EXISTS `ims_ewei_shop_universalform_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_universalform_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `typeid` int(11) NOT NULL DEFAULT '0',
  `cid` int(11) DEFAULT '0',
  `fields` text NOT NULL,
  `universalformfields` text,
  `openid` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(2) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_typeid` (`typeid`),
  KEY `idx_cid` (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_universalform_data`
--

LOCK TABLES `ims_ewei_shop_universalform_data` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_universalform_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_universalform_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_universalform_temp`
--

DROP TABLE IF EXISTS `ims_ewei_shop_universalform_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_universalform_temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `typeid` int(11) DEFAULT '0',
  `cid` int(11) NOT NULL DEFAULT '0',
  `universalformfields` text,
  `fields` text NOT NULL,
  `openid` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(1) DEFAULT '0',
  `universalformid` int(11) DEFAULT '0',
  `universalformdata` text,
  `carrier_realname` varchar(255) DEFAULT '',
  `carrier_mobile` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_cid` (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_universalform_temp`
--

LOCK TABLES `ims_ewei_shop_universalform_temp` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_universalform_temp` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_universalform_temp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_universalform_type`
--

DROP TABLE IF EXISTS `ims_ewei_shop_universalform_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_universalform_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `cate` int(11) DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `adpic` varchar(255) NOT NULL DEFAULT '',
  `adurl` varchar(255) NOT NULL DEFAULT '',
  `fields` text NOT NULL,
  `usedata` int(11) NOT NULL DEFAULT '0',
  `alldata` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_cate` (`cate`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_universalform_type`
--

LOCK TABLES `ims_ewei_shop_universalform_type` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_universalform_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_universalform_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_verifygoods`
--

DROP TABLE IF EXISTS `ims_ewei_shop_verifygoods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_verifygoods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT NULL,
  `openid` varchar(255) DEFAULT NULL,
  `orderid` int(11) DEFAULT NULL,
  `ordergoodsid` int(11) DEFAULT NULL,
  `storeid` int(11) DEFAULT NULL,
  `starttime` int(11) DEFAULT NULL,
  `limitdays` int(11) DEFAULT NULL,
  `limitnum` int(11) DEFAULT NULL,
  `used` tinyint(1) DEFAULT '0',
  `verifycode` varchar(20) DEFAULT NULL,
  `codeinvalidtime` int(11) DEFAULT NULL,
  `invalid` tinyint(1) DEFAULT '0',
  `getcard` tinyint(1) DEFAULT '0',
  `activecard` tinyint(1) DEFAULT '0',
  `cardcode` varchar(255) DEFAULT '',
  `limittype` tinyint(1) DEFAULT '0',
  `limitdate` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `verifycode` (`verifycode`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_verifygoods`
--

LOCK TABLES `ims_ewei_shop_verifygoods` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_verifygoods` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_verifygoods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_verifygoods_log`
--

DROP TABLE IF EXISTS `ims_ewei_shop_verifygoods_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_verifygoods_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT NULL,
  `verifygoodsid` int(11) DEFAULT NULL,
  `salerid` int(11) DEFAULT NULL,
  `storeid` int(11) DEFAULT NULL,
  `verifynum` int(11) DEFAULT NULL,
  `verifydate` int(11) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_verifygoods_log`
--

LOCK TABLES `ims_ewei_shop_verifygoods_log` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_verifygoods_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_verifygoods_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_virtual_category`
--

DROP TABLE IF EXISTS `ims_ewei_shop_virtual_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_virtual_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_virtual_category`
--

LOCK TABLES `ims_ewei_shop_virtual_category` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_virtual_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_virtual_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_virtual_data`
--

DROP TABLE IF EXISTS `ims_ewei_shop_virtual_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_virtual_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `typeid` int(11) NOT NULL DEFAULT '0',
  `pvalue` varchar(255) DEFAULT '',
  `fields` text NOT NULL,
  `openid` varchar(255) NOT NULL DEFAULT '',
  `usetime` int(11) NOT NULL DEFAULT '0',
  `orderid` int(11) DEFAULT '0',
  `ordersn` varchar(255) DEFAULT '',
  `price` decimal(10,2) DEFAULT '0.00',
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_typeid` (`typeid`),
  KEY `idx_usetime` (`usetime`),
  KEY `idx_orderid` (`orderid`)
) ENGINE=MyISAM AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_virtual_data`
--

LOCK TABLES `ims_ewei_shop_virtual_data` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_virtual_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_virtual_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_virtual_type`
--

DROP TABLE IF EXISTS `ims_ewei_shop_virtual_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_virtual_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `cate` int(11) DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `fields` text NOT NULL,
  `usedata` int(11) NOT NULL DEFAULT '0',
  `alldata` int(11) NOT NULL DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_cate` (`cate`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_virtual_type`
--

LOCK TABLES `ims_ewei_shop_virtual_type` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_virtual_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_virtual_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_ewei_shop_wxcard`
--

DROP TABLE IF EXISTS `ims_ewei_shop_wxcard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_ewei_shop_wxcard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT NULL,
  `card_id` varchar(255) DEFAULT '0',
  `displayorder` int(11) DEFAULT NULL,
  `catid` int(11) DEFAULT NULL,
  `card_type` varchar(50) DEFAULT NULL,
  `logo_url` varchar(255) DEFAULT NULL,
  `wxlogourl` varchar(255) DEFAULT NULL,
  `brand_name` varchar(255) DEFAULT NULL,
  `code_type` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `notice` varchar(50) DEFAULT NULL,
  `service_phone` varchar(50) DEFAULT NULL,
  `description` text,
  `datetype` varchar(50) DEFAULT NULL,
  `begin_timestamp` int(11) DEFAULT NULL,
  `end_timestamp` int(11) DEFAULT NULL,
  `fixed_term` int(11) DEFAULT NULL,
  `fixed_begin_term` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `total_quantity` varchar(255) DEFAULT NULL,
  `use_limit` int(11) DEFAULT NULL,
  `get_limit` int(11) DEFAULT NULL,
  `use_custom_code` tinyint(1) DEFAULT NULL,
  `bind_openid` tinyint(1) DEFAULT NULL,
  `can_share` tinyint(1) DEFAULT NULL,
  `can_give_friend` tinyint(1) DEFAULT NULL,
  `center_title` varchar(20) DEFAULT NULL,
  `center_sub_title` varchar(20) DEFAULT NULL,
  `center_url` varchar(255) DEFAULT NULL,
  `setcustom` tinyint(1) DEFAULT NULL,
  `custom_url_name` varchar(20) DEFAULT NULL,
  `custom_url_sub_title` varchar(20) DEFAULT NULL,
  `custom_url` varchar(255) DEFAULT NULL,
  `setpromotion` tinyint(1) DEFAULT NULL,
  `promotion_url_name` varchar(20) DEFAULT NULL,
  `promotion_url_sub_title` varchar(20) DEFAULT NULL,
  `promotion_url` varchar(255) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `can_use_with_other_discount` tinyint(1) DEFAULT NULL,
  `setabstract` tinyint(1) DEFAULT NULL,
  `abstract` varchar(50) DEFAULT NULL,
  `abstractimg` varchar(255) DEFAULT NULL,
  `icon_url_list` varchar(255) DEFAULT NULL,
  `accept_category` varchar(50) DEFAULT NULL,
  `reject_category` varchar(50) DEFAULT NULL,
  `least_cost` decimal(10,2) DEFAULT NULL,
  `reduce_cost` decimal(10,2) DEFAULT NULL,
  `discount` decimal(10,2) DEFAULT NULL,
  `limitgoodtype` tinyint(1) DEFAULT '0',
  `limitgoodcatetype` tinyint(1) unsigned DEFAULT '0',
  `limitgoodcateids` varchar(255) DEFAULT NULL,
  `limitgoodids` varchar(255) DEFAULT NULL,
  `limitdiscounttype` tinyint(1) unsigned DEFAULT '0',
  `merchid` int(11) DEFAULT '0',
  `gettype` tinyint(3) DEFAULT NULL,
  `islimitlevel` tinyint(1) DEFAULT '0',
  `limitmemberlevels` varchar(500) DEFAULT '',
  `limitagentlevels` varchar(500) DEFAULT '',
  `limitpartnerlevels` varchar(500) DEFAULT '',
  `limitaagentlevels` varchar(500) DEFAULT '',
  `settitlecolor` tinyint(1) DEFAULT '0',
  `titlecolor` varchar(10) DEFAULT '',
  `tagtitle` varchar(20) DEFAULT '',
  `use_condition` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_ewei_shop_wxcard`
--

LOCK TABLES `ims_ewei_shop_wxcard` WRITE;
/*!40000 ALTER TABLE `ims_ewei_shop_wxcard` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_ewei_shop_wxcard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_images_reply`
--

DROP TABLE IF EXISTS `ims_images_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_images_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `mediaid` varchar(255) NOT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_images_reply`
--

LOCK TABLES `ims_images_reply` WRITE;
/*!40000 ALTER TABLE `ims_images_reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_images_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_card`
--

DROP TABLE IF EXISTS `ims_mc_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_card` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '会员卡名称',
  `color` varchar(255) NOT NULL DEFAULT '' COMMENT '会员卡字颜色',
  `background` varchar(255) NOT NULL DEFAULT '' COMMENT '背景设置',
  `logo` varchar(255) NOT NULL DEFAULT '' COMMENT 'logo图片',
  `format_type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否用手机号作为会员卡号',
  `format` varchar(50) NOT NULL DEFAULT '' COMMENT '会员卡卡号规则',
  `description` varchar(512) NOT NULL DEFAULT '' COMMENT '会员卡说明',
  `fields` varchar(1000) NOT NULL DEFAULT '' COMMENT '会员卡资料',
  `snpos` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用1:启用0:关闭',
  `business` text NOT NULL,
  `discount_type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '折扣类型.1:满减,2:折扣',
  `discount` varchar(3000) NOT NULL DEFAULT '' COMMENT '各个会员组的优惠详情',
  `grant` varchar(3000) NOT NULL COMMENT '领卡赠送:积分,余额,优惠券',
  `grant_rate` varchar(20) NOT NULL DEFAULT '0' COMMENT '消费返积分比率',
  `offset_rate` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '积分抵现比例',
  `offset_max` int(10) NOT NULL DEFAULT '0' COMMENT '每单最多可抵现金数量',
  `nums_status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '计次是否开启，0为关闭，1为开启',
  `nums_text` varchar(15) NOT NULL COMMENT '计次名称',
  `nums` varchar(1000) NOT NULL DEFAULT '' COMMENT '计次规则',
  `times_status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '计时是否开启，0为关闭，1为开启',
  `times_text` varchar(15) NOT NULL COMMENT '计时名称',
  `times` varchar(1000) NOT NULL DEFAULT '' COMMENT '计时规则',
  `params` longtext NOT NULL,
  `html` longtext NOT NULL,
  `recommend_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `sign_status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '签到功能是否开启，0为关闭，1为开启',
  `brand_name` varchar(128) NOT NULL DEFAULT '' COMMENT '商户名字,',
  `notice` varchar(48) NOT NULL DEFAULT '' COMMENT '卡券使用提醒',
  `quantity` int(10) NOT NULL DEFAULT '0' COMMENT '会员卡库存',
  `max_increase_bonus` int(10) NOT NULL DEFAULT '0' COMMENT '用户单次可获取的积分上限',
  `least_money_to_use_bonus` int(10) NOT NULL DEFAULT '0' COMMENT '抵扣条件',
  `source` int(1) NOT NULL DEFAULT '1' COMMENT '1.系统会员卡，2微信会员卡',
  `card_id` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_card`
--

LOCK TABLES `ims_mc_card` WRITE;
/*!40000 ALTER TABLE `ims_mc_card` DISABLE KEYS */;
INSERT INTO `ims_mc_card` VALUES (1,6,'我的会员卡','','','',1,'','','a:2:{i:0;a:3:{s:5:\"title\";s:6:\"姓名\";s:7:\"require\";i:1;s:4:\"bind\";s:8:\"realname\";}i:1;a:3:{s:5:\"title\";s:6:\"手机\";s:7:\"require\";i:1;s:4:\"bind\";s:6:\"mobile\";}}',0,1,'',1,'','','0',0,0,0,'','',0,'','','','',0,0,'','',0,0,0,1,'');
/*!40000 ALTER TABLE `ims_mc_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_card_credit_set`
--

DROP TABLE IF EXISTS `ims_mc_card_credit_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_card_credit_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL DEFAULT '0',
  `sign` varchar(1000) NOT NULL,
  `share` varchar(500) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_card_credit_set`
--

LOCK TABLES `ims_mc_card_credit_set` WRITE;
/*!40000 ALTER TABLE `ims_mc_card_credit_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_mc_card_credit_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_card_members`
--

DROP TABLE IF EXISTS `ims_mc_card_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_card_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) DEFAULT NULL,
  `openid` varchar(50) NOT NULL,
  `cid` int(10) NOT NULL DEFAULT '0',
  `cardsn` varchar(20) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `nums` int(10) unsigned NOT NULL DEFAULT '0',
  `endtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_card_members`
--

LOCK TABLES `ims_mc_card_members` WRITE;
/*!40000 ALTER TABLE `ims_mc_card_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_mc_card_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_card_notices`
--

DROP TABLE IF EXISTS `ims_mc_card_notices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_card_notices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1:公共消息，2:个人消息',
  `title` varchar(30) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `groupid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '通知会员组。默认为所有会员',
  `content` text NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_card_notices`
--

LOCK TABLES `ims_mc_card_notices` WRITE;
/*!40000 ALTER TABLE `ims_mc_card_notices` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_mc_card_notices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_card_notices_unread`
--

DROP TABLE IF EXISTS `ims_mc_card_notices_unread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_card_notices_unread` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL DEFAULT '0',
  `notice_id` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `is_new` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1:公共通知，2：个人通知',
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `uid` (`uid`),
  KEY `notice_id` (`notice_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_card_notices_unread`
--

LOCK TABLES `ims_mc_card_notices_unread` WRITE;
/*!40000 ALTER TABLE `ims_mc_card_notices_unread` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_mc_card_notices_unread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_card_record`
--

DROP TABLE IF EXISTS `ims_mc_card_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_card_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(15) NOT NULL,
  `model` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1：充值，2：消费',
  `fee` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '充值金额',
  `tag` varchar(10) NOT NULL COMMENT '次数|时长|充值金额',
  `note` varchar(255) NOT NULL,
  `remark` varchar(200) NOT NULL COMMENT '备注，只有管理员可以看',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `uid` (`uid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_card_record`
--

LOCK TABLES `ims_mc_card_record` WRITE;
/*!40000 ALTER TABLE `ims_mc_card_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_mc_card_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_card_sign_record`
--

DROP TABLE IF EXISTS `ims_mc_card_sign_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_card_sign_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `credit` int(10) unsigned NOT NULL DEFAULT '0',
  `is_grant` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_card_sign_record`
--

LOCK TABLES `ims_mc_card_sign_record` WRITE;
/*!40000 ALTER TABLE `ims_mc_card_sign_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_mc_card_sign_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_cash_record`
--

DROP TABLE IF EXISTS `ims_mc_cash_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_cash_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `clerk_id` int(10) unsigned NOT NULL,
  `store_id` int(10) unsigned NOT NULL,
  `clerk_type` tinyint(3) unsigned NOT NULL,
  `fee` decimal(10,2) unsigned NOT NULL,
  `final_fee` decimal(10,2) unsigned NOT NULL,
  `credit1` int(10) unsigned NOT NULL,
  `credit1_fee` decimal(10,2) unsigned NOT NULL,
  `credit2` decimal(10,2) unsigned NOT NULL,
  `cash` decimal(10,2) unsigned NOT NULL,
  `return_cash` decimal(10,2) unsigned NOT NULL,
  `final_cash` decimal(10,2) unsigned NOT NULL,
  `remark` varchar(255) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `trade_type` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_cash_record`
--

LOCK TABLES `ims_mc_cash_record` WRITE;
/*!40000 ALTER TABLE `ims_mc_cash_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_mc_cash_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_chats_record`
--

DROP TABLE IF EXISTS `ims_mc_chats_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_chats_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `flag` tinyint(3) unsigned NOT NULL,
  `openid` varchar(32) NOT NULL,
  `msgtype` varchar(15) NOT NULL,
  `content` varchar(10000) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`,`acid`),
  KEY `openid` (`openid`),
  KEY `createtime` (`createtime`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_chats_record`
--

LOCK TABLES `ims_mc_chats_record` WRITE;
/*!40000 ALTER TABLE `ims_mc_chats_record` DISABLE KEYS */;
INSERT INTO `ims_mc_chats_record` VALUES (1,6,0,1,'oZo4hw8Wt565YLamn2TJqGExQirA','text','a:1:{s:7:\"content\";s:8:\"11111111\";}',1504115389);
/*!40000 ALTER TABLE `ims_mc_chats_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_credits_recharge`
--

DROP TABLE IF EXISTS `ims_mc_credits_recharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_credits_recharge` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `openid` varchar(50) NOT NULL,
  `tid` varchar(64) NOT NULL,
  `transid` varchar(30) NOT NULL,
  `fee` varchar(10) NOT NULL,
  `type` varchar(15) NOT NULL,
  `tag` varchar(10) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `backtype` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid_uid` (`uniacid`,`uid`),
  KEY `idx_tid` (`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_credits_recharge`
--

LOCK TABLES `ims_mc_credits_recharge` WRITE;
/*!40000 ALTER TABLE `ims_mc_credits_recharge` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_mc_credits_recharge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_credits_record`
--

DROP TABLE IF EXISTS `ims_mc_credits_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_credits_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `uniacid` int(11) NOT NULL,
  `credittype` varchar(10) NOT NULL,
  `num` decimal(10,2) NOT NULL,
  `operator` int(10) unsigned NOT NULL,
  `module` varchar(30) NOT NULL,
  `clerk_id` int(10) unsigned NOT NULL,
  `store_id` int(10) unsigned NOT NULL,
  `clerk_type` tinyint(3) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `remark` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_credits_record`
--

LOCK TABLES `ims_mc_credits_record` WRITE;
/*!40000 ALTER TABLE `ims_mc_credits_record` DISABLE KEYS */;
INSERT INTO `ims_mc_credits_record` VALUES (1,1,6,'credit2','99999999.00',1,'ewei_shopv2',0,0,0,1504402523,'后台会员充值余额 测试后台充值99999999'),(2,1,6,'credit2','-0.01',1,'ewei_shopv2',0,0,0,1504404150,'adjyc消费0.01'),(3,3,6,'credit2','9999999.00',1,'ewei_shopv2',0,0,0,1504425682,'后台会员充值余额 测试充值'),(4,2,6,'credit2','99999999.00',1,'ewei_shopv2',0,0,0,1504425699,'后台会员充值余额 测试充值'),(5,2,6,'credit2','-455.00',2,'ewei_shopv2',0,0,0,1504428052,'adjyc消费455'),(6,2,6,'credit1','9100.00',0,'ewei_shopv2',0,0,0,1504428052,'积分活动购物送积分: 9100积分'),(7,1,6,'credit2','-244.00',1,'ewei_shopv2',0,0,0,1504500363,'融惠联消费244'),(8,1,6,'credit1','4880.00',0,'ewei_shopv2',0,0,0,1504500363,'积分活动购物送积分: 4880积分'),(9,1,6,'credit2','-10777.00',1,'ewei_shopv2',0,0,0,1504500657,'融惠联消费10777');
/*!40000 ALTER TABLE `ims_mc_credits_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_fans_groups`
--

DROP TABLE IF EXISTS `ims_mc_fans_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_fans_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `groups` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_fans_groups`
--

LOCK TABLES `ims_mc_fans_groups` WRITE;
/*!40000 ALTER TABLE `ims_mc_fans_groups` DISABLE KEYS */;
INSERT INTO `ims_mc_fans_groups` VALUES (1,6,6,'a:1:{i:2;a:3:{s:2:\"id\";i:2;s:4:\"name\";s:9:\"星标组\";s:5:\"count\";i:1;}}');
/*!40000 ALTER TABLE `ims_mc_fans_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_fans_tag_mapping`
--

DROP TABLE IF EXISTS `ims_mc_fans_tag_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_fans_tag_mapping` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `fanid` int(11) unsigned NOT NULL,
  `tagid` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mapping` (`fanid`,`tagid`),
  KEY `fanid_index` (`fanid`),
  KEY `tagid_index` (`tagid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_fans_tag_mapping`
--

LOCK TABLES `ims_mc_fans_tag_mapping` WRITE;
/*!40000 ALTER TABLE `ims_mc_fans_tag_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_mc_fans_tag_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_groups`
--

DROP TABLE IF EXISTS `ims_mc_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_groups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `title` varchar(20) NOT NULL,
  `credit` int(10) unsigned NOT NULL,
  `isdefault` tinyint(4) NOT NULL,
  PRIMARY KEY (`groupid`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_groups`
--

LOCK TABLES `ims_mc_groups` WRITE;
/*!40000 ALTER TABLE `ims_mc_groups` DISABLE KEYS */;
INSERT INTO `ims_mc_groups` VALUES (1,1,'默认会员组',0,1),(2,2,'默认会员组',0,1),(3,3,'默认会员组',0,1),(4,4,'默认会员组',0,1),(5,5,'默认会员组',0,1),(6,6,'默认会员组',0,1);
/*!40000 ALTER TABLE `ims_mc_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_handsel`
--

DROP TABLE IF EXISTS `ims_mc_handsel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_handsel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) NOT NULL,
  `touid` int(10) unsigned NOT NULL,
  `fromuid` varchar(32) NOT NULL,
  `module` varchar(30) NOT NULL,
  `sign` varchar(100) NOT NULL,
  `action` varchar(20) NOT NULL,
  `credit_value` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`touid`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_handsel`
--

LOCK TABLES `ims_mc_handsel` WRITE;
/*!40000 ALTER TABLE `ims_mc_handsel` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_mc_handsel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_mapping_fans`
--

DROP TABLE IF EXISTS `ims_mc_mapping_fans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_mapping_fans` (
  `fanid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `acid` int(10) unsigned NOT NULL,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `openid` varchar(50) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `groupid` varchar(30) NOT NULL,
  `salt` char(8) NOT NULL,
  `follow` tinyint(1) unsigned NOT NULL,
  `followtime` int(10) unsigned NOT NULL,
  `unfollowtime` int(10) unsigned NOT NULL,
  `tag` varchar(1000) NOT NULL,
  `updatetime` int(10) unsigned DEFAULT NULL,
  `unionid` varchar(64) NOT NULL,
  PRIMARY KEY (`fanid`),
  UNIQUE KEY `openid_2` (`openid`),
  KEY `acid` (`acid`),
  KEY `uniacid` (`uniacid`),
  KEY `nickname` (`nickname`),
  KEY `updatetime` (`updatetime`),
  KEY `uid` (`uid`),
  KEY `openid` (`openid`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_mapping_fans`
--

LOCK TABLES `ims_mc_mapping_fans` WRITE;
/*!40000 ALTER TABLE `ims_mc_mapping_fans` DISABLE KEYS */;
INSERT INTO `ims_mc_mapping_fans` VALUES (1,6,6,0,'oZo4hw57L7s_-5-y9zNM3suU4w9o','点胜支付','','ctb7eByR',1,1500026173,0,'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib1pvNGh3NTdMN3NfLTUteTl6Tk0zc3VVNHc5byI7czo4OiJuaWNrbmFtZSI7czoxMjoi54K56IOc5pSv5LuYIjtzOjM6InNleCI7aTowO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czowOiIiO3M6ODoicHJvdmluY2UiO3M6MDoiIjtzOjc6ImNvdW50cnkiO3M6MDoiIjtzOjEwOiJoZWFkaW1ndXJsIjtzOjExNzoiaHR0cDovL3d4LnFsb2dvLmNuL21tb3Blbi9hak5WZHFIWkxMRFVhNW01dUJsVGljZ1h6ekNXaGM0bUlnZFM3d3dmaWNOM2QzaWFnY2tQWTM3VUV4UkpyYXN0UURBUVAxU2JXY2NTTEtlZkhPNzgzZ2E1Zy8wIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTAwMDI2MTczO3M6NjoicmVtYXJrIjtzOjA6IiI7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9fQ==',1504618448,''),(2,6,6,0,'oZo4hw_eo2FmzeHnWTTGcjkghDaI','王大锤','','IsHR09YF',1,1500514262,0,'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib1pvNGh3X2VvMkZtemVIbldUVEdjamtnaERhSSI7czo4OiJuaWNrbmFtZSI7czo5OiLnjovlpKfplKQiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjA6IiI7czo4OiJwcm92aW5jZSI7czowOiIiO3M6NzoiY291bnRyeSI7czo5OiLlronpgZPlsJQiO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTI4OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL3JHc3VHUmdMQVBoZnBLaFRZMkxJZmpCUG1VWUVlSk16ZGxqMXYxQ2dOdmhuZzVmb3dpY1VjZnVrQnplekN3a2tHUjVWY09VbnV2dDBpY2NJYWlhcGNpYWdTTkVITjdWd2hXVngvMCI7czoxNDoic3Vic2NyaWJlX3RpbWUiO2k6MTUwMDUxNDI2MjtzOjY6InJlbWFyayI7czowOiIiO3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fX0=',1504618448,''),(3,6,6,0,'oZo4hw5jj38oFIJvu3CEgwKF8qIU','废弃的猪','','t0poaPPv',1,1500003390,0,'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib1pvNGh3NWpqMzhvRklKdnUzQ0Vnd0tGOHFJVSI7czo4OiJuaWNrbmFtZSI7czoxMjoi5bqf5byD55qE54yqIjtzOjM6InNleCI7aToxO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLnu7XpmLMiO3M6ODoicHJvdmluY2UiO3M6Njoi5Zub5bedIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzNDoiaHR0cDovL3d4LnFsb2dvLmNuL21tb3Blbi9ISW1UcjlZNWJKWE9RNE1lcHZrSDM1WWliaWNDaWJpY09pYXlSYWZPUGljdTNYOFZFSnJKM3hhaWJ5dTJ2d3lVVXVzVExpYmQyNHNMTGlhU0tDWk1DUmVpY3FUZzFROXZzSnFFVFI1eHVILzAiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1MDAwMDMzOTA7czo2OiJyZW1hcmsiO3M6MDoiIjtzOjc6Imdyb3VwaWQiO2k6MDtzOjEwOiJ0YWdpZF9saXN0IjthOjA6e319',1504618448,''),(4,6,6,0,'oZo4hw84Jkl14EOT-D0UP7IWrrFY','LinLi','','smj0qZ91',1,1500086306,0,'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib1pvNGh3ODRKa2wxNEVPVC1EMFVQN0lXcnJGWSI7czo4OiJuaWNrbmFtZSI7czo1OiJMaW5MaSI7czozOiJzZXgiO2k6MjtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi5Y6m6ZeoIjtzOjg6InByb3ZpbmNlIjtzOjY6Iuemj+W7uiI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMzA6Imh0dHA6Ly93eC5xbG9nby5jbi9tbW9wZW4vckdzdUdSZ0xBUGlhZHZxb3g1NW1sVFBYdE9CaWJ0Ujh4eUR4TnpwZ3VYTnpkNzVOZlI5OGVMQWlhYnZmUjNEWUFPbkVFdFQyaDNYTlUzczVUcEVqcVlNZU8zTmlha2lib0FWSGlhLzAiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1MDAwODYzMDY7czo2OiJyZW1hcmsiO3M6MDoiIjtzOjc6Imdyb3VwaWQiO2k6MDtzOjEwOiJ0YWdpZF9saXN0IjthOjA6e319',1504618448,''),(5,6,6,1,'oZo4hw8Wt565YLamn2TJqGExQirA','街墙','','d43j43gB',1,1504271579,0,'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib1pvNGh3OFd0NTY1WUxhbW4yVEpxR0V4UWlyQSI7czo4OiJuaWNrbmFtZSI7czo2OiLooZflopkiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuWOpumXqCI7czo4OiJwcm92aW5jZSI7czo2OiLnpo/lu7oiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTI1OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL0hJbVRyOVk1YkpYT1E0TWVwdmtIMzBYR2lhODZLTFdDdU1oN3RJZW9QMUVGZUNVRmxIQW5GbmRQZUxrZzlnTmtUQVA1cExjdlJhbTBUVHhnb2Jyc1FKd2xURG5MY0NEd00vMCI7czoxNDoic3Vic2NyaWJlX3RpbWUiO2k6MTUwNDI3MTU3OTtzOjY6InJlbWFyayI7czowOiIiO3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fX0=',1504618448,''),(6,6,6,2,'oZo4hw-Dv3uxhgBm549mY7-ikdyc','揭果','','OZO0T50X',0,0,0,'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im9abzRody1EdjN1eGhnQm01NDltWTctaWtkeWMiO3M6ODoibmlja25hbWUiO3M6Njoi5o+t5p6cIjtzOjM6InNleCI7aToxO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLmtbfmt4AiO3M6ODoicHJvdmluY2UiO3M6Njoi5YyX5LqsIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyOToiaHR0cDovL3d4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUTHVvbGIzYXdsNW9KOWFNc1VxUnlzWXR0TUhKTmlhN2VUMjhIb3hpYjJpYnQ2bWppYmtpY3JJNHd6ZGZ1ZWxERmliMlMwSlZIVGliSkIwTHRZRncvMTMyIjtzOjk6InByaXZpbGVnZSI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI5OiJodHRwOi8vd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL1EwajRUd0dUZlRMdW9sYjNhd2w1b0o5YU1zVXFSeXNZdHRNSEpOaWE3ZVQyOEhveGliMmlidDZtamlia2ljckk0d3pkZnVlbERGaWIyUzBKVkhUaWJKQjBMdFlGdy8xMzIiO30=',1504519639,''),(7,6,6,3,'oZo4hw7Rho-Val4FIVX5oKc2OTUI','冯颖','','hol85Li6',0,0,0,'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im9abzRodzdSaG8tVmFsNEZJVlg1b0tjMk9UVUkiO3M6ODoibmlja25hbWUiO3M6Njoi5Yav6aKWIjtzOjM6InNleCI7aToyO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czowOiIiO3M6ODoicHJvdmluY2UiO3M6Njoi5YyX5LqsIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyNToiaHR0cDovL3d4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUTDJZOVBVYmljWmNUOUk4Qjl2RHNOWkd4c0hDT3RpY1hiWUpoZEd1dlo3VFBWT2V3RnpiYWZuOVBSaWExNUlBMnFrZHEzMExxSnRxR2pPUS8xMzIiO3M6OToicHJpdmlsZWdlIjthOjA6e31zOjY6ImF2YXRhciI7czoxMjU6Imh0dHA6Ly93eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvUTBqNFR3R1RmVEwyWTlQVWJpY1pjVDlJOEI5dkRzTlpHeHNIQ090aWNYYllKaGRHdXZaN1RQVk9ld0Z6YmFmbjlQUmlhMTVJQTJxa2RxMzBMcUp0cUdqT1EvMTMyIjt9',1504520478,''),(8,6,6,4,'oZo4hw8_uBuJA4We7GGNc8oeU_RQ','中治律所闵瀚霖','','E1L4Zs63',0,0,0,'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im9abzRodzhfdUJ1SkE0V2U3R0dOYzhvZVVfUlEiO3M6ODoibmlja25hbWUiO3M6MjE6IuS4reayu+W+i+aJgOmXteeAmumcliI7czozOiJzZXgiO2k6MTtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6MDoiIjtzOjg6InByb3ZpbmNlIjtzOjY6IuWMl+S6rCI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMjU6Imh0dHA6Ly93eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvRFlBSU9ncTgzZW9DOWJlUFBFTHV4aG9nQjRjU2gyNTc1bTNFR2U4TzVVaDJOaWN1Mm1vNXBNeklGTUxFSWdNVExvc2UzS2ljWXYyZzFUWEFFaWNybHR1dXcvMTMyIjtzOjk6InByaXZpbGVnZSI7YToxOntpOjA7czoxMToiY2hpbmF1bmljb20iO31zOjY6ImF2YXRhciI7czoxMjU6Imh0dHA6Ly93eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvRFlBSU9ncTgzZW9DOWJlUFBFTHV4aG9nQjRjU2gyNTc1bTNFR2U4TzVVaDJOaWN1Mm1vNXBNeklGTUxFSWdNVExvc2UzS2ljWXYyZzFUWEFFaWNybHR1dXcvMTMyIjt9',1504520103,''),(9,6,6,5,'oZo4hw2mx_hd2cIa4_doocGay7-w','郝叶','','dg0GWggV',0,0,0,'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im9abzRodzJteF9oZDJjSWE0X2Rvb2NHYXk3LXciO3M6ODoibmlja25hbWUiO3M6Njoi6YOd5Y+2IjtzOjM6InNleCI7aToyO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czowOiIiO3M6ODoicHJvdmluY2UiO3M6MDoiIjtzOjc6ImNvdW50cnkiO3M6OToi5a6J6YGT5bCUIjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyNzoiaHR0cDovL3d4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9QaWFqeFNxQlJhRUoyMzZLQ2ljb2VQaWJ0TWgzYmhveFZzYld5VEtocXVGRHh5ZjR1YVZCbGc0T29mR1lCTkRDdEJYNGljQ2FkU3l4Y3hTcTlyTlV1bnJ2aWNRLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEyNzoiaHR0cDovL3d4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9QaWFqeFNxQlJhRUoyMzZLQ2ljb2VQaWJ0TWgzYmhveFZzYld5VEtocXVGRHh5ZjR1YVZCbGc0T29mR1lCTkRDdEJYNGljQ2FkU3l4Y3hTcTlyTlV1bnJ2aWNRLzEzMiI7fQ==',1504565246,'');
/*!40000 ALTER TABLE `ims_mc_mapping_fans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_mapping_ucenter`
--

DROP TABLE IF EXISTS `ims_mc_mapping_ucenter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_mapping_ucenter` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `centeruid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_mapping_ucenter`
--

LOCK TABLES `ims_mc_mapping_ucenter` WRITE;
/*!40000 ALTER TABLE `ims_mc_mapping_ucenter` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_mc_mapping_ucenter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_mass_record`
--

DROP TABLE IF EXISTS `ims_mc_mass_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_mass_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `groupname` varchar(50) NOT NULL,
  `fansnum` int(10) unsigned NOT NULL,
  `msgtype` varchar(10) NOT NULL,
  `content` varchar(10000) NOT NULL,
  `group` int(10) NOT NULL,
  `attach_id` int(10) unsigned NOT NULL,
  `media_id` varchar(100) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `cron_id` int(10) unsigned NOT NULL,
  `sendtime` int(10) unsigned NOT NULL,
  `finalsendtime` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`,`acid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_mass_record`
--

LOCK TABLES `ims_mc_mass_record` WRITE;
/*!40000 ALTER TABLE `ims_mc_mass_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_mc_mass_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_member_address`
--

DROP TABLE IF EXISTS `ims_mc_member_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_member_address` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(50) unsigned NOT NULL,
  `username` varchar(20) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `zipcode` varchar(6) NOT NULL,
  `province` varchar(32) NOT NULL,
  `city` varchar(32) NOT NULL,
  `district` varchar(32) NOT NULL,
  `address` varchar(512) NOT NULL,
  `isdefault` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uinacid` (`uniacid`),
  KEY `idx_uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_member_address`
--

LOCK TABLES `ims_mc_member_address` WRITE;
/*!40000 ALTER TABLE `ims_mc_member_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_mc_member_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_member_fields`
--

DROP TABLE IF EXISTS `ims_mc_member_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_member_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) NOT NULL,
  `fieldid` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `available` tinyint(1) NOT NULL,
  `displayorder` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_fieldid` (`fieldid`)
) ENGINE=MyISAM AUTO_INCREMENT=181 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_member_fields`
--

LOCK TABLES `ims_mc_member_fields` WRITE;
/*!40000 ALTER TABLE `ims_mc_member_fields` DISABLE KEYS */;
INSERT INTO `ims_mc_member_fields` VALUES (1,2,1,'真实姓名',1,0),(2,2,2,'昵称',1,1),(3,2,3,'头像',1,1),(4,2,4,'QQ号',1,0),(5,2,5,'手机号码',1,0),(6,2,6,'VIP级别',1,0),(7,2,7,'性别',1,0),(8,2,8,'出生生日',1,0),(9,2,9,'星座',1,0),(10,2,10,'生肖',1,0),(11,2,11,'固定电话',1,0),(12,2,12,'证件号码',1,0),(13,2,13,'学号',1,0),(14,2,14,'班级',1,0),(15,2,15,'邮寄地址',1,0),(16,2,16,'邮编',1,0),(17,2,17,'国籍',1,0),(18,2,18,'居住地址',1,0),(19,2,19,'毕业学校',1,0),(20,2,20,'公司',1,0),(21,2,21,'学历',1,0),(22,2,22,'职业',1,0),(23,2,23,'职位',1,0),(24,2,24,'年收入',1,0),(25,2,25,'情感状态',1,0),(26,2,26,' 交友目的',1,0),(27,2,27,'血型',1,0),(28,2,28,'身高',1,0),(29,2,29,'体重',1,0),(30,2,30,'支付宝帐号',1,0),(31,2,31,'MSN',1,0),(32,2,32,'电子邮箱',1,0),(33,2,33,'阿里旺旺',1,0),(34,2,34,'主页',1,0),(35,2,35,'自我介绍',1,0),(36,2,36,'兴趣爱好',1,0),(37,3,1,'真实姓名',1,0),(38,3,2,'昵称',1,1),(39,3,3,'头像',1,1),(40,3,4,'QQ号',1,0),(41,3,5,'手机号码',1,0),(42,3,6,'VIP级别',1,0),(43,3,7,'性别',1,0),(44,3,8,'出生生日',1,0),(45,3,9,'星座',1,0),(46,3,10,'生肖',1,0),(47,3,11,'固定电话',1,0),(48,3,12,'证件号码',1,0),(49,3,13,'学号',1,0),(50,3,14,'班级',1,0),(51,3,15,'邮寄地址',1,0),(52,3,16,'邮编',1,0),(53,3,17,'国籍',1,0),(54,3,18,'居住地址',1,0),(55,3,19,'毕业学校',1,0),(56,3,20,'公司',1,0),(57,3,21,'学历',1,0),(58,3,22,'职业',1,0),(59,3,23,'职位',1,0),(60,3,24,'年收入',1,0),(61,3,25,'情感状态',1,0),(62,3,26,' 交友目的',1,0),(63,3,27,'血型',1,0),(64,3,28,'身高',1,0),(65,3,29,'体重',1,0),(66,3,30,'支付宝帐号',1,0),(67,3,31,'MSN',1,0),(68,3,32,'电子邮箱',1,0),(69,3,33,'阿里旺旺',1,0),(70,3,34,'主页',1,0),(71,3,35,'自我介绍',1,0),(72,3,36,'兴趣爱好',1,0),(73,4,1,'真实姓名',1,0),(74,4,2,'昵称',1,1),(75,4,3,'头像',1,1),(76,4,4,'QQ号',1,0),(77,4,5,'手机号码',1,0),(78,4,6,'VIP级别',1,0),(79,4,7,'性别',1,0),(80,4,8,'出生生日',1,0),(81,4,9,'星座',1,0),(82,4,10,'生肖',1,0),(83,4,11,'固定电话',1,0),(84,4,12,'证件号码',1,0),(85,4,13,'学号',1,0),(86,4,14,'班级',1,0),(87,4,15,'邮寄地址',1,0),(88,4,16,'邮编',1,0),(89,4,17,'国籍',1,0),(90,4,18,'居住地址',1,0),(91,4,19,'毕业学校',1,0),(92,4,20,'公司',1,0),(93,4,21,'学历',1,0),(94,4,22,'职业',1,0),(95,4,23,'职位',1,0),(96,4,24,'年收入',1,0),(97,4,25,'情感状态',1,0),(98,4,26,' 交友目的',1,0),(99,4,27,'血型',1,0),(100,4,28,'身高',1,0),(101,4,29,'体重',1,0),(102,4,30,'支付宝帐号',1,0),(103,4,31,'MSN',1,0),(104,4,32,'电子邮箱',1,0),(105,4,33,'阿里旺旺',1,0),(106,4,34,'主页',1,0),(107,4,35,'自我介绍',1,0),(108,4,36,'兴趣爱好',1,0),(109,5,1,'真实姓名',1,0),(110,5,2,'昵称',1,1),(111,5,3,'头像',1,1),(112,5,4,'QQ号',1,0),(113,5,5,'手机号码',1,0),(114,5,6,'VIP级别',1,0),(115,5,7,'性别',1,0),(116,5,8,'出生生日',1,0),(117,5,9,'星座',1,0),(118,5,10,'生肖',1,0),(119,5,11,'固定电话',1,0),(120,5,12,'证件号码',1,0),(121,5,13,'学号',1,0),(122,5,14,'班级',1,0),(123,5,15,'邮寄地址',1,0),(124,5,16,'邮编',1,0),(125,5,17,'国籍',1,0),(126,5,18,'居住地址',1,0),(127,5,19,'毕业学校',1,0),(128,5,20,'公司',1,0),(129,5,21,'学历',1,0),(130,5,22,'职业',1,0),(131,5,23,'职位',1,0),(132,5,24,'年收入',1,0),(133,5,25,'情感状态',1,0),(134,5,26,' 交友目的',1,0),(135,5,27,'血型',1,0),(136,5,28,'身高',1,0),(137,5,29,'体重',1,0),(138,5,30,'支付宝帐号',1,0),(139,5,31,'MSN',1,0),(140,5,32,'电子邮箱',1,0),(141,5,33,'阿里旺旺',1,0),(142,5,34,'主页',1,0),(143,5,35,'自我介绍',1,0),(144,5,36,'兴趣爱好',1,0),(145,6,1,'真实姓名',1,0),(146,6,2,'昵称',1,1),(147,6,3,'头像',1,1),(148,6,4,'QQ号',1,0),(149,6,5,'手机号码',1,0),(150,6,6,'VIP级别',1,0),(151,6,7,'性别',1,0),(152,6,8,'出生生日',1,0),(153,6,9,'星座',1,0),(154,6,10,'生肖',1,0),(155,6,11,'固定电话',1,0),(156,6,12,'证件号码',1,0),(157,6,13,'学号',1,0),(158,6,14,'班级',1,0),(159,6,15,'邮寄地址',1,0),(160,6,16,'邮编',1,0),(161,6,17,'国籍',1,0),(162,6,18,'居住地址',1,0),(163,6,19,'毕业学校',1,0),(164,6,20,'公司',1,0),(165,6,21,'学历',1,0),(166,6,22,'职业',1,0),(167,6,23,'职位',1,0),(168,6,24,'年收入',1,0),(169,6,25,'情感状态',1,0),(170,6,26,' 交友目的',1,0),(171,6,27,'血型',1,0),(172,6,28,'身高',1,0),(173,6,29,'体重',1,0),(174,6,30,'支付宝帐号',1,0),(175,6,31,'MSN',1,0),(176,6,32,'电子邮箱',1,0),(177,6,33,'阿里旺旺',1,0),(178,6,34,'主页',1,0),(179,6,35,'自我介绍',1,0),(180,6,36,'兴趣爱好',1,0);
/*!40000 ALTER TABLE `ims_mc_member_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_member_property`
--

DROP TABLE IF EXISTS `ims_mc_member_property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_member_property` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `property` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_member_property`
--

LOCK TABLES `ims_mc_member_property` WRITE;
/*!40000 ALTER TABLE `ims_mc_member_property` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_mc_member_property` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_members`
--

DROP TABLE IF EXISTS `ims_mc_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_members` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `salt` varchar(8) NOT NULL,
  `groupid` int(11) NOT NULL,
  `credit1` decimal(10,2) unsigned NOT NULL,
  `credit2` decimal(10,2) unsigned NOT NULL,
  `credit3` decimal(10,2) unsigned NOT NULL,
  `credit4` decimal(10,2) unsigned NOT NULL,
  `credit5` decimal(10,2) unsigned NOT NULL,
  `credit6` decimal(10,2) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `realname` varchar(10) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `qq` varchar(15) NOT NULL,
  `vip` tinyint(3) unsigned NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `birthyear` smallint(6) unsigned NOT NULL,
  `birthmonth` tinyint(3) unsigned NOT NULL,
  `birthday` tinyint(3) unsigned NOT NULL,
  `constellation` varchar(10) NOT NULL,
  `zodiac` varchar(5) NOT NULL,
  `telephone` varchar(15) NOT NULL,
  `idcard` varchar(30) NOT NULL,
  `studentid` varchar(50) NOT NULL,
  `grade` varchar(10) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zipcode` varchar(10) NOT NULL,
  `nationality` varchar(30) NOT NULL,
  `resideprovince` varchar(30) NOT NULL,
  `residecity` varchar(30) NOT NULL,
  `residedist` varchar(30) NOT NULL,
  `graduateschool` varchar(50) NOT NULL,
  `company` varchar(50) NOT NULL,
  `education` varchar(10) NOT NULL,
  `occupation` varchar(30) NOT NULL,
  `position` varchar(30) NOT NULL,
  `revenue` varchar(10) NOT NULL,
  `affectivestatus` varchar(30) NOT NULL,
  `lookingfor` varchar(255) NOT NULL,
  `bloodtype` varchar(5) NOT NULL,
  `height` varchar(5) NOT NULL,
  `weight` varchar(5) NOT NULL,
  `alipay` varchar(30) NOT NULL,
  `msn` varchar(30) NOT NULL,
  `taobao` varchar(30) NOT NULL,
  `site` varchar(30) NOT NULL,
  `bio` text NOT NULL,
  `interest` text NOT NULL,
  PRIMARY KEY (`uid`),
  KEY `groupid` (`groupid`),
  KEY `uniacid` (`uniacid`),
  KEY `email` (`email`),
  KEY `mobile` (`mobile`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_members`
--

LOCK TABLES `ims_mc_members` WRITE;
/*!40000 ALTER TABLE `ims_mc_members` DISABLE KEYS */;
INSERT INTO `ims_mc_members` VALUES (1,6,'','885683cbf66237d4f7a25c37650d1255@we7.cc','c89aa80f72b50eaec5c96d57f015f02b','WX60oR6U',6,'4880.00','99988977.99','0.00','0.00','0.00','0.00',1504141851,'','街墙','http://wx.qlogo.cn/mmopen/HImTr9Y5bJXOQ4MepvkH30XGia86KLWCuMh7tIeoP1EFeCUFlHAnFndPeLkg9gNkTAP5pLcvRam0TTxgobrsQJwlTDnLcCDwM/132','',0,1,0,0,0,'','','','','','','','','中国','福建省','厦门市','','','','','','','','','','','','','','','','','',''),(2,6,'','fdd4c8b6a339dd830d9b5314b169bdf5@we7.cc','d24f2bfff6b18d8438822411b9e2666b','yCpe35pm',6,'9100.00','99999544.00','0.00','0.00','0.00','0.00',1504154222,'','揭果','http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLuolb3awl5oJ9aMsUqRysYttMHJNia7eT28Hoxib2ibt6mjibkicrI4wzdfuelDFib2S0JVHTibJB0LtYFw/132','',0,1,0,0,0,'','','','','','','','','中国','北京省','海淀市','','','','','','','','','','','','','','','','','',''),(3,6,'','f8c68a2664c1f081904d3f6c041e7d7f@we7.cc','d24f2bfff6b18d8438822411b9e2666b','FuPX1Pf1',6,'0.00','9999999.00','0.00','0.00','0.00','0.00',1504164620,'','冯颖','http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTL2Y9PUbicZcT9I8B9vDsNZGxsHCOticXbYJhdGuvZ7TPVOewFzbafn9PRia15IA2qkdq30LqJtqGjOQ/132','',0,2,0,0,0,'','','','','','','','','中国','北京省','市','','','','','','','','','','','','','','','','','',''),(4,6,'','32d5d7e043080b83737937497b1b1a91@we7.cc','d24f2bfff6b18d8438822411b9e2666b','QH7AXZrT',6,'0.00','0.00','0.00','0.00','0.00','0.00',1504520103,'','中治律所闵瀚霖','http://wx.qlogo.cn/mmopen/vi_32/DYAIOgq83eoC9bePPELuxhogB4cSh2575m3EGe8O5Uh2Nicu2mo5pMzIFMLEIgMTLose3KicYv2g1TXAEicrltuuw/132','',0,1,0,0,0,'','','','','','','','','中国','北京省','市','','','','','','','','','','','','','','','','','',''),(5,6,'','39880da131c0a19c996545479de15b83@we7.cc','d24f2bfff6b18d8438822411b9e2666b','jSbfF0Ee',6,'0.00','0.00','0.00','0.00','0.00','0.00',1504522105,'','郝叶','http://wx.qlogo.cn/mmopen/vi_32/PiajxSqBRaEJ236KCicoePibtMh3bhoxVsbWyTKhquFDxyf4uaVBlg4OofGYBNDCtBX4icCadSyxcxSq9rNUunrvicQ/132','',0,2,0,0,0,'','','','','','','','','安道尔','省','市','','','','','','','','','','','','','','','','','','');
/*!40000 ALTER TABLE `ims_mc_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mc_oauth_fans`
--

DROP TABLE IF EXISTS `ims_mc_oauth_fans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mc_oauth_fans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `oauth_openid` varchar(50) NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `openid` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_oauthopenid_acid` (`oauth_openid`,`acid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mc_oauth_fans`
--

LOCK TABLES `ims_mc_oauth_fans` WRITE;
/*!40000 ALTER TABLE `ims_mc_oauth_fans` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_mc_oauth_fans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_menu_event`
--

DROP TABLE IF EXISTS `ims_menu_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_menu_event` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `keyword` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `picmd5` varchar(32) NOT NULL,
  `openid` varchar(128) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `picmd5` (`picmd5`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_menu_event`
--

LOCK TABLES `ims_menu_event` WRITE;
/*!40000 ALTER TABLE `ims_menu_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_menu_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_mobilenumber`
--

DROP TABLE IF EXISTS `ims_mobilenumber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_mobilenumber` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(10) NOT NULL,
  `enabled` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_mobilenumber`
--

LOCK TABLES `ims_mobilenumber` WRITE;
/*!40000 ALTER TABLE `ims_mobilenumber` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_mobilenumber` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_modules`
--

DROP TABLE IF EXISTS `ims_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_modules` (
  `mid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `version` varchar(15) NOT NULL,
  `ability` varchar(500) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `author` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `settings` tinyint(1) NOT NULL,
  `subscribes` varchar(500) NOT NULL,
  `handles` varchar(500) NOT NULL,
  `isrulefields` tinyint(1) NOT NULL,
  `issystem` tinyint(1) unsigned NOT NULL,
  `target` int(10) unsigned NOT NULL,
  `iscard` tinyint(3) unsigned NOT NULL,
  `permissions` varchar(5000) NOT NULL,
  `title_initial` varchar(1) NOT NULL,
  `wxapp_support` tinyint(1) NOT NULL,
  `app_support` tinyint(1) NOT NULL,
  PRIMARY KEY (`mid`),
  KEY `idx_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_modules`
--

LOCK TABLES `ims_modules` WRITE;
/*!40000 ALTER TABLE `ims_modules` DISABLE KEYS */;
INSERT INTO `ims_modules` VALUES (1,'basic','system','基本文字回复','1.0','和您进行简单对话','一问一答得简单对话. 当访客的对话语句中包含指定关键字, 或对话语句完全等于特定关键字, 或符合某些特定的格式时. 系统自动应答设定好的回复内容.','WEB7 Club','http://www.we7.cc/',0,'','',1,1,0,0,'','',1,2),(2,'news','system','基本混合图文回复','1.0','为你提供生动的图文资讯','一问一答得简单对话, 但是回复内容包括图片文字等更生动的媒体内容. 当访客的对话语句中包含指定关键字, 或对话语句完全等于特定关键字, 或符合某些特定的格式时. 系统自动应答设定好的图文回复内容.','We7 CC','http://www.we7.cc/',0,'','',1,1,0,0,'','',1,2),(3,'music','system','基本音乐回复','1.0','提供语音、音乐等音频类回复','在回复规则中可选择具有语音、音乐等音频类的回复内容，并根据用户所设置的特定关键字精准的返回给粉丝，实现一问一答得简单对话。','We7 CC','http://www.we7.cc/',0,'','',1,1,0,0,'','',1,2),(4,'userapi','system','自定义接口回复','1.1','更方便的第三方接口设置','自定义接口又称第三方接口，可以让开发者更方便的接入微信系统，高效的与微信公众平台进行对接整合。','We7 CC','http://www.we7.cc/',0,'','',1,1,0,0,'','',1,2),(5,'recharge','system','会员中心充值模块','1.0','提供会员充值功能','','We7 CC','http://www.we7.cc/',0,'','',0,1,0,0,'','',1,2),(6,'custom','system','多客服转接','1.0.0','用来接入腾讯的多客服系统','','We7 CC','http://www.we7.cc',0,'a:0:{}','a:6:{i:0;s:5:\"image\";i:1;s:5:\"voice\";i:2;s:5:\"video\";i:3;s:8:\"location\";i:4;s:4:\"link\";i:5;s:4:\"text\";}',1,1,0,0,'','',1,2),(7,'images','system','基本图片回复','1.0','提供图片回复','在回复规则中可选择具有图片的回复内容，并根据用户所设置的特定关键字精准的返回给粉丝图片。','We7 CC','http://www.we7.cc/',0,'','',1,1,0,0,'','',1,2),(8,'video','system','基本视频回复','1.0','提供图片回复','在回复规则中可选择具有视频的回复内容，并根据用户所设置的特定关键字精准的返回给粉丝视频。','We7 CC','http://www.we7.cc/',0,'','',1,1,0,0,'','',1,2),(9,'voice','system','基本语音回复','1.0','提供语音回复','在回复规则中可选择具有语音的回复内容，并根据用户所设置的特定关键字精准的返回给粉丝语音。','We7 CC','http://www.we7.cc/',0,'','',1,1,0,0,'','',1,2),(10,'chats','system','发送客服消息','1.0','公众号可以在粉丝最后发送消息的48小时内无限制发送消息','','We7 CC','http://www.we7.cc/',0,'','',0,1,0,0,'','',1,2),(11,'wxcard','system','微信卡券回复','1.0','微信卡券回复','微信卡券回复','We7 CC','http://www.we7.cc/',0,'','',1,1,0,0,'','',1,2),(12,'ewei_shopv2','business','人人店','3.5.4','人人店','人人店','weichengtech','weichengtech',0,'a:14:{i:0;s:4:\"text\";i:1;s:5:\"image\";i:2;s:5:\"voice\";i:3;s:5:\"video\";i:4;s:10:\"shortvideo\";i:5;s:8:\"location\";i:6;s:4:\"link\";i:7;s:9:\"subscribe\";i:8;s:11:\"unsubscribe\";i:9;s:2:\"qr\";i:10;s:5:\"trace\";i:11;s:5:\"click\";i:12;s:4:\"view\";i:13;s:14:\"merchant_order\";}','a:12:{i:0;s:4:\"text\";i:1;s:5:\"image\";i:2;s:5:\"voice\";i:3;s:5:\"video\";i:4;s:10:\"shortvideo\";i:5;s:8:\"location\";i:6;s:4:\"link\";i:7;s:9:\"subscribe\";i:8;s:2:\"qr\";i:9;s:5:\"trace\";i:10;s:5:\"click\";i:11;s:14:\"merchant_order\";}',0,0,0,0,'a:0:{}','R',1,2),(13,'bm_top','business','粉丝榜','1.0','粉丝榜','粉丝榜','折翼天使资源社区','www.zheyitianshi.com',0,'a:1:{i:0;s:9:\"subscribe\";}','a:1:{i:0;s:4:\"text\";}',1,0,0,0,'N;','F',1,2),(14,'stonefish_bigwheel','activity','幸运大转盘','1.6','幸运大转盘营销抽奖','幸运大转盘营销抽奖-结合商家网点模块，每个商家可送抽奖机会,分享还可以额外获得抽奖机会哟','折翼天使资源社区','http://www.zheyitianshi.com/',0,'a:0:{}','a:1:{i:0;s:4:\"text\";}',1,0,0,0,'N;','X',1,2),(15,'we7_coupon','business','系统卡券','3.8','微信卡券','微信卡券','蓝梦社区','',1,'a:0:{}','a:0:{}',0,0,0,0,'a:0:{}','X',1,2);
/*!40000 ALTER TABLE `ims_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_modules_bindings`
--

DROP TABLE IF EXISTS `ims_modules_bindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_modules_bindings` (
  `eid` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(30) NOT NULL,
  `entry` varchar(10) NOT NULL,
  `call` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `do` varchar(30) NOT NULL,
  `state` varchar(200) NOT NULL,
  `direct` int(11) NOT NULL,
  `url` varchar(100) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `displayorder` tinyint(255) unsigned NOT NULL,
  PRIMARY KEY (`eid`),
  KEY `idx_module` (`module`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_modules_bindings`
--

LOCK TABLES `ims_modules_bindings` WRITE;
/*!40000 ALTER TABLE `ims_modules_bindings` DISABLE KEYS */;
INSERT INTO `ims_modules_bindings` VALUES (1,'ewei_shopv2','cover','','商城入口','mobile','',0,'','',0),(2,'ewei_shopv2','menu','getMenus','','','',0,'','',0),(3,'stonefish_bigwheel','menu','','大转盘管理','manage','',0,'','',0),(4,'stonefish_bigwheel','home','gethome','','','',0,'','',0),(5,'we7_coupon','cover','','会员卡入口设置','card','',0,'','',0),(6,'we7_coupon','cover','','收银台入口设置','clerk','',0,'','',0),(7,'we7_coupon','menu','','会员卡设置','membercard','',0,'','',0),(8,'we7_coupon','menu','','会员卡管理','cardmanage','',0,'','',0),(9,'we7_coupon','menu','','会员属性','memberproperty','',0,'','',0),(10,'we7_coupon','menu','','优惠券管理','couponmanage','',0,'','',0),(11,'we7_coupon','menu','','优惠券核销','couponconsume','',0,'','',0),(12,'we7_coupon','menu','','优惠券派发','couponmarket','',0,'','',0),(13,'we7_coupon','menu','','兑换优惠券','couponexchange','',0,'','',0),(14,'we7_coupon','menu','','兑换真实物品','goodsexchange','',0,'','',0),(15,'we7_coupon','menu','','门店管理','storelist','',0,'','',0),(16,'we7_coupon','menu','','店员管理','clerklist','',0,'','',0),(17,'we7_coupon','menu','','门店收银台','paycenter','',0,'','',0),(18,'we7_coupon','menu','','工作台菜单设置','clerkdeskmenu','',0,'','',0),(19,'we7_coupon','menu','','签到管理','signmanage','',0,'','',0),(20,'we7_coupon','menu','','通知管理','noticemanage','',0,'','',0),(21,'we7_coupon','menu','','会员积分统计','statcredit1','',0,'','',0),(22,'we7_coupon','menu','','会员余额统计','statcredit2','',0,'','',0),(23,'we7_coupon','menu','','会员现金消费统计','statcash','',0,'','',0),(24,'we7_coupon','menu','','会员卡统计','statcard','',0,'','',0),(25,'we7_coupon','menu','','收银台收款统计','statpaycenter','',0,'','',0),(26,'we7_coupon','menu','','微信卡券回复','wxcardreply','',0,'','',0),(27,'we7_coupon','profile','','会员卡','card','',0,'','',0),(28,'we7_coupon','profile','','兑换商城','activity','',0,'','',0);
/*!40000 ALTER TABLE `ims_modules_bindings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_modules_plugin`
--

DROP TABLE IF EXISTS `ims_modules_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_modules_plugin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `main_module` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `main_module` (`main_module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_modules_plugin`
--

LOCK TABLES `ims_modules_plugin` WRITE;
/*!40000 ALTER TABLE `ims_modules_plugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_modules_plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_modules_recycle`
--

DROP TABLE IF EXISTS `ims_modules_recycle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_modules_recycle` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `modulename` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `modulename` (`modulename`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_modules_recycle`
--

LOCK TABLES `ims_modules_recycle` WRITE;
/*!40000 ALTER TABLE `ims_modules_recycle` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_modules_recycle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_music_reply`
--

DROP TABLE IF EXISTS `ims_music_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_music_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `url` varchar(300) NOT NULL,
  `hqurl` varchar(300) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_music_reply`
--

LOCK TABLES `ims_music_reply` WRITE;
/*!40000 ALTER TABLE `ims_music_reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_music_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_news_reply`
--

DROP TABLE IF EXISTS `ims_news_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_news_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `parent_id` int(10) NOT NULL,
  `title` varchar(50) NOT NULL,
  `author` varchar(64) NOT NULL,
  `description` varchar(255) NOT NULL,
  `thumb` varchar(500) NOT NULL,
  `content` mediumtext NOT NULL,
  `url` varchar(255) NOT NULL,
  `displayorder` int(10) NOT NULL,
  `incontent` tinyint(1) NOT NULL,
  `createtime` int(10) NOT NULL,
  `media_id` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_news_reply`
--

LOCK TABLES `ims_news_reply` WRITE;
/*!40000 ALTER TABLE `ims_news_reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_news_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_paycenter_order`
--

DROP TABLE IF EXISTS `ims_paycenter_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_paycenter_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `clerk_id` int(10) unsigned NOT NULL DEFAULT '0',
  `store_id` int(10) unsigned NOT NULL DEFAULT '0',
  `clerk_type` tinyint(3) unsigned NOT NULL DEFAULT '2',
  `uniontid` varchar(40) NOT NULL,
  `transaction_id` varchar(40) NOT NULL,
  `type` varchar(10) NOT NULL COMMENT '支付方式',
  `trade_type` varchar(10) NOT NULL COMMENT '支付类型:刷卡支付,扫描支付',
  `body` varchar(255) NOT NULL COMMENT '商品信息',
  `fee` varchar(15) NOT NULL COMMENT '商品费用',
  `final_fee` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '优惠后应付价格',
  `credit1` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '抵消积分',
  `credit1_fee` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '积分抵消金额',
  `credit2` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '余额支付金额',
  `cash` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '线上支付金额',
  `remark` varchar(255) NOT NULL,
  `auth_code` varchar(30) NOT NULL,
  `openid` varchar(50) NOT NULL,
  `nickname` varchar(50) NOT NULL COMMENT '付款人',
  `follow` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否关注公众号',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '线上支付状态',
  `credit_status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '积分,余额的交易状态.0:未扣除,1:已扣除',
  `paytime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '支付时间',
  `createtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_paycenter_order`
--

LOCK TABLES `ims_paycenter_order` WRITE;
/*!40000 ALTER TABLE `ims_paycenter_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_paycenter_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_profile_fields`
--

DROP TABLE IF EXISTS `ims_profile_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_profile_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field` varchar(255) NOT NULL,
  `available` tinyint(1) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `displayorder` smallint(6) NOT NULL,
  `required` tinyint(1) NOT NULL,
  `unchangeable` tinyint(1) NOT NULL,
  `showinregister` tinyint(1) NOT NULL,
  `field_length` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_profile_fields`
--

LOCK TABLES `ims_profile_fields` WRITE;
/*!40000 ALTER TABLE `ims_profile_fields` DISABLE KEYS */;
INSERT INTO `ims_profile_fields` VALUES (1,'realname',1,'真实姓名','',0,1,1,1,0),(2,'nickname',1,'昵称','',1,1,0,1,0),(3,'avatar',1,'头像','',1,0,0,0,0),(4,'qq',1,'QQ号','',0,0,0,1,0),(5,'mobile',1,'手机号码','',0,0,0,0,0),(6,'vip',1,'VIP级别','',0,0,0,0,0),(7,'gender',1,'性别','',0,0,0,0,0),(8,'birthyear',1,'出生生日','',0,0,0,0,0),(9,'constellation',1,'星座','',0,0,0,0,0),(10,'zodiac',1,'生肖','',0,0,0,0,0),(11,'telephone',1,'固定电话','',0,0,0,0,0),(12,'idcard',1,'证件号码','',0,0,0,0,0),(13,'studentid',1,'学号','',0,0,0,0,0),(14,'grade',1,'班级','',0,0,0,0,0),(15,'address',1,'邮寄地址','',0,0,0,0,0),(16,'zipcode',1,'邮编','',0,0,0,0,0),(17,'nationality',1,'国籍','',0,0,0,0,0),(18,'resideprovince',1,'居住地址','',0,0,0,0,0),(19,'graduateschool',1,'毕业学校','',0,0,0,0,0),(20,'company',1,'公司','',0,0,0,0,0),(21,'education',1,'学历','',0,0,0,0,0),(22,'occupation',1,'职业','',0,0,0,0,0),(23,'position',1,'职位','',0,0,0,0,0),(24,'revenue',1,'年收入','',0,0,0,0,0),(25,'affectivestatus',1,'情感状态','',0,0,0,0,0),(26,'lookingfor',1,' 交友目的','',0,0,0,0,0),(27,'bloodtype',1,'血型','',0,0,0,0,0),(28,'height',1,'身高','',0,0,0,0,0),(29,'weight',1,'体重','',0,0,0,0,0),(30,'alipay',1,'支付宝帐号','',0,0,0,0,0),(31,'msn',1,'MSN','',0,0,0,0,0),(32,'email',1,'电子邮箱','',0,0,0,0,0),(33,'taobao',1,'阿里旺旺','',0,0,0,0,0),(34,'site',1,'主页','',0,0,0,0,0),(35,'bio',1,'自我介绍','',0,0,0,0,0),(36,'interest',1,'兴趣爱好','',0,0,0,0,0);
/*!40000 ALTER TABLE `ims_profile_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_qrcode`
--

DROP TABLE IF EXISTS `ims_qrcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_qrcode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `type` varchar(10) NOT NULL,
  `extra` int(10) unsigned NOT NULL,
  `qrcid` bigint(20) NOT NULL,
  `scene_str` varchar(64) NOT NULL,
  `name` varchar(50) NOT NULL,
  `keyword` varchar(100) NOT NULL,
  `model` tinyint(1) unsigned NOT NULL,
  `ticket` varchar(250) NOT NULL,
  `url` varchar(256) NOT NULL,
  `expire` int(10) unsigned NOT NULL,
  `subnum` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qrcid` (`qrcid`),
  KEY `uniacid` (`uniacid`),
  KEY `ticket` (`ticket`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_qrcode`
--

LOCK TABLES `ims_qrcode` WRITE;
/*!40000 ALTER TABLE `ims_qrcode` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_qrcode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_qrcode_stat`
--

DROP TABLE IF EXISTS `ims_qrcode_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_qrcode_stat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `qid` int(10) unsigned NOT NULL,
  `openid` varchar(50) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `qrcid` bigint(20) unsigned NOT NULL,
  `scene_str` varchar(64) NOT NULL,
  `name` varchar(50) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_qrcode_stat`
--

LOCK TABLES `ims_qrcode_stat` WRITE;
/*!40000 ALTER TABLE `ims_qrcode_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_qrcode_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_rule`
--

DROP TABLE IF EXISTS `ims_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  `displayorder` int(10) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  `containtype` varchar(100) NOT NULL,
  `reply_type` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_rule`
--

LOCK TABLES `ims_rule` WRITE;
/*!40000 ALTER TABLE `ims_rule` DISABLE KEYS */;
INSERT INTO `ims_rule` VALUES (1,0,'城市天气','userapi',255,1,'',0),(2,0,'百度百科','userapi',255,1,'',0),(3,0,'即时翻译','userapi',255,1,'',0),(4,0,'今日老黄历','userapi',255,1,'',0),(5,0,'看新闻','userapi',255,1,'',0),(6,0,'快递查询','userapi',255,1,'',0),(7,1,'个人中心入口设置','cover',0,1,'',0),(8,1,'微信系统入口设置','cover',0,1,'',0),(9,6,'ewei_shopv2:diypage:19','ewei_shopv2',0,1,'',0);
/*!40000 ALTER TABLE `ims_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_rule_keyword`
--

DROP TABLE IF EXISTS `ims_rule_keyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_rule_keyword` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `uniacid` int(10) unsigned NOT NULL,
  `module` varchar(50) NOT NULL,
  `content` varchar(255) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_content` (`content`),
  KEY `rid` (`rid`),
  KEY `idx_rid` (`rid`),
  KEY `idx_uniacid_type_content` (`uniacid`,`type`,`content`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_rule_keyword`
--

LOCK TABLES `ims_rule_keyword` WRITE;
/*!40000 ALTER TABLE `ims_rule_keyword` DISABLE KEYS */;
INSERT INTO `ims_rule_keyword` VALUES (1,1,0,'userapi','^.+天气$',3,255,1),(2,2,0,'userapi','^百科.+$',3,255,1),(3,2,0,'userapi','^定义.+$',3,255,1),(4,3,0,'userapi','^@.+$',3,255,1),(5,4,0,'userapi','日历',1,255,1),(6,4,0,'userapi','万年历',1,255,1),(7,4,0,'userapi','黄历',1,255,1),(8,4,0,'userapi','几号',1,255,1),(9,5,0,'userapi','新闻',1,255,1),(10,6,0,'userapi','^(申通|圆通|中通|汇通|韵达|顺丰|EMS) *[a-z0-9]{1,}$',3,255,1),(11,7,1,'cover','个人中心',1,0,1),(12,8,1,'cover','首页',1,0,1),(13,9,6,'ewei_shopv2','首页',1,0,1);
/*!40000 ALTER TABLE `ims_rule_keyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_site_article`
--

DROP TABLE IF EXISTS `ims_site_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_site_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `rid` int(10) unsigned NOT NULL,
  `kid` int(10) unsigned NOT NULL,
  `iscommend` tinyint(1) NOT NULL,
  `ishot` tinyint(1) unsigned NOT NULL,
  `pcate` int(10) unsigned NOT NULL,
  `ccate` int(10) unsigned NOT NULL,
  `template` varchar(300) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `incontent` tinyint(1) NOT NULL,
  `source` varchar(255) NOT NULL,
  `author` varchar(50) NOT NULL,
  `displayorder` int(10) unsigned NOT NULL,
  `linkurl` varchar(500) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `edittime` int(10) NOT NULL,
  `click` int(10) unsigned NOT NULL,
  `type` varchar(10) NOT NULL,
  `credit` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_iscommend` (`iscommend`),
  KEY `idx_ishot` (`ishot`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_site_article`
--

LOCK TABLES `ims_site_article` WRITE;
/*!40000 ALTER TABLE `ims_site_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_site_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_site_category`
--

DROP TABLE IF EXISTS `ims_site_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_site_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `nid` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `parentid` int(10) unsigned NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  `enabled` tinyint(1) unsigned NOT NULL,
  `icon` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `styleid` int(10) unsigned NOT NULL,
  `linkurl` varchar(500) NOT NULL,
  `ishomepage` tinyint(1) NOT NULL,
  `icontype` tinyint(1) unsigned NOT NULL,
  `css` varchar(500) NOT NULL,
  `multiid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_site_category`
--

LOCK TABLES `ims_site_category` WRITE;
/*!40000 ALTER TABLE `ims_site_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_site_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_site_multi`
--

DROP TABLE IF EXISTS `ims_site_multi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_site_multi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `title` varchar(30) NOT NULL,
  `styleid` int(10) unsigned NOT NULL,
  `site_info` text NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `bindhost` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `bindhost` (`bindhost`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_site_multi`
--

LOCK TABLES `ims_site_multi` WRITE;
/*!40000 ALTER TABLE `ims_site_multi` DISABLE KEYS */;
INSERT INTO `ims_site_multi` VALUES (1,1,'微信',1,'',1,''),(2,2,'test',2,'',0,''),(3,3,'adjyc',3,'',0,''),(4,4,'adjyc2',4,'',0,''),(5,5,'jietest',5,'',0,''),(6,6,'adjyc',6,'',0,'');
/*!40000 ALTER TABLE `ims_site_multi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_site_nav`
--

DROP TABLE IF EXISTS `ims_site_nav`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_site_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `multiid` int(10) unsigned NOT NULL,
  `section` tinyint(4) NOT NULL,
  `module` varchar(50) NOT NULL,
  `displayorder` smallint(5) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `position` tinyint(4) NOT NULL,
  `url` varchar(255) NOT NULL,
  `icon` varchar(500) NOT NULL,
  `css` varchar(1000) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  `categoryid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `multiid` (`multiid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_site_nav`
--

LOCK TABLES `ims_site_nav` WRITE;
/*!40000 ALTER TABLE `ims_site_nav` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_site_nav` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_site_page`
--

DROP TABLE IF EXISTS `ims_site_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_site_page` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `multiid` int(10) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `params` longtext NOT NULL,
  `html` longtext NOT NULL,
  `multipage` longtext NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `goodnum` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `multiid` (`multiid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_site_page`
--

LOCK TABLES `ims_site_page` WRITE;
/*!40000 ALTER TABLE `ims_site_page` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_site_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_site_slide`
--

DROP TABLE IF EXISTS `ims_site_slide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_site_slide` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `multiid` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `displayorder` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `multiid` (`multiid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_site_slide`
--

LOCK TABLES `ims_site_slide` WRITE;
/*!40000 ALTER TABLE `ims_site_slide` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_site_slide` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_site_styles`
--

DROP TABLE IF EXISTS `ims_site_styles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_site_styles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `templateid` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_site_styles`
--

LOCK TABLES `ims_site_styles` WRITE;
/*!40000 ALTER TABLE `ims_site_styles` DISABLE KEYS */;
INSERT INTO `ims_site_styles` VALUES (1,1,1,'微站默认模板_gC5C'),(2,2,1,'微站默认模板_CDQs'),(3,3,1,'微站默认模板_rmL6'),(4,4,1,'微站默认模板_uOKT'),(5,5,1,'微站默认模板_pb7F'),(6,6,1,'微站默认模板_S6ZK');
/*!40000 ALTER TABLE `ims_site_styles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_site_styles_vars`
--

DROP TABLE IF EXISTS `ims_site_styles_vars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_site_styles_vars` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `templateid` int(10) unsigned NOT NULL,
  `styleid` int(10) unsigned NOT NULL,
  `variable` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `description` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_site_styles_vars`
--

LOCK TABLES `ims_site_styles_vars` WRITE;
/*!40000 ALTER TABLE `ims_site_styles_vars` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_site_styles_vars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_site_templates`
--

DROP TABLE IF EXISTS `ims_site_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_site_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `title` varchar(30) NOT NULL,
  `version` varchar(64) NOT NULL,
  `description` varchar(500) NOT NULL,
  `author` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `sections` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_site_templates`
--

LOCK TABLES `ims_site_templates` WRITE;
/*!40000 ALTER TABLE `ims_site_templates` DISABLE KEYS */;
INSERT INTO `ims_site_templates` VALUES (1,'default','微站默认模板','','由微信提供默认微站模板套系','微信社区','http://www.we7.cc','1',0),(2,'style1','微站模板1','','微站模板','微信','http://weixin.v-888.com','drink',0),(3,'style13','微站模板13','','微站模板','微信','http://weixin.v-888.com','realty',0),(4,'style_car','微站微汽车','','微站模板','微信','http://weixin.v-888.com','other',0),(5,'style88','微站模板88','','微站模板','微信','http://weixin.v-888.com','other',0),(6,'style10','微站模板10','','微站模板','微信','http://weixin.v-888.com','shoot',0),(7,'style100','微站模板100','','微站模板','微信','http://weixin.v-888.com','other',0),(8,'style99','微站模板99','','微站模板','微信','http://weixin.v-888.com','other',0),(9,'style102','微站模板102','','微站模板','微信','http://weixin.v-888.com','other',0),(10,'style92','微站模板92','','微站模板','微信','http://weixin.v-888.com','other',0);
/*!40000 ALTER TABLE `ims_site_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_stat_fans`
--

DROP TABLE IF EXISTS `ims_stat_fans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_stat_fans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `new` int(10) unsigned NOT NULL,
  `cancel` int(10) unsigned NOT NULL,
  `cumulate` int(10) NOT NULL,
  `date` varchar(8) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`,`date`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_stat_fans`
--

LOCK TABLES `ims_stat_fans` WRITE;
/*!40000 ALTER TABLE `ims_stat_fans` DISABLE KEYS */;
INSERT INTO `ims_stat_fans` VALUES (1,3,0,0,5,'20170829'),(2,3,0,0,5,'20170828'),(3,3,0,0,5,'20170827'),(4,3,0,0,5,'20170826'),(5,3,0,0,5,'20170825'),(6,3,0,0,5,'20170824'),(7,3,0,0,5,'20170823'),(8,5,0,0,0,'20170829'),(9,5,0,0,0,'20170828'),(10,5,0,0,0,'20170827'),(11,5,0,0,0,'20170826'),(12,5,0,0,0,'20170825'),(13,5,0,0,0,'20170824'),(14,5,0,0,0,'20170823'),(15,6,0,0,5,'20170829'),(16,6,0,0,5,'20170828'),(17,6,0,0,5,'20170827'),(18,6,0,0,5,'20170826'),(19,6,0,0,5,'20170825'),(20,6,0,0,5,'20170824'),(21,6,0,0,5,'20170823'),(22,6,0,0,5,'20170830'),(23,3,0,0,5,'20170830'),(24,6,0,0,5,'20170831'),(25,6,1,1,5,'20170901'),(26,6,0,0,5,'20170902'),(27,6,0,0,5,'20170903'),(28,6,0,0,5,'20170904');
/*!40000 ALTER TABLE `ims_stat_fans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_stat_keyword`
--

DROP TABLE IF EXISTS `ims_stat_keyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_stat_keyword` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `rid` varchar(10) NOT NULL,
  `kid` int(10) unsigned NOT NULL,
  `hit` int(10) unsigned NOT NULL,
  `lastupdate` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_createtime` (`createtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_stat_keyword`
--

LOCK TABLES `ims_stat_keyword` WRITE;
/*!40000 ALTER TABLE `ims_stat_keyword` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_stat_keyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_stat_msg_history`
--

DROP TABLE IF EXISTS `ims_stat_msg_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_stat_msg_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `rid` int(10) unsigned NOT NULL,
  `kid` int(10) unsigned NOT NULL,
  `from_user` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  `message` varchar(1000) NOT NULL,
  `type` varchar(10) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_createtime` (`createtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_stat_msg_history`
--

LOCK TABLES `ims_stat_msg_history` WRITE;
/*!40000 ALTER TABLE `ims_stat_msg_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_stat_msg_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_stat_rule`
--

DROP TABLE IF EXISTS `ims_stat_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_stat_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `rid` int(10) unsigned NOT NULL,
  `hit` int(10) unsigned NOT NULL,
  `lastupdate` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_createtime` (`createtime`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_stat_rule`
--

LOCK TABLES `ims_stat_rule` WRITE;
/*!40000 ALTER TABLE `ims_stat_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_stat_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_stonefish_bigwheel_award`
--

DROP TABLE IF EXISTS `ims_stonefish_bigwheel_award`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_stonefish_bigwheel_award` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `rid` int(11) DEFAULT '0',
  `fansID` int(11) DEFAULT '0',
  `from_user` varchar(50) DEFAULT '0' COMMENT '用户ID',
  `name` varchar(50) DEFAULT '' COMMENT '名称',
  `description` varchar(200) DEFAULT '' COMMENT '描述',
  `prizetype` varchar(10) DEFAULT '' COMMENT '类型',
  `prize` int(11) DEFAULT '0' COMMENT '奖品ID',
  `award_sn` varchar(50) DEFAULT '' COMMENT 'SN',
  `createtime` int(10) DEFAULT '0',
  `consumetime` int(10) DEFAULT '0',
  `status` tinyint(1) DEFAULT '0',
  `xuni` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `indx_rid` (`rid`),
  KEY `indx_uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_stonefish_bigwheel_award`
--

LOCK TABLES `ims_stonefish_bigwheel_award` WRITE;
/*!40000 ALTER TABLE `ims_stonefish_bigwheel_award` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_stonefish_bigwheel_award` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_stonefish_bigwheel_data`
--

DROP TABLE IF EXISTS `ims_stonefish_bigwheel_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_stonefish_bigwheel_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '规则id',
  `uniacid` int(10) unsigned NOT NULL COMMENT '公众号ID',
  `from_user` varchar(50) NOT NULL DEFAULT '' COMMENT '用户openid',
  `fromuser` varchar(50) NOT NULL DEFAULT '' COMMENT '分享人openid',
  `avatar` varchar(512) NOT NULL DEFAULT '' COMMENT '微信头像',
  `nickname` varchar(50) NOT NULL DEFAULT '' COMMENT '微信昵称',
  `visitorsip` varchar(15) NOT NULL DEFAULT '' COMMENT '访问IP',
  `visitorstime` int(10) unsigned NOT NULL COMMENT '访问时间',
  `viewnum` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '查看次数',
  PRIMARY KEY (`id`),
  KEY `indx_rid` (`rid`),
  KEY `indx_uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_stonefish_bigwheel_data`
--

LOCK TABLES `ims_stonefish_bigwheel_data` WRITE;
/*!40000 ALTER TABLE `ims_stonefish_bigwheel_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_stonefish_bigwheel_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_stonefish_bigwheel_fans`
--

DROP TABLE IF EXISTS `ims_stonefish_bigwheel_fans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_stonefish_bigwheel_fans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) DEFAULT '0',
  `uniacid` int(11) DEFAULT '0',
  `fansID` int(11) DEFAULT '0',
  `from_user` varchar(50) DEFAULT '' COMMENT '用户ID',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '微信头像',
  `nickname` varchar(50) NOT NULL DEFAULT '' COMMENT '微信昵称',
  `realname` varchar(20) NOT NULL DEFAULT '' COMMENT '真实姓名',
  `mobile` varchar(20) NOT NULL DEFAULT '' COMMENT '联系电话',
  `qq` varchar(15) NOT NULL DEFAULT '' COMMENT '联系QQ号码',
  `email` varchar(50) NOT NULL DEFAULT '' COMMENT '联系邮箱',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '联系地址',
  `gender` tinyint(1) NOT NULL DEFAULT '0' COMMENT '性别',
  `telephone` varchar(15) NOT NULL DEFAULT '' COMMENT '固定电话',
  `idcard` varchar(30) NOT NULL DEFAULT '' COMMENT '证件号码',
  `company` varchar(50) NOT NULL DEFAULT '' COMMENT '公司名称',
  `occupation` varchar(30) NOT NULL DEFAULT '' COMMENT '职业',
  `position` varchar(30) NOT NULL DEFAULT '' COMMENT '职位',
  `sharenum` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分享量',
  `sharetime` int(10) DEFAULT '0' COMMENT '最后分享时间',
  `awardingid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '兑奖地址ID',
  `todaynum` int(11) DEFAULT '0',
  `totalnum` int(11) DEFAULT '0',
  `awardnum` int(11) DEFAULT '0',
  `last_time` int(10) DEFAULT '0',
  `zhongjiang` tinyint(1) DEFAULT '0',
  `xuni` tinyint(1) DEFAULT '0',
  `createtime` int(10) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `indx_rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_stonefish_bigwheel_fans`
--

LOCK TABLES `ims_stonefish_bigwheel_fans` WRITE;
/*!40000 ALTER TABLE `ims_stonefish_bigwheel_fans` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_stonefish_bigwheel_fans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_stonefish_bigwheel_prize`
--

DROP TABLE IF EXISTS `ims_stonefish_bigwheel_prize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_stonefish_bigwheel_prize` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) NOT NULL,
  `rid` int(10) unsigned NOT NULL COMMENT '规则ID',
  `turntable` int(10) unsigned NOT NULL COMMENT '转盘类型',
  `prizetype` varchar(50) NOT NULL COMMENT '奖品类别',
  `prizename` varchar(50) NOT NULL COMMENT '奖品名称',
  `prizepro` double DEFAULT '0' COMMENT '奖品概率',
  `prizetotal` int(10) NOT NULL COMMENT '奖品数量',
  `prizedraw` int(10) NOT NULL COMMENT '中奖数量',
  `prizepic` varchar(255) NOT NULL COMMENT '奖品图片',
  `prizetxt` text NOT NULL COMMENT '奖品说明',
  `credit` int(10) NOT NULL COMMENT '积分',
  `credit_type` varchar(20) DEFAULT '' COMMENT '积分类型',
  PRIMARY KEY (`id`),
  KEY `indx_rid` (`rid`),
  KEY `indx_uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_stonefish_bigwheel_prize`
--

LOCK TABLES `ims_stonefish_bigwheel_prize` WRITE;
/*!40000 ALTER TABLE `ims_stonefish_bigwheel_prize` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_stonefish_bigwheel_prize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_stonefish_bigwheel_reply`
--

DROP TABLE IF EXISTS `ims_stonefish_bigwheel_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_stonefish_bigwheel_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned DEFAULT '0',
  `uniacid` int(11) DEFAULT '0',
  `title` varchar(50) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `start_picurl` varchar(200) DEFAULT '',
  `isshow` tinyint(1) DEFAULT '0',
  `ticket_information` varchar(200) DEFAULT '',
  `starttime` int(10) DEFAULT '0',
  `endtime` int(10) DEFAULT '0',
  `repeat_lottery_reply` varchar(50) DEFAULT '',
  `end_theme` varchar(50) DEFAULT '',
  `end_instruction` varchar(200) DEFAULT '',
  `end_picurl` varchar(200) DEFAULT '',
  `turntable` tinyint(1) DEFAULT '0',
  `turntablenum` tinyint(1) DEFAULT '6',
  `adpic` varchar(200) DEFAULT '',
  `adpicurl` varchar(200) DEFAULT '',
  `total_num` int(11) DEFAULT '0' COMMENT '总获奖人数(自动加)',
  `award_info` text NOT NULL,
  `probability` double DEFAULT '0',
  `award_times` int(11) DEFAULT '0',
  `number_times` int(11) DEFAULT '0',
  `most_num_times` int(11) DEFAULT '0',
  `credit_times` int(11) DEFAULT '0',
  `credittype` varchar(20) DEFAULT '',
  `credit_type` varchar(20) DEFAULT '',
  `credit1` int(11) DEFAULT '0',
  `credit2` int(11) DEFAULT '0',
  `sn_code` tinyint(4) DEFAULT '0',
  `sn_rename` varchar(20) DEFAULT '',
  `copyright` varchar(20) DEFAULT '',
  `show_num` tinyint(1) DEFAULT '0',
  `viewnum` int(11) DEFAULT '0' COMMENT '浏览次数',
  `awardnum` int(10) unsigned NOT NULL DEFAULT '50' COMMENT '首页滚动中奖人数显示',
  `fansnum` int(11) DEFAULT '0' COMMENT '参与人数',
  `createtime` int(10) DEFAULT '0',
  `share_acid` int(10) DEFAULT '0',
  `ticketinfo` varchar(50) DEFAULT '' COMMENT '兑奖参数提示词',
  `isrealname` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否需要输入姓名0为不需要1为需要',
  `ismobile` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否需要输入手机号0为不需要1为需要',
  `isqq` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要输入QQ号0为不需要1为需要',
  `isemail` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要输入邮箱0为不需要1为需要',
  `isaddress` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要输入地址0为不需要1为需要',
  `isgender` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要输入性别0为不需要1为需要',
  `istelephone` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要输入固定电话0为不需要1为需要',
  `isidcard` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要输入证件号码0为不需要1为需要',
  `iscompany` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要输入公司名称0为不需要1为需要',
  `isoccupation` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要输入职业0为不需要1为需要',
  `isposition` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要输入职位0为不需要1为需要',
  `isfans` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '0只保存本模块下1同步更新至官方FANS表',
  `isfansname` varchar(225) NOT NULL DEFAULT '真实姓名,手机号码,QQ号,邮箱,地址,性别,固定电话,证件号码,公司名称,职业,职位' COMMENT '显示字段名称',
  `xuninum` int(10) unsigned NOT NULL DEFAULT '500' COMMENT '虚拟人数',
  `xuninumtime` int(10) unsigned NOT NULL DEFAULT '86400' COMMENT '虚拟间隔时间',
  `xuninuminitial` int(10) unsigned NOT NULL DEFAULT '10' COMMENT '虚拟随机数值1',
  `xuninumending` int(10) unsigned NOT NULL DEFAULT '100' COMMENT '虚拟随机数值2',
  `xuninum_time` int(10) unsigned NOT NULL COMMENT '虚拟更新时间',
  `homepictime` int(3) unsigned NOT NULL COMMENT '首页秒显图片显示时间',
  `homepic` varchar(225) NOT NULL COMMENT '首页秒显图片',
  `opportunity` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '抽奖次数选项 0活动设置次数1商户赠送次数',
  `opportunity_txt` text NOT NULL COMMENT '商户赠送参数说明',
  `bigwheelpic` varchar(225) NOT NULL COMMENT '转盘图',
  `bigwheelimg` varchar(225) NOT NULL COMMENT '指针图',
  `bigwheelimgan` varchar(225) NOT NULL COMMENT '九宫格按钮',
  `bigwheelimgbg` varchar(225) NOT NULL COMMENT '九宫格转动背景图',
  `prizeDeg` varchar(225) NOT NULL COMMENT '中奖角度设置',
  `lostDeg` varchar(225) NOT NULL COMMENT '未中奖角度设置',
  `showparameters` varchar(1000) NOT NULL COMMENT '显示界面参数：背景色、背景图以及文字色等',
  PRIMARY KEY (`id`),
  KEY `indx_rid` (`rid`),
  KEY `indx_uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_stonefish_bigwheel_reply`
--

LOCK TABLES `ims_stonefish_bigwheel_reply` WRITE;
/*!40000 ALTER TABLE `ims_stonefish_bigwheel_reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_stonefish_bigwheel_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_stonefish_bigwheel_share`
--

DROP TABLE IF EXISTS `ims_stonefish_bigwheel_share`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_stonefish_bigwheel_share` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `rid` int(11) DEFAULT '0',
  `acid` int(11) DEFAULT '0',
  `share_title` varchar(200) DEFAULT '',
  `share_desc` varchar(300) DEFAULT '',
  `share_url` varchar(100) DEFAULT '',
  `share_txt` text NOT NULL COMMENT '参与活动规则',
  `share_imgurl` varchar(255) NOT NULL COMMENT '分享朋友或朋友圈图',
  `share_picurl` varchar(255) NOT NULL COMMENT '分享图片按钮',
  `share_pic` varchar(255) NOT NULL COMMENT '分享弹出图片',
  `sharenumtype` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '分享赠送抽奖类型',
  `sharenum` int(11) DEFAULT '0' COMMENT '分享赠送抽奖基数',
  `sharetype` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '分享赠送类型',
  `share_confirm` varchar(200) DEFAULT '' COMMENT '分享成功提示语',
  `share_fail` varchar(200) DEFAULT '' COMMENT '分享失败提示语',
  `share_cancel` varchar(200) DEFAULT '' COMMENT '分享中途取消提示语',
  PRIMARY KEY (`id`),
  KEY `indx_rid` (`rid`),
  KEY `indx_acid` (`acid`),
  KEY `indx_uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_stonefish_bigwheel_share`
--

LOCK TABLES `ims_stonefish_bigwheel_share` WRITE;
/*!40000 ALTER TABLE `ims_stonefish_bigwheel_share` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_stonefish_bigwheel_share` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_uni_account`
--

DROP TABLE IF EXISTS `ims_uni_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_uni_account` (
  `uniacid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `groupid` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `default_acid` int(10) unsigned NOT NULL,
  `rank` int(10) DEFAULT NULL,
  `title_initial` varchar(1) NOT NULL,
  PRIMARY KEY (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_uni_account`
--

LOCK TABLES `ims_uni_account` WRITE;
/*!40000 ALTER TABLE `ims_uni_account` DISABLE KEYS */;
INSERT INTO `ims_uni_account` VALUES (1,-1,'微信','微信系统',1,NULL,'W'),(2,0,'test','test',2,1,'T'),(3,0,'adjyctest','adjyc',3,NULL,'A'),(4,0,'adjyc2','',4,NULL,'A'),(5,0,'jietest','',5,NULL,'J'),(6,0,'融惠联','adjyc',6,2,'A');
/*!40000 ALTER TABLE `ims_uni_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_uni_account_group`
--

DROP TABLE IF EXISTS `ims_uni_account_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_uni_account_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `groupid` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_uni_account_group`
--

LOCK TABLES `ims_uni_account_group` WRITE;
/*!40000 ALTER TABLE `ims_uni_account_group` DISABLE KEYS */;
INSERT INTO `ims_uni_account_group` VALUES (1,6,-1),(2,6,1);
/*!40000 ALTER TABLE `ims_uni_account_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_uni_account_menus`
--

DROP TABLE IF EXISTS `ims_uni_account_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_uni_account_menus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `menuid` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `title` varchar(30) NOT NULL,
  `sex` tinyint(3) unsigned NOT NULL,
  `group_id` int(10) NOT NULL,
  `client_platform_type` tinyint(3) unsigned NOT NULL,
  `area` varchar(50) NOT NULL,
  `data` text NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `isdeleted` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `menuid` (`menuid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_uni_account_menus`
--

LOCK TABLES `ims_uni_account_menus` WRITE;
/*!40000 ALTER TABLE `ims_uni_account_menus` DISABLE KEYS */;
INSERT INTO `ims_uni_account_menus` VALUES (1,6,0,1,'默认菜单_1',0,-1,0,'','YTozOntzOjY6ImJ1dHRvbiI7YToxOntpOjA7YTozOntzOjQ6Im5hbWUiO3M6Njoi5ZWG5Z+OIjtzOjQ6InR5cGUiO3M6NDoidmlldyI7czozOiJ1cmwiO3M6NTQ6Imh0dHA6Ly9zaG9wLmFkanljLmNvbS9hcHAvaW5kZXgucGhwP2k9NSZjPWVudHJ5JmVpZD0xNCI7fX1zOjk6Im1hdGNocnVsZSI7YTowOnt9czo0OiJ0eXBlIjtpOjE7fQ==',0,0,0),(2,6,0,1,'adjyc菜单',0,-1,0,'','YToyOntzOjY6ImJ1dHRvbiI7YTozOntpOjA7YTozOntzOjQ6Im5hbWUiO3M6Njoi5ZWG5Z+OIjtzOjQ6InR5cGUiO3M6NDoidmlldyI7czozOiJ1cmwiO3M6NTE6Imh0dHA6Ly93eC5hZGp5Yy5jb20vYXBwL2luZGV4LnBocD9pPTYmYz1lbnRyeSZlaWQ9MSI7fWk6MTthOjM6e3M6NDoibmFtZSI7czo2OiLpppbpobUiO3M6NDoidHlwZSI7czo0OiJ2aWV3IjtzOjM6InVybCI7czo0NToiaHR0cDovL3d4LmFkanljLmNvbS9hcHAvaW5kZXgucGhwP2k9NiZjPWhvbWUmIjt9aToyO2E6Mzp7czo0OiJuYW1lIjtzOjY6IuiQpemUgCI7czo0OiJ0eXBlIjtzOjQ6InZpZXciO3M6MzoidXJsIjtzOjIzOiJodHRwOi8vd3guYWRqeWMuY29tL2FwcCI7fX1zOjk6Im1hdGNocnVsZSI7YTowOnt9fQ==',1,1504178948,0);
/*!40000 ALTER TABLE `ims_uni_account_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_uni_account_modules`
--

DROP TABLE IF EXISTS `ims_uni_account_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_uni_account_modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `module` varchar(50) NOT NULL,
  `enabled` tinyint(1) unsigned NOT NULL,
  `settings` text NOT NULL,
  `shortcut` tinyint(1) unsigned NOT NULL,
  `displayorder` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_module` (`module`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_uni_account_modules`
--

LOCK TABLES `ims_uni_account_modules` WRITE;
/*!40000 ALTER TABLE `ims_uni_account_modules` DISABLE KEYS */;
INSERT INTO `ims_uni_account_modules` VALUES (1,1,'ewei_shopv2',1,'',0,0),(2,2,'ewei_shopv2',1,'',0,0),(3,1,'bm_top',1,'',0,0),(4,2,'bm_top',1,'',0,0),(5,1,'stonefish_bigwheel',1,'',0,0),(6,2,'stonefish_bigwheel',1,'',0,0),(7,1,'we7_coupon',1,'',0,0),(8,2,'we7_coupon',1,'',0,0),(9,3,'we7_coupon',1,'',0,0),(10,3,'stonefish_bigwheel',1,'',0,0),(11,3,'bm_top',1,'',0,0),(12,3,'ewei_shopv2',1,'',0,0),(13,4,'ewei_shopv2',1,'',0,0),(14,4,'bm_top',1,'',0,0),(15,4,'stonefish_bigwheel',1,'',0,0),(16,4,'we7_coupon',1,'',0,0),(17,5,'ewei_shopv2',1,'',0,0),(18,5,'bm_top',1,'',0,0),(19,5,'stonefish_bigwheel',1,'',0,0),(20,5,'we7_coupon',1,'',0,0),(21,6,'we7_coupon',1,'',0,0),(22,6,'stonefish_bigwheel',1,'',0,0),(23,6,'bm_top',1,'',0,0),(24,6,'ewei_shopv2',1,'',0,0);
/*!40000 ALTER TABLE `ims_uni_account_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_uni_account_users`
--

DROP TABLE IF EXISTS `ims_uni_account_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_uni_account_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `role` varchar(255) NOT NULL,
  `rank` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_memberid` (`uid`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_uni_account_users`
--

LOCK TABLES `ims_uni_account_users` WRITE;
/*!40000 ALTER TABLE `ims_uni_account_users` DISABLE KEYS */;
INSERT INTO `ims_uni_account_users` VALUES (1,3,2,'owner',0),(2,3,3,'manager',0);
/*!40000 ALTER TABLE `ims_uni_account_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_uni_group`
--

DROP TABLE IF EXISTS `ims_uni_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_uni_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `modules` varchar(15000) NOT NULL,
  `templates` varchar(5000) NOT NULL,
  `uniacid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_uni_group`
--

LOCK TABLES `ims_uni_group` WRITE;
/*!40000 ALTER TABLE `ims_uni_group` DISABLE KEYS */;
INSERT INTO `ims_uni_group` VALUES (1,'体验套餐服务','a:4:{i:0;s:11:\"ewei_shopv2\";i:1;s:6:\"bm_top\";i:2;s:18:\"stonefish_bigwheel\";i:3;s:10:\"we7_coupon\";}','a:7:{i:0;s:1:\"2\";i:1;s:1:\"3\";i:2;s:1:\"5\";i:3;s:1:\"7\";i:4;s:1:\"8\";i:5;s:1:\"9\";i:6;s:2:\"10\";}',0);
/*!40000 ALTER TABLE `ims_uni_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_uni_settings`
--

DROP TABLE IF EXISTS `ims_uni_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_uni_settings` (
  `uniacid` int(10) unsigned NOT NULL,
  `passport` varchar(200) NOT NULL,
  `oauth` varchar(100) NOT NULL,
  `jsauth_acid` int(10) unsigned NOT NULL,
  `uc` varchar(500) NOT NULL,
  `notify` varchar(2000) NOT NULL,
  `creditnames` varchar(500) NOT NULL,
  `creditbehaviors` varchar(500) NOT NULL,
  `welcome` varchar(60) NOT NULL,
  `default` varchar(60) NOT NULL,
  `default_message` varchar(2000) NOT NULL,
  `payment` varchar(2000) NOT NULL,
  `stat` varchar(300) NOT NULL,
  `default_site` int(10) unsigned DEFAULT NULL,
  `sync` tinyint(3) unsigned NOT NULL,
  `recharge` varchar(500) NOT NULL,
  `tplnotice` varchar(1000) NOT NULL,
  `grouplevel` tinyint(3) unsigned NOT NULL,
  `mcplugin` varchar(500) NOT NULL,
  `exchange_enable` tinyint(3) unsigned NOT NULL,
  `coupon_type` tinyint(3) unsigned NOT NULL,
  `menuset` text NOT NULL,
  PRIMARY KEY (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_uni_settings`
--

LOCK TABLES `ims_uni_settings` WRITE;
/*!40000 ALTER TABLE `ims_uni_settings` DISABLE KEYS */;
INSERT INTO `ims_uni_settings` VALUES (1,'a:3:{s:8:\"focusreg\";i:0;s:4:\"item\";s:5:\"email\";s:4:\"type\";s:8:\"password\";}','a:2:{s:6:\"status\";s:1:\"0\";s:7:\"account\";s:1:\"0\";}',0,'a:1:{s:6:\"status\";i:0;}','a:1:{s:3:\"sms\";a:2:{s:7:\"balance\";i:0;s:9:\"signature\";s:0:\"\";}}','a:5:{s:7:\"credit1\";a:2:{s:5:\"title\";s:6:\"积分\";s:7:\"enabled\";i:1;}s:7:\"credit2\";a:2:{s:5:\"title\";s:6:\"余额\";s:7:\"enabled\";i:1;}s:7:\"credit3\";a:2:{s:5:\"title\";s:0:\"\";s:7:\"enabled\";i:0;}s:7:\"credit4\";a:2:{s:5:\"title\";s:0:\"\";s:7:\"enabled\";i:0;}s:7:\"credit5\";a:2:{s:5:\"title\";s:0:\"\";s:7:\"enabled\";i:0;}}','a:2:{s:8:\"activity\";s:7:\"credit1\";s:8:\"currency\";s:7:\"credit2\";}','','','','a:4:{s:6:\"credit\";a:1:{s:6:\"switch\";b:0;}s:6:\"alipay\";a:4:{s:6:\"switch\";b:0;s:7:\"account\";s:0:\"\";s:7:\"partner\";s:0:\"\";s:6:\"secret\";s:0:\"\";}s:6:\"wechat\";a:5:{s:6:\"switch\";b:0;s:7:\"account\";b:0;s:7:\"signkey\";s:0:\"\";s:7:\"partner\";s:0:\"\";s:3:\"key\";s:0:\"\";}s:8:\"delivery\";a:1:{s:6:\"switch\";b:0;}}','',1,0,'','',0,'',0,0,''),(2,'','a:2:{s:7:\"account\";s:1:\"2\";s:4:\"host\";s:0:\"\";}',0,'','','a:2:{s:7:\"credit1\";a:2:{s:5:\"title\";s:6:\"积分\";s:7:\"enabled\";i:1;}s:7:\"credit2\";a:2:{s:5:\"title\";s:6:\"余额\";s:7:\"enabled\";i:1;}}','a:2:{s:8:\"activity\";s:7:\"credit1\";s:8:\"currency\";s:7:\"credit2\";}','','','','','',2,0,'','',0,'',0,0,''),(3,'','a:2:{s:7:\"account\";s:1:\"3\";s:4:\"host\";s:0:\"\";}',0,'','','a:2:{s:7:\"credit1\";a:2:{s:5:\"title\";s:6:\"积分\";s:7:\"enabled\";i:1;}s:7:\"credit2\";a:2:{s:5:\"title\";s:6:\"余额\";s:7:\"enabled\";i:1;}}','a:2:{s:8:\"activity\";s:7:\"credit1\";s:8:\"currency\";s:7:\"credit2\";}','','','','','',3,0,'','',0,'',0,0,''),(4,'','',0,'','','a:2:{s:7:\"credit1\";a:2:{s:5:\"title\";s:6:\"积分\";s:7:\"enabled\";i:1;}s:7:\"credit2\";a:2:{s:5:\"title\";s:6:\"余额\";s:7:\"enabled\";i:1;}}','a:2:{s:8:\"activity\";s:7:\"credit1\";s:8:\"currency\";s:7:\"credit2\";}','','','','','',4,0,'','',0,'',0,0,''),(5,'','a:2:{s:7:\"account\";s:1:\"6\";s:4:\"host\";s:0:\"\";}',0,'','','a:2:{s:7:\"credit1\";a:2:{s:5:\"title\";s:6:\"积分\";s:7:\"enabled\";i:1;}s:7:\"credit2\";a:2:{s:5:\"title\";s:6:\"余额\";s:7:\"enabled\";i:1;}}','a:2:{s:8:\"activity\";s:7:\"credit1\";s:8:\"currency\";s:7:\"credit2\";}','','','','a:4:{s:8:\"delivery\";a:1:{s:6:\"switch\";b:1;}s:6:\"credit\";a:1:{s:6:\"switch\";b:0;}s:6:\"wechat\";a:6:{s:6:\"switch\";s:1:\"1\";s:7:\"version\";s:1:\"2\";s:5:\"mchid\";s:10:\"1485461622\";s:6:\"apikey\";s:32:\"ab235bf8be745b7d2c268ed8723020e2\";s:7:\"account\";s:1:\"6\";s:7:\"signkey\";s:32:\"ab235bf8be745b7d2c268ed8723020e2\";}s:6:\"alipay\";a:4:{s:7:\"account\";s:6:\"666666\";s:7:\"partner\";s:8:\"88888888\";s:6:\"secret\";s:9:\"88e6dghgf\";s:6:\"switch\";b:0;}}','',5,0,'','',0,'',0,0,''),(6,'','a:2:{s:4:\"host\";s:0:\"\";s:7:\"account\";s:1:\"6\";}',0,'','','a:2:{s:7:\"credit1\";a:2:{s:5:\"title\";s:6:\"积分\";s:7:\"enabled\";i:1;}s:7:\"credit2\";a:2:{s:5:\"title\";s:6:\"余额\";s:7:\"enabled\";i:1;}}','a:2:{s:8:\"activity\";s:7:\"credit1\";s:8:\"currency\";s:7:\"credit2\";}','','','','a:4:{s:8:\"delivery\";a:1:{s:6:\"switch\";b:1;}s:6:\"credit\";a:1:{s:6:\"switch\";b:0;}s:6:\"wechat\";a:6:{s:6:\"switch\";s:1:\"1\";s:7:\"version\";s:1:\"2\";s:5:\"mchid\";s:10:\"1485461622\";s:6:\"apikey\";s:32:\"ab235bf8be745b7d2c268ed8723020e2\";s:7:\"account\";s:1:\"6\";s:7:\"signkey\";s:32:\"ab235bf8be745b7d2c268ed8723020e2\";}s:6:\"alipay\";a:4:{s:7:\"account\";s:6:\"666666\";s:7:\"partner\";s:8:\"88888888\";s:6:\"secret\";s:9:\"88e6dghgf\";s:6:\"switch\";b:0;}}','',6,1,'','',0,'',0,0,'');
/*!40000 ALTER TABLE `ims_uni_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_uni_verifycode`
--

DROP TABLE IF EXISTS `ims_uni_verifycode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_uni_verifycode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `receiver` varchar(50) NOT NULL,
  `verifycode` varchar(6) NOT NULL,
  `total` tinyint(3) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_uni_verifycode`
--

LOCK TABLES `ims_uni_verifycode` WRITE;
/*!40000 ALTER TABLE `ims_uni_verifycode` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_uni_verifycode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_userapi_cache`
--

DROP TABLE IF EXISTS `ims_userapi_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_userapi_cache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(32) NOT NULL,
  `content` text NOT NULL,
  `lastupdate` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_userapi_cache`
--

LOCK TABLES `ims_userapi_cache` WRITE;
/*!40000 ALTER TABLE `ims_userapi_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_userapi_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_userapi_reply`
--

DROP TABLE IF EXISTS `ims_userapi_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_userapi_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `description` varchar(300) NOT NULL,
  `apiurl` varchar(300) NOT NULL,
  `token` varchar(32) NOT NULL,
  `default_text` varchar(100) NOT NULL,
  `cachetime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_userapi_reply`
--

LOCK TABLES `ims_userapi_reply` WRITE;
/*!40000 ALTER TABLE `ims_userapi_reply` DISABLE KEYS */;
INSERT INTO `ims_userapi_reply` VALUES (1,1,'\"城市名+天气\", 如: \"北京天气\"','weather.php','','',0),(2,2,'\"百科+查询内容\" 或 \"定义+查询内容\", 如: \"百科姚明\", \"定义自行车\"','baike.php','','',0),(3,3,'\"@查询内容(中文或英文)\"','translate.php','','',0),(4,4,'\"日历\", \"万年历\", \"黄历\"或\"几号\"','calendar.php','','',0),(5,5,'\"新闻\"','news.php','','',0),(6,6,'\"快递+单号\", 如: \"申通1200041125\"','express.php','','',0);
/*!40000 ALTER TABLE `ims_userapi_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_users`
--

DROP TABLE IF EXISTS `ims_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `groupid` int(10) unsigned NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(200) NOT NULL,
  `salt` varchar(10) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  `joindate` int(10) unsigned NOT NULL,
  `joinip` varchar(15) NOT NULL,
  `lastvisit` int(10) unsigned NOT NULL,
  `lastip` varchar(15) NOT NULL,
  `remark` varchar(500) NOT NULL,
  `starttime` int(10) unsigned NOT NULL,
  `endtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_users`
--

LOCK TABLES `ims_users` WRITE;
/*!40000 ALTER TABLE `ims_users` DISABLE KEYS */;
INSERT INTO `ims_users` VALUES (1,0,'admin','c6ee5a382b0feb28ac2c253ad7adfaca7fe258d6','3face81b',0,0,1504112529,'',1504616018,'120.41.220.107','',0,0),(2,1,'adjyc','9f4837f038b93e31ddd9709a7b259da904daa039','d21Q6mxC',0,2,1504101505,'27.154.183.97',1504101505,'27.154.183.97','adjyc',1504101505,0),(3,1,'jieqiang','285903b559395efc15402887734d17324bea1e4d','bX34wcVJ',0,2,1504101536,'27.154.183.97',1504101536,'27.154.183.97','jieqiang',1504101536,0);
/*!40000 ALTER TABLE `ims_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_users_failed_login`
--

DROP TABLE IF EXISTS `ims_users_failed_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_users_failed_login` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) NOT NULL,
  `username` varchar(32) NOT NULL,
  `count` tinyint(1) unsigned NOT NULL,
  `lastupdate` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ip_username` (`ip`,`username`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_users_failed_login`
--

LOCK TABLES `ims_users_failed_login` WRITE;
/*!40000 ALTER TABLE `ims_users_failed_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_users_failed_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_users_group`
--

DROP TABLE IF EXISTS `ims_users_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_users_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `package` varchar(5000) NOT NULL,
  `maxaccount` int(10) unsigned NOT NULL,
  `maxsubaccount` int(10) unsigned NOT NULL,
  `timelimit` int(10) unsigned NOT NULL,
  `maxwxapp` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_users_group`
--

LOCK TABLES `ims_users_group` WRITE;
/*!40000 ALTER TABLE `ims_users_group` DISABLE KEYS */;
INSERT INTO `ims_users_group` VALUES (1,'管理员','a:2:{i:0;i:1;i:1;i:-1;}',3,0,0,3),(2,'编辑组','a:2:{i:0;i:1;i:1;i:-1;}',3,0,0,3),(3,'测试组','a:2:{i:0;i:1;i:1;i:-1;}',9,0,0,9);
/*!40000 ALTER TABLE `ims_users_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_users_invitation`
--

DROP TABLE IF EXISTS `ims_users_invitation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_users_invitation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `fromuid` int(10) unsigned NOT NULL,
  `inviteuid` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_code` (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_users_invitation`
--

LOCK TABLES `ims_users_invitation` WRITE;
/*!40000 ALTER TABLE `ims_users_invitation` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_users_invitation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_users_permission`
--

DROP TABLE IF EXISTS `ims_users_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_users_permission` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `type` varchar(30) NOT NULL,
  `permission` varchar(10000) NOT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_users_permission`
--

LOCK TABLES `ims_users_permission` WRITE;
/*!40000 ALTER TABLE `ims_users_permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_users_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_users_profile`
--

DROP TABLE IF EXISTS `ims_users_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_users_profile` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `edittime` int(10) NOT NULL,
  `realname` varchar(10) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `qq` varchar(15) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `fakeid` varchar(30) NOT NULL,
  `vip` tinyint(3) unsigned NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `birthyear` smallint(6) unsigned NOT NULL,
  `birthmonth` tinyint(3) unsigned NOT NULL,
  `birthday` tinyint(3) unsigned NOT NULL,
  `constellation` varchar(10) NOT NULL,
  `zodiac` varchar(5) NOT NULL,
  `telephone` varchar(15) NOT NULL,
  `idcard` varchar(30) NOT NULL,
  `studentid` varchar(50) NOT NULL,
  `grade` varchar(10) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zipcode` varchar(10) NOT NULL,
  `nationality` varchar(30) NOT NULL,
  `resideprovince` varchar(30) NOT NULL,
  `residecity` varchar(30) NOT NULL,
  `residedist` varchar(30) NOT NULL,
  `graduateschool` varchar(50) NOT NULL,
  `company` varchar(50) NOT NULL,
  `education` varchar(10) NOT NULL,
  `occupation` varchar(30) NOT NULL,
  `position` varchar(30) NOT NULL,
  `revenue` varchar(10) NOT NULL,
  `affectivestatus` varchar(30) NOT NULL,
  `lookingfor` varchar(255) NOT NULL,
  `bloodtype` varchar(5) NOT NULL,
  `height` varchar(5) NOT NULL,
  `weight` varchar(5) NOT NULL,
  `alipay` varchar(30) NOT NULL,
  `msn` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `taobao` varchar(30) NOT NULL,
  `site` varchar(30) NOT NULL,
  `bio` text NOT NULL,
  `interest` text NOT NULL,
  `workerid` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_users_profile`
--

LOCK TABLES `ims_users_profile` WRITE;
/*!40000 ALTER TABLE `ims_users_profile` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_users_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_video_reply`
--

DROP TABLE IF EXISTS `ims_video_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_video_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `mediaid` varchar(255) NOT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_video_reply`
--

LOCK TABLES `ims_video_reply` WRITE;
/*!40000 ALTER TABLE `ims_video_reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_video_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_voice_reply`
--

DROP TABLE IF EXISTS `ims_voice_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_voice_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `mediaid` varchar(255) NOT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_voice_reply`
--

LOCK TABLES `ims_voice_reply` WRITE;
/*!40000 ALTER TABLE `ims_voice_reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_voice_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_wechat_attachment`
--

DROP TABLE IF EXISTS `ims_wechat_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_wechat_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `attachment` varchar(255) NOT NULL,
  `media_id` varchar(255) NOT NULL,
  `width` int(10) unsigned NOT NULL,
  `height` int(10) unsigned NOT NULL,
  `type` varchar(15) NOT NULL,
  `model` varchar(25) NOT NULL,
  `tag` varchar(5000) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `media_id` (`media_id`),
  KEY `acid` (`acid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_wechat_attachment`
--

LOCK TABLES `ims_wechat_attachment` WRITE;
/*!40000 ALTER TABLE `ims_wechat_attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_wechat_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_wechat_news`
--

DROP TABLE IF EXISTS `ims_wechat_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_wechat_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned DEFAULT NULL,
  `attach_id` int(10) unsigned NOT NULL,
  `thumb_media_id` varchar(60) NOT NULL,
  `thumb_url` varchar(255) NOT NULL,
  `title` varchar(50) NOT NULL,
  `author` varchar(30) NOT NULL,
  `digest` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `content_source_url` varchar(200) NOT NULL,
  `show_cover_pic` tinyint(3) unsigned NOT NULL,
  `url` varchar(200) NOT NULL,
  `displayorder` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `attach_id` (`attach_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_wechat_news`
--

LOCK TABLES `ims_wechat_news` WRITE;
/*!40000 ALTER TABLE `ims_wechat_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_wechat_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_wxapp_versions`
--

DROP TABLE IF EXISTS `ims_wxapp_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_wxapp_versions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `multiid` int(10) unsigned NOT NULL,
  `version` varchar(10) NOT NULL,
  `description` varchar(255) NOT NULL,
  `modules` varchar(1000) NOT NULL,
  `design_method` tinyint(1) NOT NULL,
  `template` int(10) NOT NULL,
  `quickmenu` varchar(2500) NOT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `version` (`version`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_wxapp_versions`
--

LOCK TABLES `ims_wxapp_versions` WRITE;
/*!40000 ALTER TABLE `ims_wxapp_versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_wxapp_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ims_wxcard_reply`
--

DROP TABLE IF EXISTS `ims_wxcard_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ims_wxcard_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `title` varchar(30) NOT NULL,
  `card_id` varchar(50) NOT NULL,
  `cid` int(10) unsigned NOT NULL,
  `brand_name` varchar(30) NOT NULL,
  `logo_url` varchar(255) NOT NULL,
  `success` varchar(255) NOT NULL,
  `error` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ims_wxcard_reply`
--

LOCK TABLES `ims_wxcard_reply` WRITE;
/*!40000 ALTER TABLE `ims_wxcard_reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_wxcard_reply` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-09-05 21:35:05
