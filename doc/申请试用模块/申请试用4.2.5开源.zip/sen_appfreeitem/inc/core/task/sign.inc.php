<?php
global $_W,$_GPC;

//签到