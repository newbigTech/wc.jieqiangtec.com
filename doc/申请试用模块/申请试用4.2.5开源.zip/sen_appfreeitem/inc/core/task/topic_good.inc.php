<?php
global $_W,$_GPC;

//点赞