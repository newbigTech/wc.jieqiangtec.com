<?php
global $_W,$_GPC;
//发帖