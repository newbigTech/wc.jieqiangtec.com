<?php
global $_W,$_GPC;

//回帖