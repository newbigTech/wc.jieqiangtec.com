<?php
global $_W,$_GPC;

//分享