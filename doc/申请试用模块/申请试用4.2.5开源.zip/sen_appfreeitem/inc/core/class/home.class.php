<?php
//个人中心
class home{
	
	function __construct(){
		//初始化
		
	}
	
}