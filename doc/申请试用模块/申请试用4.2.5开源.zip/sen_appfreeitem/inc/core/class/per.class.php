<?php
//权限控制
class per{
	
}