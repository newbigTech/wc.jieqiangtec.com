<?php
//插件管理
class plus {
	
}