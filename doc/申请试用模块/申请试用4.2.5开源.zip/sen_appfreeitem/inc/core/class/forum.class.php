<?php
//论坛
class forum {
	
}