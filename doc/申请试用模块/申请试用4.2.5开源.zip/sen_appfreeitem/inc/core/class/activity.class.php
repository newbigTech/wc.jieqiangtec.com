<?php
//活动模块
class activity {
	
}