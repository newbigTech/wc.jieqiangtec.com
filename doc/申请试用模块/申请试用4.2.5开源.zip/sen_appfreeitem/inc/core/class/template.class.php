<?php

//模板管理
class template{}