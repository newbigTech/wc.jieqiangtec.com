<?php
defined('IN_IA') or exit('Access Denied');
class update{
	function __construct(){
		
	}
}