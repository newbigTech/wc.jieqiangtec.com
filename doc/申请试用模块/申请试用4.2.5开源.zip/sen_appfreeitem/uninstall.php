<?php
pdo_query("DROP TABLE IF EXISTS ".tablename('sen_appfreeitem_address').";");
pdo_query("DROP TABLE IF EXISTS ".tablename('sen_appfreeitem_adv').";");
pdo_query("DROP TABLE IF EXISTS ".tablename('sen_appfreeitem_cart').";");
pdo_query("DROP TABLE IF EXISTS ".tablename('sen_appfreeitem_category').";");
pdo_query("DROP TABLE IF EXISTS ".tablename('sen_appfreeitem_dispatch').";");

pdo_query("DROP TABLE IF EXISTS ".tablename('sen_appfreeitem_express').";");
pdo_query("DROP TABLE IF EXISTS ".tablename('sen_appfreeitem_feedback').";");
pdo_query("DROP TABLE IF EXISTS ".tablename('sen_appfreeitem_order').";");
pdo_query("DROP TABLE IF EXISTS ".tablename('sen_appfreeitem_project').";");
pdo_query("DROP TABLE IF EXISTS ".tablename('sen_appfreeitem_project_item').";");

pdo_query("DROP TABLE IF EXISTS ".tablename('sen_appfreeitem_rule').";");
pdo_query("DROP TABLE IF EXISTS ".tablename('sen_appfreeitem_report').";");
pdo_query("DROP TABLE IF EXISTS ".tablename('sen_appfreeitem_share').";");


